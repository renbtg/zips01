package com.tiin.databaseapi.run;

//import org.junit.jupiter.api.Test;

//@SpringBootTest
class DatabaseapiApplicationTests {

 //   @Test
    void contextLoads() {
    }

}
