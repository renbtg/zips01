package com.tiin.databaseapi.controller;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tiin.databaseapi.view.ViewBean;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RepoImageFileListReturn extends ViewBean implements Serializable {
    @Getter @Setter private Long examId;
    @Getter @Setter private String fileName;
/*
    @Getter @Setter private String objectUri;
    Do not return URI, spec seems to mention only filename
 */
    @JsonProperty("objectList")
    private @Getter @Setter List<RepoImageFile> repoImageFileList = new ArrayList<>();
}

