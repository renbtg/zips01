package com.tiin.databaseapi.controller;

import com.tiin.databaseapi.model.Diagnosis;
import com.tiin.databaseapi.model.Encounter;
import com.tiin.databaseapi.model.ExamType;
import com.tiin.databaseapi.model.Subject;
import com.tiin.databaseapi.repository.DatabaseApiRepository;
import com.tiin.databaseapi.service.RestClient;
import com.tiin.databaseapi.view.Exam;
import com.tiin.databaseapi.view.ExamImage;
import com.tiin.databaseapi.view.ExamImageListReturn;
import com.tiin.databaseapi.view.ExamListReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@RestController
@RequestMapping("database-api")
@Validated
public class DatabaseApiController {
    private static Logger logger = LoggerFactory.getLogger(DatabaseApiController.class);

    private final DatabaseApiRepository repository;
    private final RestClient restClient;

    @Value("${debugSleepSecondsInGetImageList}")
    private long debugSleepSecondsInGetImageList;

    @Value("${getImageList.maxJsonRecords}") //rbattaglia 2021Jan06 - problem with default values
    private Long maxJsonRecords;

    @Value("${getImageList.getExamIds.chunkSize}")
    private Long chunkSize;

    public DatabaseApiController(DatabaseApiRepository repository, RestClient restClient) {
        this.repository = repository;
        this.restClient = restClient;
    }

    /**
     * This entire method is intented to be used for testing handling of POST (non-get, with body) http request
     * @param myRequest
     * @return
     */
    @PostMapping("/setExample")
    @CrossOrigin(origins = {"http://localhost:3000", "http://localhost:8080"}) // rbattaglia 2020Dec27 added
    String setExample (@RequestBody String myRequest) {

        int i = ThreadLocalRandom.current().nextInt(0,100);
        i = i / 3;
        logger.debug("random, i=" + i);
        if (i % 3 == 0) {
            throw new RuntimeException("[harmless throw, bogus endpoint] DEBUG THROW CONDITION MET: ThreadLocalRandom.current().nextInt() % 2 == 0");
        }

        int pp=2;

        return "This is a raw string retval for setExamIds";
    }

    // rbattaglia 2021Jan15 - fixed one of the CORS/CrossOrigin endpoints, from port 80 to 8080
    @GetMapping("/getExamIds")
    @CrossOrigin(origins = {"http://localhost:3000", "http://localhost:8080"}) // rbattaglia 2020Dec27 added
    ExamListReturn getExamIds (
            @RequestParam(value="examStartDate", required = false) @DateTimeFormat(pattern = "MM/dd/yyyy")  Date examStartDate,
            @RequestParam(value="examEndDate", required = false) @DateTimeFormat(pattern = "MM/dd/yyyy") Date examEndDate,
            @RequestParam(value="subjectIds", required = false) Long[] aSubjectIds,
            @RequestParam(value="diagnosisCodes", required = false) Long[] aDiagnosisCodes,
            @RequestParam(value="modalities", required = false) String[] aModalities,
            @RequestParam(value="includeEmptyDiagnoses", required = false) Boolean includeEmptyDiagnoses,
            @RequestParam(value="includeEmptyModalities", required = false) Boolean includeEmptyModalities) {

        List<Long> subjectIds =
                (aSubjectIds != null && aSubjectIds.length > 0) ? Arrays.asList(aSubjectIds) : null;
        List<Long> diagnosisCodes =
                (aDiagnosisCodes != null && aDiagnosisCodes.length > 0) ? Arrays.asList(aDiagnosisCodes) : null;
        List<String> modalities =
                (aModalities != null && aModalities.length > 0) ? Arrays.asList(aModalities) : null;

        if (examStartDate == null) {
            examStartDate = new Date(0);
        }
        Calendar cal = Calendar.getInstance();
        if (examEndDate == null) {
            cal.set(3000, Calendar.DECEMBER, 31);
        } else {
            cal.setTime(examEndDate);
            cal.add(Calendar.DATE, 1);
        }
        examEndDate = cal.getTime();

        var eecList =
                repository.findExamsByDateSubjectDiagnosis(
                        examStartDate, examEndDate, subjectIds, diagnosisCodes, modalities,
                        includeEmptyDiagnoses, includeEmptyModalities
                        // NOTE: don't try to limit database result set, because maybe
                        // some (or many) of the examIds don't have image file in REPO database
                );
        List<Exam> examList = new ArrayList<>();

        for (var eec: eecList) {
            // non-trivial assignments, single objects in containers, due to oneToMany relationships
            // that allowed single SQL query join to be performed.
            // TODO - research ways to do single SQL join-query without distorting JPA entity model

            var exam = new Exam();
            Encounter enc;
            Subject sub;
            ExamType examType;

            exam.setExamId(eec.getEncounterExamTypeId());
            if (! eec.getEncounterList().isEmpty()) {
                enc = (Encounter) eec.getEncounterList().toArray()[0];
                exam.setSubjectId(enc.getSubjectId());
                exam.setExamDate(enc.getStartDate());
                if (! enc.getSubjectList().isEmpty()) {
                    sub = (Subject) enc.getSubjectList().toArray()[0];
                    exam.setPrimaryDiagnosisCode(sub.getPrimaryDiagnosisCode());
                    exam.setSecondaryDiagnosisCode(sub.getSecondaryDiagnosisCode());
                    exam.setOtherDiagnosisCode(sub.getOtherDiagnosisCode());
                    exam.setSecondaryDiagnosisCode(sub.getSecondaryDiagnosisCode());
                    exam.setOtherDiagnosisCode(sub.getOtherDiagnosisCode());
                    exam.setSubjectDescription(sub.getSubjectDescription());
                    // TODO - fix query so diagnonis lists/sets containing description in Subject are never null
                    if (sub.getPrimaryDiagnosisList() != null && ! sub.getPrimaryDiagnosisList().isEmpty()) {
                        exam.setPrimaryDiagnosisDescription(
                                ((Diagnosis) sub.getPrimaryDiagnosisList().toArray()[0]).getShortDescription());
                    }
                    if (sub.getSecondaryDiagnosisList() != null && ! sub.getSecondaryDiagnosisList().isEmpty()) {
                        exam.setSecondaryDiagnosisDescription(
                                ((Diagnosis) sub.getSecondaryDiagnosisList().toArray()[0]).getShortDescription());
                    }
                    if (sub.getOtherDiagnosisList() != null && ! sub.getOtherDiagnosisList().isEmpty()) {
                        exam.setOtherDiagnosisDescription(
                                ((Diagnosis) sub.getOtherDiagnosisList().toArray()[0]).getShortDescription());
                    }
                }
            }
            if (! eec.getExamTypeList().isEmpty()) {
                examType = (ExamType) eec.getExamTypeList().toArray()[0];
                exam.setModality(examType.getExamTypeCode());
            }

            examList.add(exam);
        }
        var examListReturn = new ExamListReturn();
        examListReturn.setExamList(examList);
        return examListReturn;
    }


    @GetMapping("/getImageList")
    @CrossOrigin(origins = {"http://localhost:3000", "http://localhost:8080"}) // rbattaglia 2020Dec27 added
    ExamImageListReturn getImageList(
        @RequestParam(value="exam_start_date", required = false) @DateTimeFormat(pattern = "MM/dd/yyyy")  Date examStartDate,
        @RequestParam(value="exam_end_date", required = false) @DateTimeFormat(pattern = "MM/dd/yyyy") Date examEndDate,
        @RequestParam(value="subject_ids", required = false) Long[] aSubjectIds,
        @RequestParam(value="diagnosis_codes", required = false) Long[] aDiagnosisCodes,
        @RequestParam(value="modalities", required = false) String[] aModalities,
        @RequestParam(value="includeEmptyDiagnoses", required = false) Boolean includeEmptyDiagnoses,
        @RequestParam(value="includeEmptyModalities", required = false) Boolean includeEmptyModalities) {

        try {
            Thread.sleep(debugSleepSecondsInGetImageList * 1000);
        } catch (InterruptedException e) {
            logger.warn("Interrupted during Thread.sleep(...)");
        }

        List<Long> subjectIds =
                (aSubjectIds != null && aSubjectIds.length > 0) ? Arrays.asList(aSubjectIds) : null;
        List<Long> diagnosisCodes =
                (aDiagnosisCodes != null && aDiagnosisCodes.length > 0) ? Arrays.asList(aDiagnosisCodes) : null;
        List<String> modalities =
                (aModalities != null && aModalities.length > 0) ? Arrays.asList(aModalities) : null;

        List<Exam> examList;
        try {
            examList = restClient.getExamIds(examStartDate, examEndDate,
                    subjectIds, diagnosisCodes, modalities, includeEmptyDiagnoses, includeEmptyModalities);
        } catch (Exception e) {
            throw e; //TODO - what and how to catch? How to handle?
        }


        if (examList == null) {
            // TODO - needs better error handling, propagating message and error code.
            //  PS: we definitely want to fail for all if single REPO API fails
            throw new RuntimeException("null data when fetching examIds");
        }


        var filterValue = getFilteredExamList(examList);
        List<ExamImage> filteredExamImageList = filterValue.examImageList;
        boolean filteredExamLimited = filterValue.limited;
        var examImageListReturn = new ExamImageListReturn();
        // examListReturn.setTotalRecords((long) exa.size());
        // Can´t know what totalRecords would be, since we only make enough calls to REPO API to get maxJsonRecords
        examImageListReturn.setExamImageList(filteredExamImageList);
        examImageListReturn.setReturnedRecords(filteredExamImageList.size());
        if (filteredExamLimited) {
            examImageListReturn.setLimited(true);
            examImageListReturn.getStatusMessages().add(
                    "examList was limited to " + filteredExamImageList.size() + " records");
        }

        return examImageListReturn;
    }

    private FilterValue getFilteredExamList(List<Exam> examList) {
        List<ExamImage> filteredExamImageList = new ArrayList<>();

        boolean limited = false;
        int nofExamsFiltered = 0;
        while (filteredExamImageList.size() < maxJsonRecords && nofExamsFiltered < examList.size())  {
            List<Long> repoCallExamIdList = new ArrayList<>();
            List<Exam> processingExamList = new ArrayList<>();

            for (int x = 0; x < Math.min(chunkSize, examList.size() - nofExamsFiltered); x++) {
                // chunkSize = avoid calling RepoAPI HTtP GET with too many examIds at once
                int elt = nofExamsFiltered + x;
                repoCallExamIdList.add(examList.get(elt).getExamId());
                processingExamList.add(examList.get(elt));
            }
            List<RepoImageFile> repoImageFileList = this.callRepoImage(repoCallExamIdList);

            processingExamList = processingExamList.stream().
                    filter(exam -> repoImageFileList.stream().
                    //filter out exam without image file
                    anyMatch(imgFile -> imgFile.getExamId().longValue() == exam.getExamId().longValue()))
                    .collect(Collectors.toList());
            if (processingExamList.size() > maxJsonRecords - filteredExamImageList.size()) {
                limited = true; // defined
                processingExamList = processingExamList.stream()
                    .limit(maxJsonRecords - filteredExamImageList.size())
                    .collect(Collectors.toList());
            }
            // now, add image file names to ExamImages
            filteredExamImageList.addAll(processingExamList.stream()
                .map(exam -> {
                        ExamImage img = new ExamImage(exam);
                        img.setImageFileList(repoImageFileList.stream()
                            .filter(repoImg -> repoImg.getExamId().longValue() == exam.getExamId().longValue())
                            .map(RepoImageFile::getFileName)
                            .collect(Collectors.toList()));
                        return img;
                    })
                .collect(Collectors.toList()));

            nofExamsFiltered += repoCallExamIdList.size();
        }

        var filterValue = new FilterValue();
        filterValue.limited = limited;
        filterValue.examImageList = filteredExamImageList;
        return filterValue;
    }

    private List<RepoImageFile> callRepoImage(List<Long> repoCallExamIdList) {
        // TODO - maybe add some validation here.
        RepoImageFileListReturn retVal;

        try {
            retVal = restClient.getRepoImageFileList(repoCallExamIdList);
        } catch (Exception e) {
            throw e; //TODO - what and how to catch? How to handle?
        }
        if (retVal == null) {
            // Should not ever get here
            throw new RuntimeException("Error in call to REPO API, retVal null in call to restClient.getRepoImageFileList(...)");
        }
        return retVal.getRepoImageFileList();
    }

    private static class FilterValue {
        boolean limited;
        List<ExamImage> examImageList;
    }
}
