package com.tiin.databaseapi.view;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ViewBean implements Serializable {
    @Getter @Setter private List<String> statusMessages = new ArrayList<>();
}

