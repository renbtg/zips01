package com.tiin.databaseapi.repository;

import com.tiin.databaseapi.model.EncounterExamType;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface DatabaseApiRepository extends Repository<EncounterExamType, Long> {

    /**
     *
     * @param examStartDate start datetime, 00:00:00.000
     * @param examEndDate   end datetetime PLUS 1 DAY, 00:00:00
     * @param subjectIds
     * @param diagnosisCodes
     * @return
     */
    @Query("""
        SELECT
            eet
        FROM
            EncounterExamType eet
        INNER JOIN FETCH
            eet.examTypeList extype
        INNER JOIN FETCH
            eet.encounterList enc
        INNER JOIN FETCH
            enc.subjectList sub
        LEFT OUTER JOIN 
            sub.primaryDiagnosisList primDiag
        LEFT OUTER JOIN
            sub.secondaryDiagnosisList secDiag
        LEFT OUTER JOIN
            sub.otherDiagnosisList otherDiag
        WHERE
           (
                enc.statusId IN (1,4) AND
                    ( (cast(:exam_start_date as date) IS NULL) 
                            OR 
                    (enc.startDate >= :exam_start_date AND enc.startDate < :exam_end_date))
            )
            AND 
            ( 
                ((:subject_ids) IS NULL) OR (sub.subjectId IN (:subject_ids))
            )
            AND 
            (
                ( 
                        ( 
                            ((:diagnosis_codes) IS NULL) AND
                            (
                                (
                                    sub.primaryDiagnosisCode IS NOT NULL OR
                                    sub.secondaryDiagnosisCode IS NOT NULL OR
                                    sub.otherDiagnosisCode IS NOT NULL
                                )
                            ) 
                        )
                        OR
                        (
                            ((:diagnosis_codes) IS NOT NULL) AND 
                            (
                                (sub.primaryDiagnosisCode IN (:diagnosis_codes)) OR
                                (sub.secondaryDiagnosisCode IN (:diagnosis_codes)) OR
                                (sub.otherDiagnosisCode IN (:diagnosis_codes))
                            )
                        )
                )
                OR
                (
                        (((:include_empty_diagnoses) IS NULL) OR (:include_empty_diagnoses = true)) AND
                        (
                            sub.primaryDiagnosisCode IS NULL AND
                            sub.secondaryDiagnosisCode IS NULL AND
                            sub.otherDiagnosisCode IS NULL
                        )
                 )
            )
            AND 
            ( 
                ( ((:exam_type_codes) IS NULL) AND (extype.examTypeCode IS NOT NULL) ) 
                OR
                ( ((:exam_type_codes) IS NOT NULL) AND extype.examTypeCode IN (:exam_type_codes) )
                OR
                (
                   ( ((:include_empty_exam_type_codes) IS NULL) OR :include_empty_exam_type_codes = true) AND
                   extype.examTypeCode IS NULL
                )
            )
           """)
    List<EncounterExamType> findExamsByDateSubjectDiagnosis(
            @Param("exam_start_date") Date examStartDate,
            @Param("exam_end_date") Date examEndDate,
            @Param("subject_ids") List<Long> subjectIds,
            @Param("diagnosis_codes") List<Long> diagnosisCodes,
            @Param("exam_type_codes") List<String> examTypeCodes,
            @Param("include_empty_diagnoses") Boolean includeEmptyDiagnoses,
            @Param("include_empty_exam_type_codes") Boolean includeEmptyExamTypeCodes
    );

}
