package com.tiin.databaseapi.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Entity
public class Subject implements Serializable {
    @Id
    @Column(name = "subject_id")
    @Getter @Setter
    private Long subjectId;

    @Column(name = "dx_pri")
    @Getter @Setter
    Long primaryDiagnosisCode;

    /**
     * needs join with SQL table diagnosis to get disagnosis.
     */
    @Column(name = "dx_sec")
    @Getter @Setter
    Long secondaryDiagnosisCode;

    @Column(name = "dx_other")
    @Getter @Setter
    Long otherDiagnosisCode;

    /**
     * subject's very short description
     */
    @Column(name = "aoip_id")
    @Getter @Setter
    String subjectDescription;

    @OneToMany(fetch = FetchType.LAZY) //mapping as oneToMany to enable single query with join in Repository
    @JoinColumn(name = "dx_id", referencedColumnName = "dx_pri")
    @Getter @Setter
    private Set<Diagnosis> primaryDiagnosisList;

    @OneToMany(fetch = FetchType.LAZY) //mapping as oneToMany to enable single query with join in Repository
    @JoinColumn(name = "dx_id", referencedColumnName = "dx_sec")
    @Getter @Setter
    private Set<Diagnosis> secondaryDiagnosisList;

    @OneToMany(fetch = FetchType.LAZY) //mapping as oneToMany to enable single query with join in Repository
    @JoinColumn(name = "dx_id", referencedColumnName = "dx_other")
    @Getter @Setter
    private Set<Diagnosis> otherDiagnosisList;
}
