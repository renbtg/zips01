package com.tiin.databaseapi.service;

import com.tiin.databaseapi.controller.RepoImageFileListReturn;
import com.tiin.databaseapi.view.Exam;
import com.tiin.databaseapi.view.ExamListReturn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RestClient {
    private static Logger logger = LoggerFactory.getLogger(RestClient.class);

    private final RestTemplate restTemplate;

    @Value("${repoApi.getImageList.serverAndPort}")
    private String repoImageListServerAndPort;
    @Value("${repoApi.getImageList.methodEndpoint}")
    private String repoImageListMethodEndpoint;
    @Value("${repoApi.getImageList.parameter.name.examIds}")
    private String repoImageListParamExamIds;

    @Value("${databaseApi.getExmIds.serverAndPort}")
    private String dbExamIdsServerAndPort;
    @Value("${databaseApi.getExamIds.methodEndpoint}")
    private String dbExamIdsMethodEndpoint;
    @Value("${databaseApi.getExamIds.parameter.name.startDate}")
    private String dbExamIdsParamStartDate;
    @Value("${databaseApi.getExamIds.parameter.name.endDate}")
    private String dbExamIdsParamEndDate;
    @Value("${databaseApi.getExamIds.parameter.name.subjectIds}")
    private String dbExamIdsSubjectIds;
    @Value("${databaseApi.getExamIds.parameter.name.diagnosisCodes}")
    private String dbExamIdsDiagnosisCodes;
    @Value("${databaseApi.getExamIds.parameter.name.modalities}")
    private String dbExamIdsModalities;
    @Value("${databaseApi.getExamIds.parameter.name.includeEmptyDiagnoses}")
    private String dbExamIdsIncludeEmptyDiagnoses;
    @Value("${databaseApi.getExamIds.parameter.name.includeEmptyModalities}")
    private String dbExamIdsIncludeEmptyModalities;

    public RestClient(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder.build();
    }


    public RepoImageFileListReturn getRepoImageFileList(List<Long> examIdList) {
        String url = getEndpointUrl(repoImageListServerAndPort, repoImageListMethodEndpoint);

        String commaSeparated = examIdList.stream().map(Object::toString).collect(Collectors.joining(","));
        url = url + "?" + repoImageListParamExamIds + "=" + commaSeparated;

        ResponseEntity<RepoImageFileListReturn> response = null;
        try {
            response = this.restTemplate.getForEntity(url, RepoImageFileListReturn.class);
        } catch (Exception e) {
            throw e;
        }

        //TODO NOW NECESSARY - complete endpoint (including last piece/method) must be in .properties
        //TODO - enhance error handling, with throw(SomeException) containing body error?
        //TODO - maybe lower level abstraction needs to be used, so we get lower level raw body?
        //TODO - maybe JSON returned by REPO API can have err/status/whatever field, maybe just 1 status row?

        if (response.getStatusCode() == HttpStatus.OK) {
            var body = response.getBody();
            return body;
        } else {
            logger.error("Error calling REPO API to get examIds");
            return null;
        }
    }


    public List<Exam> getExamIds(
            Date examStartDate,
            Date examEndDate,
            List<Long> subjectIds,
            List<Long> diagnosisCodes,
            List<String> modalities,
            Boolean includeEmptyDiagnoses,
            Boolean includeEmptyModalities) {
        StringBuilder url = new StringBuilder();
        url.append(getEndpointUrl(dbExamIdsServerAndPort, dbExamIdsMethodEndpoint));

        boolean firstParam = true;
        firstParam = appendGetParameter(url,  firstParam, dbExamIdsParamStartDate, examStartDate);
        firstParam = appendGetParameter(url,  firstParam, dbExamIdsParamEndDate, examEndDate);
        firstParam = appendGetParameter(url,  firstParam, dbExamIdsSubjectIds, subjectIds);
        firstParam = appendGetParameter(url,  firstParam, dbExamIdsDiagnosisCodes, diagnosisCodes);
        firstParam = appendGetParameter(url,  firstParam, dbExamIdsModalities, modalities);
        firstParam = appendGetParameter(url,  firstParam, dbExamIdsIncludeEmptyDiagnoses, includeEmptyDiagnoses);
        firstParam = appendGetParameter(url,  firstParam, dbExamIdsIncludeEmptyModalities, includeEmptyModalities);

        String callUri = url.toString();

        ResponseEntity<ExamListReturn> response = null;
        try {
            response = this.restTemplate.getForEntity(callUri, ExamListReturn.class);
        } catch (Exception e) {
            throw e;
        }


        //TODO NOW NECESSARY - complete endpoint (including last piece/method) must be in .properties
        //TODO - enhance error handling, with throw(SomeException) containing body error?

        if (response.getStatusCode() == HttpStatus.OK) {
            var body = response.getBody();
            return body.getExamList();
        } else {
            logger.error("Error calling Database API to get examIds");
            return null;
        }
    }

    private static String getEndpointUrl(String serverAndPort, String method) {
        return serverAndPort + "/" +
                (! method.startsWith("/") ?
                        method :
                        method.substring(1)
                );
    }

    private static boolean appendGetParameter(StringBuilder url, boolean firstParam, String name, String value) {
        if (value != null) {
            url.append((firstParam ? "?" : "&") + name + "=" + value);
            firstParam = false;
        }
        return firstParam;
    }
    private static boolean appendGetParameter(StringBuilder url, boolean firstParam, String name, List<?> value) {
        if (value != null) {
            String commaSeparated = value.stream().map(Object::toString).
                    collect(Collectors.joining(","));
            firstParam = appendGetParameter(url, firstParam, name, commaSeparated);
        }
        return firstParam;
    }
    private static boolean appendGetParameter(StringBuilder url, boolean firstParam, String name, Date value) {
        if (value != null) {
            String datePattern = "MM/dd/yyyy";
            DateFormat df = new SimpleDateFormat(datePattern);
            var strDate = df.format(value);
            firstParam = appendGetParameter(url, firstParam, name, strDate);
        }
        return firstParam;
    }

    private static boolean appendGetParameter(StringBuilder url, boolean firstParam, String name, Boolean value) {
        if (value != null) {
            firstParam = appendGetParameter(url, firstParam, name, value.toString());
        }
        return firstParam;
    }

}
