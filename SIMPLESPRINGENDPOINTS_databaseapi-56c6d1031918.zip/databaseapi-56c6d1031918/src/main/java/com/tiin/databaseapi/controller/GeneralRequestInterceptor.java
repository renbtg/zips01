package com.tiin.databaseapi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.ContentCachingRequestWrapper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class GeneralRequestInterceptor implements HandlerInterceptor {
    private static Logger logger = LoggerFactory.getLogger(GeneralRequestInterceptor.class);

    public GeneralRequestInterceptor() {
        int i = 0;
    }
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
                             Object handler) throws Exception {


        String strParameters = ControllerUtils.getHttpParametersString(request);

        logger.info("TIIN DATABASE-API HTTP REQUEST RECEIVED, method=[" + request.getMethod() + "]" +
                ", URI=[" + request.getRequestURI() + "]" +
                ", parameters=" +
                "[" + strParameters + "]"
        );

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
                                @Nullable Exception ex) throws Exception {
        logger.info("TIIN DATABASE-API HTTP RESPONSE SENT: status=[" + response.getStatus() + "]");
    }

}
