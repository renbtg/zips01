package com.tiin.databaseapi.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Set;

@Entity
public class Encounter implements Serializable {
    @Id
    @Column(name = "encounter_id")
    @Getter @Setter
    private Long encounterId;

    @Column(name = "encounter_start_date")
    @Getter @Setter
    private Date startDate;

    @Column(name="encounter_status_id")
    @Getter @Setter
    private Long statusId;

    @Column(name = "subject_id")
    @Getter @Setter
    private long subjectId;

    @OneToMany(fetch = FetchType.LAZY) //mapping as oneToMany to enable single query with join in Repository
    @JoinColumn(name = "subject_id", referencedColumnName = "subject_id")
    @Getter @Setter
    private Set<Subject> subjectList;
}
