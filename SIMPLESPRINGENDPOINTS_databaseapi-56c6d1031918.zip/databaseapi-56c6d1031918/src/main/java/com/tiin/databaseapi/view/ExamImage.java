package com.tiin.databaseapi.view;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

public class ExamImage extends Exam implements Serializable  {
    @Getter @Setter List<String> imageFileList;

    public ExamImage(Exam exam) {
        super(exam);
    }
}
