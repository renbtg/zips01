package com.tiin.databaseapi.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Entity
@Table(name="encounter_exam_type")
public class EncounterExamType implements Serializable {
    @Id
    @Column(name = "encounter_exam_type_id")
    @Getter @Setter
    private Long encounterExamTypeId;

    @Column(name="encounter_id")
    @Getter @Setter
    private Long encounterId;

    @OneToMany(fetch = FetchType.LAZY) //mapping as oneToMany to enable single query with join in Repository
    @JoinColumn(name = "encounter_id", referencedColumnName = "encounter_id")
    @Getter @Setter
    private Set<Encounter> encounterList;

    @Column(name="exam_type_id")
    @Getter @Setter
    private Long examTypeId;

    @OneToMany(fetch = FetchType.LAZY) //mapping as oneToMany to enable single query with join in Repository
    @JoinColumn(name = "exam_type_id", referencedColumnName = "exam_type_id")
    @Getter @Setter
    private Set<ExamType> examTypeList;

}
