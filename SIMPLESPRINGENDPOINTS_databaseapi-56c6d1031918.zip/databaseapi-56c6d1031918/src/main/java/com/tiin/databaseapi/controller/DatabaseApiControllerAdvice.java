package com.tiin.databaseapi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@EnableWebMvc
@ControllerAdvice
public class DatabaseApiControllerAdvice {
    private static Logger logger = LoggerFactory.getLogger(DatabaseApiControllerAdvice.class);


    @ExceptionHandler({ MethodArgumentTypeMismatchException.class })
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    protected ResponseEntity<Object> processException(MethodArgumentTypeMismatchException ex) {


        var sb = new StringBuilder();
        sb.append("database-api: Invalid parameter, name=[");
        sb.append(ex.getName());
        sb.append("] with value=[");
        sb.append((ex.getValue() == null) ? "" : ex.getValue().toString());
        sb.append("], expected parameter type=[");
        sb.append(ex.getParameter() .getGenericParameterType().toString());
        sb.append("]");

        return new ResponseEntity<>(sb.toString(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler({ MissingServletRequestParameterException.class })
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    protected ResponseEntity<Object> processException(MissingServletRequestParameterException ex) {

        var sb = new StringBuilder();
        sb.append("database-api: Missing parameter, name=[");
        sb.append(ex.getParameterName());
        sb.append("], expected parameter type=[");
        sb.append(ex.getParameterType());
        sb.append("]");

        return new ResponseEntity<>(sb.toString(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler({ Exception.class })
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    protected ResponseEntity<Object> processException(Exception ex) {

        var sb = new StringBuilder();
        sb.append("database-api: Exception processing request, message=[");
        sb.append(ex.getMessage());
        sb.append("], class=[");
        sb.append(ex.getClass().getName());
        sb.append("]");

        return new ResponseEntity<>(sb.toString(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
