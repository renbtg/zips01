package com.tiin.databaseapi.view;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

public class Exam implements Serializable {
    @Getter @Setter private Long examId;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy HH:mm:ss")
    @Getter @Setter private Date examDate;
    @Getter @Setter private Long subjectId;
    @Getter @Setter private String subjectDescription;
    @Getter @Setter private Long primaryDiagnosisCode;
    @Getter @Setter private String primaryDiagnosisDescription;
    @Getter @Setter private Long secondaryDiagnosisCode;
    @Getter @Setter private String secondaryDiagnosisDescription;
    @Getter @Setter private Long otherDiagnosisCode;
    @Getter @Setter private String otherDiagnosisDescription;
    @Getter @Setter private String modality;

    public Exam() {
    }

    public Exam(Long examId, Date examDate, Long subjectId,
                Long primaryDiagnosisCode, String primaryDiagnosisDescription,
                Long secondaryDiagnosisCode, String secondaryDiagnosisDescription,
                Long otherDiagnosisCode, String otherDiagnosisDescription,
                String modality) {
        this.examId = examId;
        this.examDate = examDate;
        this.subjectId = subjectId;
        this.primaryDiagnosisCode = primaryDiagnosisCode;
        this.primaryDiagnosisDescription = primaryDiagnosisDescription;
        this.secondaryDiagnosisCode = secondaryDiagnosisCode;
        this.secondaryDiagnosisDescription = secondaryDiagnosisDescription;
        this.otherDiagnosisCode = otherDiagnosisCode;
        this.otherDiagnosisDescription = otherDiagnosisDescription;
        this.modality = modality;
    }

    public Exam(Exam exam) {
        this.examId = exam.examId;
        this.examDate = exam.examDate;
        this.subjectId = exam.subjectId;
        this.subjectDescription = exam.subjectDescription;
        this.primaryDiagnosisCode = exam.primaryDiagnosisCode;
        this.primaryDiagnosisDescription = exam.primaryDiagnosisDescription;
        this.secondaryDiagnosisCode = exam.secondaryDiagnosisCode;
        this.secondaryDiagnosisDescription = exam.secondaryDiagnosisDescription;
        this.otherDiagnosisCode = exam.otherDiagnosisCode;
        this.otherDiagnosisDescription = exam.otherDiagnosisDescription;
        this.modality = exam.modality;
    }

}
