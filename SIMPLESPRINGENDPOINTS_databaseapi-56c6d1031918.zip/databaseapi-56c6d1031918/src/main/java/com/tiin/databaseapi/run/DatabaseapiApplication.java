package com.tiin.databaseapi.run;

import com.tiin.databaseapi.controller.DatabaseApiController;
import com.tiin.databaseapi.controller.GeneralMVCConfig;
import com.tiin.databaseapi.controller.GeneralRequestInterceptor;
import com.tiin.databaseapi.service.RestClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SpringBootApplication
@ComponentScan(basePackageClasses = DatabaseApiController.class)
@ComponentScan(basePackageClasses = GeneralRequestInterceptor.class)
@ComponentScan(basePackageClasses = GeneralMVCConfig.class)
@ComponentScan(basePackageClasses = RestClient.class)
@EntityScan(basePackages = {
        "com.tiin.databaseapi.model"
})
@EnableJpaRepositories(basePackages = {
        "com.tiin.databaseapi.repository"
})
public class DatabaseapiApplication {
    public static void main(String[] args) {
        // rbattaglia 2021Jan15 - removed useless comment
        SpringApplication.run(DatabaseapiApplication.class, args);
    }
}
