package com.tiin.databaseapi.view;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

public class ExamListReturn extends ViewBean implements Serializable
{
//    @Getter @Setter Long totalRecords;
// Can´t know what totalRecords would be, since we only make enough calls to REPO API to get maxJsonRecords

    @Getter @Setter List<Exam> examList;
}
