while true
	begin
		sleep 5
		puts 'dormiu'
	rescue StandardError => e
		puts "e.class=#{e.class}, excecao=#{e}"
		raise e
	end
end


