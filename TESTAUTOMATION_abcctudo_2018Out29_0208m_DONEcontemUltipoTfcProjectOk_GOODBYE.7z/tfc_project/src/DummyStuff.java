import br.com.santander.abertdigitpf.TfcMain;

public class DummyStuff {
	public static void main(String[] args) throws Throwable {
		Thread.sleep(5*1000);
		TfcMain.voltarPraTelaInicial();
	}

}
