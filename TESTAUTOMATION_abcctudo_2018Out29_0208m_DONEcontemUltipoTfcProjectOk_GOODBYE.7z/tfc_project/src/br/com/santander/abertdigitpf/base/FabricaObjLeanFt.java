package br.com.santander.abertdigitpf.base;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAlertAprovadaSucesso;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAlteracaoConta;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAprovaDevolveRejeita;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsDadosBasicosCC;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsDadosContaPessFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsProdServPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDetCartao;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDetPacServ;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDlgConsManutPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDlgInconsistDetConsManutPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfExtrato;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfHistAberConta;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfManutCadPesFisRapido;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfManutDadosBasicosComplPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfPropostaNucleo;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSaldoCC;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSolicitacaoTaloes;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSubstituiRestituiTerminal;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbccDigPfPropostaEditavel;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.HomeTFC;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.LogonTFC;

import br.com.santander.abertdigitpf.tfc.pageObjects.leantf.*;

public class FabricaObjLeanFt implements FabricaObjAbertura {

	@Override
	public AbCcDigPfDlgConsManutPesFis getAbCcDigPfDlgConsManutPesFis() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanDlgConsManutPesFis() ;
	}

	@Override
	public AbCcDigPfDlgInconsistDetConsManutPesFis getAbCcDigPfDlgInconsistDeConsManutPesFis() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanDlgInconsistDetConsManutPesFis() ;
	}

	@Override
	public AbCcDigPfManutDadosBasicosComplPesFis getAbCcDigPManutDadosBasicosComplPesFis() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanManutDadosBasicosComplPesFis() ;
	}

	@Override
	public AbCcDigPfSolicitacaoTaloes getAbCcDigPSolicitacaoTaloes() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanSolicitacaoTaloes() ;
	}

	@Override
	public AbCcDigPfSaldoCC getAbCcDigPSaldoCC() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanSaldoCC() ;
	}

	@Override
	public AbCcDigPfHistAberConta getAbCcDigPHistAberConta() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanHistAberConta() ;
	}

	/**
	 * created 2018Set07
	 * @author x140824
	 */
	@Override
	public AbccDigPfPropostaEditavel getAbCcDigPropostaEmStatusQueAprova(String statusInicialDaProposta) throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		AbccDigPfPropostaEditavel retval = null;
		if (statusInicialDaProposta.equals(ClasseGenerica.STR_PENDENTE_DE_APROVACAO_DIGITAL)) {
			retval = new AbCcLeanPropostaPendAprov();
		} else if (statusInicialDaProposta.equals(ClasseGenerica.STR_EM_APROVACAO_DIGITAL)) {
			retval = new AbCcLeanPropostaEmAprov();
		}
		return retval ;
	}

	@Override
	public AbCcDigPfAlteracaoConta getAbCcDigPAlteracaoConta() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanAlteracaoConta() ;
	}

	@Override
	public AbCcDigPfConsDadosBasicosCC getAbCcDigPConsDadosBasicosCC() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanConsDadosBasicosCC() ;
	}

	@Override
	public AbCcDigPfExtrato getAbCcDigPExtrato() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanExtrato() ;
	}

	@Override
	public HomeTFC getHomeTFC() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new LeanHomeTFC() ;
	}

	@Override
	public AbCcDigPfPropostaNucleo getAbCcDigPPropostaNucleo() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanPropostaNucleo() ;
	}

	@Override
	public AbCcDigPfConsProdServPesFis getAbCcDigPConsProdServPesFis() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanConsProdServPesFis();
	}

	@Override
	public AbCcDigPfDetPacServ getAbCcDigPDetPacServ() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanDetPacServ() ;
	}

	@Override
	public AbCcDigPfDetCartao getAbCcDigPDetCartao() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanDetCartao() ;
	}

	@Override
	public AbCcDigPfAprovaDevolveRejeita getAbCcDigPAprovaDevolveRejeita() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanAprovaDevolveRejeita() ;
	}

	@Override
	public AbCcDigPfManutCadPesFisRapido getAbCcDigPManutCadPesFisRapido() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanManutCadPesFisRapido() ;
	}

	@Override
	public AbCcDigPfAlertAprovadaSucesso getAbCcDigPAlertAprovadaSucesso() throws GeneralLeanFtException, IOException {
		return new AbCcLeanAlertAprovadaSucesso() ;
	}

	@Override
	public LogonTFC getLogonTFC() throws GeneralLeanFtException, IOException {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new LeanLogonTFC() ;
	}

	@Override
	public AbCcDigPfConsDadosContaPessFis getAbCcDigPConsDadosContaPessFis() throws Exception {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanConsDadosContaPessFis() ;
	}

	/**
	 * created 2018Out25
	 */
	@Override
	public AbCcDigPfSubstituiRestituiTerminal getAbgetCcDigPfSubstituiRestituiTerminal() throws Exception {
		TfcExcecoes.throwGeneralLeanFtExceptionIfInterrompido();
		return new AbCcLeanSubstituiRestituiTerminal();
	}

}
