package br.com.santander.abertdigitpf.base;

public class FabricaObjAberturaMgr {
	public static final char MOCK = 'M';
	public static final char LEANFT = 'L';
	
	public static FabricaObjAbertura getFactory() {
		FabricaObjAbertura factory = null;
		factory = new FabricaObjLeanFt();
		//2018Out19 - MOCK completamente removido
			
		return factory;
	}

}
