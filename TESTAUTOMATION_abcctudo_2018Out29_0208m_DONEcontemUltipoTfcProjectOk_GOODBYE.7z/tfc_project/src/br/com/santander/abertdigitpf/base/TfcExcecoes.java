package br.com.santander.abertdigitpf.base;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.suporte.DadosExecucao;

public class TfcExcecoes {

	public static Exception getExcecaoMotivoChequeRuim(String motivo) {
		return new AberDigException(String.format("Campo MotivoBloqueioTalao [%s] invalido em aba Dados Adicionais de tela BRBC241",motivo));
	}

	public static SemPropostaPendNucleoException getExcecaoTardeSemPropostaPendente() {
		return new SemPropostaPendNucleoException(
				String.format("Nao existem linhas na tabela da tela de [Abertura->Propostas Pendentes]"));
	}

	// nao existe mais SEM PROPOSTA PENDENTE CEDO, 2018Julho20
	
	public static AberDigException getExcecaoLimiteRuim(String sLimWebapp, String sLimTfc) {
		return new AberDigException(
				String.format("Campo LimiteContratado de tela TFC BRBW091 diferente do limite de WebApp Abertura de Conta Digital, TFC=%s,AberturaDigital=%s", sLimWebapp, sLimTfc));
	}

	
	/**
	 * @created 2018Julho20
	 * @return
	 */
	public static Exception getExcecaoPropostaNaoEncontrada() {
		return new AberDigException("Proposta nao foi encontrada na pesquisa de nucleo inicial");
	}

	public static Exception getExcecaoRendaRuim(String sRendaInformadaWebApp, String sRendaInformadaTfc, String sOutrasRendasWebApp, String sOutrasRendasTfc) {
		return new AberDigException(
				String.format("Colunas 'RENDA INFORMADA' e/ou 'OUTRAS RENDAS'  tela TFC BRPE082 são incompativeis com renda inferidas da WebApp Abertura de Conta Digital, TFC RENDA INFORMADA=%s,AberturaDigital=%s, TFC OUTRAS RENDAS=%s, AberturaDigital=%s", sRendaInformadaTfc, sRendaInformadaWebApp, sOutrasRendasTfc, sOutrasRendasWebApp));
		
	}

	/**
	 * Criada em 2018Out5, interrupcao precoce
	 */
	public static void throwGeneralLeanFtExceptionIfInterrompido() throws GeneralLeanFtException {
		if (DadosExecucao.getInterrompido()) {
			throw new GeneralLeanFtException("Processamento interrompido precocemente por intervenção do operador");
		}
		return;
	}

	/**
	 * criada 2018Out21 - proposta nao está pendente de aprovação digital (para retomada desabilitada)
	 * @return
	 */
	public static AberDigException getExcecaoPropostaNaoPendenteDeAprovacao(String statusInvalido) {
		return new AberDigException(
				String.format("Situação da proposta %s invalida, diferente de %s", statusInvalido, ClasseGenerica.STR_PENDENTE_DE_APROVACAO_DIGITAL));
	}
	
}
