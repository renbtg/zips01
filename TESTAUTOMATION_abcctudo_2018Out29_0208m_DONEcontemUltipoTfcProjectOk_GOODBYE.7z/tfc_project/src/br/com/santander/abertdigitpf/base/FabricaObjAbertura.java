package br.com.santander.abertdigitpf.base;

import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAlertAprovadaSucesso;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAlteracaoConta;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAprovaDevolveRejeita;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsDadosBasicosCC;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsDadosContaPessFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsProdServPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDetCartao;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDetPacServ;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDlgConsManutPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDlgInconsistDetConsManutPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfExtrato;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfHistAberConta;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfManutCadPesFisRapido;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfManutDadosBasicosComplPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfPropostaNucleo;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSaldoCC;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSolicitacaoTaloes;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSubstituiRestituiTerminal;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbccDigPfPropostaEditavel;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.HomeTFC;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.LogonTFC;

public interface FabricaObjAbertura {

	public static final String MOCK   = "MOCK";
	public static final String LEANFT = "LEANFT";
	public AbCcDigPfDlgConsManutPesFis getAbCcDigPfDlgConsManutPesFis() throws Exception;
	public AbCcDigPfDlgInconsistDetConsManutPesFis getAbCcDigPfDlgInconsistDeConsManutPesFis() throws Exception;
	public AbCcDigPfManutDadosBasicosComplPesFis getAbCcDigPManutDadosBasicosComplPesFis() throws Exception;
	public AbCcDigPfSolicitacaoTaloes getAbCcDigPSolicitacaoTaloes() throws Exception;
	public AbCcDigPfSaldoCC getAbCcDigPSaldoCC() throws Exception;
	public AbCcDigPfHistAberConta getAbCcDigPHistAberConta() throws Exception;
	public AbccDigPfPropostaEditavel getAbCcDigPropostaEmStatusQueAprova(String statusInicialDaProposta) throws Exception;
	public AbCcDigPfAlteracaoConta getAbCcDigPAlteracaoConta() throws Exception;
	public AbCcDigPfConsDadosBasicosCC getAbCcDigPConsDadosBasicosCC() throws Exception;
	public AbCcDigPfExtrato getAbCcDigPExtrato() throws Exception;
	public HomeTFC getHomeTFC() throws Exception;
	public AbCcDigPfPropostaNucleo getAbCcDigPPropostaNucleo() throws Exception;
	public AbCcDigPfConsProdServPesFis getAbCcDigPConsProdServPesFis() throws Exception;
	public AbCcDigPfDetPacServ getAbCcDigPDetPacServ() throws Exception;
	public AbCcDigPfDetCartao getAbCcDigPDetCartao() throws Exception;
	public AbCcDigPfAprovaDevolveRejeita getAbCcDigPAprovaDevolveRejeita() throws Exception;
	public AbCcDigPfManutCadPesFisRapido getAbCcDigPManutCadPesFisRapido() throws Exception;
	public AbCcDigPfAlertAprovadaSucesso getAbCcDigPAlertAprovadaSucesso() throws Exception;
	public LogonTFC getLogonTFC() throws Exception;
	public AbCcDigPfConsDadosContaPessFis getAbCcDigPConsDadosContaPessFis() throws Exception;
	public AbCcDigPfSubstituiRestituiTerminal getAbgetCcDigPfSubstituiRestituiTerminal() throws Exception; 
	
}

