package br.com.santander.abertdigitpf.base;

import java.util.Map;
import java.util.TreeMap;

public class ExecutaExclusivo {
	/**
	 * Porte do método ruby executa_exclusivo, de shared_utils.rb
	 * 
	 * @@@@ Permite que TFC divida "tempo de tela" com a parte Ruby/Web
	 * @param hash_param
	 */
	public static final int maximizar_janela_antes = 0;
	public  static final int restore_janela_depois = 1;
	public  static final int trazer_janela_para_topo_antes = 2;
	public static Map<String,Boolean> already_locked = new TreeMap<String,Boolean>();
	
/*
	public static void executa_exclusivo(Map<Integer,String> hash_param, String ctx) {
 
		// executa_exclusivo hash_params: :maximizar_janela_antes , :trazer_janela_para_topo_antes, :restore_janela_depois# executa_exclusivo hash_params: :maximizar_janela_antes , :trazer_janela_para_topo_antes, :restore_janela_depois

		if (ctx == null) ctx="LOCK_EXCLUSIVO_GUI";
		if (hash_param == null) hash_param = new TreeMap();
		
		List alwaysmax_1_useless_keys= Arrays.asList( new int[] {
				maximizar_janela_antes , 
				//2018Jan19 - :trazer_janela_para_topo_antes, 
				restore_janela_depois
		});

		List valid_hash_keys= Arrays.asList( new int[] {
				maximizar_janela_antes , 
				trazer_janela_para_topo_antes, 
				restore_janela_depois
		});
*/
			
		
/*
		#
		#
		#
		#2017Nov28 - ACELERANDO AMBIENTES ONDE run_autohk SEJA DEMORADO DEMAIS, PROIBITIVO:
		#     1) Paralelismo=1
		#     2) Vai fazer MAXIMIZA_ESTE_BROWSER logo depois de abre_janela_browser 
		#(app_lifefecycle_hooks, pelo jeito)
		#     3) Esta rotina será hackeada pra remover as CHAVES DE HASH que indiquem
		# maximizar, restaurar etc.
*/

/*		
#		if janelas_sempre_maximizadas? #se apenas 1 jan ou SEMPRE MAX
#			alwaysmax_1_useless_keys.each {|k| hash_param[k] = false}
#			# AVANÇADO em 2017Nov29 pra poder executar paralle>1 com todas janelas maximizadas
#		end
*/
		
/*
 
  		for (int key:hash_param.keySet()) {
			if (! valid_hash_keys.contains(key)) {
				throw new Exception(
					String.format(
						"executa_exclusivo - Erro - chave errada (value)=%d no hash de parametros, chaves validas=%s\n",
						key, valid_hash_keys)
				);
			}
		}

		String nomearq_lock_exclusivo_semaforo = String.format("../%s.LCK", ctx);
		
		//CmdUtis.imprimeStack(String.format("executa_exclusivo: PAUSAR.LCK(principalmente), OUTROS.LCK, write_rsi_log(aqui e em yield) e rotina_interrupcao_de_log - CUIDADO! Checar efeitos colaterais"));
		

		//#write_rsi_log :trace, "executa_exclusivo(ctx=#{ctx}): 00 = defined? #{$already_locked} = #{defined? $already_locked}"
		if (!already_locked.containsKey(ctx)) {
			CmdUtis.imprimeStack(String.format("executa_exclusivo: already_locked[%s] INDEFINIDO\n",ctx));
			already_locked.put(ctx, false);
		}
		CmdUtis.imprimeStack(String.format("executa_exclusivo(ctx=%s): 01 = already_locked %b\n", ctx, already_locked));

		boolean fez_lock_agora = false;

		if (! already_locked.get(ctx)) {
			int segundos_espera_flock = get_segundos_fila_lock_exclusivo(ctx);
			CmdUtis.imprimeStack(String.format("executa_exclusivo:  antes de tentar abrir/criar arquivo %s\n",nomearq_lock_exclusivo_semaforo));
			File rf = new File(nomearq_lock_exclusivo_semaforo);
			FileChannel f = new RandomAccessFile(file, "w").getChannel(); 
			CmdUtis.imprimeStack(String.format("executa_exclusivo:  depois de tentar abrir/criar arquivo %s\n",nomearq_lock_exclusivo_semaforo));

			try {
				CmdUtis.imprimeStack(String.format("executa_exclusivo: Esperando %d segundos por LOCK_EXCLUSIVO, arquivo=%s\n", segundos_espera_flock, nomearq_lock_exclusivo_semaforo});
				long tini = System.currentTimeMillis();
				Timeout::timeout(segundos_espera_flock, TimeoutDeLockExclusivoxception) do
					while not fez_lock_agora
						rotina_de_interrupcao_em_log

						if f.flock(File::LOCK_NB|File::LOCK_EX)
							fez_lock_agora = true
							$already_locked[ctx] = true
						end
					end
				end
			rescue TimeoutDeLockExclusivoxception => e
				falhar "executa_exclusivo:LOCK EXCLUSIVO nao obtido depois de #{segundos_espera_flock} segundos por , arquivo=#{nomearq_lock_exclusivo_semaforo}"
		#	ensure
		#		if f != nil
		#			f.flock(File::LOCK_UN)
		#		end
			end
			write_rsi_log :trace, "executa_exclusivo:SUCESSO em obter lock do arquivo de LOCK_EXCLUSIVO, arquivo=#{nomearq_lock_exclusivo_semaforo}"
		end

		x=y=largura=altura=nil
		excecao_inicial = nil
		begin
			write_rsi_log :trace, "executa_exclusivo:iniciado trecho de execucao"
			if hash_param[:restore_janela_depois]  # RIBY: 
				write_rsi_log :trace, "executa_exclusivo:vai chamar get_rectangle_este_browser pra obter x,y,w,h "
				begin
					x,y,largura,altura = get_rectangle_este_browser
				rescue Exception => e
					write_rsi_log :warn, "executa_exclusivo: erro em get_rectangle_estr_browser, excecao=#{e}"
				end
				write_rsi_log :trace, "executa_exclusivo:chamou get_rectangle_este_browser e obteve x #{x} e y #{y} e altura #{altura} e largura #{largura} da janela antes de yield "
			end
			if hash_param[:maximizar_janela_antes]  # RIBY: 
				begin
					maximiza_este_browser
				rescue Exception => e
					write_rsi_log :warn, "executa_exclusivo: erro em maximima_este_browser, excecao=#{e}"
				end
				write_rsi_log :trace, "executa_exclusivo:maximizou janela antes de yield "
			end
		
			if hash_param[:trazer_janela_para_topo_antes]  # RIBY: 
				write_rsi_log :trace, "executa_exclusivo:vai trazer janela pro topo antes de yield "
				begin
					traz_esta_janela_pra_topo
				rescue Exception => e
					write_rsi_log :warn, "executa_exclusivo: erro em traz_esta_janela_pra_topo, excecao=#{e}"
				end
				write_rsi_log :trace, "executa_exclusivo:trouxe janela pro topo antes de yield "
			end
			dormir_yield=0
			write_rsi_log :trace, "executa_exclusivo:imediatamente antes de yield, dormirah #{dormir_yield}"
			sleep dormir_yield if dormir_yield > 0
			#begin; raise 'veja stack trace'; rescue Exception =>e; write_rsi_log :trace, e.backtrace; end
			ret = yield # SEM CONTROLE DE TIMEOUT na execucao do
			write_rsi_log :debug, "executa_exclusivo:imediatamente depois de yield, dormiu #{dormir_yield}"
			sleep dormir_yield if dormir_yield > 0
		rescue Exception => e
			write_rsi_log :error, "executa_exclusivo: excecao qye relancarei obtida nas proximidades de yield, excecao=#{e}, full exception backtrace=#{e.backtrace}"
			excecao_inicial = e
			raise e
		ensure
			excecao_no_ensure = nil
			begin
				write_rsi_log :debug, "executa_exclusivo:ensure"
				if hash_param[:restore_janela_depois]  # 2017Set9 - RESIZE ANTES DE UNLOCK!!! 
					write_rsi_log :trace, "executa_exclusivo:ensure, vai restaurar size de janela"
					
					begin
						if x
							#2017Out27 - fix "nao restaurava tamanho", passando x,y,largura,altura
							seta_rectangle_este_browser x,y,largura,altura  
						end
						reorganiza_janelas_topo				
					rescue Exception => e
						write_rsi_log :warn, "executa_exclusivo: erro em seta_rectangle_este_browser ou reorganiza_janelas_topo, excecao=#{e}"
					end
					write_rsi_log :trace, "executa_exclusivo:ensure, restaurou size de janela e reorganizou topo"
				end
			rescue Exception => e
				write_rsi_log :trace, "executa_exclusivo:excecao em ensure de execua_exclusivo, excecao=#{e.inspect}"
				excecao_no_ensure = e
			end
			if fez_lock_agora #se nao entrou aqui já lockado, e tentou e conseguiu lockar
				write_rsi_log :trace, "executa_exclusivo:ensure, vai liberar lock - ( $already_locked[#{ctx}] = false + flock(File::LOCK_UN)"
				$already_locked[ctx] = false #2017Set10 am, faltava @$already_locked=false@ 
				f.flock(File::LOCK_UN)
				write_rsi_log :trace, "executa_exclusivo:ensure, liberou lock - ( $already_locked[#{ctx}] = false + flock(File::LOCK_UN)"
			end
			raise excecao_no_ensure if (excecao_no_ensure and not excecao_inicial)
		end

		write_rsi_log :debug, "executa_exclusivo:retornando, nao mostrando variavel ret aqui"
		return ret 
	}*/

	public static int get_segundos_fila_lock_exclusivo(String ctx) {
		// TODO Auto-generated method stub
		return 0;
	}
}
