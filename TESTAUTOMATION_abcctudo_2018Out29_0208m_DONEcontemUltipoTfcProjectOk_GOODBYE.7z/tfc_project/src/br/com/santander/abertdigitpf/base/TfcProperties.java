package br.com.santander.abertdigitpf.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.Properties;

import br.com.santander.abertdigitpf.TfcMain;
import br.com.santander.abertdigitpf.suporte.Logger;

public class TfcProperties {

	public static final String EXC_AINDA_NAO_PEND = "EXC_AINDA_NAO_PEND";
//	public static final String CEDO = "CEDO";
	private static final String TARDE = "TARDE";
	private static int globalScenarioCount;
	/**
	 * @since 2018Abr02 17:xx pm
	 */
	private static int iniciouCheckPropostaPendAprov = 0;
	/**
	 * @since 2018Abr02 17:xx pm
	 */
	private static int concluiuCheckPropostaPendAprov = 0;

	public static String getConfigValue(String propKey) {
		return getPropertyValue("../tfc_config.properties", propKey);
	}
	public static String getMockValue(String propKey) {
		return getPropertyValue("../tfc_mock.properties", propKey);
	}
	public static String getPropertyValue(String fname, String propKey) {
		String retval = "";

		Properties p = getProperties(fname);
		retval = p.getProperty(propKey);
		if (retval == null) {
			retval = "";
		}
		return retval;
	}
	/**
	 * isTardeExcAindaNaoPend - se nao defino CEDO ou TARDE em tfc_config.properties, farç validaçço CEDO
	 * @return
	 */
	public static boolean isCedoExcAindaNaoPend() {
		return ! getExcAindaNaoPend().equals(TARDE);
	}
	
	public static boolean isTardeExcAindaNaoPend() {
		return getExcAindaNaoPend().equals(TARDE); 
	}

	private static String getExcAindaNaoPend() {
		return getConfigValue(EXC_AINDA_NAO_PEND);
	}
	public static String getLoginValue(String propKey) {
		return getPropertyValue("../tfc_login.properties", propKey);
	}
	public static int getGlobalScenarioCount() {
		return globalScenarioCount;
	}
	public static void setGlobalScenarioCount(int cmd_numero_globalScenario) {
		globalScenarioCount = cmd_numero_globalScenario;
	}
///
	public static Properties getProperties(String fname) {
		Properties p = new Properties();
		FileInputStream fs = null;
		try {
			fs = new FileInputStream(fname);
			p.load(fs);
		} catch (IOException e) {
			Logger.imprimeStackTrace(e);
		} finally {
			if (fs != null) {
				try {
					fs.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					Logger.imprimeStackTrace(e);
				}
			}
		}
		return p;
	}
	public static void appendProperties(Properties p, Properties inputProps) {
		Enumeration<Object> en = inputProps.keys();
		while (en.hasMoreElements()) {
			String inputKey = (String) en.nextElement();
			p.setProperty(inputKey, inputProps.getProperty(inputKey));
		}
	}
	public static void saveProperties(Properties p, String propFile) throws FileNotFoundException, IOException {
		FileOutputStream fos = new FileOutputStream(new File(propFile));
		p.store(fos, "");
		fos.close();
	}
	public static Path getPathCmdOrigem() {
		return TfcProperties.getPath(TfcProperties.getCaminhoCompletoCmdOrigem());
	}
	public static String getCaminhoCompletoCmdDestino() {
		return String.format("%s/%s", TfcProperties.getDiretorioDestino(), TfcProperties.getFileNameCmdOrigem());
	}
	public static Path getPathOutOrigem() {
		return TfcProperties.getPath(TfcMain.getCaminhoCompletoOutOrigem());
	}
	public static String getCaminhoCompletoCmdOrigem() {
		return String.format("%s/%s", TfcProperties.getDirNameOrigem(), TfcProperties.getFileNameCmdOrigem());
	}
	public static String getDirNameOrigem() {
		return "../tfc_origem"; // TODO dir base da automacao.?? FIX ME
	}
	public static String getDiretorioDestino() {
		return "../tfc_destino"; // TODO dir base da automacao.?? FIX ME
	}
	public static String getFileNameCmdOrigem() {
		return "tfc_cmd.properties";
	}
	public static Path getPath(String caminho) {
		return FileSystems.getDefault().getPath(caminho);
	}
	public static Path getPathCmdDestino() {
		return getPath(getCaminhoCompletoCmdDestino());
	}
	public static void deleteProperties() throws IOException {
		Files.deleteIfExists(getPathCmdOrigem()); // overkill por poor desugn de "tfc_origem/tfc_cmd.properties nao desaparece"
		Files.deleteIfExists(getPathCmdDestino()); // overkill por poor desugn de "tfc_origem/tfc_cmd.properties nao desaparece"
		Files.deleteIfExists(getPathOutOrigem()); // overkill por poor desugn de "tfc_origem/tfc_cmd.properties nao desaparece"
	}
	public static String getImgLogonPropertiesFilePath() {
		return "../tfc_img_logon.properties";
	}
	public static int getIniciouCheckPropostaPendAprov() {
		return iniciouCheckPropostaPendAprov;
	}
	public static void setIniciouCheckPropostaPendAprov(int iniciouCheckPropostaPendAprov) {
		TfcProperties.iniciouCheckPropostaPendAprov = iniciouCheckPropostaPendAprov;
	}
	/**
	 * @since 2018Abr02 17:xx pm
	 */
	public static int getConcluiuCheckPropostaPendAprov() {
		return concluiuCheckPropostaPendAprov;
	}
	/**
	 * @since 2018Abr02 17:xx pm
	 */
	public static void setConcluiuCheckPropostaPendAprov(int concluiuCheckPropostaPendAprov) {
		TfcProperties.concluiuCheckPropostaPendAprov = concluiuCheckPropostaPendAprov;
	}
	
}
