package br.com.santander.abertdigitpf.base;

public class SemPropostaPendNucleoException extends AberDigException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3553343663935964498L;

	/**
	 * 
	 */
	public SemPropostaPendNucleoException(String message) {
		super(message);
	}

}
