package br.com.santander.abertdigitpf.base;

public class AberDigException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -824206186588277062L;

	public AberDigException(String message) {
		super(message);
	}
}
