package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.hp.lft.sdk.Description;
import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.TestObject;

import br.com.santander.abertdigitpf.base.AberDigException;
import br.com.santander.abertdigitpf.base.SemPropostaPendNucleoException;
import br.com.santander.abertdigitpf.base.TfcExcecoes;
import br.com.santander.abertdigitpf.suporte.AutoItRunner;
import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.suporte.DadosExecucao;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.suporte.TempoEspera;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsDadosContaPessFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfPropostaNucleo;
import unittesting.AberDigPropostaNucleo;
import unittesting.AberDigPropostaNucleo.TerminalFinanceiroCorporativoWindow.BRBW037ConsultaDePropostasDigitalNCleoInternalFrame.NDocumentoTable;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 */
public class AbCcLeanPropostaNucleo extends UnitTestClassBase implements AbCcDigPfPropostaNucleo {
	private List<Map<String, String>> dadosDaTabela = null;
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigPropostaNucleo janela;

	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanPropostaNucleo() throws GeneralLeanFtException, IOException {
		janela = new AberDigPropostaNucleo();
		janela.TerminalFinanceiroCorporativoWindow().BRBW037ConsultaDePropostasDigitalNCleoInternalFrame().activate();

		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"Tela Consulta de Propostas Digital Núcleo");
	}

	/**
	 * 
	 * @param numeroDoc
	 * @param abreDetalhe
	 *            - se true, significa chamada isolada: nao deve esperar antes de
	 *            pesquisar. E... quando true, causa obtencao de globais para
	 *            AGENCIA e CONTA
	 * @throws Exception
	 */
	public void efetuaPesquisa(String numeroDoc, boolean abreDetalhe, boolean isInicial) throws Exception {
		inserirNumeroDocumento(numeroDoc);
		pesquisar(abreDetalhe);
		if (isInicial) {
			// 2018Julho20
			obterStatusInicialDaProposta();
		}

		mostraColunaSituacaoNaTabela();

		if (isInicial) {
			// 2018Out21 - valida status inicial, DEPOIS de mostrar situacao na tabela
			validarStatusInicialDaProposta();
		}

		if (abreDetalhe) {
			janela.TerminalFinanceiroCorporativoWindow().BRBW037ConsultaDePropostasDigitalNCleoInternalFrame()
					.DetalheButton().click();

			AbCcDigPfConsDadosContaPessFis consDadosContaPessFis = new AbCcLeanConsDadosContaPessFis();
			String statusInicialDaProposta = DadosExecucao.getDadosFuncionalidade("STATUS_INICIAL_DA_PROPOSTA");
			if (isInicial && !statusInicialDaProposta.equals(ClasseGenerica.STR_PENDENTE_DE_APROVACAO_DIGITAL)
					&& !statusInicialDaProposta.equals("EM APROVAÇÃO DIGITAL")) {
				// 2018Set11 - corrigi, FALTAVA EVIDENCIAR pacoteServicos e Cartao para PROP JA
				// APROVADA,RETOMADA
				Logger.debug(
						"AbccLeanPropsotaNucleo::efetuaPesquisa, vai avançar precocemente, isInicial=%b,statusInicialDaProposta=%s",
						isInicial, statusInicialDaProposta);
				;

				consDadosContaPessFis.avancar();
				AbCcLeanConsProdServPesFis abCcLeanConsProdServPesFis = new AbCcLeanConsProdServPesFis();
				abCcLeanConsProdServPesFis.clickPacoteServicos();
				new AbCcLeanDetPacServ().clickFechar();
				abCcLeanConsProdServPesFis.clickCartao();
				new AbCcLeanDetCartao().clickCancelar();
				abCcLeanConsProdServPesFis.clickFechar();
			}
			consDadosContaPessFis.fechar();
		}
		fechar();
	}

	private void validarStatusInicialDaProposta() throws AberDigException {
		// 2018Out21 - validacao adicional: lançar exception se NAO PERMITE RETOMADA
		// (chamador=java TestNG single run, sem rubby)
		String statusInicialProposta = DadosExecucao.getDadosFuncionalidade("STATUS_INICIAL_DA_PROPOSTA");
		if (! statusInicialProposta.equals(ClasseGenerica.STR_PENDENTE_DE_APROVACAO_DIGITAL)) {
			if (DadosExecucao.getPropertiesDoComando().getProperty("RETOMADA_DESABILITADA", "0").equals("1")) {
				// OBS: RETOMADA_DESABILITADA é propriedade nova. Ruby nao a define e depende
				// que, se nao passada, seja FALSE/0
				throw TfcExcecoes.getExcecaoPropostaNaoPendenteDeAprovacao(statusInicialProposta);
			}
		}
	}

	private void obterStatusInicialDaProposta() throws Exception, SemPropostaPendNucleoException {
		if (getDadosDaTabela().size() == 0) {
			throw TfcExcecoes.getExcecaoPropostaNaoEncontrada();
		}
		/**
		 * Se nao estiver PENDENTE DE APTOVAÇÃO, posso mudar fluxo (retomada).
		 */
		String statusInicialProposta = getDadosDaTabela().get(0).get("Situação");
		DadosExecucao.setDadosFuncionalidade("STATUS_INICIAL_DA_PROPOSTA", statusInicialProposta);

	}

	private List<Map<String, String>> getDadosDaTabela() throws Exception {
		if (dadosDaTabela != null) {
			return dadosDaTabela;
		}
		NDocumentoTable tbl = janela.TerminalFinanceiroCorporativoWindow()
				.BRBW037ConsultaDePropostasDigitalNCleoInternalFrame().NDocumentoTable();

		dadosDaTabela = ClasseGenerica.getMapsConteudoDaTabela(tbl,
				janela.TerminalFinanceiroCorporativoWindow().BRBW037ConsultaDePropostasDigitalNCleoInternalFrame(), 90,
				"tabela de consulta nucleo");
		return dadosDaTabela;
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void inserirNumeroDocumento(String numeroDoc)
			throws GeneralLeanFtException, InterruptedException, IOException {

		janela.TerminalFinanceiroCorporativoWindow().BRBW037ConsultaDePropostasDigitalNCleoInternalFrame()
				.NDocumentoEditor().sendKeys(numeroDoc);
	}

	/**
	 * @author x140824-rbattaglia
	 * @param isInicial
	 */
	private void mostraColunaSituacaoNaTabela() throws Exception {

		/**
		 * rbattaglia 2018Set07 - usando ClasseGenerica.getMapsConteudoDaTabela(...)
		 * para obter nomes e conteudo das colunas, e entao dizer cedo o status da
		 * proposta de forma confiável
		 */

		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"mostraColunaSituacaoNaTabela, antes de esperar tabela preenchida");

		String statusAtualDaProposta = "N/A - sem linhas na tabela";
		if (getDadosDaTabela().size() > 0) {
			// 2018Out10 - tabela pode estar vazia.
			statusAtualDaProposta = getDadosDaTabela().get(0).get("Situação");
		}
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				String.format("mostraColunaSituacaoNaTabela, tabela tem status %s", statusAtualDaProposta));

		NDocumentoTable tbl = janela.TerminalFinanceiroCorporativoWindow()
				.BRBW037ConsultaDePropostasDigitalNCleoInternalFrame().NDocumentoTable();
		tbl.activateRow(0);

		// 2018Set10 - removida espera antes de scroll pois agora já detectamos linha(s)
		AutoItRunner.execute("scrollaTelaDireitaMostraStatusProposta");
		Thread.sleep((long) (TempoEspera.MEDIO / 2.0 * 1000));
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"mostraColunaSituacaoNaTabela, display status proposta");

		//
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void pesquisar(boolean abreDetalhe) throws GeneralLeanFtException, InterruptedException, IOException {
		String statusInicialDaProposta = DadosExecucao.getDadosFuncionalidade("STATUS_INICIAL_DA_PROPOSTA");
		boolean esperarAntes = false;
		if (abreDetalhe) {
			if (statusInicialDaProposta != null && (statusInicialDaProposta.equals("PENDENTE DE APROVAÇÂO DIGITAL")
					|| statusInicialDaProposta.equals("EM APROVAÇÃO DIGITAL"))) {
				esperarAntes = true;
			}
		}
		if (esperarAntes) {
			Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
					"esperando antes de pesquisar, aguaradando atualiz. status proposta em backendd");
			Thread.sleep(TempoEspera.SEGUNDOS_ATEH_APROVACAO_APARECER_EM_STATUS * 1000);
		}
		TestObject testObtPesqBtn = janela.TerminalFinanceiroCorporativoWindow()
				.BRBW037ConsultaDePropostasDigitalNCleoInternalFrame().PesquisarButton();
		Logger.debug(String.format("Descricao e display name do botao PesquisarButton() upcasted pra TestObject=%s,%s",
				testObtPesqBtn.getDescription(), testObtPesqBtn.getDisplayName()));
		Description dsc = testObtPesqBtn.getDescription();
		dsc.toString();

		janela.TerminalFinanceiroCorporativoWindow().BRBW037ConsultaDePropostasDigitalNCleoInternalFrame()
				.PesquisarButton().click();
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot());
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void fechar() throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow().BRBW037ConsultaDePropostasDigitalNCleoInternalFrame()
				.FecharButton().click();
		/*
		 * // PRA QUE evidenciar simples FECHAR? Denecessario...
		 * Thread.sleep(TempoEspera.retornarTempoEsperaMilisegundos(TempoEspera.MEDIO));
		 * Evidencias.evidenciarAcao(aberturaNucleo.TerminalFinanceiroCorporativoWindow(
		 * ).getSnapshot());
		 * 
		 */
	}

}