package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfConsDadosBasicosCC {
	public void processa(String agencia, String conta) throws Exception;

}