package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

public interface AbCcDigPfPropostaNucleo {

	public void efetuaPesquisa(String numeroDoc, boolean abreDetalhe, boolean isInicial) throws Exception;
	public void fechar() throws GeneralLeanFtException, InterruptedException, IOException, Exception;

}