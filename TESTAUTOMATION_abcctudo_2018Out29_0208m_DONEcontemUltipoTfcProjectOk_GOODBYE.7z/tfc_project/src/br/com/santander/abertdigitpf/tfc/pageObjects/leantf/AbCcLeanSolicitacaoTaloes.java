package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.AutoItRunner;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.suporte.TempoEspera;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSolicitacaoTaloes;
import unittesting.AberDigSolicitacaoTaloes;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanSolicitacaoTaloes extends UnitTestClassBase implements AbCcDigPfSolicitacaoTaloes  {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigSolicitacaoTaloes janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanSolicitacaoTaloes() throws GeneralLeanFtException, IOException {
		janela = new AberDigSolicitacaoTaloes();
		janela .TerminalFinanceiroCorporativoWindow().BRBC315ConsultaDeSolicitaEsDeTalEsInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"SolicitacaoTaloes");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void clickFechar()  throws Exception {
	
		janela.TerminalFinanceiroCorporativoWindow().BRBC315ConsultaDeSolicitaEsDeTalEsInternalFrame().FecharButton().click();
	}

	/**
	 * @author x140824-rbattaglia
	 * @throws Exception 
	 */
	public void efetuaPesquisa(String agencia, String conta) throws Exception {
		pesquisaAgenciaConta(agencia, conta);
		mostraTabela();
		clickFechar();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void pesquisaAgenciaConta(String agencia, String conta) throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow().
		   BRBC315ConsultaDeSolicitaEsDeTalEsInternalFrame().
		   PesquisarPorList().click();
		Thread.sleep(TempoEspera.CURTO*1000);
		AutoItRunner.execute("escolhePesqPorContaEmSolicTaloes");
		Thread.sleep(TempoEspera.CURTO*1000);
		
		janela.TerminalFinanceiroCorporativoWindow().
		   BRBC315ConsultaDeSolicitaEsDeTalEsInternalFrame().
		   AgEditor().
		   sendKeys(agencia);

		janela.TerminalFinanceiroCorporativoWindow().
		   BRBC315ConsultaDeSolicitaEsDeTalEsInternalFrame().
		   ContaEditor().
		   sendKeys(conta);
		

		janela.TerminalFinanceiroCorporativoWindow().BRBC315ConsultaDeSolicitaEsDeTalEsInternalFrame().PesquisarButton().click();

	}

	/**
	 * @author x140824-rbattaglia
	 * @throws GeneralLeanFtException 
	 * @throws IOException 
	 */
	private void mostraTabela() throws GeneralLeanFtException, IOException {
		
		try {
			Thread.sleep(TempoEspera.MEDIO* 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
		}
		// tabela provavelmente vazia. Nao tenho objeto JTable. Nao saberei se done, entao, SLEEP
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),"mostrarTabela(), depois de pesquisar e esperar");
	}

}