package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfHistAberConta {
	public void fazPesquisa(String agencia, String conta) throws Exception;
}