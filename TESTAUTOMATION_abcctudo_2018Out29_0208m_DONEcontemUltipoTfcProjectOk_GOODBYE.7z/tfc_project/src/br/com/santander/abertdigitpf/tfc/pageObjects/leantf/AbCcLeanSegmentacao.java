package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSegmentacao;
import unittesting.AberDigSegmentacao;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 *         TODO - talvez, esperar que tabela preenchida... e scrshots
 *         adicionais, TALVEZ
 */
public class AbCcLeanSegmentacao extends UnitTestClassBase implements AbCcDigPfSegmentacao  {

	/**
	 * @author x140824-rbattaglia
	 */
	AberDigSegmentacao janela;

	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanSegmentacao() throws GeneralLeanFtException, IOException {
		janela = new AberDigSegmentacao();
		janela.TerminalFinanceiroCorporativoWindow().BRPE090SegmentaOInternalFrame().activate();

		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"Segmentacao");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickFechar() throws Exception {

		janela.TerminalFinanceiroCorporativoWindow().BRPE090SegmentaOInternalFrame().FecharButton().click();
	}

}