package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public interface AbCcDigPfAprovaDevolveRejeita {
	public void ClickFecharDummyDontCall()  throws Exception;
	public void clickCadastro()  throws Exception;
	public void clickAprovacao()  throws Exception;

}