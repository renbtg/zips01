package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfManutCadPesFisRapido;
import unittesting.AberDigManutCadPesFisRapido;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanManutCadPesFisRapido extends UnitTestClassBase  implements AbCcDigPfManutCadPesFisRapido {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigManutCadPesFisRapido janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanManutCadPesFisRapido() throws GeneralLeanFtException, IOException {
		janela = new AberDigManutCadPesFisRapido();
		
		janela .TerminalFinanceiroCorporativoWindow().BRPE900ManutenODeDadosCadastraisDePessoaFSicaCadastroRPidoInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"ManutCadPesFisRapido");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickCancelar()  throws Exception {
	
		janela.TerminalFinanceiroCorporativoWindow().BRPE900ManutenODeDadosCadastraisDePessoaFSicaCadastroRPidoInternalFrame().CancelarButton().click();
	}

}