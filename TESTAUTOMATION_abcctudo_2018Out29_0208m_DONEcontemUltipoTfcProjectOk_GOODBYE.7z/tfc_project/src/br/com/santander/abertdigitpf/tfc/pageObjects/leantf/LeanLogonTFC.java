package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.java.Applet;
import com.hp.lft.sdk.java.AppletDescription;
import com.hp.lft.sdk.java.Button;
import com.hp.lft.sdk.java.ButtonDescription;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.LogonTFC;
import unittesting.LoginTFC;
import unittesting.TerminalFinanceiroCorporativoTFC;

public class LeanLogonTFC implements LogonTFC {

	LoginTFC login;
	TerminalFinanceiroCorporativoTFC janelaPrincipal;

	public LeanLogonTFC() throws GeneralLeanFtException, IOException {
		login = new LoginTFC();
		Evidencias.evidenciarAcao(login.TerminalFinanceiroCorporativoWindow().getSnapshot(), "Logon TFC");

	}

	public void realizarLogin(String usuario, String senha)
			throws GeneralLeanFtException, InterruptedException, IOException {

		login.TerminalFinanceiroCorporativoWindow().LogonDialog().activate();
		login.TerminalFinanceiroCorporativoWindow().LogonDialog().UsuRioEditor().setText(usuario);
		login.TerminalFinanceiroCorporativoWindow().LogonDialog().SenhaEditor().setText(senha);

		Evidencias.evidenciarAcao(login.TerminalFinanceiroCorporativoWindow().getSnapshot());
		login.TerminalFinanceiroCorporativoWindow().LogonDialog().OKButton().click();

		// WaitUntilEvaluator<Button> evaluator = new WaitUntilEvaluator<Button>() {
		// @Override
		// public boolean evaluate(Button botao) throws GeneralLeanFtException {
		// return botao.exists();
		// }
		// };
		// WaitUntilTestObjectState.waitUntil(
		// login.TerminalFinanceiroCorporativoWindow().PERGUNTADialog().AceitarButton(),
		// evaluator, 3000);

		try {
			login.TerminalFinanceiroCorporativoWindow().LogonDialog().ContinuarButton().click();
		} catch (GeneralLeanFtException ge) {
			if (System.currentTimeMillis() == 0) {
				// 2018Mar20 - rbattaglia DESFAZENDO a besteira que eu havia feito,
				// nao dá mais THROW aqui... assim, permito que código original
				// cedido por Danilo brandçço prossiga e derrube outros terminais etc,

				// by rbattaglia x140824
				Logger.debug("ERRO NO LeanLogonTFC.java, em realizarLogin");
				Logger.imprimeStackTrace(ge);
				throw ge;
			}
			if (login.TerminalFinanceiroCorporativoWindow().PERGUNTADialog().isEnabled()) {
				login.TerminalFinanceiroCorporativoWindow().PERGUNTADialog().activate();
				login.TerminalFinanceiroCorporativoWindow().PERGUNTADialog().AceitarButton().click();

				login.TerminalFinanceiroCorporativoWindow().INFORMAODialog().activate();
				login.TerminalFinanceiroCorporativoWindow().INFORMAODialog().FecharButton().click();

				login.TerminalFinanceiroCorporativoWindow().LogonDialog().activate();
				login.TerminalFinanceiroCorporativoWindow().LogonDialog().OKButton().click();
			} else {
				throw new GeneralLeanFtException("Erro ao acessar TFC");

			}
			Evidencias.evidenciarAcao(login.TerminalFinanceiroCorporativoWindow().getSnapshot());
			login.TerminalFinanceiroCorporativoWindow().LogonDialog().ContinuarButton().click();
		}

		janelaPrincipal = new TerminalFinanceiroCorporativoTFC();

		if (!janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Button.class, new ButtonDescription.Builder().objectName("ExitButton").build()).isVisible()) {

			throw new GeneralLeanFtException("Erro ao efeturar Logon");
		}

	}

	/**
	 * @author x140824 - rbattaglia
	 * @throws GeneralLeanFtException
	 */
	public void ativacaoDigitarUsuario() throws GeneralLeanFtException {
		login.TerminalFinanceiroCorporativoWindow().LogonDialog().activate();
	}

}