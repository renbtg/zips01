package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDlgConsManutPesFis;
import unittesting.AberDigDlgConsManutPesFis;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanDlgConsManutPesFis extends UnitTestClassBase implements AbCcDigPfDlgConsManutPesFis {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigDlgConsManutPesFis janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanDlgConsManutPesFis() throws GeneralLeanFtException, IOException {
		janela = new AberDigDlgConsManutPesFis();
		janela .TerminalFinanceiroCorporativoWindow().BRPE428ConsultaManutenODePessoaFSicaInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"DlgConsManutPesFis");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickCancelar()  throws Exception {
	
		janela.TerminalFinanceiroCorporativoWindow().BRPE428ConsultaManutenODePessoaFSicaInternalFrame().CancelarButton().click();
	}

	/**
	 * @author x140824-rbattaglia
	 * @throws Exception 
	 */
	public void efetuaPesquisa(String cpf) throws Exception {
		pesquisaCpf(cpf);
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void pesquisaCpf(String cpf) throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow().
		   BRPE428ConsultaManutenODePessoaFSicaInternalFrame().
		   NDocumentoEditor().
		   sendKeys(cpf);
		ClasseGenerica.esperaTestObjectNotBlank(90,"AbccLeanDlgConsManutPesFis::nome", janela.TerminalFinanceiroCorporativoWindow().
				   BRPE428ConsultaManutenODePessoaFSicaInternalFrame().
				   NOMEEditor());

		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), " depois de digitar cpf e esperar ");
		janela.TerminalFinanceiroCorporativoWindow().BRPE428ConsultaManutenODePessoaFSicaInternalFrame().OkButton().click();
	}

}