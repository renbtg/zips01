package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfSubstituiRestituiTerminal {
	public void modificaCentro(String centro) throws Exception;
}
