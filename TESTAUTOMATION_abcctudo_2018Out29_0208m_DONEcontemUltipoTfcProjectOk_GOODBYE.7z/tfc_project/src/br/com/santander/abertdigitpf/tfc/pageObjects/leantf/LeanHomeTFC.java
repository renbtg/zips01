package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;
import java.util.List;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.java.Applet;
import com.hp.lft.sdk.java.AppletDescription;
import com.hp.lft.sdk.java.Button;
import com.hp.lft.sdk.java.ButtonDescription;
import com.hp.lft.sdk.java.ListDescription;
import com.hp.lft.sdk.java.ListItem;
import com.hp.lft.sdk.java.Menu;
import com.hp.lft.sdk.java.MenuDescription;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.TempoEspera;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.HomeTFC;
import unittesting.TerminalFinanceiroCorporativoTFC;
import unittesting.UnitTestClassBase;

public class LeanHomeTFC extends UnitTestClassBase implements HomeTFC {

	TerminalFinanceiroCorporativoTFC janelaPrincipal;
//
	public LeanHomeTFC() throws GeneralLeanFtException, IOException {
		this(false);
	}
	public LeanHomeTFC(boolean wantsScreenshot) throws GeneralLeanFtException, IOException {
		janelaPrincipal = new TerminalFinanceiroCorporativoTFC();
		janelaPrincipal.TerminalFinanceiroCorporativoWindow().activate();
		if (wantsScreenshot) {
			Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot(), "Tela Home TFC");
		}
	}

	/**
	 * @author x140824 - Renato Battaglia
	 */
	public void acessarMenuContasServicos() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow().describe(Applet.class, new AppletDescription())
				.describe(Button.class, new ButtonDescription.Builder().attachedText("contas5").build()).click();
	}

	/**
	 * @author x140824 - Renato Battaglia
	 */
	public void acessarContasServicosBotaoExtrato() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow().describe(Applet.class, new AppletDescription())
				.describe(Button.class, new ButtonDescription.Builder().attachedText("Extrato").build()).click();
	}

	/**
	 * @author x140824 - Renato Battaglia
	 */
	public void acessarIconePessoaFisica() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow().describe(Applet.class, new AppletDescription())
				.describe(Button.class, new ButtonDescription.Builder().attachedText("clienteMant2").build()).click();
	}

	/**
	 * @author x140824 - Renato Battaglia
	 */
	public void acessarContasServicosBotaoSaldoCC() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow().describe(Applet.class, new AppletDescription())
				.describe(Button.class, new ButtonDescription.Builder().attachedText("Saldo C/C").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuContasCorrentes() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().label("Contas Correntes").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAberturas() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().label("Aberturas").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuConsultas() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().label("Consultas").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAberturaDePropostasDigitais()
			throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class,
						new MenuDescription.Builder().label("Controle de Abertura de Propostas Digitais").build())
				.click();
	}

	/**
	 * created 2018Set07
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAberturaDigitalEmAprovacao()
			throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().label("Em Aprovação Digital").build())
				.click();
	}
	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAberturaDigitalPendenteDeAprovacao()
			throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().label("Pendente de Aprovação Digital").build())
				.click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAberturaDigitalConsultaNucleo()
			throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class,
						new MenuDescription.Builder().label("Consulta de Propostas Digital Núcleo").build())
				.click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuControleDeAberturaDePropostasContasNucleo()
			throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder()
						.label("Controle de Abertura de Propostas / Contas - Núcleo").build())
				.click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuHistoricoDePropostasContas()
			throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().objectName("MyMenuItemBC8160WF").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuDadosDaConta() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().objectName("MyMenuItemBC8340").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuDadosDeContaCorrente() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().label("Dados de Conta Corrente").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuSolicInfoHistoricas() throws GeneralLeanFtException, InterruptedException, IOException {
		Thread.sleep(TempoEspera.CURTO * 1000);
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().objectName("MyMenuItemBC8390").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAltaracaoDaConta() throws GeneralLeanFtException, InterruptedException, IOException {
		Thread.sleep(TempoEspera.CURTO * 1000);
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().label("Alteração da Conta").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuCheques() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().label("Cheques").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuConsultaManutChequesTaloes()
			throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().objectName("MyMenuItemBC8410").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuSolicitacaoTaloes() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().objectName("MyMenuItemBC8419").build()).click();
	}

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuConsultaManutPessFisica()
			throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Menu.class, new MenuDescription.Builder().label("Consulta / manutenção de P. Física").build())
				.click();
	}

	public void clicarBotaoSair() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
				.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
				.describe(Button.class, new ButtonDescription.Builder().objectName("ExitButton").build()).click();
	}

	public void reiniciarTFC() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow().JDialog().ReiniciarButton().click();
	}

	public void sairTFC() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow().JDialog().SairButton().click();
	}

	public String armazenarUltimaMensagem() throws IOException, GeneralLeanFtException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		String mensagem = null;
		try {
			List<ListItem> listaMsg = janelaPrincipal.TerminalFinanceiroCorporativoWindow()
					.describe(Applet.class, new AppletDescription.Builder().tagName("Desktop").build())
					.describe(com.hp.lft.sdk.java.List.class,
							new ListDescription.Builder().objectName("MessageText").tagName("MyComboBox").build())
					.getSelectedItems();
			for (ListItem msg : listaMsg) {
				mensagem += msg.getText();
			}
		} catch (GeneralLeanFtException ge) {
		}

		return mensagem;

	}

	public void finalizarAplicacao() throws IOException {
		try {
			janelaPrincipal.TerminalFinanceiroCorporativoWindow().close();
			janelaPrincipal.MessageDialog().activate();
			Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
			janelaPrincipal.MessageDialog().OKButton().click();
		} catch (GeneralLeanFtException ge) {
		}
	}
	
	/**
	 * created 2018Out25
	 * @author x140824 - Renato Battaglia
	 */
	@Override
	public void acessarIconeArquitectura() throws GeneralLeanFtException, InterruptedException, IOException {
		Evidencias.evidenciarAcao(janelaPrincipal.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janelaPrincipal.TerminalFinanceiroCorporativoWindow().describe(Applet.class, new AppletDescription())
				.describe(Button.class, new ButtonDescription.Builder().attachedText("arquitectura").build()).click();
	}

	/**
	 * created 2018Out25
	 * @author x140824 - Renato Battaglia
	 */
	@Override
	public void acessarSubMenuSubRestitTerm() throws Exception {
		janelaPrincipal.TerminalFinanceiroCorporativoWindow()
		.describe(Applet.class, new AppletDescription.Builder().objectName("Desktop").build())
		.describe(Menu.class, new MenuDescription.Builder().label("Substit./Restit.Term.").build()).click();
																  
	}

}