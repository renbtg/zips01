package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDetCartao;
import unittesting.AberDigDetCartao;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanDetCartao extends UnitTestClassBase  implements AbCcDigPfDetCartao {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigDetCartao janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanDetCartao() throws GeneralLeanFtException, IOException {
		janela = new AberDigDetCartao();
		
		janela .TerminalFinanceiroCorporativoWindow().BRBW093ConsultaDeDadosDoCartOPessoaFSicaInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"DetCartao");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickCancelar()  throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW093ConsultaDeDadosDoCartOPessoaFSicaInternalFrame().CancelarButton().click();
	}

}