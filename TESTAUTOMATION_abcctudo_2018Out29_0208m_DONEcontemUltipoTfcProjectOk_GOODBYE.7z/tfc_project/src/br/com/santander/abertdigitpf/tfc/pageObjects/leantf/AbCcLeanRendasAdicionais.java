package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;
import java.util.List;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.base.TfcExcecoes;
import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfRendasAdicionais;
import unittesting.AberDigRendasAdicionais;
import unittesting.AberDigRendasAdicionais.TerminalFinanceiroCorporativoWindow.BRPE082ConsultaManutenODeRendasInternalFrame.PeriodicidadeTable;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 *         TODO - talvez, esperar que tabela preenchida... e scrshots
 *         adicionais, TALVEZ
 */
public class AbCcLeanRendasAdicionais extends UnitTestClassBase  implements AbCcDigPfRendasAdicionais {

	/**
	 * @author x140824-rbattaglia
	 */
	AberDigRendasAdicionais janela;

	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanRendasAdicionais() throws GeneralLeanFtException, IOException {
		janela = new AberDigRendasAdicionais();
		janela.TerminalFinanceiroCorporativoWindow().BRPE082ConsultaManutenODeRendasInternalFrame()
				.activate();
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), "RendasAdicionais");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickFechar() throws Exception {

		janela.TerminalFinanceiroCorporativoWindow().BRPE082ConsultaManutenODeRendasInternalFrame()
				.FecharButton().click();
	}

	/**
	 * Diretamente no LeanFT, sem espelho na Interface sem Mock, é chamada
	 * diretamente de dentro de outra implementação LeanFT 
	 * (OBS: Tanto MOCK quanto INTERFACE vão deixar de existir em breve)
	 * @throws Exception 
	 * @since 2018Julho31
	 */
	public void validaRendas(String sRendaInformada, String sOutrasRendas) throws Exception {
		PeriodicidadeTable tbl = janela.TerminalFinanceiroCorporativoWindow().BRPE082ConsultaManutenODeRendasInternalFrame().PeriodicidadeTable();
		// TODO Auto-generated method stub


		Logger.debug("antes de retornaTodoConteudoTabela");
		List<List<String>> linhas= ClasseGenerica.retornaTodoConteudoDaTabela(tbl, 10);
		Logger.debug("depois de retornaTodoConteudoTabela");

		String vlrColRendaInformada = "";
		String vlrColOutrasRendas = "";


		for (List<String >linha: linhas) {
			boolean procurando = false;
			if (sOutrasRendas != null && vlrColOutrasRendas.equals("")) {
				procurando = true;
				int idxOutrasRendas = linha.indexOf("OUTRAS RENDAS");			
				if (idxOutrasRendas != -1) {
					vlrColOutrasRendas = linha.get(idxOutrasRendas+1);
				}
			} 
			if (sRendaInformada != null && vlrColRendaInformada.equals("")) {
				procurando = true;
				int idxRendaInformada = linha.indexOf("RENDA INFORMADA");			
				if (idxRendaInformada != -1) {
					vlrColRendaInformada = linha.get(idxRendaInformada+1);
				}
			}
			if (! procurando) {
				break;
			}
		}
		

		if ((sRendaInformada != null && !sRendaInformada.equals(vlrColRendaInformada)) || (sOutrasRendas != null && !sOutrasRendas.equals(vlrColOutrasRendas)) ) { 
				throw TfcExcecoes.getExcecaoRendaRuim(sRendaInformada, vlrColRendaInformada, sOutrasRendas, vlrColOutrasRendas);
		}
	}

}