package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfDetPacServ {
	public void clickFechar()  throws Exception;

}