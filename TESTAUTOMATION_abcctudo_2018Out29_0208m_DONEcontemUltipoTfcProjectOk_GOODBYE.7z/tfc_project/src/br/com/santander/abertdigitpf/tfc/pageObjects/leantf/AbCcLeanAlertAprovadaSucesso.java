package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAlertAprovadaSucesso;
import unittesting.AberDigAlertAprovadaSucesso;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 */
public class AbCcLeanAlertAprovadaSucesso extends UnitTestClassBase implements AbCcDigPfAlertAprovadaSucesso {
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigAlertAprovadaSucesso janela;

	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanAlertAprovadaSucesso() throws GeneralLeanFtException, IOException {
		janela = new AberDigAlertAprovadaSucesso();
		janela.TerminalFinanceiroCorporativoWindow1().AvisoDialog().activate();

		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow1().getSnapshot(), "AlertAprovadaSucesso");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickOk() throws Exception {

		janela.TerminalFinanceiroCorporativoWindow1().AvisoDialog().OKButton().click();
	}

}