package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDetPacServ;
import unittesting.AberDigDetPacServ;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanDetPacServ extends UnitTestClassBase  implements AbCcDigPfDetPacServ {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigDetPacServ janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanDetPacServ() throws GeneralLeanFtException, IOException {
		janela = new AberDigDetPacServ();
		
		janela .TerminalFinanceiroCorporativoWindow().BRBW048PacoteDeServiOsInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"DetPacServ");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickFechar()  throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW048PacoteDeServiOsInternalFrame().FecharButton().click();
	}

}