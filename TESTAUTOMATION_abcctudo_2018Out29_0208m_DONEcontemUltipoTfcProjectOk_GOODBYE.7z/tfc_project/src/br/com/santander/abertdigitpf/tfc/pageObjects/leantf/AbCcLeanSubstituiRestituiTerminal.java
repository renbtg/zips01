package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSubstituiRestituiTerminal;
import unittesting.AberDigSubstituiRestituiTerminal;
import unittesting.AberDigSubstituiRestituiTerminal.TerminalFinanceiroCorporativoWindow1.QG32SubstituiORestituiODeTerminalInternalFrame;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanSubstituiRestituiTerminal extends UnitTestClassBase implements AbCcDigPfSubstituiRestituiTerminal {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigSubstituiRestituiTerminal janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanSubstituiRestituiTerminal() throws GeneralLeanFtException, IOException {
		janela = new AberDigSubstituiRestituiTerminal();
		
		janela.TerminalFinanceiroCorporativoWindow1().QG32SubstituiORestituiODeTerminalInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow1().getSnapshot(),
				"SubstituiRestituiTerminal");
	}

	/**
	 * @author x140824-rbattaglia
	 * @param centro 
	 */
	public void modificaCentro(String centro) throws Exception {
		QG32SubstituiORestituiODeTerminalInternalFrame frame = janela.TerminalFinanceiroCorporativoWindow1().QG32SubstituiORestituiODeTerminalInternalFrame();
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow1().getSnapshot(),
				"SubstituiRestTermCentro");
		if (centro == null) {
			centro = "";
		}
		Logger.debug("AbCcLeanSubstituiRestituiTerminal::modificaCentro(centro=%s), INI", centro);
		
		//2018Out28 - corrigido bug, antes, tentava editar se igual e ignorar se diferente!
		String centroTfc = frame.OriginalCentroEditor().getText();
		boolean igual = centroTfc.equals(centro);
		Logger.debug("AbCcLeanSubstituiRestituiTerminal::modificaCentro(centro=%s), centroTfc=%s, igual=%b", centro, centroTfc, igual);
		if (! centro.isEmpty() && ! centroTfc.equals(centro)) {
			Logger.debug("AbCcLeanSubstituiRestituiTerminal::modificaCentro(centro=%s), centroTfc=%s, igual=%b, modificando", centro, centroTfc, igual);
			frame.EmpresaEditor().sendKeys("0033");
			frame.CentroEditor().sendKeys(centro);
			Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow1().getSnapshot(),
					"SubstituiRestTermCentro");
			Logger.debug("AbCcLeanSubstituiRestituiTerminal::modificaCentro(centro=%s), centroTfc=%s, igual=%b, modificou", centro, centroTfc, igual);
			frame.OKButton().click();
			Thread.sleep(20*1000); //dorme 20 segundos depois de modificar centro, aumenta chance de chamadora refrescar a tela
		} else {
			Logger.debug("AbCcLeanSubstituiRestituiTerminal::modificaCentro(centro=%s), centroTfc=%s, igual=%b, NAO modificando", centro, centroTfc, igual);
			frame.CancelarButton().click();
		}
	}


}