package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbccDigPfPropostaEditavel {
	public void clickFechar() throws Exception;


	public void pesquisaCpfMostraTabela(String numeroDoc) throws Exception;


	
}