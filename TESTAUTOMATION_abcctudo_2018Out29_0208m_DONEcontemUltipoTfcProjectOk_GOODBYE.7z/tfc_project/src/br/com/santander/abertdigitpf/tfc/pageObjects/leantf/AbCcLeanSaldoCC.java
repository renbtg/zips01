package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSaldoCC;
import unittesting.AberDigSaldoCC;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanSaldoCC extends UnitTestClassBase  implements AbCcDigPfSaldoCC {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigSaldoCC janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanSaldoCC() throws GeneralLeanFtException, IOException {
		janela = new AberDigSaldoCC();
		
		janela .TerminalFinanceiroCorporativoWindow().BRBC111ConsultaDeSaldosDeContaInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"SaldoCC");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void clickFechar()  throws Exception {
	
		janela.TerminalFinanceiroCorporativoWindow().BRBC111ConsultaDeSaldosDeContaInternalFrame().FecharButton().click();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void fazPesquisa(String agencia, String conta) throws Exception {
		inserirAgenciaConta(agencia, conta);
		pesquisar();
		clickFechar();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void inserirAgenciaConta(String agencia, String conta) throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().
		   BRBC111ConsultaDeSaldosDeContaInternalFrame().
		   AgEditor().
		   sendKeys(agencia);
		janela.TerminalFinanceiroCorporativoWindow().
		   BRBC111ConsultaDeSaldosDeContaInternalFrame().
		   ContaEditor().
		   sendKeys(conta);
		//ECONOMIZE SCRSHOTS! //Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot());
	}
	/**
	 * @author x140824-rbattaglia
	 */
	private void pesquisar() throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow().
		   BRBC111ConsultaDeSaldosDeContaInternalFrame().PesquisarButton().click();
		ClasseGenerica.esperaTestObjectNotBlank(90, "pesquisa ag/cta em SaldoCC, NomeProduto", janela.TerminalFinanceiroCorporativoWindow().
		   BRBC111ConsultaDeSaldosDeContaInternalFrame().NomeDoProdutoEditor());
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), "saldoCC pesquisa realizada");
	}


}