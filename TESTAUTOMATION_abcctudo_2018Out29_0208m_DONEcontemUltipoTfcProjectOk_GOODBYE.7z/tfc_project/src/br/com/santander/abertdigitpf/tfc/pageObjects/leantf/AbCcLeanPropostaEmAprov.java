package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.awt.image.RenderedImage;
import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.java.Table;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfPropostaEmAprov;
import unittesting.AberDigPropostaEmAprovDigital;

/**
 * @author x140824-rbattaglia
 * 
 *         TODO - talvez, esperar que tabela preenchida... e scrshots
 *         adicionais, TALVEZ
 */
public class AbCcLeanPropostaEmAprov extends  AbCcLeanPropostaEditavel  implements AbCcDigPfPropostaEmAprov {

	private AberDigPropostaEmAprovDigital janela;
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanPropostaEmAprov() throws GeneralLeanFtException, IOException {
		janela = new AberDigPropostaEmAprovDigital();
		janela.TerminalFinanceiroCorporativoWindow().BRBW073PropostasEmAprovaODigitalInternalFrame().activate();
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), "PropostaEmAprov");
	}

	@Override
	public void clickFechar() throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW073PropostasEmAprovaODigitalInternalFrame().FecharButton().click();
	}


	@Override
	public void clickVoltarFase() throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW073PropostasEmAprovaODigitalInternalFrame().RetornarFaseButton().click();
	}
	@Override
	protected void inserirNumeroDocumento(String numeroDoc) throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow().BRBW073PropostasEmAprovaODigitalInternalFrame()
				.NDocumentoEditor().sendKeys(numeroDoc);
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot());
	}

	@Override
	protected void pesquisar() throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow().BRBW073PropostasEmAprovaODigitalInternalFrame()
				.PesquisarButton().click();
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot());
	}

	@Override
	protected Table getTabela() {
		return janela.TerminalFinanceiroCorporativoWindow().BRBW073PropostasEmAprovaODigitalInternalFrame().NDocumentoTable();
	}

	@Override
	protected String getNomeTela() {
		return "Propostas Em Aprov.";
	}

	@Override
	protected RenderedImage getTfcSnapshot() throws GeneralLeanFtException {
		return janela.TerminalFinanceiroCorporativoWindow().getSnapshot();
	}

}