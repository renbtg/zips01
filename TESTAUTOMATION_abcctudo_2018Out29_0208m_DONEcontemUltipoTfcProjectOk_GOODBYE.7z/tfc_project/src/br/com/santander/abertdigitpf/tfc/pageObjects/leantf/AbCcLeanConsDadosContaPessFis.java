package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import br.com.santander.abertdigitpf.base.TfcExcecoes;
import br.com.santander.abertdigitpf.suporte.DadosExecucao;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsDadosContaPessFis;
import unittesting.AberDigConsDadosContaPessFis;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 */
public class AbCcLeanConsDadosContaPessFis extends UnitTestClassBase  implements AbCcDigPfConsDadosContaPessFis {
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigConsDadosContaPessFis janela;

	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanConsDadosContaPessFis() throws Exception {
		janela = new AberDigConsDadosContaPessFis();
		janela.TerminalFinanceiroCorporativoWindow().BRBW091ConsultaDeDadosDaContaPessoaFSicaInternalFrame().activate();

		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), "ConsDadosContaPessFis");
		defineDadosAgenciaConta();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void validarLimites(String limite) throws Exception {
		String limiteContratado = getTextLimiteContratado();
		String limiteAprovado = getTextLimiteAprovado();

		Logger.debug(String.format(
				"AbCcDigPfConsDadosContaPessFis.validarLimites() - lim massa=%s, contr=%s, aprov=%s\n",
				limite, limiteContratado, limiteAprovado));

		if (!limiteContratado.equals(limite)) {
			if (System.currentTimeMillis() == 0) {
				throw TfcExcecoes.getExcecaoLimiteRuim(limite, limiteContratado);
			}
			else {
				Logger.debug(String.format(
						"IGNORANDO ERRO 2018Mai24 - AbCcDigPfConsDadosContaPessFis.validarLimites() - lim massa=%s, contr=%s, aprov=%s\n",
						limite, limiteContratado, limiteAprovado));
			}
		}
	}

	private void defineDadosAgenciaConta() throws Exception {
		DadosExecucao.setDadosFuncionalidade("AGENCIA", getDadoNumAgencia());
		DadosExecucao.setDadosFuncionalidade("CONTA", getDadoNumConta());
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private String getDadoNumAgencia() throws Exception {
		String retval;

		retval = janela.TerminalFinanceiroCorporativoWindow().BRBW091ConsultaDeDadosDaContaPessoaFSicaInternalFrame()
				.AgEditor().getText();

		return retval;
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private String getDadoNumConta() throws Exception {
		String retval;

		retval = janela.TerminalFinanceiroCorporativoWindow().BRBW091ConsultaDeDadosDaContaPessoaFSicaInternalFrame()
				.NMeroDaContaEditor().getText();

		return retval;
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void avancar() throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW091ConsultaDeDadosDaContaPessoaFSicaInternalFrame()
				.AvanArButton().click();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void fechar() throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW091ConsultaDeDadosDaContaPessoaFSicaInternalFrame()
				.FecharButton().click();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private String getTextLimiteAprovado() throws Exception {
		String retval;

		retval = janela.TerminalFinanceiroCorporativoWindow().BRBW091ConsultaDeDadosDaContaPessoaFSicaInternalFrame()
				.LimiteAprovadoEditor().getText();

		return retval;
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private String getTextLimiteContratado() throws Exception {
		String retval;

		retval = janela.TerminalFinanceiroCorporativoWindow().BRBW091ConsultaDeDadosDaContaPessoaFSicaInternalFrame()
				.LimiteContratadoEditor().getText();

		return retval;
	}

}