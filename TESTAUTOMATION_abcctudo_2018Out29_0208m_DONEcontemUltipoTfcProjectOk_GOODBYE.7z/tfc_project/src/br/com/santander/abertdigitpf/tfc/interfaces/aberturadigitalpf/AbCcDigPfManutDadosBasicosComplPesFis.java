package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

/**
 * @author x140824-rbattaglia
 */
public interface AbCcDigPfManutDadosBasicosComplPesFis {
	/**
	 * @author x140824-rbattaglia
	 */
	public void processa(String sRendaInformada, String sOutrasRendas) throws Exception;

	/**
	 * @author x140824-rbattaglia
	 * @throws Exception 
	 */
	public void clickCancelar() throws GeneralLeanFtException, InterruptedException, IOException, Exception;

}