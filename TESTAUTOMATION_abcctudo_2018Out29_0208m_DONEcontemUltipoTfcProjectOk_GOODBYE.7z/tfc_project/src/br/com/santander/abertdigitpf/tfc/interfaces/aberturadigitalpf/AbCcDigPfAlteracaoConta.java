package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfAlteracaoConta {

	public void efetuaPesquisa(String agencia, String conta) throws Exception;


}