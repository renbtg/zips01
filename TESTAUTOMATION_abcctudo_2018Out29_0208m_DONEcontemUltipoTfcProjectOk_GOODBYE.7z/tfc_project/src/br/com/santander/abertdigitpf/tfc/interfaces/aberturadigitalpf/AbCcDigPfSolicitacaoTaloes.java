package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfSolicitacaoTaloes {
	/**
	 * @author x140824-rbattaglia
	 * @throws Exception 
	 */
	public void efetuaPesquisa(String agencia, String conta) throws Exception;



}