package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.AutoItRunner;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.TempoEspera;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfHistAberConta;
import unittesting.AberDigHistAberConta;
import unittesting.AberDigHistAberConta.TerminalFinanceiroCorporativoWindow.BRBW211HistRicoDaAberturaDeContaInternalFrame.NDocumentoTable;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanHistAberConta extends UnitTestClassBase  implements AbCcDigPfHistAberConta {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigHistAberConta janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanHistAberConta() throws GeneralLeanFtException, IOException {
		janela = new AberDigHistAberConta();
		
		janela .TerminalFinanceiroCorporativoWindow().BRBW211HistRicoDaAberturaDeContaInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"HistAberConta");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void clickFechar()  throws Exception {
	
		janela.TerminalFinanceiroCorporativoWindow().BRBW211HistRicoDaAberturaDeContaInternalFrame().FecharButton().click();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void mostraColunaSituacaoNaTabela()  throws Exception {
		
		NDocumentoTable tbl = janela.TerminalFinanceiroCorporativoWindow().
		           BRBW211HistRicoDaAberturaDeContaInternalFrame().NDocumentoTable();
		
		tbl.activateRow(0);
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), "mostraColunaSituacaoNaTabela, tabela, antes de rolar");
		Thread.sleep(TempoEspera.MEDIO* 1000);
		AutoItRunner.execute("scrollaTelaDireitaMostraRestoHistAberConta");
		Thread.sleep(TempoEspera.MEDIO * 1000);
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), "mostraColunaSituacaoNaTabela, tabela, depois de rolar");
	}

	public void fazPesquisa(String agencia, String conta) throws Exception {
		inserirAgenciaConta(agencia, conta);
		pesquisar();
		mostraColunaSituacaoNaTabela();
		clickFechar();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void inserirAgenciaConta(String agencia, String conta) throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().
		   BRBW211HistRicoDaAberturaDeContaInternalFrame().
		   AgEditor().
		   sendKeys(agencia);
		janela.TerminalFinanceiroCorporativoWindow().
		   BRBW211HistRicoDaAberturaDeContaInternalFrame().
		   ContaEditor().
		   sendKeys(conta);
		//ECONOMIZE SCRSHOTS! //Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot());
	}
	/**
	 * @author x140824-rbattaglia
	 */
	private void pesquisar() throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow().
		   BRBW211HistRicoDaAberturaDeContaInternalFrame().PesquisarButton().click();
	}


}