package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfExtrato;
import unittesting.AberDigExtrato;
import unittesting.AberDigExtrato.TerminalFinanceiroCorporativoWindow.BRBC101ConsultaDeExtratoDeContaInternalFrame.ProdutoTable;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanExtrato extends UnitTestClassBase  implements AbCcDigPfExtrato {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigExtrato janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanExtrato() throws GeneralLeanFtException, IOException {
		janela = new AberDigExtrato();
		janela .TerminalFinanceiroCorporativoWindow().BRBC101ConsultaDeExtratoDeContaInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"Extratov");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickFechar()  throws Exception {
	
		janela.TerminalFinanceiroCorporativoWindow().BRBC101ConsultaDeExtratoDeContaInternalFrame().FecharButton().click();
	}

	/**
	 * @author x140824-rbattaglia
	 * @throws Exception 
	 */
	public void efetuaPesquisa(String agencia, String conta) throws Exception {
		pesquisaAgenciaConta(agencia, conta);
		mostraTabela();
		clickFechar();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void pesquisaAgenciaConta(String agencia, String conta) throws GeneralLeanFtException, InterruptedException, IOException {

		janela.TerminalFinanceiroCorporativoWindow().
		   BRBC101ConsultaDeExtratoDeContaInternalFrame().
		   AgEditor().
		   sendKeys(agencia);

		janela.TerminalFinanceiroCorporativoWindow().
		   BRBC101ConsultaDeExtratoDeContaInternalFrame().
		   ContaEditor().
		   sendKeys(conta);
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot());

		janela.TerminalFinanceiroCorporativoWindow().BRBC101ConsultaDeExtratoDeContaInternalFrame().PesquisarButton().click();
	
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void mostraTabela()  throws Exception {
		
		ProdutoTable tbl = janela.TerminalFinanceiroCorporativoWindow().
		           BRBC101ConsultaDeExtratoDeContaInternalFrame().ProdutoTable();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), "Extrato, antes de esperar tabela preenchida");
		ClasseGenerica.retornarLinhaTabela(tbl, new String[0], 5);
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), "Extrato, depois de esperar tabela preenchida");
	}

}