package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDlgInconsistDetConsManutPesFis;
import unittesting.AberDigDlgInconsistDeConsManutPesFis;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanDlgInconsistDetConsManutPesFis extends UnitTestClassBase  implements AbCcDigPfDlgInconsistDetConsManutPesFis {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigDlgInconsistDeConsManutPesFis janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanDlgInconsistDetConsManutPesFis() throws GeneralLeanFtException, IOException {
		janela = new AberDigDlgInconsistDeConsManutPesFis();
		janela .TerminalFinanceiroCorporativoWindow().BRPE0004CamposInconsistentesInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"DlgInconsistDeConsManutPesFis");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickOk()  throws Exception {
	
		janela.TerminalFinanceiroCorporativoWindow().BRPE0004CamposInconsistentesInternalFrame().OkButton().click();
	}

}