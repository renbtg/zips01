package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.AutoItRunner;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.suporte.TempoEspera;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAprovaDevolveRejeita;
import unittesting.AberDigAprovaDevolveRejeita;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanAprovaDevolveRejeita extends UnitTestClassBase implements AbCcDigPfAprovaDevolveRejeita {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigAprovaDevolveRejeita janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanAprovaDevolveRejeita() throws GeneralLeanFtException, IOException {
		janela = new AberDigAprovaDevolveRejeita();
		
		janela .TerminalFinanceiroCorporativoWindow().BRBW069AprovaODevoluOOuRejeiODePropostaDigitalInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"AprovaDevolveRejeita");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void ClickFecharDummyDontCall()  throws Exception {
		if (System.currentTimeMillis() > 0) {
			throw new RuntimeException("Nao deve chamar FECHAR, pois click em Aprovacao/Devolucao/Rejeicao jah fecha!");
		}
		janela.TerminalFinanceiroCorporativoWindow().BRBW069AprovaODevoluOOuRejeiODePropostaDigitalInternalFrame().FecharButton().click();
	}
	/**
	 * @author x140824-rbattaglia
	 */
	public void clickCadastro()  throws Exception {
	
		janela.TerminalFinanceiroCorporativoWindow().BRBW069AprovaODevoluOOuRejeiODePropostaDigitalInternalFrame().CadastroButton().click();
	}
	/**
	 * @author x140824-rbattaglia
	 */
	public void clickAprovacao()  throws Exception {
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				" vai mudar status, dormindo antes de clickar Aprovacao");
		try {
			Thread.sleep(TempoEspera.LONGO*1000);
		} catch (InterruptedException e) {
			Logger.imprimeStackTrace(e);
		}
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				" vai mudar status agora, clickando em Aprovacao");
		
		janela.TerminalFinanceiroCorporativoWindow().BRBW069AprovaODevoluOOuRejeiODePropostaDigitalInternalFrame().AprovacaoButton().click();
		if (System.currentTimeMillis() == 0) {
			//2018Mai09 - HACK desabilitado, TFC voltou ao normal
			Thread.sleep(20 * 1000);
			AutoItRunner.execute("teclaEnter");
			/**
			 * 2018Mai06 - erro de CICs inçcuo ocorrendo em click de Analisar. Podemos
			 * simplesmente clickar em OK no dialog de erro de CICs e prosseguir, sem nem
			 * mesmo clickar novamente en Analisar.
			 */
		}

	}

}