package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfDetCartao {
	public void clickCancelar()  throws Exception ;
}