package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

/**
 * @author x140824-rbattaglia
 * 
 *         TODO - talvez, esperar que tabela preenchida... e scrshots
 *         adicionais, TALVEZ
 */
public interface AbCcDigPfPropostaPendAprov extends AbccDigPfPropostaEditavel {
	public void clickAnalisar() throws Exception;
	public void clickDetalhe() throws Exception;


}