package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsProdServPesFis;
import unittesting.AberDigConsProdServPesFis;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanConsProdServPesFis extends UnitTestClassBase  implements AbCcDigPfConsProdServPesFis  {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigConsProdServPesFis janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanConsProdServPesFis() throws GeneralLeanFtException, IOException {
		janela = new AberDigConsProdServPesFis();
		
		janela .TerminalFinanceiroCorporativoWindow().BRBW092ConsultaDeProdutosServiOsPessoaFSicaInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"ConsProdServPesFis");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickFechar()  throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW092ConsultaDeProdutosServiOsPessoaFSicaInternalFrame().FecharButton().click();
	}
	/**
	 * @author x140824-rbattaglia
	 */
	public void clickPacoteServicos()  throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW092ConsultaDeProdutosServiOsPessoaFSicaInternalFrame().PacServButton().click();
	}
	/**
	 * @author x140824-rbattaglia
	 */
	public void clickCartao()  throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW092ConsultaDeProdutosServiOsPessoaFSicaInternalFrame().CartaoButton().click();
	}

}