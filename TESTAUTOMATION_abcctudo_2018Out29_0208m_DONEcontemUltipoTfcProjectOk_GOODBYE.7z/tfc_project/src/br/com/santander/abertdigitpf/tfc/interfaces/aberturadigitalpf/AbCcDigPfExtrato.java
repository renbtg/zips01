package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfExtrato {
	public void clickFechar()  throws Exception;
	public void efetuaPesquisa(String agencia, String conta) throws Exception;
}