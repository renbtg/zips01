package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.TestObject;

import br.com.santander.abertdigitpf.base.TfcExcecoes;
import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.suporte.TempoEspera;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsDadosBasicosCC;
import unittesting.AberDigConsDadosBasicosCC;
import unittesting.AberDigConsDadosBasicosCC.TerminalFinanceiroCorporativoWindow.BRBC241ConsultaDeDadosBSicosDeUmaContaCorrenteInternalFrame;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 */
public class AbCcLeanConsDadosBasicosCC extends UnitTestClassBase implements AbCcDigPfConsDadosBasicosCC {
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigConsDadosBasicosCC janela;

	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanConsDadosBasicosCC() throws GeneralLeanFtException, IOException {
		janela = new AberDigConsDadosBasicosCC();
		janela.TerminalFinanceiroCorporativoWindow().BRBC241ConsultaDeDadosBSicosDeUmaContaCorrenteInternalFrame()
				.activate();

		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), "DadosBasicosCC");

	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void processa(String agencia, String conta) throws Exception {
		pesquisaAgenciaConta(agencia, conta);

		visitaTodasAbas();
		fechar();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void pesquisaAgenciaConta(String agencia, String conta)
			throws GeneralLeanFtException, InterruptedException, IOException {

		janela.TerminalFinanceiroCorporativoWindow().BRBC241ConsultaDeDadosBSicosDeUmaContaCorrenteInternalFrame()
				.AgEditor().sendKeys(agencia);

		janela.TerminalFinanceiroCorporativoWindow().BRBC241ConsultaDeDadosBSicosDeUmaContaCorrenteInternalFrame()
				.ContaEditor().sendKeys(conta);

		janela.TerminalFinanceiroCorporativoWindow().BRBC241ConsultaDeDadosBSicosDeUmaContaCorrenteInternalFrame()
				.PesquisarButton().click();
		Thread.sleep(TempoEspera.MEDIO * 1000);
	}

	private void evidenciaUmaAba(String nomeAba) throws GeneralLeanFtException {
		String evidNomeAba = nomeAba.replaceAll("/", " ");
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"Consulta dados Básicos de Conta - aba " + evidNomeAba);
	}

	private void visitaUmaAba(String nomeAba) throws GeneralLeanFtException {
		// antes de evidenciar
		Logger.debug("visitaUmaAba, INI geral, P00, nomeAba=%s", nomeAba);
		getInternalFrame().TheTabControl().select(nomeAba);
		Logger.debug("visitaUmaAba, selecionou aba, nomeAba=%s", nomeAba);
		TestObject anObject;
		if (nomeAba.equals("Dados gerais")) {
			anObject = getInternalFrame().DadosGeraisTitularEditor();
		} else if (nomeAba.equals("Dados adicionais")) {
			anObject = getInternalFrame().DadosAdicionaisModTalaoEditor();
		} else if (nomeAba.equals("Juros/SRB")) {
			anObject = getInternalFrame().JurosDevedoresEditor();
		} else {
			anObject = getInternalFrame().InicadoresContaMaxEditor();
		}
		Logger.debug("visitaUmaAba, obteve variavel anObject, nomeAba=%s", nomeAba);
		ClasseGenerica.esperaTestObjectNotBlank(90, nomeAba, anObject);
		if (System.currentTimeMillis() == 0) {
			Logger.debug("Tirando screenshot da aba %s antes de sleep, pra provar que tem q fazer SLEEP depois de esperaTestObjectNotBlank", nomeAba);
			evidenciaUmaAba("antes"+nomeAba);
		}
		try {
			Thread.sleep(5 * 1000);
			/*
			 * 2018Out21 - screenshot imediatamente após elemento presente estava rápido demais, ainda
			 * icone ESPERA na tela! TENTANDO: sleep de 5 segundos. HMMM, tentar CLICK,
			 * ignorando excecao, pode ser melhor! Repsitando TIMEOUT PADRAO do LeanFT!
			 */
		} catch (InterruptedException e) {
			Logger.imprimeStackTrace(e);
		}
		if (System.currentTimeMillis() > 0) {
			Logger.debug("Tirando screenshot da aba %s depois de sleep, tem q fazer SLEEP depois de esperaTestObjectNotBlank", nomeAba);
			evidenciaUmaAba(nomeAba);
		}
		/*
		 * tolerante: mesmo que nao tenha conseguido evidenciar aba, deixa passar sem
		 * erro! ?? Será que eu deveria ser permissivo assim?
		 */
	}

	private BRBC241ConsultaDeDadosBSicosDeUmaContaCorrenteInternalFrame getInternalFrame() {
		return janela.TerminalFinanceiroCorporativoWindow()
				.BRBC241ConsultaDeDadosBSicosDeUmaContaCorrenteInternalFrame();
	}

	private void visitaTodasAbas() throws Exception {
		visitaUmaAba("Dados gerais");
		visitaUmaAba("Dados adicionais");
		validaCampoEmitirTalao();
		visitaUmaAba("Juros/SRB");
		visitaUmaAba("Indicadores");
	}

	private void validaCampoEmitirTalao() throws Exception {
		String strMotivoBloq = janela.TerminalFinanceiroCorporativoWindow()
				.BRBC241ConsultaDeDadosBSicosDeUmaContaCorrenteInternalFrame().MotBloqEntregaTalOEditor().getText();
		// 2018Set09 - motivo VAZIO(length=0) considerado OK.
		if (!strMotivoBloq.equals("NAO EMITIR") && !strMotivoBloq.equals("")) {
			if (System.currentTimeMillis() != 0) {
				if (strMotivoBloq.equals("")) {
					for (int x = 0; x < 50; x++) {
						Logger.debug(
								"2018Set09 am - strMotivoBloq - falar com QAs, nao estou considerando VAZIO como erro! Apareceu strMotivoBoq vazio em inicio de madrugada de 2018Set9!");
					}
				}
			}
			throw TfcExcecoes.getExcecaoMotivoChequeRuim(strMotivoBloq);
		}

	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void fechar() throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow().BRBC241ConsultaDeDadosBSicosDeUmaContaCorrenteInternalFrame()
				.FecharButton().click();
		/*
		 * // PRA QUE evidenciar simples FECHAR? Denecessario...
		 * Thread.sleep(TempoEspera.retornarTempoEsperaMilisegundos(TempoEspera.MEDIO));
		 * Evidencias.evidenciarAcao(aberturaNucleo.TerminalFinanceiroCorporativoWindow(
		 * ).getSnapshot());
		 * 
		 */
	}

}