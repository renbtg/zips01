package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

/**
 * @author x140824-rbattaglia
 * 
 *         TODO - talvez, esperar que tabela preenchida... e scrshots
 *         adicionais, TALVEZ
 */
public interface AbCcDigPfSegmentacao {
	public void clickFechar() throws Exception;
}