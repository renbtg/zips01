package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

public interface LogonTFC {

	public void realizarLogin(String usuario, String senha)
			throws GeneralLeanFtException, InterruptedException, IOException, Exception;

	/**
	 * @author x140824 - rbattaglia
	 * @throws GeneralLeanFtException
	 * @throws Exception 
	 */
	public void ativacaoDigitarUsuario() throws GeneralLeanFtException, Exception;

}