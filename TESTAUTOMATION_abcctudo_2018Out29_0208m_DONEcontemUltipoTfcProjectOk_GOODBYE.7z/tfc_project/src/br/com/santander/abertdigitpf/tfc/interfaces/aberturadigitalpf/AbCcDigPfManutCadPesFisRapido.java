package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfManutCadPesFisRapido {
	public void clickCancelar()  throws Exception;

}