package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.suporte.TempoEspera;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAlteracaoConta;
import unittesting.AberDigAlteracaoConta;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 * 
 * TODO - talvez, esperar que tabela preenchida... e scrshots adicionais, TALVEZ
 */
public class AbCcLeanAlteracaoConta extends UnitTestClassBase implements AbCcDigPfAlteracaoConta {
	
	
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigAlteracaoConta janela ;

	
	
	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanAlteracaoConta() throws GeneralLeanFtException, IOException {
		janela = new AberDigAlteracaoConta();
		janela .TerminalFinanceiroCorporativoWindow().BRBC060LConsultaHistRicoDeAlteraEsPorAgNciaInternalFrame().activate();
		
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"AlteracaoConta");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void clickFechar()  throws Exception {
	
		janela.TerminalFinanceiroCorporativoWindow().BRBC060LConsultaHistRicoDeAlteraEsPorAgNciaInternalFrame().FecharButton().click();
	}

	/**
	 * @author x140824-rbattaglia
	 * @throws Exception 
	 */
	public void efetuaPesquisa(String agencia, String conta) throws Exception {
		pesquisaAgenciaConta(agencia, conta);
		mostraTabela();
		clickFechar();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	private void pesquisaAgenciaConta(String agencia, String conta) throws GeneralLeanFtException, InterruptedException, IOException {


		janela.TerminalFinanceiroCorporativoWindow().
		   BRBC060LConsultaHistRicoDeAlteraEsPorAgNciaInternalFrame().
		   AgEditor().
		   sendKeys(agencia);

		janela.TerminalFinanceiroCorporativoWindow().
		   BRBC060LConsultaHistRicoDeAlteraEsPorAgNciaInternalFrame().
		   ContaEditor().
		   sendKeys(conta);
		

		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot());
		janela.TerminalFinanceiroCorporativoWindow().BRBC060LConsultaHistRicoDeAlteraEsPorAgNciaInternalFrame().PesquisarButton().click();
	
	}

	/**
	 * @author x140824-rbattaglia
	 * @throws GeneralLeanFtException 
	 * @throws IOException 
	 */
	private void mostraTabela() throws GeneralLeanFtException, IOException {
		
		try {
			Thread.sleep(TempoEspera.MEDIO* 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
		}
		// tabela provavelmente vazia. Nao tenho objeto JTable. Nao saberei se done, entao, SLEEP
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),"mostrarTabela(), depois de esperar");
	}

}