package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfDlgInconsistDetConsManutPesFis {
	public void clickOk()  throws Exception;
}