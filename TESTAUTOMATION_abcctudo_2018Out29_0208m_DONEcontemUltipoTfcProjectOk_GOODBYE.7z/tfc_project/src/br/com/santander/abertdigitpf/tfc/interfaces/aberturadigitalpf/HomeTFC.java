package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface HomeTFC{
	public void acessarMenuContasServicos() throws Exception;

	/**
	 * @author x140824 - Renato Battaglia
	 */
	public void acessarContasServicosBotaoExtrato() throws Exception;
	/**
	 * @author x140824 - Renato Battaglia
	 */
	public void acessarIconePessoaFisica() throws Exception;
	/**
	 * @author x140824 - Renato Battaglia
	 */
	public void acessarContasServicosBotaoSaldoCC() throws Exception;
	/**
	 * @author x140824-Renato Battaglia
	 * @throws Exception 
	 */
	public void acessarSubMenuContasCorrentes() throws Exception;

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAberturas() throws Exception;
	/**
	 * @author x140824-Renato Battaglia
	 * @throws Exception 
	 */
	public void acessarSubMenuConsultas() throws Exception;

	
	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAberturaDePropostasDigitais() throws Exception;
	
	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAberturaDigitalEmAprovacao() throws Exception;
	/**
	 * created 2018Set07
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAberturaDigitalPendenteDeAprovacao() throws Exception;
	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuAberturaDigitalConsultaNucleo() throws Exception;

	/**
	 * @author x140824-Renato Battaglia
	 * @throws Exception 
	 */
	public void acessarSubMenuControleDeAberturaDePropostasContasNucleo() throws Exception;
	
	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuHistoricoDePropostasContas() throws Exception;

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuDadosDaConta() throws Exception;

	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuDadosDeContaCorrente() throws Exception;
	
	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuSolicInfoHistoricas() throws Exception;

	/**
	 * @author x140824-Renato Battaglia
	 * @throws Exception 
	 */
	public void acessarSubMenuAltaracaoDaConta() throws Exception;
	/**
	 * @author x140824-Renato Battaglia
	 * @throws Exception 
	 */
	public void acessarSubMenuCheques() throws Exception;
	/**
	 * @author x140824-Renato Battaglia
	 * @throws Exception 
	 */
	public void acessarSubMenuConsultaManutChequesTaloes() throws Exception;
	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuSolicitacaoTaloes() throws Exception;
	/**
	 * @author x140824-Renato Battaglia
	 */
	public void acessarSubMenuConsultaManutPessFisica() throws Exception;

	public void clicarBotaoSair() throws Exception;

	public void reiniciarTFC() throws Exception;

	public void sairTFC() throws Exception;

	public String armazenarUltimaMensagem() throws Exception;

	public void finalizarAplicacao() throws Exception;
	public void acessarIconeArquitectura() throws Exception;

	public void acessarSubMenuSubRestitTerm() throws Exception;



}