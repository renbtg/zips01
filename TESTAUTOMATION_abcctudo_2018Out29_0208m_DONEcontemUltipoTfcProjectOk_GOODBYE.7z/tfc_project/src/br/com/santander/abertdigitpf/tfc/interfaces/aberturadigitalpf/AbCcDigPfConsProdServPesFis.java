package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfConsProdServPesFis {
	public void clickFechar()  throws Exception ;
	public void clickPacoteServicos()  throws Exception;
	public void clickCartao()  throws Exception ;

}