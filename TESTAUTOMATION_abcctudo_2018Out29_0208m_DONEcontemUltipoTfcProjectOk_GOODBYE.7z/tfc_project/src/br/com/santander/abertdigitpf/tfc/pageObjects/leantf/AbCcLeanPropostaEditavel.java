package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.java.Table;

import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.suporte.DadosExecucao;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbccDigPfPropostaEditavel;
import unittesting.UnitTestClassBase;

public abstract class AbCcLeanPropostaEditavel extends UnitTestClassBase implements AbccDigPfPropostaEditavel {

	/**
	 * @author x140824-rbattaglia
	 */
	private void validaTabela() throws Exception {
		Table tbl = getTabela();

		int nlinOk = ClasseGenerica.retornarLinhaTabela(tbl, new String[0], 5);
		
		Evidencias.evidenciarAcao(this.getTfcSnapshot(),
				"tabela talvez preenchida");

		if (nlinOk < 0) {
			throw new RuntimeException(
						String.format("validarTabela em tela de %s, com status inicial %s, nao tem linhas.",
								getNomeTela(), DadosExecucao.getDadosFuncionalidade("STATUS_INICIAL_DA_PROPOSTA")));
		}
		// 2018Out27 - código que validava DAR ERRO SE ACHOU EM TAL CONDICAO era
		// bobagem, removido.
	}

	protected abstract String getNomeTela();

	protected abstract Table getTabela();

	public void pesquisaCpfMostraTabela(String numeroDoc) throws Exception {
		inserirNumeroDocumento(numeroDoc);
		pesquisar();
		validaTabela();
	}

	protected abstract void inserirNumeroDocumento(String numeroDoc)
			throws GeneralLeanFtException, InterruptedException, IOException;

	/**
	 * @author x140824-rbattaglia
	 */
	protected abstract void pesquisar() throws GeneralLeanFtException, InterruptedException, IOException;
	protected abstract java.awt.image.RenderedImage getTfcSnapshot() throws GeneralLeanFtException;
}