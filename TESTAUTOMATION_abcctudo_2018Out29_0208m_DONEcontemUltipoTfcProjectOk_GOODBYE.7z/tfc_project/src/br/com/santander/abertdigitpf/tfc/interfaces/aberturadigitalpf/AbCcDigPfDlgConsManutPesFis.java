package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfDlgConsManutPesFis {
	public void clickCancelar()  throws Exception;
	public void efetuaPesquisa(String cpf) throws Exception;
}