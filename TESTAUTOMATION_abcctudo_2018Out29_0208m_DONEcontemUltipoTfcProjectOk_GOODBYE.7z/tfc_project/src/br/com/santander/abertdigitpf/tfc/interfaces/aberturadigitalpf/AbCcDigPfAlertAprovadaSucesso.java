package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

/**
 * @author x140824-rbattaglia
 */
public interface AbCcDigPfAlertAprovadaSucesso {

	/**
	 * @author x140824-rbattaglia
	 * @throws Exception 
	 */
	public void clickOk() throws Exception;

}