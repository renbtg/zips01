package br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf;

public interface AbCcDigPfConsDadosContaPessFis {
	public void validarLimites(String limite) throws Exception;
	public void avancar() throws Exception;
	public void fechar() throws Exception;
}