package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.awt.image.RenderedImage;
import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.java.Table;

import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfPropostaPendAprov;
import unittesting.AberDigPropostaPendAprovDigital;

/**
 * @author x140824-rbattaglia
 * 
 *         TODO - talvez, esperar que tabela preenchida... e scrshots
 *         adicionais, TALVEZ
 */
public class AbCcLeanPropostaPendAprov extends AbCcLeanPropostaEditavel implements AbCcDigPfPropostaPendAprov {
	private AberDigPropostaPendAprovDigital janela;

	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanPropostaPendAprov() throws GeneralLeanFtException, IOException {
		janela = new AberDigPropostaPendAprovDigital();
		janela.TerminalFinanceiroCorporativoWindow().BRBW035PropostaPendentesDeAprovaODigitalInternalFrame().activate();
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(), "PropostaPendAprov");
	}

	/**
	 * @author x140824-rbattaglia
	 */
	@Override
	public void clickDetalhe() throws Exception {

		janela.TerminalFinanceiroCorporativoWindow().BRBW035PropostaPendentesDeAprovaODigitalInternalFrame()
				.DetalheButton().click();
	}
	@Override
	protected void inserirNumeroDocumento(String numeroDoc) throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow().BRBW035PropostaPendentesDeAprovaODigitalInternalFrame()
				.NDocumentoEditor().sendKeys(numeroDoc);
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot());
	}
	@Override
	protected void pesquisar() throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow().BRBW035PropostaPendentesDeAprovaODigitalInternalFrame()
				.PesquisarButton().click();
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot());
	}

	@Override
	protected Table getTabela() {
		return janela.TerminalFinanceiroCorporativoWindow().BRBW035PropostaPendentesDeAprovaODigitalInternalFrame().NDocumentoTable();
	}

	@Override
	public void clickFechar() throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW035PropostaPendentesDeAprovaODigitalInternalFrame().FecharButton().click();
	}

	@Override
	public void clickAnalisar() throws Exception {
		janela.TerminalFinanceiroCorporativoWindow().BRBW035PropostaPendentesDeAprovaODigitalInternalFrame().AnalisarButton().click();
	}

	@Override
	protected String getNomeTela() {
		return "Propostas Pend.Aprov.";
	}

	@Override
	protected RenderedImage getTfcSnapshot() throws GeneralLeanFtException {
		return janela.TerminalFinanceiroCorporativoWindow().getSnapshot();
	}

}