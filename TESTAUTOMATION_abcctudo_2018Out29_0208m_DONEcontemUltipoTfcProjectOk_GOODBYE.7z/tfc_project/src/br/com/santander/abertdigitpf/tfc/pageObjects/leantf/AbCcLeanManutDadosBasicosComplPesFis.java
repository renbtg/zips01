package br.com.santander.abertdigitpf.tfc.pageObjects.leantf;

import java.io.IOException;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.TestObject;

import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfManutDadosBasicosComplPesFis;
import unittesting.AberDigManutDadosBasicosComplPesFis;
import unittesting.AberDigManutDadosBasicosComplPesFis.TerminalFinanceiroCorporativoWindow.BRPE284ManutenODeDadosBSicosEOuComplementaresDePessoaFSicaInternalFrame;
import unittesting.UnitTestClassBase;

/**
 * @author x140824-rbattaglia
 */
public class AbCcLeanManutDadosBasicosComplPesFis extends UnitTestClassBase
		implements AbCcDigPfManutDadosBasicosComplPesFis {
	/**
	 * @author x140824-rbattaglia
	 */
	AberDigManutDadosBasicosComplPesFis janela;
	private String sRendaInformada;
	private String sOutrasRendas;

	/**
	 * @author x140824-rbattaglia
	 */
	public AbCcLeanManutDadosBasicosComplPesFis() throws GeneralLeanFtException, IOException {
		janela = new AberDigManutDadosBasicosComplPesFis();
		janela.TerminalFinanceiroCorporativoWindow()
				.BRPE284ManutenODeDadosBSicosEOuComplementaresDePessoaFSicaInternalFrame().activate();

		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"ManutDadosBasicosComplPesFis");

	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void processa(String sRendaInformada, String sOutrasRendas) throws Exception {
		this.sRendaInformada = sRendaInformada;
		this.sOutrasRendas = sOutrasRendas;

		visitaTodasAbas();
		clickCancelar();
	}

	private void evidenciaUmaAba(String nomeAba) throws GeneralLeanFtException {
		String evidNomeAba = nomeAba.replaceAll("/", " ");
		Evidencias.evidenciarAcao(janela.TerminalFinanceiroCorporativoWindow().getSnapshot(),
				"Consulta dados Básicos de Conta - aba " + evidNomeAba);
	}

	private BRPE284ManutenODeDadosBSicosEOuComplementaresDePessoaFSicaInternalFrame getInternalFrame() {
		return janela.TerminalFinanceiroCorporativoWindow()
				.BRPE284ManutenODeDadosBSicosEOuComplementaresDePessoaFSicaInternalFrame();
	}

	private void visitaUmaAba(String nomeAba) throws GeneralLeanFtException {
		// antes de evidenciar
		Logger.debug("visitaUmaAba, INI geral, P00, nomeAba=%s", nomeAba);
		getInternalFrame().PaSDeNascimentoTabControl().select(nomeAba);
		Logger.debug("visitaUmaAba, selecionou aba, nomeAba=%s", nomeAba);
		TestObject anObject;
		if (nomeAba.equals("Dados básicos")) {
			anObject = getInternalFrame().DadosBasicosCPFEditor();
		} else if (nomeAba.equals("Endereços")) {
			anObject = getInternalFrame().EnderecosRegistrosEncontradosLabel();
		} else if (nomeAba.equals("Telefone")) {
			anObject = getInternalFrame().TelefoneDDIEditor();
		} else if (nomeAba.equals("Relacionamentos")) {
			anObject = getInternalFrame().Relac0RegsEncontradosLabel();
		} else {
			anObject = getInternalFrame().DadosComplValorRendaEditor();
		}
		Logger.debug("visitaUmaAba, obteve variavel anObject, nomeAba=%s", nomeAba);
		ClasseGenerica.esperaTestObjectNotBlank(90, nomeAba, anObject);
		if (System.currentTimeMillis() == 0) {
			Logger.debug("Tirando screenshot da aba %s antes de sleep, pra provar que tem q fazer SLEEP depois de esperaTestObjectNotBlank", nomeAba);
			evidenciaUmaAba("antes"+nomeAba);
		}
		try {
			Thread.sleep(5 * 1000);
			/*
			 * 2018Out21 - screenshot imediatamente após elemento presente estava rápido demais, ainda
			 * icone ESPERA na tela! TENTANDO: sleep de 5 segundos. HMMM, tentar CLICK,
			 * ignorando excecao, pode ser melhor! Repsitando TIMEOUT PADRAO do LeanFT!
			 */
		} catch (InterruptedException e) {
			Logger.imprimeStackTrace(e);
		}
		if (System.currentTimeMillis() == 0) {
			Logger.debug("Tirando screenshot da aba %s depois de sleep, tem q fazer SLEEP depois de esperaTestObjectNotBlank", nomeAba);
			evidenciaUmaAba("antes"+nomeAba);
		}

		evidenciaUmaAba(nomeAba);
		/*
		 * tolerante: mesmo que nao tenha conseguido evidenciar aba, deixa passar sem
		 * erro! ?? Será que eu deveria ser permissivo assim?
		 */
	}

	private void visitaTodasAbas() throws Exception {
		visitaUmaAba("Dados básicos");
		visitaUmaAba("Endereços");
		visitaUmaAba("Telefone");
		visitaUmaAba("Relacionamentos");
		visitaUmaAba("Dados complementares");
		detalhaDadosComplementares();
	}

	private void detalhaDadosComplementares() throws Exception {
		mostraRendasAdicionais();
		mostraSegmentacao();

	}

	private void mostraSegmentacao() throws Exception {

		janela.TerminalFinanceiroCorporativoWindow()
				.BRPE284ManutenODeDadosBSicosEOuComplementaresDePessoaFSicaInternalFrame().SegmentaOButton().click();
		new AbCcLeanSegmentacao().clickFechar();
		//

	}

	private void mostraRendasAdicionais() throws IOException, Exception {
		janela.TerminalFinanceiroCorporativoWindow()
				.BRPE284ManutenODeDadosBSicosEOuComplementaresDePessoaFSicaInternalFrame().RendasAdicButton().click();

		/**
		 * @author x140824 rbattaglia x140824
		 */

		AbCcLeanRendasAdicionais rendasAdicionais = new AbCcLeanRendasAdicionais();
		rendasAdicionais.validaRendas(sRendaInformada, sOutrasRendas);
		rendasAdicionais.clickFechar();
	}

	/**
	 * @author x140824-rbattaglia
	 */
	public void clickCancelar() throws GeneralLeanFtException, InterruptedException, IOException {
		janela.TerminalFinanceiroCorporativoWindow()
				.BRPE284ManutenODeDadosBSicosEOuComplementaresDePessoaFSicaInternalFrame().CancelarButton().click();
	}

}