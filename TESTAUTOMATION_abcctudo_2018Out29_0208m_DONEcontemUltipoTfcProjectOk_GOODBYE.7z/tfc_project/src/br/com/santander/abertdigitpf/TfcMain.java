package br.com.santander.abertdigitpf;

//import static java.nio.file.StandardCopyOption.ATOMIC_MOVE;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.util.Properties;
import java.util.Set;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.ModifiableSDKConfiguration;
import com.hp.lft.sdk.SDK;

import br.com.santander.abertdigitpf.base.FabricaObjAbertura;
import br.com.santander.abertdigitpf.base.FabricaObjAberturaMgr;
import br.com.santander.abertdigitpf.base.TfcProperties;
import br.com.santander.abertdigitpf.suporte.AutoItRunner;
import br.com.santander.abertdigitpf.suporte.ClasseGenerica;
import br.com.santander.abertdigitpf.suporte.CmdUtils;
import br.com.santander.abertdigitpf.suporte.DadosExecucao;
import br.com.santander.abertdigitpf.suporte.Evidencias;
import br.com.santander.abertdigitpf.suporte.LocalDateUtils;
import br.com.santander.abertdigitpf.suporte.Logger;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAlertAprovadaSucesso;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfAprovaDevolveRejeita;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsDadosContaPessFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfConsProdServPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfDlgConsManutPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfHistAberConta;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfManutCadPesFisRapido;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfManutDadosBasicosComplPesFis;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfPropostaEmAprov;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfPropostaNucleo;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfPropostaPendAprov;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbCcDigPfSolicitacaoTaloes;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.AbccDigPfPropostaEditavel;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.HomeTFC;
import br.com.santander.abertdigitpf.tfc.interfaces.aberturadigitalpf.LogonTFC;
import unittesting.TerminalFinanceiroCorporativoTFC;

public class TfcMain {
	// TODO 2018Fev03 - após concluir, Ruby deve mover diretório de evidências
	// TFC
	// para autom\Reports\TRN*\#{NomeCenarioRuby}\
	private static HomeTFC theHomeTfc;
	private static Properties propertiesTfcServer = new Properties();

	private static char RODAR_EXECTFC = FabricaObjAberturaMgr.LEANFT;
	private static FabricaObjAbertura factory = null;

	private static void initLeanFt() throws Exception {
		Logger.debug("initLeanFt() - P00");
		CmdUtils.startLftRuntime(getMaxSegundosStartLftRuntimeExe());
		Logger.debug("initLeanFt() - P00,1");
		ModifiableSDKConfiguration config;
		try {
			config = new ModifiableSDKConfiguration();
			Logger.debug("initLeanFt() - P01,1");
			config.setServerAddress(new URI("ws://localhost:5095"));
			config.setResponseTimeoutSeconds(120000);
			config.setConnectTimeoutSeconds(120000);
			Logger.debug("initLeanFt() - P01,2");
			if (System.currentTimeMillis() != 0) {
				Logger.debug("initLeanFt() - P01,3,1");
				SDK.init(config);
				Logger.debug("initLeanFt() - P01,3,2");
			} else {
				Logger.debug("rbattaglia, nao chamando SDK.init(config)");
				Logger.debug("initLeanFt() - P01,4");
			}
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			Logger.debug("initLeanFt() - P01,5");
			Logger.imprimeStackTrace(e);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.debug("initLeanFt() - P01,6");
			Logger.imprimeStackTrace(e);
		}
		Logger.debug("initLeanFt() - P01,7");
	}

	private static int getMaxSegundosStartLftRuntimeExe() {
		return 150; // 2018Set09, 150 segs. Antes, eram 90. // 2018Mar18, 90 segs. antes, eram 30
					// segundos
	}

	public static Thread[] getListaDeThreads() {
		Set<Thread> threadSet = Thread.getAllStackTraces().keySet();
		Thread[] threadArray = threadSet.toArray(new Thread[threadSet.size()]);

		return threadArray;

	}

	public static void xmain(String[] args) throws Throwable {
		chamaStack();
	}

	public static void chamaStack() throws Throwable {
		maisStack();
	}

	public static void maisStack() throws Throwable {
		CmdUtils.imprimeStack("alguma_msg");
	}

	public static void main(String[] args) throws Throwable {
		// int quantosJavaw = Integer.parseInt(args[0]);
		// CmdUtis.setQuantosJavawTerminalOk(quantosJavaw);
		core_main(args);
		Logger.debug("MAIN - terminou");
	}

	public static void core_main(String[] argv) throws Throwable {

		if (System.currentTimeMillis() > 0) {
			Logger.debug("rbattaglia main, vai rodar tfcMain()");
			tfcServer();
			Logger.debug("rbattaglia main, rodou tfcMain()");
		}

		return;
	}

	private static String get_massaparam_cpf() {
		return propertiesTfcServer.getProperty("CPF");
	}

	private static String get_massaparam_limite() {
		return propertiesTfcServer.getProperty("LIMITE");
	}

	private static String get_massaparam_rendaInformada() {
		return propertiesTfcServer.getProperty("RENDA_INFORMADA");
	}

	private static String get_massaparam_outrasRendas() {
		return propertiesTfcServer.getProperty("OUTRAS_RENDAS");
	}

	private static int get_cmd_numero_globalScenario() {
		int retval = 1;
		String s = propertiesTfcServer.getProperty("GLOBAL_SCENARIO_COUNT");
		if (s != null && !s.isEmpty()) {
			try {
				retval = Integer.parseInt(s);
			} catch (NumberFormatException nfe) {
				Logger.imprimeStackTrace(nfe);
			}
		}
		return retval;
	}

	// 2018Set07, get_cmd_numero_sequencia_retry() NUNCA CHAMADO, removiodo!

	private static void depoisDaAprovacao(String cpf, boolean abreDetalhe) throws Exception {
		String statusInicialDaProposta = DadosExecucao.getDadosFuncionalidade("STATUS_INICIAL_DA_PROPOSTA");
		if (statusInicialDaProposta.equals(ClasseGenerica.STR_PENDENTE_DE_APROVACAO_DIGITAL)
				|| statusInicialDaProposta.equals(ClasseGenerica.STR_EM_APROVACAO_DIGITAL)) {
			/**
			 * 2018Set07 - CUIDADO! já terá visto status que nao mudou, já estava ARQUIVADA.
			 * CUIDADO! PODE HAVER OUTROS STATUS QUE ATRAPALHEM, TALVEZ DEVA CHECAR
			 * 'ARQUIVADA', 'PENDENTE DE ASSINATURA DIGITAL' etc. !s
			 */
			consultaNucleo(cpf, abreDetalhe, false);
		}
		historicoDePropostas();
		extrato();
		saldoCC();
		dadosCC();
		alteracaoConta();
		taloes();
		pessoaFisica();
		// TODO - big consulta manus pess fis
	}

	private static void pessoaFisica() throws Exception {
		String cpf = get_massaparam_cpf();
		HomeTFC home = getHomeTFC();
		home.acessarIconePessoaFisica();

		// DUPLICATE, E NAO CONSIGO MAPEAR VIA SKY!!!
		// home.acessarSubMenuConsultaManutPessFisica();
		AutoItRunner.execute("teclaEnter");

		AbCcDigPfDlgConsManutPesFis dlgConsManutPesFis = factory.getAbCcDigPfDlgConsManutPesFis();
		dlgConsManutPesFis.efetuaPesquisa(cpf);
		if (System.currentTimeMillis() > 0) {
			try {
				factory.getAbCcDigPfDlgInconsistDeConsManutPesFis().clickOk();
			} catch (GeneralLeanFtException glfe) {
				Logger.debug(
						"2018Ago09 - Ignorando GeneralLeanFtException no dialog de inconsistencias AbCcDigPfDlgInconsistDeConsManutPesFis - talvrz seja assim mesmo, e soh apareça de vez em quando");
			}
		} else {
			Logger.debug(
					"ODD DISABLED 2018Ago01 - click em OK de um dialog gera exception. POREM, código parecia estar aqui faz tempo!");
		}

		AbCcDigPfManutDadosBasicosComplPesFis pesFis = null;
		try {
			pesFis = factory.getAbCcDigPManutDadosBasicosComplPesFis();
		} catch (GeneralLeanFtException glfe) {
			Logger.debug(
					"2018Set09 - Ignorando GeneralLeanFtException ao tentar usar dialog AbCcDigPfManutDadosBasicosComplPesFis- lentidao para abrir essa tela por vees é extrema (mesmo com timeout 40 segundos no SETTINGs do LeanFt). Então, tento novamente se deu a exception");
			Logger.imprimeStackTrace(glfe);
			pesFis = factory.getAbCcDigPManutDadosBasicosComplPesFis();
		}
		pesFis.processa(get_massaparam_rendaInformada(), get_massaparam_outrasRendas()); // faz tudo da tea de
																							// manutencao BRPE284
		dlgConsManutPesFis.clickCancelar(); // aih, basta cancelar o dialog onde digitamos CPF
		// E PRONTO!
	}

	private static void taloes() throws Exception {
		HomeTFC home = getHomeTFC();
		home.acessarSubMenuCheques();
		home.acessarSubMenuConsultaManutChequesTaloes();
		home.acessarSubMenuSolicitacaoTaloes();
		AbCcDigPfSolicitacaoTaloes solicitacaoTaloes = factory.getAbCcDigPSolicitacaoTaloes();
		String agencia = DadosExecucao.getDadosFuncionalidade("AGENCIA");
		String conta = DadosExecucao.getDadosFuncionalidade("CONTA");
		solicitacaoTaloes.efetuaPesquisa(agencia, conta);
	}

	private static void saldoCC() throws Exception {
		HomeTFC home = factory.getHomeTFC();
		home.acessarContasServicosBotaoSaldoCC();
		String agencia = DadosExecucao.getDadosFuncionalidade("AGENCIA");
		String conta = DadosExecucao.getDadosFuncionalidade("CONTA");
		factory.getAbCcDigPSaldoCC().fazPesquisa(agencia, conta);

	}

	private static void historicoDePropostas() throws Exception {
		String agencia = DadosExecucao.getDadosFuncionalidade("AGENCIA");
		String conta = DadosExecucao.getDadosFuncionalidade("CONTA");

		HomeTFC home = getHomeTFC();

		home.acessarSubMenuAberturas();
		home.acessarSubMenuControleDeAberturaDePropostasContasNucleo();
		home.acessarSubMenuHistoricoDePropostasContas();
		AbCcDigPfHistAberConta histAberConta = factory.getAbCcDigPHistAberConta();
		histAberConta.fazPesquisa(agencia, conta);
	}

	private static void coreRunScenario() throws Exception {
		voltarPraTelaInicial();
		defineCentro(propertiesTfcServer.getProperty("CENTRO"), true, 5);
		garanteInicioEmContasCorrentesAberturaDigital();
		atehAprovacao(get_massaparam_cpf());
		depoisDaAprovacao(get_massaparam_cpf(), false);
		// false para depoisDaAprovacao=ja pegou AGENCUA e CTA, nai precis abrir detalhe
		// em consultaNucleo
	}

	private static void atehAprovacao(String cpf)
			throws GeneralLeanFtException, IOException, InterruptedException, Exception {

		consultaNucleo(cpf, true, true); // 2018Set11 - se proposta ja aprovada, ja terah e AVANÇAR
		// true para consultaNucleo = abra detalhe soh pra pegar agencia e conta e setar
		// DadosExecucao.setDadosFuncionalidade
		theHomeTfc = getHomeTFC();
		// 2018Set07 - removidos "*CHECK_PROPOSTA_PENDAPROV*" e simiare

		String statusInicialDaProposta = DadosExecucao.getDadosFuncionalidade("STATUS_INICIAL_DA_PROPOSTA");
		if (statusInicialDaProposta.equals(ClasseGenerica.STR_PENDENTE_DE_APROVACAO_DIGITAL)
				|| statusInicialDaProposta.equals(ClasseGenerica.STR_EM_APROVACAO_DIGITAL)) {
			AbCcDigPfPropostaPendAprov pendAprov = chegarEmPendenteDeAprovacao(statusInicialDaProposta, cpf);

			/*
			 * 2018Out26 - adicionado código VOLTAR STATUS PARA PENDENTE se em EM APROVACAO.
			 * Conceitualmente, tela "BRBW0073 - Propostas em Aprovação Digital" deixou de
			 * ser tela que aprova, apesar de (até 2018Out26 2033pm) ainda termos classes
			 * *PropostaEmAprov* extendendo *PropostaEmStatusQueAprova*
			 */

			detalhesDeTelaPendAprov(pendAprov); // sem NEW, sem novo screenshot
			if (System.currentTimeMillis() == 0) {
				throw new RuntimeException("DEBUG, desabilitada a aprovacao");
			} else {
				fazAprovacaoEmPendAprov(pendAprov); // sem NEW, sem novo screenshot
				pendAprov.clickFechar(); // NEW para tirar screenshot depois de aprovacao
			}
		}

		// TODO - continuar daqui. Algumas coisas ja tem dummy/PageObj, outras, apenas
		// MAP BASICO
	}

	/**
	 * create 2018Out26
	 * 
	 * @param statusProposta
	 * @param cpf
	 * @return
	 * @throws Exception
	 */
	private static AbCcDigPfPropostaPendAprov chegarEmPendenteDeAprovacao(String statusProposta, String cpf)
			throws Exception {
		AbCcDigPfPropostaPendAprov pendAprov = null;

		acessarTelaAberturaEmStatusQueAprova(statusProposta);
		AbccDigPfPropostaEditavel telaAprov = factory.getAbCcDigPropostaEmStatusQueAprova(statusProposta);
		telaAprov.pesquisaCpfMostraTabela(cpf);
		if (telaAprov instanceof AbCcDigPfPropostaPendAprov) {
			pendAprov = (AbCcDigPfPropostaPendAprov) telaAprov;
		} else if (telaAprov instanceof AbCcDigPfPropostaEmAprov) {
			AbCcDigPfPropostaEmAprov emAprov = (AbCcDigPfPropostaEmAprov) telaAprov;
			emAprov.clickVoltarFase(); // voltou fase
			Thread.sleep(20 * 1000); // espera 20 segundos para que backend registre retorno de fase da proposta
			emAprov.clickFechar(); // fechou, voltou pra home
			pendAprov = chegarEmPendenteDeAprovacao(ClasseGenerica.STR_PENDENTE_DE_APROVACAO_DIGITAL, cpf);
		} else {
			throw new RuntimeException(
					String.format("ERRO DE IMPLEMENTACAO - telaAprov é instancia de classe invalida, className=%s",
							telaAprov.getClass().getName()));
		}

		return pendAprov;
	}

	public static void voltarPraTelaInicial() throws GeneralLeanFtException {
		if (!CmdUtils.existeJanelaWindowsTerminalCorporativo(RODAR_EXECTFC)) {
			throw new GeneralLeanFtException("existeJanelaWindowsTerminalCorporativo() retornou false");
		}
		Logger.debug("voltarPraTelaInicial() - P00 - INI");

		for (int i = 0; i < 1; i++) {
			CmdUtils.winActivateTfc(RODAR_EXECTFC);
			Logger.debug("LOOP (necessário?) since 2018Out21, voltarPraTelaInicial() - P01, i=%d", i);
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				Logger.imprimeStackTrace(e);
			}
		}
		// AutoItRunner.execute("rightMouseClick");
		// Thread.sleep(3000);
		AutoItRunner.execute("variasTeclasESC");
		Logger.debug("voltarPraTelaInicial() - P02");
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
		}

		if (System.currentTimeMillis() == 0) {
			// INUTIL! Fecha janela SWING deordenadamente sem eventos CLOSE associados bla
			// bla bla.
			ClasseGenerica.chamaDisposeEmJanelas(
					new TerminalFinanceiroCorporativoTFC().TerminalFinanceiroCorporativoWindow());
		} else if (System.currentTimeMillis() == 0) {
			throw new RuntimeException(
					"2018Set9 - TODO - ainda nao sei fazer 'click em botoes de description ok,fechar,cancelar' - ATENCAO - devo me fiar nas abas de janelas abertas do TERMINALTFC, e entao me viro pra me afundar apenas nesse bichinhos e USAR MÈTODOS LeanFT q ainda desconheco!!!");
		}
		Logger.debug("voltarPraTelaInicial() - P03 - FIM");
		// com.hp.lft.sdk.java.Dialog dlg;
		// dlg.close(); - nem precisa de click em botao!
	}

	private static void garanteInicioEmContasCorrentesAberturaDigital() throws Exception {
		//2018Out26 - método renomeado de testarCHegarAoNucleoInicial()
		acessarContasCorrentes(); // MISERÀVI! Faltava até 2018Fev10 95:20am
		HomeTFC home = getHomeTFC(); // NEW para screenshot
		home.acessarSubMenuAberturas();
		home.acessarSubMenuAberturaDePropostasDigitais();
		home.acessarSubMenuAberturaDigitalConsultaNucleo();
		factory.getAbCcDigPPropostaNucleo().fechar();
	}

	private static void consultaNucleo(String cpf, boolean abreDetalhe, boolean isInicial) throws Exception {
		HomeTFC home = getHomeTFC(); // NEW para screenshot

		home.acessarSubMenuAberturas();
		home.acessarSubMenuAberturaDePropostasDigitais();
		home.acessarSubMenuAberturaDigitalConsultaNucleo();
		AbCcDigPfPropostaNucleo aberturaNucleo = factory.getAbCcDigPPropostaNucleo();

		// 2018Set07 - removidos usos de *CHECK_PEND_APROV* e similares

		aberturaNucleo.efetuaPesquisa(cpf, abreDetalhe, isInicial); // seta DadosFunc AG E CTA

		// TODO Auto-generated method stub

	}

	private static void detalhesDeTelaPendAprov(AbCcDigPfPropostaPendAprov propPendAprov) throws Exception {
		Logger.debug("detalhesDeTelaQueAprova(); - init");
		propPendAprov.clickDetalhe();

		AbCcDigPfConsDadosContaPessFis consDadosContaPessFis = factory.getAbCcDigPConsDadosContaPessFis();
		consDadosContaPessFis.validarLimites(get_massaparam_limite());
		Logger.debug(String.format("AbdummyConsDadosContaPessFis() - DadosExecucao.dadosFunc, AGENCIA=%s, CONTA=%s\n",
				DadosExecucao.getDadosFuncionalidade("AGENCIA"), DadosExecucao.getDadosFuncionalidade("CONTA")));
		consDadosContaPessFis.avancar();

		AbCcDigPfConsProdServPesFis consProdServPesFis = factory.getAbCcDigPConsProdServPesFis();
		consProdServPesFis.clickPacoteServicos();
		factory.getAbCcDigPDetPacServ().clickFechar();
		consProdServPesFis.clickCartao();
		factory.getAbCcDigPDetCartao().clickCancelar();

		consProdServPesFis.clickFechar();
		consDadosContaPessFis.fechar();

		Logger.debug("detalhesDeTelaQueAprova(); - end");
	}

	// AutoItRunner.execute("teclaEnter"); //simplista. Vai que cola.

	private static void fazAprovacaoEmPendAprov(AbCcDigPfPropostaPendAprov pendAprov) throws Exception {
		Logger.debug("fazAprovacaoEmPendAprov(); - init");
		pendAprov.clickAnalisar();

		AbCcDigPfAprovaDevolveRejeita aprovDevRej = factory.getAbCcDigPAprovaDevolveRejeita();
		aprovDevRej.clickCadastro();
		AbCcDigPfManutCadPesFisRapido manutCadPesFisRapido = factory.getAbCcDigPManutCadPesFisRapido();
		manutCadPesFisRapido.clickCancelar();

		aprovDevRej.clickAprovacao();
		AbCcDigPfAlertAprovadaSucesso alertAprovadaSucesso = factory.getAbCcDigPAlertAprovadaSucesso();
		alertAprovadaSucesso.clickOk();

		Logger.debug("fazAprovacaoEmPendAprov(); - end");
	}

	private static void dadosCC() throws Exception {
		HomeTFC home = factory.getHomeTFC();
		home.acessarSubMenuConsultas();
		home.acessarSubMenuDadosDaConta();
		home.acessarSubMenuDadosDeContaCorrente();
		String agencia = DadosExecucao.getDadosFuncionalidade("AGENCIA");
		String conta = DadosExecucao.getDadosFuncionalidade("CONTA");
		factory.getAbCcDigPConsDadosBasicosCC().processa(agencia, conta);

	}

	private static void extrato() throws Exception {
		HomeTFC home = factory.getHomeTFC();
		home.acessarContasServicosBotaoExtrato();
		String agencia = DadosExecucao.getDadosFuncionalidade("AGENCIA");
		String conta = DadosExecucao.getDadosFuncionalidade("CONTA");
		factory.getAbCcDigPExtrato().efetuaPesquisa(agencia, conta);
	}

	private static void alteracaoConta() throws Exception {
		HomeTFC home = factory.getHomeTFC();
		home.acessarSubMenuConsultas();
		home.acessarSubMenuSolicInfoHistoricas();
		home.acessarSubMenuAltaracaoDaConta();

		String agencia = DadosExecucao.getDadosFuncionalidade("AGENCIA");
		String conta = DadosExecucao.getDadosFuncionalidade("CONTA");
		factory.getAbCcDigPAlteracaoConta().efetuaPesquisa(agencia, conta);
	}

	private static void acessarTelaAberturaEmStatusQueAprova(String statusInicialDaProposta) throws Exception {
		// TODO Auto-generated method stub
		HomeTFC home = getHomeTFC();
		home.acessarSubMenuAberturas();
		home.acessarSubMenuAberturaDePropostasDigitais();
		if (statusInicialDaProposta.equals(ClasseGenerica.STR_PENDENTE_DE_APROVACAO_DIGITAL)) {
			home.acessarSubMenuAberturaDigitalPendenteDeAprovacao();
		} else if (statusInicialDaProposta.equals(ClasseGenerica.STR_EM_APROVACAO_DIGITAL)) {
			home.acessarSubMenuAberturaDigitalEmAprovacao();
		}
	}

	private static HomeTFC getHomeTFC() throws Exception {
		if (theHomeTfc == null) {
			theHomeTfc = factory.getHomeTFC();
		} else {
			if (System.currentTimeMillis() > 0) {
				// nada, deixa retornar valor ja definido
				Logger.debug("getHomeTFC(); - retornando homeTFC salvo, apesar de suspeita que tive,"
						+ "de que retornar valor pre-obtido em theHomeTFC() pode estar ligado a estranhos erros");
				theHomeTfc = factory.getHomeTFC();

			} else {
				Logger.debug("getHomeTFC(); - sempre retornando [factory.getHomeTFC()],"
						+ "eu suspeito que retornar valor pre-obtido em theHomeTFC() pode estar ligado a estranhos erros");
				theHomeTfc = factory.getHomeTFC();
			}
		}
		return theHomeTfc;

	}

	private static HomeTFC acessarContasCorrentes() throws Exception {
		HomeTFC home = factory.getHomeTFC();
		home.acessarMenuContasServicos();
		home.acessarSubMenuContasCorrentes();
		return home;
	}

	public static void rebootarTfc_e_fazerLogon() throws Exception {
		Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - P00");
		if (RODAR_EXECTFC == FabricaObjAberturaMgr.LEANFT) {
			CmdUtils.finalizaProcessosAbertos();
		} else {
			CmdUtils.finalizaMockProcessos();
		}
		Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - P00.1");

		Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - P00.2");

		CmdUtils.startExecTfcBat(RODAR_EXECTFC);

		Logger.debug(
				"TfcMain::rebootarTfc_e_fazerLogon() - P02 - rodou execTFC;bat, e nao vai dormir nada, apenas tentar achar img do logon");

		boolean okLogon = false; // 2018Fev17 - reativanado detecçço de dialog de Logon: desta vez, com BUSCA DE
									// IMAGEM

		final int logon_segundos = get_logon_dialog_segundos();

		if (!okLogon) {
			Logger.debug(String.format(
					"TfcMain::rebootarTfc_e_fazerLogon() - reativando deteccaoo de dialog de Logon, tempo=%s segundos: desta vez, com BUSCA DE IMAGEM",
					logon_segundos));
		}

		int elapsed = 0;
		long tIni = System.currentTimeMillis();
		while (!okLogon) {
			elapsed = (int) ((System.currentTimeMillis() - tIni) / 1000);
			Logger.debug(String.format(
					"TfcMain::rebootarTfc_e_fazerLogon() - DETECTANDO LOGON DIALOG: okLogon ainda false, logon_segundos=%d, elapsed=%d",
					logon_segundos, elapsed));

			if (elapsed > logon_segundos) {
				break;
			}
			// < 1000 * logon_segundos) {
			/*
			 * 2018Out19 - desabilitando checagem de existeJanelaWindowsTerminalCorporativo,
			 * talvez seja incompativel com "maquina com varios processos java/javaw"
			 *
			 **/
			if (System.currentTimeMillis() == 0) {
				if (!CmdUtils.existeJanelaWindowsTerminalCorporativo(RODAR_EXECTFC)) {
					Logger.debug(
							"TfcMain::rebootarTfc_e_fazerLogon() - ATENCAO - BIZARRE - um javaw.exe é derrubado se tentar detectar elementos antes da janela ativa!");
					Thread.sleep(2 * 1000);
					continue;
				}
			}
			Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - antes de chamar winActivateTFC()");
			CmdUtils.winActivateTfc(RODAR_EXECTFC);
			Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - depois de chamar winActivateTFC()");

			Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - antes de chamar imagenDialogLogonPresente()");
			int retAutoitImg = AutoItRunner.execute("tfc_imglogon_find");
			okLogon = (retAutoitImg == 0);
			Logger.debug(String.format(
					"TfcMain::rebootarTfc_e_fazerLogon() - depois de chamar imagenDialogLogonPresente(), okLogon=%b",
					okLogon));
			// okLogon = true; - rbattaglia, 2018Mar20 - DAMN! Corrigido, setar pra true
			// aqui a var okLogon provavelmente fazia app esperar pouco tempo demais pelo
			// dialog!!
			Thread.sleep(1000 * 2);
		}
		if (!okLogon) {
			throw new RuntimeException(
					"Nao conseguiu detectar dialog de logon depois de rodar execTFC.bat, depois de esperar os segundos e/ou checar image, whatever");
		}
		Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - antes de chamar fazer_login_tfc");
		fazer_login_TFC(TfcProperties.getLoginValue("USUARIO"), TfcProperties.getLoginValue("SENHA"));
		Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - depois de chamar fazer_login_tfc");

		/*
		 * 2018Out25 - pode modificar o centro do usuario TFC, evitando conflitos
		 * 2018Out28 - propriedade CENCTRO agora deve ser enviada boot e nao mais em tfc_login.properties, pra setar no inicio
		 */
		String centro = propertiesTfcServer.getProperty("CENTRO");
		Logger.debug(
				"TfcMain::rebootarTfc_e_fazerLogon() - centro=%s, se for not null vai chamar defineCentro(centro)",
				centro);
		defineCentro(centro, true, 5);
		Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - centro=%s, chamou defineCentro(centro)", centro);

		Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - antes de chamar testaChegarAoNucleoInicial");
		garanteInicioEmContasCorrentesAberturaDigital();
		Logger.debug("TfcMain::rebootarTfc_e_fazerLogon() - depois de chamar testaChegarAoNucleoInicial");
	}

	private static void defineCentro(String centro, boolean trazerTfcTopo, int segundosSleep)
			throws Exception, InterruptedException {
		Logger.debug("TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, INI",
				centro, trazerTfcTopo, segundosSleep);
		if (centro == null || centro.isEmpty()) {
			Logger.debug(
					"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, centro eh null ou vazio, retornando",
					centro, trazerTfcTopo, segundosSleep);
			return;
		}

		if (trazerTfcTopo) {
			Logger.debug(
					"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, vai chamar winActivateTfc",
					centro, trazerTfcTopo, segundosSleep);
			CmdUtils.winActivateTfc(RODAR_EXECTFC); // traz pra topo, just in case
			Logger.debug(
					"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, chamou winActivateTfc",
					centro, trazerTfcTopo, segundosSleep);
		}

		Logger.debug(
				"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, antes de clicar",
				centro, trazerTfcTopo, segundosSleep);
		getHomeTFC().acessarIconeArquitectura();
		Logger.debug(
				"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, depois de clicar botao",
				centro, trazerTfcTopo, segundosSleep);

		if (segundosSleep > 0) {
			Logger.debug(
					"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, antes de sleep",
					centro, trazerTfcTopo, segundosSleep);
			Thread.sleep(5 * 1000);
			Logger.debug(
					"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, depois de sleep",
					centro, trazerTfcTopo, segundosSleep);
		}

		if (System.currentTimeMillis() == 0) {
			// 2018Out28 - estranhamente, nao reage à chamada a acessarSubMenuSubRestitTerm.
			// ALternativa: AUTOIT TECLA ENTER
			Logger.debug(
					"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, vai chamar acessarSubMenuSubRestitTerm",
					centro, trazerTfcTopo, segundosSleep);
			getHomeTFC().acessarSubMenuSubRestitTerm();
			Logger.debug(
					"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, chamou acessarSubMenuSubRestitTerm",
					centro, trazerTfcTopo, segundosSleep);
		} else {
			Logger.debug(
					"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, vai chamar autoIT teclaEnter",
					centro, trazerTfcTopo, segundosSleep);
			AutoItRunner.execute("teclaEnter");
			Logger.debug(
					"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, vai chamou autoIT teclaEnter",
					centro, trazerTfcTopo, segundosSleep);
		}

		Logger.debug(
				"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, vai chamar modificaCentro",
				centro, trazerTfcTopo, segundosSleep);
		factory.getAbgetCcDigPfSubstituiRestituiTerminal().modificaCentro(centro);
		Logger.debug(
				"TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, chamou modificaCentro",
				centro, trazerTfcTopo, segundosSleep);

		Logger.debug("TfcMain::defineCentro(String centro) - centro=%s, trazerTfcTopo=%b, segundosSleep=%d, FIM",
				centro, trazerTfcTopo, segundosSleep);
	}

	/**
	 * tempo bastante alto, se estourar limite do chamador (seja Ruby/Cucumber ou
	 * outro), java todo deve ser derrubado pelo chamador. OK já dei uns bons
	 * segundos pra LftRuntime. TIMEOUT do chamador deve ser maior que a soma do
	 * tempo de LFTRuntime com o de SUBIR APP/LOGIN/ETC. de método
	 * "TfcMain::rebootarTfc_e_fazerLogon".
	 * 
	 * Se uma maquina for tao lenta que estes tempos se tornem insuficientes,
	 * devemos desabilitar uso do TFC nessa maquina, pq ela estará sendo um estorvo,
	 * em vez de contribuir no processamento!!
	 * 
	 * --> Lógica similar se aplica ao processamento de um comando individual para
	 * um CPF. <--
	 * 
	 * OBS em 2018Out25 - talvez estes tempos, daqui do SERVIDOR e da CHAMADORA,
	 * possao ser configurados máquina a máquina. Aliás, sim, esses tempos PODEM ser
	 * configurados máquina-a-máquina ou até de acordo com outras questoes (lentidao
	 * conhecida em servidor etc.), mas isso ainda nao foi implementado até
	 * 2018Out25.
	 */
	private static int get_logon_dialog_segundos() {
		return 500;
	}

	public static void fazer_login_TFC(String usuario, String senha) throws Exception {
		LogonTFC logon = factory.getLogonTFC();
		logon.realizarLogin(usuario, senha);
	}

	public static void inicializaConfiguracaoDeComando() throws IOException {
		propertiesTfcServer = TfcProperties.getProperties(TfcProperties.getCaminhoCompletoCmdDestino());
		DadosExecucao.setPropertiesDoComando(propertiesTfcServer);
		// salva as propriedases cruas do comando

		TfcProperties.deleteProperties(); // 2018Fev15 03:17am, ainda DIR_ORIGEM/TFC_CMD.PROPERTIES NAO DESAPARECE blues
											// blues blues!

		Logger.setFullFilePath(propertiesTfcServer.getProperty("CAMINHO_LOG"));

		Logger.setInterruptedFilePath(propertiesTfcServer.getProperty("ARQUIVOS_INTERRUPCAO"));

		Logger.debug("inicializarMassa,P01");
		Evidencias.inicializaContadorAcao();
		Logger.debug("inicializarMassa,P02");
		DadosExecucao.setCaminhoCompletoDaEvidencia(propertiesTfcServer.getProperty("DIR_REPORT"));
		Logger.debug("inicializarMassa,P03");
		DadosExecucao.setIdExecucao(LocalDateUtils.getDataHora());
		Logger.debug("inicializarMassa,P04");

		TfcProperties.setGlobalScenarioCount(get_cmd_numero_globalScenario());

		// ExcelUtils massa = new ExcelUtils(xlsMassa);
		// Logger.debug("inicializarMassa,P05");
		// DadosExecucao.setMassaHash(massa.carregarMassaHash());
		// Logger.debug("inicializarMassa,P06");
	}

	/**
	 * Espera arquivos TXT em loop eterno, rodando automaçço de acordo com comandos/
	 * arquivos encontrados em certo diretório,
	 * 
	 * @author x140824-rbattaglia
	 * @throws Exception
	 */
	private static void tfcServer() throws Exception {
		Files.move(TfcProperties.getPathCmdOrigem(), TfcProperties.getPathCmdDestino());
		Logger.setFullFilePath(
				TfcProperties.getPropertyValue(TfcProperties.getCaminhoCompletoCmdDestino(), "CAMINHO_LOG"));
		inicializaFabricaDeObjetos();
		// nao deleta cmdOrigem aqui pq futuramente podemos querer ler PROPS dele
		escreveOutputTfc("OK", "Servidor Java TFC no ar",
				TfcProperties.getProperties(TfcProperties.getCaminhoCompletoCmdDestino())); // avisa que JAVA subiu

		// Files.deleteIfExists(getPathCmdOrigem());
		// Files.deleteIfExists(getPathCmdDestino());

		while (true) {
			Logger.setProcessandoFinalizacao(false);
			DadosExecucao.setInterrompido(false);
			// 2018Out10 am, property renomeada: agora, pode conter varios arquivos
			// separados por vírgula
			processaUmComandoTfc();
			try {
				Thread.sleep(1000 * 5);
			} catch (InterruptedException e) {
				Logger.imprimeStackTrace(e);
			}
		}
	}

	private static void inicializaFabricaDeObjetos() {
		factory = FabricaObjAberturaMgr.getFactory();
	}

	private static void processaUmComandoTfc() throws Exception {
		boolean processouCmd = false;
		try {
			processouCmd = core_processaUmComandoTfc();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			escreveOutputTfc("ERRO", String.format("Classe:%s . Msg:%s", e.getClass().getName(), e.getMessage()),
					propertiesTfcServer);

			Logger.imprimeStackTrace(e);

			for (int i = 0; i < 10; i++) {
				Logger.debug("Deve escrever/appendar ao arquivo de output dizendo que deu ruim. \n"
						+ " -- E MAIS NADA! Deixa a proxima execucao se virar pra iniciar,ver se ok e possivel RESTART/REEXECUTE");
			}
		}
		if (processouCmd) {
			escreveOutputTfc("OK", null, propertiesTfcServer);
			Logger.debug("JA deve ter escrito/appendado ao arquivo de output dizendo que foi ok. \n");
		} else {
			// nada
		}
	}

	private static void escreveOutputTfc(String status, String mensagem, Properties inputProps) throws Exception {
		CmdUtils.imprimeStack(String.format("status=%s, mensagem=%s\n", status, mensagem));

		Properties p = new Properties();
		p.setProperty("RUN_STATUS", status);
		if (mensagem != null) {
			p.setProperty("MENSAGEM", mensagem);
		}
		// 2018Set07 - removidos "*CHECK_PROPOSTA_PENDAPROV*" e simiares

		TfcProperties.appendProperties(p, inputProps);

		String propFile = getCaminhoCompletoOutOrigem();
		TfcProperties.saveProperties(p, propFile);
		CmdUtils.imprimeStack(String.format("retornando de escreveOutputTfc depois de gravar status=%s e mensagem=%s",
				status, mensagem));
	}

	public static String getCaminhoCompletoOutOrigem() {
		return "../tfc_origem/tfc_out.properties";
	}

	private static boolean core_processaUmComandoTfc() throws Throwable {
		try {
			Files.move(TfcProperties.getPathCmdOrigem(), TfcProperties.getPathCmdDestino());
			if (Files.exists(TfcProperties.getPathCmdOrigem())) {
				throw new IOException("ARQUIVO DE ORIGEM EXISTE IMEDIATAMENTE APÒS MOVER COM SUCESSO! ERRO CRASSO!");
			}
			// ATOMIC_MOVE inutil aqui, NAO USAR
		} catch (Exception e) {
			// falha ao mover... quer dizer que nao existia.
			// Logger.imprimeStackTrace(e);
			// Logger.imprimeStackTrace(e);
			Logger.debug(
					"Nao moveu arquivo TXT em core_processaUmComandoTfc();, alguma excecao, ignorando. Nada a fazer");
			return false;
		}

		Logger.debug("VAI PROCESSAR OUTRO COMANDO");
		String prevLogFullFilePath = Logger.getFullFilePath();
		try {
			inicializaConfiguracaoDeComando();
			Evidencias.screenshotDaTelaInteira("ANTES");
			initLeanFt();

			if (propertiesTfcServer.getProperty("CPF") != null) {
				Logger.debug("COMANDO COM CPF");
				// arquivo com CPF=executar cenario
				if (propertiesTfcServer.getProperty("NOTNULL_GAMBIARRA") == null) {
					doTfcScenario();
				} else {
					doTfcGambiarra();
				}
			} else {
				Logger.debug("COMANDO SEM CPF, BOOT!!!");
				rebootarTfc_e_fazerLogon();
			}
		} catch (Exception e) {
			Logger.imprimeStackTrace(e);
			throw e; // 2018Fev15 01:58am - HMMM, antes, nao dava throw, e NAO DIZIA SE FOI OK OU
						// RRO! DAVA SEMPRE OK!
		} finally {
			Evidencias.screenshotDaTelaInteira("DEPOIS");
		}
		Logger.setFullFilePath(prevLogFullFilePath);

		if (Files.exists(TfcProperties.getPathCmdOrigem())) {
			for (int i = 0; i < 10; i++) {
				Logger.debug(
						"ARQUIVO DE ORIGEM EXISTE AO FIM DA ROTINA QUE O MOVEU! INDICADOR DE ANORMALIDADE QUE PODE ER NAO ABORTIVA!!");
			}
		}
		return true;
	}

	// doTfcGambiarra

	private static void doTfcScenario() throws InterruptedException, IOException, Exception {
		coreRunScenario();
	}

	private static void doTfcGambiarra() throws InterruptedException, IOException, Exception {
		defineCentro(propertiesTfcServer.getProperty("CENTRO"), true, 5);
		// pessoaFisica();
		/*
		 * acessarContasCorrentes(); depoisDaAprovacao(get_massaparam_cpf(), true);
		 */
	}

}
