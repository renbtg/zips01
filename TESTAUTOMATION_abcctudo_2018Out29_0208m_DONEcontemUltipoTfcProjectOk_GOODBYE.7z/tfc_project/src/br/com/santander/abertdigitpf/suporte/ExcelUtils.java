package br.com.santander.abertdigitpf.suporte;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.format.CellNumberFormatter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Clase que encapsula as operações com Excel
 * 
 * @author Denis Luna Borges da Silva
 *
 */
public class ExcelUtils {
	private String fileName;
	private XSSFWorkbook wb;
	private XSSFSheet planilha;
	private static String cvsSeparator = ";";

	/**
	 * Construtor vazio da classe, permitindo que se escolha o arquivo a ser aberto
	 * através dos métodos setNomePlanilha
	 */
	public ExcelUtils() {
	}

	/**
	 * Construtor com parâmetro de nome do arquivo, permitindo a abertura de
	 * qualquer arquivo do excel
	 * 
	 * @param fileName
	 *            nome do arquivo a ser aberto
	 */
	public ExcelUtils(String fileName) {
		this.fileName = fileName;
		this.abrePlanilha();
	}

	/**
	 * Método que retorna o objeto manipulador de arquivos do excel
	 * 
	 * @return atributo do tipo XSSFSheet {@link XSSFSheet}
	 */
	public XSSFSheet getPlanilha() {
		return this.planilha;
	}

	/**
	 * Método que retorna o nome do arquivo
	 * 
	 * @return String com o caminho do arquivo aberto
	 */
	public String getFileName() {
		return this.fileName;
	}

	/**
	 * Método que retorna a planilha aberta
	 * 
	 * @return atributo do tipo XSSFWorkbook {@link XSSFWorkbook}
	 */
	public XSSFWorkbook getWorkBook() {
		return this.wb;
	}

	/**
	 * Método que abre a planilha
	 */
	public void abrePlanilha() {
		try {
			this.wb = new XSSFWorkbook(new FileInputStream(new File(this.getFileName())));
		} catch (IOException ex) {
			ex.printStackTrace();
		}

		this.planilha = this.getWorkBook().getSheetAt(0);
	}

	/**
	 * Método que grava as alterações efetuadas na planilha
	 */
	public void salvaPlanilha() {
		FileOutputStream arquivoSaida = null;
		try {
			arquivoSaida = new FileOutputStream(new File(this.getFileName()));
			this.getWorkBook().write(arquivoSaida);
			arquivoSaida.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public void salvaPlanilha(String novoNome) {
		FileOutputStream arquivoSaida = null;
		try {
			arquivoSaida = new FileOutputStream(new File(novoNome));
			this.getWorkBook().write(arquivoSaida);
			arquivoSaida.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	public void salvaPlanilhaRetro() {
		FileOutputStream arquivoSaida = null;
		try {
			String filename = (this.getFileName());
			int begin = 0;
			int end = filename.length()-11;
			String novoArquivo = filename.substring(begin,end) + "dataatual";
			arquivoSaida = new FileOutputStream(new File( novoArquivo ) );
			
					
			this.getWorkBook().write(arquivoSaida);
			arquivoSaida.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	/**
	 * Método que pega o valor de uma célula em texto
	 * 
	 * @param linha
	 *            inteiro que representa a linha da célula desejada, iniciando em 0
	 * @param coluna
	 *            inteiro que representa a coluna da célula desejada, iniciando em 0
	 * @return String com o texto contido na célula encontrada
	 */
	public String getTextoCelula(int linha, int coluna) {
		String textoCelula;
		try {
			if (this.getPlanilha().getRow(linha) == null) {
				return null;
			}
			textoCelula = this.getPlanilha().getRow(linha).getCell(coluna).getStringCellValue();
		} catch (Exception ex) {
			try { 
				textoCelula = Integer.toString((int) this.getPlanilha().getRow(linha).getCell(coluna).getNumericCellValue());
			} catch (Exception ex2) {
				textoCelula = null;
			}
		}

		return textoCelula;
	}

	/**
	 * Método que pega o texto absoluto de uma célula
	 * 
	 * @param linha
	 *            inteiro que representa a linha da célula desejada, iniciando em 0
	 * @param coluna
	 *            inteiro que representa a coluna da célula desejada, iniciando em 0
	 * @return String com o texto absoluto contido na célula encontrada
	 */
	public String getTextoSimplesCelula(int linha, int coluna) {
		String textoCelula;

		textoCelula = this.getPlanilha().getRow(linha).getCell(coluna).getStringCellValue();

		String stringFormat = this.getPlanilha().getRow(linha).getCell(coluna).getCellStyle().getDataFormatString();
		CellNumberFormatter fmt = new CellNumberFormatter(stringFormat);
		textoCelula = fmt.format(this.getPlanilha().getRow(linha).getCell(coluna).getNumericCellValue());

		return textoCelula;
	}

	/**
	 * Método que pega o valor da célula em Double
	 * 
	 * @param linha
	 *            inteiro que representa a linha da célula desejada, iniciando em 0
	 * @param coluna
	 *            inteiro que representa a coluna da célula desejada, iniciando em 0
	 * @return Double com o valor contido na célula encontrada
	 */
	public double getValorCelulaDouble(int linha, int coluna) {
		double valorCelula;
		try {
			valorCelula = this.getPlanilha().getRow(linha).getCell(coluna).getNumericCellValue();
		} catch (Exception ex) {
			valorCelula = Double.parseDouble(this.getPlanilha().getRow(linha).getCell(coluna).getStringCellValue());
		}

		return valorCelula;

	}

	/**
	 * Método que pega o valor da célula em int
	 * 
	 * @param linha
	 *            inteiro que representa a linha da célula desejada, iniciando em 0
	 * @param coluna
	 *            inteiro que representa a coluna da célula desejada, iniciando em 0
	 * @return inteiro com o valor contido na célula encontrada
	 */
	public int getValorCelulaInt(int linha, int coluna) {
		int valorCelula;
		try {
			valorCelula = (int) this.getPlanilha().getRow(linha).getCell(coluna).getNumericCellValue();
		} catch (Exception ex) {
			valorCelula = Integer.parseInt(this.getPlanilha().getRow(linha).getCell(coluna).getStringCellValue());
		}

		return valorCelula;
	}

	/**
	 * Método que insere o valor em texto em uma célula
	 * 
	 * @param linha
	 *            inteiro que representa a linha da célula desejada, iniciando em 0
	 * @param coluna
	 *            inteiro que representa a coluna da célula desejada, iniciando em 0
	 * @param value
	 *            String com o texto a ser inserido na célula
	 */
	public void setTextoCelula(int linha, int coluna, String value) {
		this.getPlanilha().getRow(linha).getCell(coluna).setCellValue(value);
	}

	/**
	 * Método que insere o valor em Double em uma célula
	 * 
	 * @param linha
	 *            inteiro que representa a linha da célula desejada, iniciando em 0
	 * @param coluna
	 *            inteiro que representa a coluna da célula desejada, iniciando em 0
	 * @param value
	 *            Double com o valor a ser inserido na célula
	 */
	public void setValorCelulaDouble(int linha, int coluna, double value) {
		this.getPlanilha().getRow(linha).getCell(coluna).setCellValue(value);
	}

	/**
	 * Método que insere o valor em int em uma célula
	 * 
	 * @param linha
	 *            inteiro que representa a linha da célula desejada, iniciando em 0
	 * @param coluna
	 *            inteiro que representa a coluna da célula desejada, iniciando em 0
	 * @param value
	 *            int ocm o valor a ser inserido na célula
	 */
	public void setValorCelulaInt(int linha, int coluna, int value) {
		this.getPlanilha().getRow(linha).getCell(coluna).setCellValue(value);
	}

	/**
	 * Método que retorna lista com os itens de uma coluna
	 * 
	 * @param coluna
	 *            çndice da coluna desejada
	 * @return List com os valores encontrados na coluna
	 */
	public List<String> itensColuna(Integer coluna) {
		List<String> valores = new ArrayList<String>();
		for (Row r : this.getWorkBook().getSheetAt(0)) {
			Cell c = r.getCell(coluna);
			if (c != null) {
				valores.add(c.getStringCellValue());
			}
		}

		return valores;
	}

	/**
	 * Método que procura um texto em uma planilha, e retorna o çndice da linha onde
	 * o texto foi encontrado
	 * 
	 * @param textoCelula
	 *            valor a ser encontrado em uma célula
	 * @return nçmero da linha onde o texto foi encontrado. Caso o texto nço tenha
	 *         sido encontrado, retorna 1
	 */
	public int achaLinhaPorTexto(String textoCelula) {
		for (Row linha : this.getWorkBook().getSheetAt(0)) {
			for (Cell celula : linha) {
				if (celula.getCellType() == Cell.CELL_TYPE_STRING) {
					if (celula.getRichStringCellValue().getString().trim().equals(textoCelula)) {
						return linha.getRowNum();
					}
				}
			}
		}
		return 1;
	}

	public int achaLinhaPorTextoR(String textoCelula) {
		for (Row linha : this.getWorkBook().getSheetAt(0)) {
			for (Cell celula : linha) {
				if (celula.getCellType() == Cell.CELL_TYPE_STRING) {
					if (celula.getRichStringCellValue().getString().trim().equals(textoCelula)) {
						return linha.getRowNum();
					}
				}
			}
		}
		return -1;
	}

	/**
	 * Método retorna massa da planilha em um objeto HashTable
	 * 
	 * @return retorna HashTable
	 */
	public Hashtable<String, String> carregarMassaHash() {

		Hashtable<String, String> massa = new Hashtable<String, String>();
		int coluna = 0;

		while (true) {
			Object t=this.getPlanilha().getRow(0).getCell(coluna);
			if (t == null) {
				break;
			}
		
			String chave=getTextoCelula(0, coluna);
			String valor=getTextoCelula(1, coluna);
			if (chave != null && valor != null) {
				massa.put(chave, valor);
			}
			coluna++;
		}
		return massa;
	}

	public static void geraArquivoDeCSVParaExcel(String nameCSVFile) {
		String currentLine = null;
		BufferedReader br = null;
		int rowNumber = 0;

		try {
			String csvFile = nameCSVFile + ".csv"; // csv file address
			String xlsxFile = nameCSVFile + ".xlsx"; // xlsx file address final
			XSSFWorkbook workBook = new XSSFWorkbook();
			XSSFSheet sheet = workBook.createSheet("Sheet1");

			br = new BufferedReader(new InputStreamReader(new FileInputStream(csvFile), "ASCII"));

			while ((currentLine = br.readLine()) != null) {
				String[] str = currentLine.split(cvsSeparator);

				XSSFRow currentRow = sheet.createRow(rowNumber);
				for (int i = 0; i < str.length; i++) {
					currentRow.createCell(i).setCellValue(str[i]);
				}

				rowNumber++;
			}

			br.close();

			FileOutputStream fileOutputStream = new FileOutputStream(xlsxFile);
			workBook.write(fileOutputStream);
			Logger.debug(xlsxFile);
			fileOutputStream.close();

			// br = new BufferedReader(new FileReader(xlsxFiletemp));
			// BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new
			// FileOutputStream(xlsxFile), "ASCII"));
			// char[] buffer = new char[16384];
			// int read;
			// while ((read = br.read(buffer)) != -1) {
			// bw.write(buffer, 0, read);
			// }
			// br.close();
			// bw.close();

			Logger.debug("Planilha gerada");
		} catch (IOException ioe) {
			Logger.imprimeStackTrace(ioe);
		}
	}
	
	public static void geraArquivoCSVAtualizado(String inputFileXlsx) {
		geraArquivoCSVAtualizado(inputFileXlsx, inputFileXlsx.split("xlsx")[0] + "csv");
	}

	public static void geraArquivoCSVAtualizado(String inputFile, String outputFile) {
		StringBuffer data = new StringBuffer();

		try {
			FileOutputStream fos = new FileOutputStream(new File(outputFile));

			XSSFWorkbook workBook = new XSSFWorkbook(new FileInputStream(inputFile));
			XSSFSheet sheet = workBook.getSheetAt(0);
			Row row;
			Cell cell;

			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				row = rowIterator.next();

				for(int i=0; i<row.getLastCellNum(); i++) {
					if (i != 0) {
						data.append(cvsSeparator);
					}
					cell = row.getCell(i, Row.CREATE_NULL_AS_BLANK);
					data.append(cell.toString());
					Logger.debug(data.toString());
				}
				
				data.append("\r\n");
			
//				int a = 0;
//				while (cellIterator.hasNext()) {
//					if (a != 0) {
//						data.append(cvsSeparator);
//					}
//					cell = cellIterator.next();
//					//data.append(cell.getStringCellValue());
//					
//
//					switch (cell.getCellType()) {
//					// case Cell.CELL_TYPE_BOOLEAN:
//					// data.append(cell.getBooleanCellValue() + cvsSeparator);
//					// break;
//					// case Cell.CELL_TYPE_NUMERIC:
//					// data.append(cell.getNumericCellValue() + cvsSeparator);
//					// break;
//					// case Cell.CELL_TYPE_STRING:
//					// data.append(cell.getStringCellValue() + cvsSeparator);
//					// break;
//					//
//					case Cell.CELL_TYPE_BLANK:
//						data.append("");
//					default:
//						data.append(cell.getStringCellValue());
//					}
//					Logger.debug(data);
//					a++;
//				}
//				Logger.debug(a);
//
//				if (cellIterator.hasNext()) {
//					data.append("\r\n");
//				} else {
//					data.append("\r\n");
//				}
			}

			fos.write(data.toString().getBytes());
			fos.close();

		} catch (Exception ioe) {
			Logger.imprimeStackTrace(ioe);
		}

		Logger.debug("CSV Gerado com sucesso!");
	}
}
