package br.com.santander.abertdigitpf.suporte;

import java.awt.AWTException;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;

import org.apache.commons.lang3.StringUtils;

public class Evidencias {

	private static String extensao = "png";
	private static String evidenciaHome = "C:/evidências/";
	private static Path diretorio;
	private static int contadorAcao;

	public static void evidenciarAcao(RenderedImage print) throws IOException {
		evidenciarAcao(print, "");
	}

	public static String dataHoraComoRuby() {
		String desiredStringFormat = "yyMMdd-HHmmss";

		SimpleDateFormat outputFormat = new SimpleDateFormat(desiredStringFormat);

		String retval = "";
		Date date = new Date();
		retval = outputFormat.format(date);
		return retval;
	}

	public static void screenshotDaTelaInteira(String pComentario) throws IOException {
		try {
			String comentario = pComentario;
			comentario = comentario + Thread.currentThread().getStackTrace()[3].getMethodName();
			comentario = comentario.replaceAll("[^A-Za-z0-9]", ""); //regex
	
			
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();  
			GraphicsDevice[] screens = ge.getScreenDevices();       
			Rectangle allScreenBounds = new Rectangle();  
			for (GraphicsDevice screen : screens) {  
			       Rectangle screenBounds = screen.getDefaultConfiguration().getBounds();        
			       allScreenBounds.width += screenBounds.width;  
			       allScreenBounds.height = Math.max(allScreenBounds.height, screenBounds.height);
			       allScreenBounds.x=Math.min(allScreenBounds.x, screenBounds.x);
			       allScreenBounds.y=Math.min(allScreenBounds.y, screenBounds.y);
			} 
			Robot robot = null;
			robot = new Robot();
			BufferedImage bufferedImage = robot.createScreenCapture(allScreenBounds);
	
			
			File img;
			if (DadosExecucao.getCaminhoCompletoDaEvidencia() == null) {
				img = new File(diretorioEvidencia() + "/" + StringUtils.leftPad(String.valueOf(contadorAcao), 4, "0") + "_"
						+ comentario + "." + extensao);
			} else {
				String shortComentario = comentario;
				int lTot = comentario.length();
				if (lTot > 50) shortComentario = comentario.substring(0, 50-1);
				String fpath = String.format("%s/%s_tfc_%04d.%s.fullScr.tfc.%s", diretorioEvidencia(), dataHoraComoRuby(),
						contadorAcao, shortComentario, extensao);
				//2018Set07 - adicionado comentario (max 50 chars) ao nome de arquivo do TFC
	
				// img = new File(diretorioEvidencia() + "/" + dataHoraComoRuby() + "_"
				// + StringUtils.leftPad(String.valueOf(contadorAcao), 4, "0") + "_tfc_" /*+
				// comentario +*/ "." + extensao);
				img = new File(fpath);
			}
			Logger.debug(String.format("JAVA tirando screenshot, arquivo=%s\n", img.getCanonicalPath()));
			img.getParentFile().mkdirs();
			ImageIO.write(bufferedImage, extensao, img);
		} catch (IOException | AWTException e) {
			Logger.imprimeStackTrace(e);
		}
		
		return;
	}

	public static void evidenciarAcao(RenderedImage print, String pComentario)  {
		try {
			Logger.debug(String.format("pComentario=%s, DadosExecucao.getCaminhoCompletoDaEvidencia()=%s",pComentario, DadosExecucao.getCaminhoCompletoDaEvidencia()==null?"null":DadosExecucao.getCaminhoCompletoDaEvidencia()));
			contadorAcao++;
			String comentario = pComentario;
			comentario = comentario + Thread.currentThread().getStackTrace()[3].getMethodName();
			comentario = comentario.replaceAll("[^A-Za-z0-9]", ""); //regex
	
			// rbattaglia-2018Fev09 // File img = new File(diretorioEvidencia() + "/" +
			// StringUtils.leftPad(String.valueOf(contadorAcao), 4, "0") + "_" + comentario
			// + "." + extensao);
			File img;
			if (DadosExecucao.getCaminhoCompletoDaEvidencia() == null) {
				img = new File(diretorioEvidencia() + "/" + StringUtils.leftPad(String.valueOf(contadorAcao), 4, "0") + "_"
						+ comentario + "." + extensao);
			} else {
				String shortComentario = comentario;
				int lTot = comentario.length();
				if (lTot > 50) shortComentario = comentario.substring(0, 50-1);
				String fpath = String.format("%s/%s_tfc_%04d.%s.tfc.%s", diretorioEvidencia(), dataHoraComoRuby(),
						contadorAcao, shortComentario, extensao);
				//2018Set07 - adicionado comentario (max 50 chars) ao nome de arquivo do TFC
	
				// img = new File(diretorioEvidencia() + "/" + dataHoraComoRuby() + "_"
				// + StringUtils.leftPad(String.valueOf(contadorAcao), 4, "0") + "_tfc_" /*+
				// comentario +*/ "." + extensao);
				img = new File(fpath);
			}
			Logger.debug(String.format("JAVA tirando screenshot, arquivo=%s\n", img.getCanonicalPath()));
			img.getParentFile().mkdirs();
			ImageIO.write(print, extensao, img);
	
			try {
				Thread.sleep((long) (1.0 * 1000));
				/*
				 * 2018Abr02 00:32am - colocado um "FREIO" para desacelerar LeanFT, pois foi
				 * detectado erro de nao aparecer menu de contas correntes após click , menos de
				 * meio segundo depois de screenshot anterior. Estamos presumindo que isso foi
				 * causado pelo pouco tempo entre as duas acoes
				 * 
				 * Elegemos este ponto, do screenshot, como local onde inserir pausa de alguns
				 * poucos segundos, generalizada, entre todas ações. Numa automaçço com 70
				 * screenshots, degradamos desempeneho em 70 segundos (se pausa=1. SIM,
				 * DEGRADAÇÃO TOLERÀVEL!!!!!!!!!!!!!!
				 * 
				 */
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException ioe) {
			Logger.imprimeStackTrace(ioe);
		}
	}

	public static void evidenciarArquivo(String dir, String arquivo) throws IOException {
		Path arquivoOrigem = Paths.get(dir + arquivo);
		Path arquivoDestino = Paths.get(diretorioEvidencia() + arquivo);
		FilesUtils.copiarArquivo(arquivoOrigem, arquivoDestino);
	}

	public static void gerarLogExecucao() throws IOException {
		String conteudo = DadosExecucao.getNomeCenarioExecucao() + "\n\n";
		conteudo += DadosExecucao.getAllMassaHash();
		conteudo += DadosExecucao.getMsgErro();
		conteudo += DadosExecucao.getDadosFuncionalidade("STATUS");

		Path file = Paths.get(diretorioEvidencia() + "/" + DadosExecucao.getNomeCenarioExecucao() + ".log");
		Files.write(file, conteudo.getBytes(), StandardOpenOption.CREATE);
	}

	public static String diretorioEvidencia() throws IOException {
		if (DadosExecucao.getCaminhoCompletoDaEvidencia() == null) {
			diretorio = Paths
					.get(evidenciaHome + DadosExecucao.getNomeCenarioExecucao() + "/" + DadosExecucao.getIdExecucao());
		} else {
			String dpath = DadosExecucao.getCaminhoCompletoDaEvidencia();
			Logger.debug(String.format("diretorioEvidencioas(); - dpath=%s\n", dpath));
			diretorio = Paths.get(dpath); // properties tem que ter path completo em DIR_REPORT
		}

		Files.createDirectories(diretorio);

		return diretorio.toString();
	}

	public static void inicializaContadorAcao() {
		contadorAcao = 0;
	}

}
