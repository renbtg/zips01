package br.com.santander.abertdigitpf.suporte;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class AutoItRunner {
	
	public static int execute(String qualScript) {
		return execute(qualScript, "");
	}
	/**
	 * Modificado por rbattaglia em 2018Out17, para retornart EXITCODE do autoit. 
	 * Problemas nao totalmente compreendidos sobre ERROELEVEL após execucao de autoit levaram
	 * a criacao de .BAT temporario que escreve output para console.
	 * @param qualScript
	 * @param arg
	 * @return
	 */
	public static int execute(String qualScript, String arg) {

		
		String exec = "\"C:\\Program Files (x86)\\AutoIt3\\AutoIt3.exe\" " + "." + "\\"+qualScript+".au3 " + arg + " & set AUTOITRET=%ERRORLEVEL%";
		try (PrintStream out = new PrintStream(new FileOutputStream("autoITScripts\\au.bat"))) {
		    out.println("@echo off");
		    out.println("cd autoITScripts");
		    out.println(exec);
		    out.println("echo %ERRORLEVEL%");
		    out.println("cd ..");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e1);
			return Integer.MAX_VALUE;
		}
		
		
		//String fullExec = "c:\\windows\\system32\\cmd.exe /c \"cd " + goDir + " & " + exec + " && echo %AUTOITRET% > AUTOITRET.out & cd " + backDir + " \"";
		Logger.debug("AutoItRunner.execute, P00, exec=%s", exec);

		final Runtime rt = Runtime.getRuntime();
		int exitValue = Integer.MAX_VALUE;
		try {
			Process p = rt.exec("autoITScripts\\au.bat");
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line;
			line = null;
			try {
				line = reader.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				Logger.imprimeStackTrace(e);
			}
			if (line != null) {
				exitValue = Integer.parseInt(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
		}
		
		return exitValue;
	}

}
