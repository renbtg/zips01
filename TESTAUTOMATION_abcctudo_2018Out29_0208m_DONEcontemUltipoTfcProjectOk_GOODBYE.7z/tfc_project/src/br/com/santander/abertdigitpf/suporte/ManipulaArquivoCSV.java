package br.com.santander.abertdigitpf.suporte;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ManipulaArquivoCSV {
	
	public ArrayList<Map<String, String>> lerDados(String caminhoArquivo){
		ArrayList<Map<String, String>> linhas  = new ArrayList<Map<String, String>>();
		
		ArrayList<String> dados = new ArrayList<String>();

		try {
			BufferedReader in = new BufferedReader(new FileReader(caminhoArquivo));
			String d;
			while (in.ready()) {
				d = in.readLine();
				dados.add(d);
			}
			in.close();
		}
		catch(IOException e) {
			Logger.imprimeStackTrace(e);
		}
		
		String[] cabecalho = dados.get(0).split(";");//linha1
		
		Boolean t = false;
		for(String linha : dados) {
			Map<String, String> tmp = new HashMap<String, String>();

			if(t) {
				String dadosIsolads[] = linha.split(";");
				for(int i = 0; i < dadosIsolads.length; i++) {
					tmp.put(cabecalho[i], dadosIsolads[i]);
				}
				linhas.add(tmp);
			}else {
				t=true;
			}
		}
		return  linhas;
	}
	
	
	public void gravarDados( String caminhoArquivo, ArrayList<HashMap<String, String>> dados) {
		
		ArrayList<String> dadosAGravar = new ArrayList<String>();
		
		String cabecalho[] = new String [120];
		
		Boolean cabecalhoFlag = true;
		for(HashMap<String, String> pos: dados) {
			String linhaDados = "";
			if(cabecalhoFlag) {
				int k = 0;
				for(String cabecalhoTmp: pos.keySet()) {
					cabecalho[k++] = cabecalhoTmp;
					linhaDados = cabecalhoTmp + ";";			}
			}else {
				for(int i = 0; i < pos.size(); i++) {
					linhaDados+= pos.get(cabecalho[i]) + ";";
				}
			}
			dadosAGravar.add(linhaDados);
		}
	}
	
	public HashMap<String, String> aldrerarDados(HashMap<String, String> alterar, String posicao, String novoValor){
		alterar.replace(posicao, novoValor);
		return alterar;
	}
}
