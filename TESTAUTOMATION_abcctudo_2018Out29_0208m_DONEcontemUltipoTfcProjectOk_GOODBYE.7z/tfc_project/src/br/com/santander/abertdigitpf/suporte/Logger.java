package br.com.santander.abertdigitpf.suporte;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import org.apache.commons.lang3.StringUtils;

/**
 * Logger hiper-simplificado. Substituir por mecanismo de LOGGING que aceite
 * sincronizacao/processos paralelos, para que JAVA e RUBY escrevam
 * concorrentemente para mesmo arquivo. APARENTEMENT, LOG4& NAO CONSEGUE LIDAR
 * COM APPENDERS PARALELOS!
 * 
 * @author x140824 - rbattaglia
 *
 */
public class Logger {
	private static final String DEFAULT_LOG_FNAME = "tfc.log";
	private static final String DEFAULT_LOG_PATH = "../reports";
	private static String fileName = DEFAULT_LOG_FNAME;
	private static String filePath = DEFAULT_LOG_PATH;
	private static String fullFilePath = null;
	private static String interruptedFilePath = null;
	private static boolean processandoFinalizacao = false;

	public static void debug(String format, Object... arguments) {
		debug(false, format, arguments);
	}
	public static void debug_raw(String msg) {
		debug(true, msg);
	}
	
	public static void debug(boolean raw, String format, Object... arguments) {
		String[] logFilePaths = getFullFilePath().split(",");
		String fullPathForLogFile = logFilePaths [0];
		String fullAuxPath = null;
		if (logFilePaths.length > 1) {
			/*
			 * 2018Out10 - simple minded: pega o 2o arquivo, e troca extensao intermediaria 'localrun'
			 * por 'localtfc'
			 */
			String[] auxPieces = logFilePaths[1].split("\\.");
			if (auxPieces.length >= 3) {
				int iTrocar = auxPieces.length - 2;
				auxPieces[iTrocar] = "localtfc";
				fullAuxPath = StringUtils.join(auxPieces,'.');
			}	
		}
		String msg;
		if (raw) {
			msg = format;
		} else {
			msg = String.format(format, arguments).trim();	
		}
		
		String datahoraprefix = LocalDateUtils.getDataHora();
		try {
			String fullMsg = String.format("%s : %s", datahoraprefix, msg);
			System.out.printf("%s%n", fullMsg);
			File f = new File(fullPathForLogFile);
			if (!f.exists()) {
				f.createNewFile();
			}
			String fileText = String.format("%s%n", fullMsg);
			Files.write(Paths.get(fullPathForLogFile), fileText.getBytes(), StandardOpenOption.APPEND);
			if (fullAuxPath != null) {
				f = new File(fullAuxPath);
				if (!f.exists()) {
					f.createNewFile();
				}
				Files.write(Paths.get(fullAuxPath), fileText.getBytes(), StandardOpenOption.APPEND);
			}
		} catch (IOException e) {
			System.err.println(e);
		}

		if (processandoFinalizacao) {
			return;
		}
		String interruptedFile = existsInterruptedFilePath();
		if (interruptedFile != null) {
			processandoFinalizacao = true;
			Logger.debug("Logger.debug, encontrado arquivo de interrupcao, interruptedFile=%s", interruptedFile);
			DadosExecucao.setInterrompido(true);
		}

	}

	public static String getFileName() {
		return fileName;
	}

	public static void setFileName(String logFileName) {
		Logger.fileName = logFileName;
	}

	public static String getFilePath() {
		return filePath;
	}

	public static void setFilePath(String lgPath) {
		filePath = lgPath;
		if (filePath == null || filePath.equals("")) {
			filePath = DEFAULT_LOG_PATH;
		}
	}

	public static void imprimeStackTrace(Throwable e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		String sStackTrace = sw.toString(); // stack trace as a string
		debug(sStackTrace);
		;
	}

	public static String getFullFilePath() {
		String fullPathForLogFile = fullFilePath;
		if (fullPathForLogFile == null) {
			fullPathForLogFile = String.format("%s/%s", getFilePath(), getFileName());
		}
		return fullPathForLogFile;
	}

	public static void setFullFilePath(String fullFilePath) {
		Logger.fullFilePath = fullFilePath;
	}

	public static void setInterruptedFilePath(String interruptedFilePath) {
		Logger.interruptedFilePath = interruptedFilePath;
	}

	public static String getInterruptedFilePath() {
		return interruptedFilePath;
	}

	public static String existsInterruptedFilePath() {
		if (interruptedFilePath == null) {
			return null;
		}
		String[] fnames = interruptedFilePath.split(",");
		for (String fname: fnames) {
			if (new File(fname).exists()) {
				return fname;
			}
		}
		
		return null;
	}

	public static void setProcessandoFinalizacao(boolean b) {
		processandoFinalizacao = b;
	}
	
	public static boolean isProcessandoFinalizacao(boolean b) {
		return processandoFinalizacao;
	}


}