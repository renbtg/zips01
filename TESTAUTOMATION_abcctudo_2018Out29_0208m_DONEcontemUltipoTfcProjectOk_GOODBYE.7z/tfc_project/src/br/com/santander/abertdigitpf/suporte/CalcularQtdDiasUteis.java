package br.com.santander.abertdigitpf.suporte;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Clase que calcula e retorna a quantidade de dias 
 * corridos considerando fins de semana e feriados
 * 
 * @author Danilo Brandao Sozua
 *
 */

public class CalcularQtdDiasUteis {
		
	public static void main(String[] args) {
		new CalcularQtdDiasUteis().retornaDiasCorridosRetroativo(6);	
		new CalcularQtdDiasUteis().retornaDiasCorridosRetroativo(7);
		
		new CalcularQtdDiasUteis().retornaDiasCorridos(6);	
		new CalcularQtdDiasUteis().retornaDiasCorridos(7);
	}
	
	//retorna a quantidade de dias corridos corrigida
	public int retornaDiasCorridos(int qtdDias) {
		int tmp = contaDias(qtdDias, 1);
		Logger.debug(tmp + " fim");
		return tmp;
	}
	
	//retorna a quantidade de dias corridos retroativos corrigida
	public int retornaDiasCorridosRetroativo(int qtdDias) {
		int tmp =contaDiasRetroAtivo(-qtdDias, -1);
		Logger.debug(tmp+ " fim");
		return tmp;
	}
	
	/************************************************************
	 * 															*
	 *                    METODOS PRIVADOS						*
	 * 															*
	 ************************************************************/
	
	//conta o numero de dias retroativo e adiciona dias caso haja feriados ou fins de semana
	private int contaDiasRetroAtivo(int dias,  int contador) {
		if( isSabado(contador) ) {
		    dias --;
		}
		else if(isDomingo(contador) ) {
		    dias --;
		}
		else if(isFeriado(contador) ) {
		    dias --;
		}
		
		if(contador <= dias)
			return  contador;
		else
			return contaDiasRetroAtivo(dias, --contador);
	}
	

	//conta o numero de dias e adiciona dias caso haja feriados ou fins de semana
	private int contaDias(int dias,  int contador) {
		if( isSabado(contador) ) {
		    dias ++;
		}
		else if(isDomingo(contador) ) {
		    dias ++;
		}
		else if(isFeriado(contador) ) {
		    dias ++;
		}
		
		if(contador >= dias)
			return  contador;
		else
			return contaDias(dias, ++contador);
	}
	
	//retorna true caso o dia seja sabado
	private Boolean isSabado(int input) {
		Calendar k = Calendar.getInstance();
		k.add(Calendar.DAY_OF_MONTH, input);
		if(k.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ) {
			return true;
		}
		return false;
	}
	
	//retorna true caso o dia seja domingo
	private Boolean isDomingo(int input) {
		Calendar k = Calendar.getInstance();
		k.add(Calendar.DAY_OF_MONTH, input);
		if(k.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
			return true;
		}
		return false;
	}
	
	//retorna true caso a quantidade de dias retroativa seja igual a um dos feriados
	private Boolean isFeriado(int input) {
		//extrair par arquivo
		String [] feriados = {
				"01/01/2015", "16/02/2015", "17/02/2015", "03/04/2015", "21/04/2015", "01/05/2015", "04/06/2015", "07/09/2015", "12/10/2015", "02/11/2015", "15/11/2015",
				"25/12/2015", "01/01/2016", "08/02/2016", "09/02/2016", "25/03/2016", "21/04/2016", "01/05/2016", "26/05/2016", "07/09/2016", "12/10/2016", "02/11/2016",
				"15/11/2016", "25/12/2016", "01/01/2017", "27/02/2017", "28/02/2017", "14/04/2017", "21/04/2017", "01/05/2017", "15/06/2017", "07/09/2017", "12/10/2017",
				"02/11/2017", "15/11/2017", "25/12/2017", "01/01/2018", "12/02/2018", "13/02/2018", "30/03/2018", "21/04/2018", "01/05/2018", "31/05/2018", "07/09/2018",
				"12/10/2018", "02/11/2018", "15/11/2018", "25/12/2018", "01/01/2019", "04/03/2019", "05/03/2019", "19/04/2019", "21/04/2019", "01/05/2019", "20/06/2019",
				"07/09/2019", "12/10/2019", "02/11/2019", "15/11/2019", "25/12/2019", "01/01/2020", "24/02/2020", "25/02/2020", "10/04/2020", "21/04/2020", "01/05/2020",
				"11/06/2020", "07/09/2020", "12/10/2020", "02/11/2020", "15/11/2020", "25/12/2020"     
			};
		
		Calendar k = Calendar.getInstance();
		k.add(Calendar.DAY_OF_MONTH, input);
		
		DateFormat df = new SimpleDateFormat ("dd/MM/yyyy");   
		String tmpData = "";
		
		for( String data : feriados) {
			tmpData = df.format (k.getTime());		
			if(tmpData.equals( data)) {
				return true;
			}
		}
		
		return false;
	}
	
}
