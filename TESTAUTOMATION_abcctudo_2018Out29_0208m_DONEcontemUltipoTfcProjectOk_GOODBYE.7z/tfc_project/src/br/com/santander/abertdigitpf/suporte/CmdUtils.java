package br.com.santander.abertdigitpf.suporte;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.RenderedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import br.com.santander.abertdigitpf.base.FabricaObjAberturaMgr;

public class CmdUtils {
	private static final String TASKLIST_MOCK_NOTEPAD_EXE = "tasklist /FI \"IMAGENAME eq notepad.exe\" /fo csv /NH";
	private static final String TASKLIST_TErMINAL_CORPORATIVO_WINDOW = "tasklist /FI \"WINDOWTITLE eq Terminal Financeiro Corporativo\" /fo csv /NH";
	private static final String TASKLIST_NOTEPAD = TASKLIST_MOCK_NOTEPAD_EXE;
	private static final String TASKLIST_JAVAW = "tasklist /FI \"IMAGENAME eq javaw.exe\" /fo csv /NH";
	private static final String TASKLIST_LFTRUNTIME = "tasklist /FI \"IMAGENAME eq LFTRuntime.exe\" /fo csv /NH";
	/**
	 * rbattaglia-2018Fev08 - mata tudo q eh javaw, mata, entao, jvm de coisa
	 * rodando dentro do Eclipse. ------------- ISSO È RUIM, deve ser evoluçdo.
	 * Agora, dá-se 1 jeito: nao posso rodar de dentro do Eclipse, mas java.exe da
	 * chamada externa dá certo. ---- TEM Q MELHORAR MUITO, tenho que identificar de
	 * forma precisa o processo que rodei de dentro do Eclipse e, entao, nao matar
	 * esse. WMIC? TASKLIST? POWERSHELL?
	 */
	/*
	 * private static final String XTASKLISTS[] = {
	 * "tasklist /FI \"IMAGENAME eq javaw.exe\" /fo csv /NH",
	 * "tasklist /FI \"IMAGENAME eq javaws.exe\" /fo csv /NH", };
	 */
	// private static final String TASKLISTS[] = {
	// TASKLIST_TErMINAL_CORPORATIVO_WINDOW };
	private static final String KILL = "taskkill /F /PID ";
	private static int quantosJavawTerminalOk = 2;

	public static void startLftRuntime(int segundos_maximo_lftruntime) throws Exception {
		Runtime.getRuntime().exec("lftruntime.exe");
		long tIni = System.currentTimeMillis();
		boolean okRuntime;
		while (!(okRuntime = isLeanFtRuntimeUp())
				&& System.currentTimeMillis() - tIni < 1000 * segundos_maximo_lftruntime) {
			int elapsed = (int) ((System.currentTimeMillis() - tIni) / 1000);
			Logger.debug(String.format(
					"Esperando que runtime do leanft esteja no ar, elapsed=%d, segundos_maximo_lftruntime=%d",
					(int) elapsed, (int) segundos_maximo_lftruntime));
			Thread.sleep(1 * 1000);
		}
		if (!okRuntime) {
			try {
				finalizaLftRuntimeExe();
				Thread.sleep(5 * 1000); // espera 5 depois de matar a janela casos mock "SEM LeanFT license"
			} catch (Exception e) {
				Logger.imprimeStackTrace(e);
			}
			throw new RuntimeException("TFC - LEANFT RUNTIME NAO INICIADA EM TEMPO");
		}
	}

	private static boolean isLeanFtRuntimeUp() {
		URL url;
		try {
			url = new URL("http://localhost:5095");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
			return false;
		}
		HttpURLConnection conn;
		try {
			conn = (HttpURLConnection) url.openConnection();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
			return false;
		}
		boolean retval = false;
		int responseCode = -1;
		try {
			responseCode = conn.getResponseCode();
		} catch (IOException e) {
			Logger.debug("IOException em getResponseCode, nao conectado");
			return false;
		}
		Logger.debug("reponseCode=%d", responseCode);
		if (responseCode == 426) {
			Logger.debug("responseCode OK");
			retval = true;
		}
		conn.disconnect();
		return retval;
	}

	public static boolean finalizaProcessosAbertos() throws Exception {
		// for (String umaTaskList : TASKLISTS) {
		boolean matou = finalizarProc(TASKLIST_TErMINAL_CORPORATIVO_WINDOW);
		if (matou) {
			Logger.debug("EFETIVAMENTE MATOU O TerMINAL CORPORATIVO");
			if (System.currentTimeMillis() == 0) {
				Logger.debug("EFETIVAMENTE MATOU O TerMINAL CORPORATIVO - DORMINGO");
				Thread.sleep(10 * 1000);
				Logger.debug("EFETIVAMENTE MATOU O TerMINAL CORPORATIVO - DORMIU");
			}
		}

		return matou;
		// }
	}

	public static boolean finalizaLftRuntimeExe() throws Exception {
		// for (String umaTaskList : TASKLISTS) {
		boolean matou = finalizarProc(TASKLIST_LFTRUNTIME);
		if (matou) {
			Logger.debug("EFETIVAMENTE MATOU O LftRuntime.exe");
			if (System.currentTimeMillis() == 0) {
				Logger.debug("EFETIVAMENTE MATOU O LftRuntime.exe- DORMINGO");
				Thread.sleep(10 * 1000);
				Logger.debug("EFETIVAMENTE MATOU O LftRuntime.exe - DORMIU");
			}
		}

		return matou;
		// }
	}

	public static boolean finalizarProc(String umaTaskList) {
		Logger.debug(String.format("finalizarProc, umaTaskList=[%s]\n", umaTaskList));
		Process p;
		try {
			p = Runtime.getRuntime().exec(umaTaskList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
			return false;
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;

		// Index processo:
		// 0 - Image Name
		// 1 - PID
		// 3 - Session Name
		// 3 - Session
		// 4 - Mem Usage
		boolean matou = false;
		while (true) {
			line = null;
			try {
				line = reader.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				Logger.imprimeStackTrace(e);
			}
			if (line == null) {
				break;
			}
			if (line.equals("INFO: No tasks are running which match the specified criteria.")) {
				continue;
			}
			String[] processo = line.split(",");
			if (processo.length <= 1) {
				System.err.println("Erro paRSEANDO LINHA DE TASKLIST: " + line);
				continue;
			}
			String cmdKill = KILL + processo[1];
			Logger.debug(String.format("finalizarProc, cmdKill=[%s]\n", cmdKill));
			try {
				Runtime.getRuntime().exec(cmdKill);
				matou = true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				Logger.imprimeStackTrace(e);
			}

		}
		return matou;
	}

	public static boolean existeJanelaWindowsTerminalCorporativo(char rodarExecTfc) {
		boolean janelaTerminal = false;
		if (rodarExecTfc == FabricaObjAberturaMgr.LEANFT) {
			janelaTerminal = temJanelaTerminal();
		} else {
			janelaTerminal = temNotepad();
		}
		Logger.debug(String.format("existeJanelaWindowsTerminalCorporativo(), janelaTerminal=%b\n", janelaTerminal));
		// boolean javaw = existeJavaw();
		// Logger.debug(String.format(("existeJanelaWindowsTerminalCorporativo(), javaw
		// =%b\n",javaw );
		boolean tem = janelaTerminal; // && javaw;;
		Logger.debug(String.format("existeJanelaWindowsTerminalCorporativo(), retornando %b\n", tem));
		return tem;
	}

	private static boolean temNotepad() {
		boolean achou = false;
		Logger.debug(
				String.format("CmdUtis.temJanelaTerminal() - quantosJavawTerminal=%s, P00 \n", quantosJavawTerminalOk));
		Process p;
		try {
			p = Runtime.getRuntime().exec(TASKLIST_NOTEPAD);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
			return false;
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;

		// Index processo:
		// 0 - Image Name
		// 1 - PID
		// 3 - Session Name
		// 3 - Session
		// 4 - Mem Usage
		while (true) {
			line = null;
			try {
				line = reader.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				Logger.imprimeStackTrace(e);
			}
			if (line == null) {
				break;
			}
			if (line.equals("INFO: No tasks are running which match the specified criteria.")) {
				continue;
			}
			String[] processo = line.split(",");
			if (processo.length <= 1) {
				System.err.println("Erro parseando linha de taklist: " + line);
				continue;
			}

			achou = true;
		}
		return achou;
	}

	public static boolean existeJavaw() {
		int ctJavaw = 0;
		Logger.debug(String.format("CmdUtis.existeJavaw() - quantosJavawTerminal=%s, P00 \n", quantosJavawTerminalOk));
		Process p;
		try {
			p = Runtime.getRuntime().exec(TASKLIST_JAVAW);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
			return false;
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;

		// Index processo:
		// 0 - Image Name
		// 1 - PID
		// 3 - Session Name
		// 3 - Session
		// 4 - Mem Usage
		while (true) {
			line = null;
			try {
				line = reader.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				Logger.imprimeStackTrace(e);
			}
			if (line == null) {
				break;
			}
			if (line.equals("INFO: No tasks are running which match the specified criteria.")) {
				continue;
			}
			String[] processo = line.split(",");
			if (processo.length <= 1) {
				System.err.println("Erro parseando linha de taklist: " + line);
				continue;
			}

			ctJavaw++;
		}
		return ctJavaw == quantosJavawTerminalOk;
	}

	private static boolean temJanelaTerminal() {
		boolean achou = false;
		Logger.debug(
				String.format("CmdUtis.temJanelaTerminal() - quantosJavawTerminal=%s, P00 \n", quantosJavawTerminalOk));
		Process p;
		try {
			p = Runtime.getRuntime().exec(TASKLIST_TErMINAL_CORPORATIVO_WINDOW);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
			return false;
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;

		// Index processo:
		// 0 - Image Name
		// 1 - PID
		// 3 - Session Name
		// 3 - Session
		// 4 - Mem Usage
		while (true) {
			line = null;
			try {
				line = reader.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				Logger.imprimeStackTrace(e);
			}
			if (line == null) {
				break;
			}
			if (line.equals("INFO: No tasks are running which match the specified criteria.")) {
				continue;
			}
			String[] processo = line.split(",");
			if (processo.length <= 1) {
				System.err.println("Erro parseando linha de taklist: " + line);
				continue;
			}

			achou = true;
		}
		return achou;
	}

	public static void setQuantosJavawTerminalOk(int quantosJavaw) {
		quantosJavawTerminalOk = quantosJavaw;

	}

	public static void imprimeStack() {
		StackTraceElement stk = Thread.currentThread().getStackTrace()[2];
		Logger.debug(String.format("stk=%s\n", stk));
	}

	public static void imprimeStack(String msg) {
		StackTraceElement stk = Thread.currentThread().getStackTrace()[2];
		Logger.debug(String.format("%s stk=%s\n", msg, stk));
	}

	public static RenderedImage getPrintDaTelaToda() {
		RenderedImage retval = null;
		try {
			retval = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
		} catch (HeadlessException | AWTException e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
		}
		return retval;
	}

	public static boolean finalizaMockProcessos() {
		// for (String umaTaskList : TASKLISTS) {
		boolean matou = finalizarProc(TASKLIST_MOCK_NOTEPAD_EXE);
		if (matou) {
			Logger.debug("EFETIVAMENTE MATOU O TerMINAL CORPORATIVO");
			if (System.currentTimeMillis() == 0) {
				Logger.debug("EFETIVAMENTE MATOU O TerMINAL CORPORATIVO - DORMINGO");
				try {
					Thread.sleep(10 * 1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					Logger.imprimeStackTrace(e);
				}
				Logger.debug("EFETIVAMENTE MATOU O NOTEPAD");
			}
		}

		return matou;
	}

	public static void startExecTfcBat(char rodarExecTfc) throws IOException {
		if (rodarExecTfc == FabricaObjAberturaMgr.LEANFT) {
			new ProcessBuilder("execTFC.bat").start();
		} else {
			new ProcessBuilder("C:\\Windows\\System32\\notepad.exe").start();
		}
	}

	public static void winActivateTfc(char rodarExecTfc) {
		if (rodarExecTfc == FabricaObjAberturaMgr.LEANFT) {
			AutoItRunner.execute("winActivateTfc");
		} else {
			AutoItRunner.execute("winActivateNotepadExe");
		}
	}



}
