package br.com.santander.abertdigitpf.suporte;

public class TempoEspera {
	public static final int SEGUNDOS_ATEH_APROVACAO_APARECER_EM_STATUS = 30;
	public static final int SEGUNDOS_ESPERA_NOME_MANUTPESFIS = 10; //TODO - wait em loop inteligente! rbattaglia. DO ME!
	
	public static int CURTO = 1;
	public static int MEDIO = 5;
	public static int LONGO = 10;
	public static int PADRAO = 90;
	
	public static long retornarTempoEsperaMilisegundos(int tempo) {
		return tempo * 1000;	
	}
	
}
