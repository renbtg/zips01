package br.com.santander.abertdigitpf.suporte;

public class Strings {
    public final static String USUARIO_MUREXIII = "BR_BRF", SENHA_MUREXIII = "INICIO01";
}
