package br.com.santander.abertdigitpf.suporte;

import static java.nio.file.StandardOpenOption.TRUNCATE_EXISTING;
import static java.nio.file.StandardOpenOption.CREATE;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

public class FilesUtils {
	
	public static void escreverArquivo(List<String> conteudo, String nomeArquivo) {
		String conteudoLinha = "";
		for(String linha: conteudo){
			conteudoLinha = conteudoLinha + linha + "\n" ;	
		}
		
		byte data[] = conteudoLinha.getBytes();
		Path file = Paths.get(nomeArquivo);

		try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(file, CREATE, TRUNCATE_EXISTING))) {
			out.write(data, 0, data.length);
			
		} catch (IOException x) {
			System.err.println(x);
		}
	}

	public static List<String> lerArquivo(String nomeArquivo) {
		List<String> arquivo = new ArrayList<String>();  
		Path file = Paths.get(nomeArquivo);
		
		if (!Files.exists(file, LinkOption.NOFOLLOW_LINKS)) {
			Logger.debug("Arquivo nço existe: "+ file.getFileName());
			return null;
		}
		
		try (InputStream in = Files.newInputStream(file);
		    BufferedReader reader =
		      new BufferedReader(new InputStreamReader(in))) {
			
		    String line = null;
		    while ((line = reader.readLine()) != null) {
		    	arquivo.add(line);
		    }
		} catch (IOException x) {
		    System.err.println(x);
		}
		return arquivo;
	}
	
	public static void copiarArquivo(Path arquivoOrigem, Path arquivoDestino) throws IOException {
		Files.copy(arquivoOrigem, arquivoDestino, StandardCopyOption.REPLACE_EXISTING);
	}

	public static void moverArquivo(Path arquivoOrigem, Path arquivoDestino) throws IOException {
		Files.move(arquivoOrigem, arquivoDestino, StandardCopyOption.REPLACE_EXISTING);
	}


}
