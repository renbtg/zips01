package br.com.santander.abertdigitpf.suporte;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;

public class OsUtils {
	public static String executa_cmd(String comando, int segundos_depois_de_exec) throws Exception {
		String cmd = comando; // String.format("c:\\windows\\system32\\cmd.exe /c %s", comando);
		//System.out.println("Z00");
		//Logger.debug_raw("executa_cmd, cmd="+cmd+", INICIO");
		//System.out.println("Z00.01");
		Process p;
		p = Runtime.getRuntime().exec(cmd);
		//System.out.println("Z00.02");
		if (segundos_depois_de_exec > 0) {
			//System.out.println("Z00.03");
			Thread.sleep(1000 * segundos_depois_de_exec);
			//System.out.println("Z00.04");
		}
		//System.out.println("Z01");
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		//System.out.println("Z02");
		String line;
		String retval = "";
		while (true) {
			//System.out.println("Z03");
			line = null;
			line = reader.readLine();
			//System.out.printf("Z04, line=%s\n", line);
			if (line == null) {
				break;
			}
			retval = retval + line + "\n";
		}
		Logger.debug_raw("FIM executa_cmd, cmd="+cmd+", retval="+retval);
		return retval;
	}

	public static void kill_and_watch(String[] signatures, Integer max_tempo) {
	//#2018Set02 - max_tempo agora tem default 128 (antes, nao tinha nenhum). ATENCAO - max_tempo ainda é ignorado! fica pra sempre!
	//#2018Ago16 pm, - residuo de CTRL+C/cmd_stop em "stt*act=done*.7z" aconteceu algumas vezes (COMPLEXAS DE DEBUGAR), gerando prolema em condolidador de reports (zs\zs_proc.rb consolidador). SOLUÇÂO: colocar asinaturas no método "zs_proc.rb::zs_run_parallel_process_signatures" na ordem correta, e, também, matar e esperar (em método "kill_and_watch") um a um os processos(em vez de matar_todos+esperar_todos.
		long t_ini = System.currentTimeMillis() / 1000;
		while(true) {
			String undead = first_undead(signatures); 
			if (undead == null) {
				break;
			}

			String[] undead_array = {undead};
			while (! is_dead( undead_array )) {
				//#2018Ago16 - insiste em matar processos(s) da assinatura até conseguir, só vai tentar outras assinatura quando esta estiver morta.
				long t_now = System.currentTimeMillis() / 1000;
				long elapsed = t_now - t_ini;
				Logger.debug("killandwatch - elapsed=%s, max_tempo=%d, t_ini=%d, t_now=%d, undead=%s, signatures=%s", elapsed,max_tempo,t_ini,t_now,undead,Arrays.toString(signatures)); 
				
				if (elapsed > max_tempo) {
					Logger.debug("NAO ABORTANDO POR ISSO, TENTANDO PROSSEGUIR MESMO ASSIM - kill_and_watch excedeu tempo limite, elapsed=%s, max_tempo=%d, t_ini=%d, t_now=%d, undead=%s, signatures=%s", elapsed,max_tempo,t_ini,t_now,undead,Arrays.toString(signatures)); 
				}
				Logger.debug( "killandwatch, P05.1 - ESPERANDO A MORTE de signatures, mandando matar o primeiro undead com zs_kill, undead=%s, signatures=%s",undead,Arrays.toString(signatures));
				just_kill(undead_array);
				Logger.debug( "killandwatch, P05.2 - ESPERANDO A MORTE de signattures, mandei matar  o primeiro undead com zs_kill, undead=%s, signatures=%s",undead,Arrays.toString(signatures));
			}

		}
		return;
	}

	

	public static void mata_todos_processos(String where) {
		Logger.debug_raw("P00 mata_todos_processos(where="+where+")");

		String c = "cmd /c C:\\Windows\\System32\\wbem\\WMIC.exe path win32_process where \"" + where + "\" get ProcessId";

		//String o = run_command_retry_eagain(c, nof_tries)
		String o=null;
		try {
			o = executa_cmd(c, 0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
			return;
		}

		Logger.debug_raw("mata_todos_processos(where="+where+"), c="+c+" , o="+o+")");
		if (o==null) {
			return;
		}

		Logger.debug_raw("mata_todos_processos(where="+where + "), antes de split, o="+o+"");

		String[] a1=o.split("\n");
		String[] aa = Arrays.stream(a1).filter(s -> !s.equals("")).toArray(String[]::new);
		
	
		Logger.debug_raw("mata_todos_processos(where="+where+"), depos de split, aa="+Arrays.toString(aa));
		if (aa.length == 0 || ! aa[0].contains("ProcessId")) {
			return;
		}
				
		Logger.debug_raw("mata_todos_processos(where="+where+"), achou ProcessId");
		for (int k=0; k < aa.length-1; k++) {
			Logger.debug_raw("mata_todos_processos(where="+where+"), k="+k+", aa.length="+new Integer(aa.length));
			String sPid = aa[k+1].trim();
			Logger.debug_raw("mata_todos_processos(where="+where+"), k="+k+", aa.length="+new Integer(aa.length) + ", sPid="+sPid);
			int pid;
			pid = Integer.parseInt(sPid);

			String wmic_del_cmdline = String.format("cmd /c C:\\Windows\\System32\\wbem\\WMIC.exe process where \"ProcessId=%d\" delete", pid);
			Logger.debug_raw("mata_todos_processos, vai execucar comando na variavel wmic_del_cmdline='"+wmic_del_cmdline+"'");
			try {
				o = executa_cmd(wmic_del_cmdline,0);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				Logger.imprimeStackTrace(e);
			}
			Logger.debug_raw("mata_todos_processos, executou comando na variavel wmic_del_cmdline='"+wmic_del_cmdline+"', o="+o);
		}
		return;
	}
	
	
	public static void just_kill(String[] assinaturas) {
		long tempo_dormir=1; // #posso refinar conforme CFG de cada máquina de zs
		long vezes=1; // #2018Fev26 - ERAM 3 VEZES JÀ AQUI! NAO PRECISA! zs_kill é chamada em LOOP! ISSO TIMEOUTAVA??? ESTRANHAMENTE?? Sem protecao contra falhar? Efeito colateral presumido de antes = "nao avancava em run_parallel ?? nao ia de waiting pra running?" 
		for (int m=0; m < vezes; m++) {
			long vez = m + 1;
			for (int k=0; k < assinaturas.length; k++) {
				String assinatura=assinaturas[k]; //java - apenas String, nao aceita Array
				long tempo_sleep_depois_matar = 0;

				String where = clausula_wmic_where_de_pid_ou_palavras(assinatura);
				Logger.debug("just_kill, (vez %d de %d) - Vai chamar mata_todos_processos com where=%s", vez, vezes, where);
				mata_todos_processos(where);
				try {
					Thread.sleep(tempo_sleep_depois_matar*1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					Logger.imprimeStackTrace(e);
				}

		//		#vai_dormir= (k==assinatura.length-1) ? 0: tempo_dormir
				long vai_dormir = tempo_dormir;
				Logger.debug("just_kill, (vez %d de %d) - Chamou     mata_todos_processos com where=%s, dormindo %d segundos",vez, vezes, where, vai_dormir);
				try {
					Thread.sleep(vai_dormir*1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return;
	}

	
	public static boolean is_dead(String[] signatures) {
		return first_undead(signatures) == null;
	}
	
	

	public static String first_undead(String[] signatures) {
	//#2018Ago16 pm, criado.
		Logger.debug("first_undead, signatures=%s", Arrays.toString(signatures));

		String retval = Arrays
		        .stream(signatures)
		        .filter(s -> {
		        	
		        		String signature = s;
						Logger.debug("first_undead - signature = %s normal, checavel, vai conferir no sistema operacional se morreu", signature);
						String where_clause = clausula_wmic_where_de_pid_ou_palavras(signature);
						boolean alive = processo_naofilho_executando(where_clause); // #2018Set01 - capaz de interpretar multiplas palavras separadas por espaço para where clause
						if (alive) {
							Logger.debug("first_undead, ainda há processos rodando com assinatura=%s",signature);
						} else {
							Logger.debug("first_undead, NAO há processos rodando com assinatura=%s",signature);
		        		}
		        		return alive;
		        	}
		        )
		        .findFirst()
		        .orElse(null);
		Logger.debug("first_undead, retornando");
		
		return retval;
	}

	
	public static String clausula_wmic_where_de_pid_ou_palavras(String pid_ou_palavras) {
		//#2018Set01 - adicionado método clausula_wmic_where_de_pid_ou_palavras
		String s = pid_ou_palavras;
		int pid = 0;
		try {
			pid = Integer.parseInt(pid_ou_palavras);
		} catch (NumberFormatException nfe) {
			
		}
		if (pid != 0) {
			throw new RuntimeException(String.format("clausula_wmic_where_de_pid_ou_palavras, pid numerico nao valido, pid_ou_palavras=%s", pid_ou_palavras));
		}
		//nao aceita array de palavras, apenas separado por ',' 
		String[] all_words = s.split(" ");
		String all_words_clauses = "(COMMANDLINE like '%%'";
		for (String one: all_words) {
			all_words_clauses += " AND COMMANDLINE like '%" + one + "%' ";
		}
		all_words_clauses += ")";
		String where_clause = "("+ all_words_clauses + " and not COMMANDLINE like '%wmic%')";
		where_clause = where_clause.replace("\\", "\\\\");
		return where_clause;
	}
	public static void main(String[] args) {
		//String prim = first_undead(new String[]{"eclipse.exe", "vi x.rb"});
		//System.out.format("first_undead=%s\n", prim);
		just_kill(new String[] {"ruby"});
	}


	public static boolean processo_naofilho_executando (String pid_or_where) {
		int pid = 0;
		try {
			pid = Integer.parseInt(pid_or_where);
		} catch (NumberFormatException nfe) {
			
		}
		String c;
		if (pid != 0) { 
			c=String.format("cmd /c C:\\Windows\\System32\\wbem\\WMIC.exe path win32_process where \"PROCESSID = %d\" get Processid 2>&1",pid);
		} else {
			String where = pid_or_where;
			c="cmd /c C:\\Windows\\System32\\wbem\\WMIC.exe path win32_process where \"" + where + "\" get ProcessId, CommandLine 2>&1";
		}

		String s = null;
		try {
			s = executa_cmd(c, 0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.imprimeStackTrace(e);
		}
		Logger.debug("processo_naofilho_executando, c=%s, s=%s", c, s);
		if (s == null || s.equals("")) {
			Logger.debug("processo_naofilho_executando, c=%s, s=%s, vai dar throw", c, s);
			throw new RuntimeException(String.format("impossível obter output de wmic, c=%s, s=%s",c,s));
		}
		Logger.debug("processo_naofilho_executando, retornando...");
		return (! (s.contains("No Instance")));
	}
}