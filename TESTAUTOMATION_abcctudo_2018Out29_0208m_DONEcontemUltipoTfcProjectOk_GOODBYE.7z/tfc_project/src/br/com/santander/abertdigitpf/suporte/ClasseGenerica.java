package br.com.santander.abertdigitpf.suporte;

import java.awt.Component;
import java.awt.Container;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.NativeObject;
import com.hp.lft.sdk.SupportsNativeObject;
import com.hp.lft.sdk.TestObject;
import com.hp.lft.sdk.java.Editor;
import com.hp.lft.sdk.java.Label;
import com.hp.lft.sdk.java.Table;
import com.hp.lft.sdk.java.TableCell;
import com.hp.lft.sdk.java.TableRow;

public class ClasseGenerica {

	public static int retornarLinhaTabela(Table tabela, String[] conteudoValidacao) throws Exception {
		return retornarLinhaTabela(tabela, conteudoValidacao, 10);
	}

	/**
	 * Encontrar linha na tabela por conteçdo
	 * 
	 * @param linhas
	 * @param conteudoValidacao
	 * @return numero da linha e caso nço encontrar conteçdo , retorna -1
	 * @throws Exception
	 */
	public static int retornarLinhaTabela(Table tabela, String[] conteudoValidacao, int segundos_espera)
			throws Exception {
		for (int i = 0; i <= segundos_espera; i++) {
			if (tabela.getRows().size() > 0) {
				break;
			}
			Thread.sleep(TempoEspera.retornarTempoEsperaMilisegundos(TempoEspera.CURTO));
		}
		List<TableRow> linhas = tabela.getRows();

		int nroLinha = 0;
		for (TableRow linha : linhas) {

			boolean linhaValidada = true;
			String conteudo = "";
			List<TableCell> celulas = linha.getCells();

			for (TableCell celula : celulas) {
				conteudo += "|" + celula.getValue().toString();

			}
			Logger.debug(conteudo);

			for (String valida : conteudoValidacao) {
				if (!conteudo.contains(valida)) {
					linhaValidada = false;
					break;
				}
			}
			if (linhaValidada) {
				return nroLinha;
			}

			nroLinha++;
		}

		return -1;
	}

	public static double retornarRentabilidadeDiaria(double index, double aplicacao) throws Exception {
		return aplicacao * Math.pow(((index / 100f) + 1), (1f / 252f));
	}

	public static String formatarValor(String formato, double valor) throws Exception {
		DecimalFormat df = new DecimalFormat(formato);
		return df.format(valor);
	}

	public static String formatarValor(String formato, String valor) throws Exception {
		return StringUtils.leftPad(String.valueOf(valor), formato.length(), "0");
	}

	public static List<List<String>> retornaTodoConteudoDaTabela(Table tabela, int segundos_espera) throws Exception {
		for (int i = 0; i <= segundos_espera; i++) {
			Logger.debug(
					"retornaTodoConteudoDaTabelaO(), i = %d, Fazendo loop de sleep de 1 segundo por segundos_espera = %d vezes, até encontrar alguma linha ou esgotar iterações",
					i, segundos_espera);
			if (tabela.getRows().size() > 0) {
				Logger.debug("retornaTodoConteudoDaTabela(), i=%d, tamanho da tabela > 0, segundos_espera = %d", i,
						segundos_espera);
				break;
			}
			Thread.sleep(1000);
		}
		List<TableRow> linhas = tabela.getRows();

		List<List<String>> lista = new ArrayList<List<String>>();

		for (TableRow linha : linhas) {

			List<String> conteudo = new ArrayList<String>();
			List<TableCell> celulas = linha.getCells();

			for (TableCell celula : celulas) {
				conteudo.add(celula.getValue().toString());

			}
			Logger.debug(String.join("|", conteudo));

			lista.add(conteudo);
		}

		return lista;
	}

	public static List<Component> getAllComponents(Object o) {
		Component[] comps;
		Container c;
		if (o instanceof Component[]) {
			comps = (Component[]) o;
		} else {
			c = (Container) o;
			comps = c.getComponents();
		}
		List<Component> compList = new ArrayList<Component>();
		for (Component comp : comps) {
			compList.add(comp);
			if (comp instanceof Container) {
				compList.addAll(getAllComponents((Container) comp));
			}
		}
		return compList;
	}

	/**
	 * 2018Ago0x a 2018Ago2x, rbattaglia, AVANÇO TÈCNICO AINDA NAO UTILIZADO
	 * -'ClasseGenerica.getMapsConteudoDaTabela' consegue obter (via chamada a
	 * wrapper NativeObject) os nomes de colunas de grids! Adeus, quantidade fixa de
	 * clicks... use quando quiser e puder!s"
	 */
	public static List<Map<String, String>> getMapsConteudoDaTabela(Table tbl, SupportsNativeObject parentFrame,
			int nSeconds, String printDataPrefix) throws Exception {
		Logger.debug("INI getMapsConteudoDaTabela");

		List<Map<String, String>> allRows = new ArrayList<Map<String, String>>();
		List<List<String>> colValues = retornaTodoConteudoDaTabela(tbl, nSeconds);
		if (colValues.size() == 0) {
			// 2018Out10am, return lista vazia antecipadamente antes da demorada obtencao de
			// nomes de coluna
			return allRows;
		}

		List<String> colNames = getNomesDeColunasDeTabela(parentFrame);

		if (colNames == null || colValues == null) {
			throw new RuntimeException("ERRO, colNames == null || colValues == new");
		}
		if (colValues.size() > 0 && colNames.size() != colValues.get(0).size()) {
			throw new RuntimeException("ERRO, colValues.size() > 0 && colNames.size() != colValues.get(0).size()");
		}

		for (int lin = 0; lin < colValues.size(); lin++) {
			Map<String, String> oneRow = new LinkedHashMap<String, String>();
			List<String> columns = colValues.get(lin);
			for (int col = 0; col < columns.size(); col++) {
				String value = columns.get(col);
				String key = colNames.get(col);
				oneRow.put(key, value);
				if (printDataPrefix != null) {
					/**
					 * 2018Set07 - se novo parâmetro 'printDataPrefix' not null, entao, imprime os
					 * dados
					 */
					Logger.debug("%s: Linha %d/%d, key=%s, value=%s", printDataPrefix, lin + 1, colValues.size(), key,
							value);
				}
			}
			allRows.add(oneRow);
		}
		Logger.debug("FIM getMapsConteudoDaTabela");
		return allRows;
	}

	private static List<String> getNomesDeColunasDeTabela(SupportsNativeObject parentFrame)
			throws GeneralLeanFtException {
		Logger.debug("INI getNomesDeColunasDeTabela");
		Map<NativeObject, List<String>> allComps = new LinkedHashMap<NativeObject, List<String>>();
		addComponentesNativosComMetodosColuna(parentFrame.getNativeObject(), allComps);

		NativeObject comp = null;
		for (NativeObject nativeObject : allComps.keySet()) {
			List<String> stringList = allComps.get(nativeObject);
			if (stringList.contains("getColumnName(int)")) {
				comp = nativeObject;
				//for (String metodo: stringList) {Logger.debug("metodo de stringList=%s", metodo);}
				if (stringList.contains("setMinWidth(int)")) {
					Logger.debug(
							"2018Out21 NAO ACHOU, seria outra busca e logica - getMapsConteudoDaTabela - DA HORA, stringList que contém getColumnName(int) também contém método de mudar LARGURA DA COLUNA!! " + 
							"Poderei usar pra ver PENDENTE DE ASSINATURA DIGITAL etc.!");
				}
				break;
			}
		}
		if (comp == null) {
			return new ArrayList<String>(); // retorna lista ainda vazia
		}

		int cNum = 0;
		List<String> retval = new ArrayList<String>();
		while (true) {
			String s = null;

			try {
				s = (String) comp.invokeMethod("getColumnName", Object.class, new Integer(cNum));
			} catch (Exception gle) { // TODO - CATCH ONLY GeneralLeanFtException
				Logger.imprimeStackTrace(gle);
				break;
			}
			retval.add(s);
			cNum++;
		}
		Logger.debug("END getNomesDeColunasDeTabela");
		return retval;
	}

	/**
	 * criada em 2018Set09 NAO precisa chamar em loop, deve fechar na ordem inversa
	 * de profundidade do componente
	 * 
	 * @param parentFrame
	 * @return
	 * @throws GeneralLeanFtException
	 */
	public static int chamaDisposeEmJanelas(SupportsNativeObject parentFrame) throws GeneralLeanFtException {
		Map<NativeObject, List<String>> allComps = new LinkedHashMap<NativeObject, List<String>>();
		addComponentesNativosComDispose(parentFrame.getNativeObject(), allComps);

		List<NativeObject> disposableList = new ArrayList<NativeObject>();
		int retval = 0;
		NativeObject comp = null;
		for (NativeObject nativeObject : allComps.keySet()) {
			List<String> stringList = allComps.get(nativeObject);
			if (stringList.contains("dispose()")) {
				comp = nativeObject;
				disposableList.add(comp);
			}
		}

		for (int pos = disposableList.size() - 1; pos >= 1; pos--) {
			// pega do ultimo proprimeiro, nao fechando MAIN WINDOW
			retval = retval + 1;
			comp = disposableList.get(pos);
			String s = "SEM RETORNO";
			try {
				if (System.currentTimeMillis() == 0) {
					Logger.debug("ainda nao chamando dispose() nativo, retval agora=%d", retval);
				} else {
					s = (String) comp.invokeMethod("dispose", Object.class, new Object[0]);
				}
			} catch (Exception gle) { // TODO - CATCH ONLY GeneralLeanFtException
				Logger.imprimeStackTrace(gle);
				break;
			}
			Logger.debug("s depois de chamada a dispose()=%s", s);
		}

		return retval;
	}

	public static Map<String, Object> addComponentesNativosComMetodosColuna(NativeObject comp,
			Map<NativeObject, List<String>> allComps) throws GeneralLeanFtException {
		Map<String, Object> retval;

		retval = new HashMap<String, Object>();

		List<String> v_members = comp.getMembers();
		retval.put("members", v_members);

		for (String sMember : v_members) {
			if (!(sMember.equals("getColumnName(int)") || sMember.equals("getColumnCount()"))) {
				continue;
			}
			int cNum = 0;
			while (true) {
				Object o = null;
				String sInvoke = null;

				// String thingName = sMember.replace("()","");
				String thingName = "getColumnName";
				Object thingParam = new Integer(cNum);
				if (sMember.toLowerCase().contains("count")) {
					thingName = "getColumnCount";
					thingParam = new Object[0];
				}

				String s = null;

				try {
					o = comp.invokeMethod(thingName, Object.class, thingParam);
					if (System.currentTimeMillis() == 0) {
						sInvoke = (String) o;
						s = sInvoke;
					}
				} catch (Exception gle) {
					break;
				}
				if (!thingName.equals("getColumnName")) {
					break;
				}
				// try {
				// o = comp.getProperty(thingName, String.class);
				// sProperty = (String) o;
				// } catch(Exception gle) {
				// Exception e = gle;
				// }
				if (s == null) {
					s = "RETORNO NULO!!!";
				}
				// Logger.debug("Algum objeto contem método potencialmente
				// desejado, sMember=%s, cNum=%d, conteudo da chamada ao metodo parece OK =%s",
				// sMember, cNum, s);
				cNum++;
			}
		}

		if (allComps != null) {
			allComps.put(comp, v_members);
		}

		if (v_members.contains("getComponents()")) {
			List<Map<String, Object>> subComps = new ArrayList<Map<String, Object>>();
			retval.put("subComps", subComps);
			int iCompNum = 0;
			while (true) {
				try {
					Object o = comp.invokeMethod("getComponent", Object.class, new Integer(iCompNum));
					NativeObject oneComp = (NativeObject) o;
					subComps.add(addComponentesNativosComMetodosColuna(oneComp, allComps));
					iCompNum++;
				} catch (GeneralLeanFtException e) {
					// TODO - qual a melhor excecao pra pegar q deu erro em INVOKE pq acabaram os
					// subcomponents?
					// Logger.debug("Erro talvez fim de components");
					// Logger.imprimeStackTrace(e);
					break;
				}
			}
		}
		return retval;
	}

	public static Map<String, Object> addComponentesNativosComDispose(NativeObject comp,
			Map<NativeObject, List<String>> allComps) throws GeneralLeanFtException {
		Logger.debug("addComponentesNativosComDispose chamada, allComps.size()=%d", allComps.size());
		Map<String, Object> retval;

		retval = new HashMap<String, Object>();

		List<String> v_members = comp.getMembers();
		retval.put("members", v_members);

		int nCoisas = 0;
		for (String sMember : v_members) {
			if (!sMember.equals("dispose()")) {
				continue;
			}
			nCoisas = nCoisas + 1;
			if (System.currentTimeMillis() > 0) {
				Logger.debug(
						String.format("uma coisa com dispose() encontrada, quantidade atual de coisas=%d", nCoisas));
				break;
			}
		}

		if (allComps != null) {
			allComps.put(comp, v_members);
		}

		if (v_members.contains("getComponents()")) {
			Logger.debug("addComponentesNativosComDispose adicionando subComponente");
			List<Map<String, Object>> subComps = new ArrayList<Map<String, Object>>();
			retval.put("subComps", subComps);
			int iCompNum = 0;
			while (true) {
				try {
					Object o = comp.invokeMethod("getComponent", Object.class, new Integer(iCompNum));
					NativeObject oneComp = (NativeObject) o;
					subComps.add(addComponentesNativosComDispose(oneComp, allComps));
					iCompNum++;
				} catch (GeneralLeanFtException e) {
					// TODO - qual a melhor excecao pra pegar q deu erro em INVOKE pq acabaram os
					// subcomponents?
					// Logger.debug("Erro talvez fim de components");
					// Logger.imprimeStackTrace(e);
					break;
				}
			}
		}
		return retval;
	}

	public static Object callReflectionMethodNoParam(Object object, String methodName) {
		Object retval = null;

		Class<?> noparams[] = {};
		Method method;
		try {
			String className;

			className = object.getClass().getCanonicalName();
			Logger.debug("callReflectionMethodNoParam, className=%s", className);
			method = object.getClass().getDeclaredMethod(methodName, noparams);
			retval = method.invoke(object, (Object[]) null);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException
				| SecurityException e) {
			Logger.imprimeStackTrace(e);
		}
		return retval;
	}

	public static String bugReflectionTestObjectGetText(TestObject testObject) {
		String text = null;
		text = (String) callReflectionMethodNoParam(testObject, "getText");
		return text;
	}

	public static String testObjectGetText(TestObject testObject) {
		String text = null;
		try {
			if (testObject instanceof Label) {
				Label z = (Label) testObject;
				text = z.getText();
			} else if (testObject instanceof Editor) {
				Editor z = (Editor) testObject;
				text = z.getText();
			} else {
				throw new IllegalArgumentException(String.format("testObject - classe nao implementada",
						testObject.getClass().getCanonicalName()));
			}
		} catch (GeneralLeanFtException e) {
			e.printStackTrace();
		}
		return text;
	}

	/**
	 * create 2018Set10, generalizacao, aguarda até que um dado Editor tenha valor
	 * "igual ou diferente" do passado
	 * 
	 * @param waitSeconds
	 *            Para mensagem de log, o contexto da comparacao
	 * @param context
	 *            Para mensagem de log, o contexto da comparacao
	 * @param anObject
	 *            editor de onde checaremos texto, deve implementar método getText()
	 *            chamado via reflection
	 * @param cmpStr
	 *            com o que comparamos
	 * @param mustEqual
	 *            true=deve ser igual, false=deve ser diferente
	 * @return se comparacao ok
	 * @throws GeneralLeanFtException
	 */
	public static boolean esperaTestObjectCompare(int waitSeconds, String context, TestObject anObject, String cmpStr,
			boolean mustEqual) throws GeneralLeanFtException {
		Logger.debug("esperaTestObjectCompare, INIT P00, context=%s, mustEqual=%b, waitSeconds=%d, cmpStr='%s'",
				context, mustEqual, waitSeconds, cmpStr);
		long elapsed = 0;
		long initTime = System.currentTimeMillis();
		String objectText = null;
		while (elapsed < waitSeconds) {
			Logger.debug(
					"esperaTestObjectCompare, LOOP antes de testObjectGetText, context=%s, mustEqual=%b, waitSeconds=%d, cmpStr='%s'",
					context, mustEqual, waitSeconds, cmpStr);
			objectText = testObjectGetText(anObject);
			Logger.debug(
					"esperaTestObjectCompare, LOOP depois de testObjectGetText, context=%s, mustEqual=%b, waitSeconds=%d, cmpStr='%s', objectText='%s'",
					context, mustEqual, waitSeconds, cmpStr, objectText);
			if (objectText.equals(cmpStr) ? mustEqual : !mustEqual) {
				Logger.debug(
						"esperaTestObjectCompare, comparacao bateu, context=%s, mustEqual=%b, objectText = '%s', objectText.length()=%d, cmpStr=%s, elapsed=%d, waitSeconds=%d",
						context, mustEqual, objectText, objectText.length(), cmpStr, elapsed, waitSeconds);
				break;
			}
			elapsed = (System.currentTimeMillis() - initTime) / 1000;
			Logger.debug(
					"esperaTestObjectCompare, aguardando comparacao, context=%s, mustEqual=%b, objectText = '%s', objectText.length()=%d, cmpStr=%s, elapsed=%d, waitSeconds=%d",
					context, mustEqual, objectText, objectText.length(), cmpStr, elapsed, waitSeconds);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Logger.imprimeStackTrace(e);
			}
		}
		boolean retval = objectText.equals(cmpStr) ? mustEqual : !mustEqual;
		Logger.debug(
				"esperaTestObjectCompare, concluida, retval=%b, context=%s, mustEqual=%b, objectText) = '%s', objectText.length()=%d, cmpStr=%s, elapsed=%d, waitSeconds=%d",
				retval, context, mustEqual, objectText, objectText.length(), cmpStr, elapsed, waitSeconds);
		return retval;
	}

	public static boolean esperaTestObjectNotEqual(int waitSeconds, String context, TestObject anObject, String cmpStr)
			throws GeneralLeanFtException {
		return esperaTestObjectCompare(waitSeconds, context, anObject, cmpStr, false);
	}

	public static boolean esperaTestObjectEqual(int waitSeconds, String context, TestObject anObject, String cmpStr)
			throws GeneralLeanFtException {
		return esperaTestObjectCompare(waitSeconds, context, anObject, cmpStr, true);
	}

	public static boolean esperaTestObjectBlank(int waitSeconds, String context, TestObject anObject)
			throws GeneralLeanFtException {
		return esperaTestObjectEqual(waitSeconds, context, anObject, "");
	}

	public static boolean esperaTestObjectNotBlank(int waitSeconds, String context, TestObject anObject)
			throws GeneralLeanFtException {
		return esperaTestObjectNotEqual(waitSeconds, context, anObject, "");
	}

	public static final String STR_PENDENTE_DE_APROVACAO_DIGITAL = "PENDENTE DE APROVAÇÃO DIGITAL";
	public static final String STR_EM_APROVACAO_DIGITAL = "EM APROVAÇÃO DIGITAL";

}