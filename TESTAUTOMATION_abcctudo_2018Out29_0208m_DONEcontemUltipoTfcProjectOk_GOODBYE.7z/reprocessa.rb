# encoding: UTF-8
require "./rotinas_processo.rb"
require_relative "./features/support/rsi_spreadsheet.rb"
require 'csv'


def deleta_excel_reprocessar(xls_file) 
	write_rsi_log :debug, "deleta_excel_reprocessar(#{xls_file} - iniciado"

	dir_arqs='planilhas e controles'
	nome_xls = dir_arqs + '/' + File.basename(xls_file)

	File.delete nome_xls if File.exist? nome_xls
end

def gera_excel_reprocessar(xls_file, a_reprocessar) 
	sep=';'

	write_rsi_log :debug, "gera_excel_reprocessar(#{xls_file} - iniciado"

	dir_arqs='planilhas e controles'
	nome_xls = dir_arqs + '/' + File.basename(xls_file)
	nome_csv = dir_arqs + '/' + File.basename(xls_file,'.xls')+".csv"
	# nao usa diretorio, sempre em Planilhas e Controles

	write_rsi_log :debug, "gera_excel_reprocessar: nome_xls=#{nome_xls}, nome_csv=#{nome_csv}"
	f_m=nil
	begin
	 	f_m = File.open(nome_csv, "wt")

		f_m.puts 'feature_name' + sep + 'razao'

		a_reprocessar.each do |rp|
	    	write_rsi_log :debug, "reprocessa.rb - adicionando csv, rp=#{rp}"
			ft = rp[:feature_name]
			rz = rp[:razao]
			f_m.write ft.encode('UTF-8')
			f_m.write sep
			f_m.write rz
			f_m.puts "\n"
		end
	rescue Exception => e
		f_m.close if f_m != nil
		falhar e
	ensure
		f_m.close if f_m != nil
	end

	#system 'type reproc.csv'	
	write_rsi_log :debug, "reprocessa.rb - vai comecar lance de excel"

	book = Spreadsheet::Workbook.new
	sheet1 = book.create_worksheet
	header_format = Spreadsheet::Format.new(
	  :weight => :bold,
	  :horizontal_align => :center,
	  #:bottom => true, #exemplo q vi bottom invalido
	  :locked => true
	)
	sheet1.row(0).default_format = header_format
	#system 'type csv_massa.txt'
	#write_rsi_log :debug, "vai manipular csv"
	write_rsi_log :debug, "reprocessa.rb - vai processar o CSV"
	CSV.open(nome_csv, 'r', :col_sep=>sep, :quote_char => "¨") do |csv| #quote_char exotico, nao acharei
		csv.each_with_index do |row, i|
	    	sheet1.row(i).replace row
	    	write_rsi_log :debug, "reprocessa.rb, manipulando linha #{i} do CSV"
	  	end
	end
	FileUtils.rm nome_csv

	write_rsi_log :debug, "reprocessa.rb, imediatamente antes de escrever output XLS"
	book.write(nome_xls)
	write_rsi_log :debug, "gera_excel_reprocessar - escrevi output #{nome_xls}"
end


param_feat_dir = ARGV[0]
param_feat_dir.gsub('\\','/').chomp('/') #troca barra invertida por barra normal, e tira a ultima barra

ruby_file_definindo_deve_reprocessar = ARGV[1]
require ruby_file_definindo_deve_reprocessar #isso mesmo, passar um arquivo ".rb" q tem a definicao do método

xls_de_output_com_as_features_a_reprocessar=ARGV[2]#será depois passado,em outro programa, p/ gerador_massa.rb
deleta_excel_reprocessar xls_de_output_com_as_features_a_reprocessar


cleanup_de_features_interrompidas(param_feat_dir) 
#   CLEANUP: faz o mesmo rename de .feature pra .i.f.feature (.i.f=interromnpido e finalizado) que run_parallel.rb faz, 
# mas tem q fazer aqui antes


a_feature_names = lista_de_features_finalizadas_ausentes_da_fila(param_feat_dir)

write_rsi_log :debug, "reprocessa.rb : a_feature_names=#{a_feature_names}"

a_reprocessar = []

quantos_hack = nil
kq=0

a_feature_names.each do |feature_name|
	write_rsi_log :debug, "reprocessa.rb : checando feature_name=#{feature_name}, feature_name.encoding=#{feature_name.encoding}"
	write_rsi_log :debug, "reprocessa.rb : feature_name.encode('UTF-8')=#{feature_name.encode('UTF-8')}"
	
	#maxtrn_desta_feature = max_trn_da_feature(param_feat_dir, feature_name)
	test_outputs = get_test_outputs_da_feature(param_feat_dir, feature_name) #, maxtrn_desta_feature)
	write_rsi_log :debug, "reprocessa.rb : obteve test_outputs de feature_name=#{feature_name}"
	#puts "BLABLA feature_name=#{feature_name}"
	#puts "BLABLA test_outputs==#{test_outputs}"

	razao = nil
	ff = feature_name.clone
	razao = deve_reprocessar(feature_name, test_outputs) #(feature_name, test_outputs)
	write_rsi_log :debug, "reprocessa.rb : checou deve_reprocessar de ff=#{ff}, feature_name=#{feature_name}"
	# razao = xxxnada(feature_name, test_outputs) #(feature_name, test_outputs)
	if razao
		kq=kq+1
		a_reprocessar << {:feature_name=>feature_name, :razao=>razao} 
		write_rsi_log :debug, "a reprocessar, feature_name=#{feature_name}, razao=#{razao}"
		if quantos_hack and quantos_hack > 0 and kq  == quantos_hack
			break
		end
	end
	



end


write_rsi_log "reprocessar.rb: a_reprocessar.length=#{a_reprocessar.length}" 
gera_excel_reprocessar xls_de_output_com_as_features_a_reprocessar,a_reprocessar
