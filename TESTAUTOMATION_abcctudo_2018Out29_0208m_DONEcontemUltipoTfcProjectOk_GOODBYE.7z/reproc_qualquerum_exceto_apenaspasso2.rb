# encoding: UTF-8
require_relative './rotinas_processo.rb'

def xxxnada(p1,p2)
	return "a"
end

def tem_cpf_ja_usado(o)
	falhar "inutil, nao diminuiu sensivelmente a quantidade de /CPF j.** utilizado/"
	featname_log=o[:outputs][:featname_log]
	fnd=[]
	if (featname_log and File.exist? featname_log)
		fnd = File.readlines(featname_log).grep(/CPF j.*usado/)
	end
	retval = fnd.length > 0
	write_rsi_log "Busca por /CPF j.*usado/, no arquivo featname_log=#{featname_log} retornou #{fnd}, portanto retval = #{retval}"
	return retval 
end

def restringe_outputs_aos_sem_problema(all_outputs)


#
# 2017Out12 - NAO REFAZENDO LOGICA basica: nao devo levar em conta epanas a ultima execucao.
#
#      Porém, temos uma dificuldade: se houver diferença entre STEP DEFINITIONS estre uma execucao
# e outra, eu terei problemas em obter TRN Q TEVE MAIS PASSOS OK... passos podem ser até distintos
#
#
#     ENTAO: Pode até mesmo ser que , mesmo com QTDE de steps igual, os steps tenham outri significado
#          ** HMMM, situação borderline...
#          ** COM ISSO EU NAO SEI LIDAR AGORA!
#
#      ** SIMPLIFICACAO: se houver diferença de qtde de steps entre TRNs, somente a ultima run
#      será levada em conta.
#           ASSIM, posso manter lógica básica. 

	

	#2017Out18 se UNIX regexp "CPF j.*usado" encontrado no Log com nome da feature, desconsidera TRN...
	# CUIDADO! Tenho que deixar ao menos uma TRN , da mais recente pra mais antiga.
	if false
		maxtrn = all_outputs.max{|o1,o2| o1[:trn] <=> o2[:trn]} [:trn]
		o_trn_mais_recente = all_outputs.select{|o| o[:trn] == maxtrn}
		outs_sem_cpfjausado = all_outputs.
			select{|o| true or (not tem_cpf_ja_usado(o))}.
			sort{|o1,o2| -1*(o1[:trn]<=>o2[:trn])}
		if outs_sem_cpfjausado.length == 0
			outs_sem_cpfjausado=[trn_mais_recente]
		end
		all_outputs = outs_sem_cpfjausado
	end

	maxtrn = all_outputs.max{|o1,o2| o1[:trn] <=> o2[:trn]} [:trn]
	qt_steps = -1
	problema_steps = false
	all_outputs.each do |o|
		quantos_steps_trn = (o[:outputs][:steps] || []).length
		if qt_steps == -1
			qt_steps = quantos_steps_trn
		end
		if quantos_steps_trn != qt_steps #evita lidar com TRNs que tenham steps incompativeis
			problema_steps = true
			break
		end
	end
	if qt_steps <= 0 #se nenhuma TRN tem qt_steps positivo, tbm é um problema
		problema_steps = true
	end


	if problema_steps
		#filtra all_outputs, pra pegar apenas a ultima TRN, e com apenas uma TRN
		all_outputs = all_outputs.select{|o| o[:trn] == maxtrn}
	end

	return all_outputs
end

def deve_reprocessar(feature_name, all_outputs)
	if false
		return "reprocessando todo mundo na marra"
	end

	all_outputs = restringe_outputs_aos_sem_problema(all_outputs)


	retval = nil
			
	razao_result=nil

	#write_rsi_log "all_outputs=#{all_outputs}, all_outputs.last=#{all_outputs.last}"
	

	maxtrn = all_outputs.max{|o1,o2| o1[:trn] <=> o2[:trn]} [:trn] #2017Set01, FIX, "[:trn]" ao fim!!
	maxtrn_passed = nil
	max_step_passed = -1
	max_step = -1
	all_outputs.each { |o|
		o[:outputs][:steps].each_index { |k|
			if k >= max_step #DUMMY, conta steps
				max_step = k
			end

			stp = o[:outputs][:steps][k]
			
			if "#{stp['result']['status']}" == 'passed'
				if k >= max_step_passed #>=, privilegia mais recente reexecucao com mesma condicao
					max_step_passed = k
					maxtrn_passed = o[:trn]
				end
			end
		}
	}
	best_trn = maxtrn_passed || maxtrn
	best_output = all_outputs.select{|o|o[:trn]==best_trn} [0]
	write_rsi_log :debug, "maxtrn=#{maxtrn}, best_trn=#{best_trn}, maxtrn=#{maxtrn}"
	write_rsi_log :debug, "max_step=#{max_step},max_step_passed=#{max_step_passed}"
	write_rsi_log :debug, "best_output=#{best_output}"
	write_rsi_log :debug, "best_output[:outputs]=#{best_output[:outputs]}"
	write_rsi_log :debug, "best_output[:outputs][:feature]=#{best_output[:outputs][:feature]}"
	ffile_best = best_output [:outputs][:feature]


	# AQUI.sei QUAL O MAX STEP OK (max_step_passed), em qual trn (maxtrn_passed)
	if (max_step and max_step >= 0) and (max_step_passed == max_step)
		write_rsi_log :info, "reproc_BLA.rb: nao precisa reprocessar, 100 pct ok, feature_name=#{feature_name}, ffile_best=#{ffile_best}, PORQUE max_step=#{max_step_passed} EH IGUAL A #{max_step}"
		return nil #significa ALGUMA EXECUCAO FUNCIONOU ATEH ULTIMO STEP, 100% OK
	end


	if ffile_best.include? 'interrompid'
		#write_rsi_log :debug, "reproc_BLA.rb: ULTIMA INTERORMPIDA. ffile_best=#{ffile_best}"
		razao_result="interrompida" 
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end
	
#
# INCOMPATIBLE CP850 - eh em 1o passo: ainda nao sei o que eh, nao vi como fica OUTPUTs, ALL_OUTs,
# quando dá isso no primeiro passo: o texto tá em FF (FEATURE FILE), depois eu descubro: até agora,
# 5 de aprox 140 deram isso, toleravel
#
#
	todas_msgs = []
	if best_output[:outputs][:steps]
		todas_msgs = best_output[:outputs][:steps].map {|st|
			st['result']['error_message'] || ''
		}
	end

	o=best_output
	stt = ''; msg = nil
	begin
		msg=o[:outputs][:steps] [7]['result']['error_message'] if o[:outputs][:steps]
		msg=msg.split("\n").first if msg
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end

	if (msg||'').include? ascii_only_str(get_msgerr_label_solicitacao_enviada_nao_presente_na_tela) #passo EnvioSolic, muito provavelmente "Desculpe-nos, estamos fazendo alguns ajustes"
		write_rsi_log :info, "reproc_BLA.rb: CASE ELSE FINAL, nao precisa reprocessar, feature_name=#{feature_name}"
		return nil
	end

	#2017Out19 - novidade: para ver se msg aparecer em qualquer step, podemos checar assim.	
	#CLARO, esta checagem nao nos diz em qual step apareceu... mas aqui queremos ignorar, OK
	if todas_msgs.index {|m| m.include? ascii_only_str(get_msgerr_desculpe_fazendo_ajustes)}
		write_rsi_log :info, "reproc_BLA.rb: CASE ELSE FINAL, nao precisa reprocessar, feature_name=#{feature_name}"
		return nil
	end

	if todas_msgs.index {|m| m.include? ascii_only_str(get_msgerr_cpf_recuperado_ou_maisdados)}
		#costuma ser por CPF ruim, etc, nao reprocessa
		#. OBS: 2017Out20 tecve bastante desses erros por VERACIDADE VERMELHA SEM MASSA, CPF ZEROS
		write_rsi_log :info, "reproc_BLA.rb: CASE ELSE FINAL, nao precisa reprocessar, feature_name=#{feature_name}"
		return nil
	end

	if false and todas_msgs.index {|m| m.include? 'Status de veracidade invalido'}
		write_rsi_log :info, "reproc_BLA.rb: CASE ELSE FINAL, nao precisa reprocessar, feature_name=#{feature_name}"
		return nil
	end


	o=best_output
	stt = ''; msg = nil
	begin
		msg=o[:outputs][:steps] [2]['result']['error_message'] if o[:outputs][:steps]
		msg=msg.split("\n").first if msg
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end
	if (msg||'').include? 'Pacote de ofertas da massa de dados' #segundo passo, old known bug, pacote de ofertas nao encontrado. 2017Out30, fix msg para nova msg
		write_rsi_log :info, "reproc_BLA.rb: CASE ELSE FINAL, nao precisa reprocessar, feature_name=#{feature_name}"
		return nil
	end

	if false
		o=best_output
		stt = ''; msg = nil
		begin
			msg=o[:outputs][:steps] [4]['result']['error_message'] if o[:outputs][:steps]
			msg=msg.split("\n").first if msg
		rescue Exception => e
			write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
		end
		if (msg||'').include? 'incompativel' #quarto passo, TIPO/NOME cartao incompativel
			write_rsi_log :info, "reproc_BLA.rb: CASE ELSE FINAL, nao precisa reprocessar, feature_name=#{feature_name}"
			return nil
		end
	end

	o=best_output
	step_do_erro = max_step_passed + 1
	msg='mensagem indefinida'
	stt = 'status indefinido'
	if o[:outputs][:steps] and o[:outputs][:steps][step_do_erro] and o[:outputs][:steps][step_do_erro]['result'] 
		if o[:outputs][:steps][step_do_erro]['result']['error_message']
			msg=o[:outputs][:steps] [step_do_erro]['result']['error_message'] 
			msg=msg.split("\n").first if msg
		end
		if o[:outputs][:steps][step_do_erro]['result']['status']
			stt=o[:outputs][:steps] [step_do_erro]['result']['status'] if o[:outputs][:steps]
	 	end
	end
	razao_result = "Falhou, step #{step_do_erro}, stt #{stt}, msg #{msg}"
	#puts razao_result
	#if stt != 'skipped'
	#	exit 1
	#end

	write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result.encode('UTF-8')}, feature_name=#{feature_name.encode('UTF-8')}, ffile_best=#{ffile_best.encode('UTF-8')}"
	return razao_result
end

def qual_trn_reportar(feature_name, all_outputs)
#
#
#            C U I D A D O
#
#      CONSOLIDADO pode ter mesmo erro de NAO IGNORAR MAX_STEP/BLA_STEP -1 Q TINHA EM deve_reprocessar! 
#
#
#
#
#
#
	all_outputs = restringe_outputs_aos_sem_problema(all_outputs)

	maxtrn = all_outputs.max{|o1,o2| o1[:trn] <=> o2[:trn]}  [:trn] #2017Out13, FIX, "[:trn]" ao fim!!
	maxtrn_passed = nil

	max_step_passed = -1

	all_outputs.each { |o|
		o[:outputs][:steps].each_index { |k|
			stp = o[:outputs][:steps][k]
			
			if "#{stp['result']['status']}" == 'passed'
				if k >= max_step_passed #>=, privilegia mais recente reexecucao com mesma condicao
					max_step_passed = k
					maxtrn_passed = o[:trn]
				end
			end
		}
	}

	return maxtrn_passed || maxtrn
end