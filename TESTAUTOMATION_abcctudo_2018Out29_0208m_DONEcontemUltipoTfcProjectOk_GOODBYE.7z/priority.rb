require_relative 'features/support/shared_utils.rb'
set_wmic_priority
