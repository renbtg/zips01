load 'l.rb'
zs_read_cfgs
profile_block lambda {zs_get_runone_onlychosen_stts.length}