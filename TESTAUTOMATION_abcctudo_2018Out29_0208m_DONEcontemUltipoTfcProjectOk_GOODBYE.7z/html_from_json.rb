# encoding: UTF-8
require 'report_builder'
require './features/support/rsi_log'

class ReportBuilder 
###
#
#    rbattaglia, 2017Set3 - monkey-patch, arruma ENCODING na leitura das features.
# Poderia ser mais simples, apenas forçando UTF-8 em File.read (MANIPULAR DEFAULTS?),
# via monkey-patching de File.read ou, talvez, chumbar DEFAULT OPTIONS. 
#
###
  def self.files(path)
    # "MonkeyPatch de ReportBuilder::self.file(path=#{path}"
    files = if path.is_a? String
    (path =~ /\.json$/) ? [path] : Dir.glob("#{path}/**/*.json") #rbattaglia 2018Out3 - monkey-patching, sem precisar editar gem original #rbattaglia 2018Set20 - nao pegava subdirs, fixed. Deve ser mobkey-patcg, se possivel
            elsif path.nil?
              Dir.glob('*.json')
            elsif path.is_a? Array
              path.map do |file|
                (file =~ /\.json$/) ? file : Dir.glob("#{file}/*.json")
              end.flatten
            else
              raise 'InvalidInput'
            end
    raise 'MonkeyPatch de ReportBuilder.files(path) - InvalidOrNoInputFile - pois files.empty? deu true' if files.empty?
    files.uniq
  end


  def self.features(files)
    files.each_with_object([]) { |file, features|
        #data = File.read(file)
      puts 'lendo '
        data = File.read(file, :encoding =>'UTF-8') #rbattaglia, 2017Set3, fix encoding
      puts 'leu '
      next if data.empty?
      features << JSON.parse(data)
    }.flatten.group_by { |feature|
      feature['uri']+feature['id']+feature['line'].to_s
    }.values.each_with_object([]) { |group, features|
      features << group.first.except('elements').merge('elements' => group.map{|feature| feature['elements']}.flatten)
    }.sort_by!{|feature| feature['name']}.each{|feature|
      if feature['elements'][0]['type'] == 'background'
        (0..feature['elements'].size-1).step(2) do |i|
          feature['elements'][i]['steps'] ||= []
          feature['elements'][i]['steps'].each{|step| step['name']+=(' ('+feature['elements'][i]['keyword']+')')}
          feature['elements'][i+1]['steps'] = feature['elements'][i]['steps'] + feature['elements'][i+1]['steps']
          feature['elements'][i+1]['before'] = feature['elements'][i]['before'] if feature['elements'][i]['before']
        end
        feature['elements'].reject!{|element| element['type'] == 'background'}
      end
      feature['elements'].each { |scenario|
        scenario['before'] ||= []
        scenario['before'].each { |before|
          before['result']['duration'] ||= 0
          before.merge! 'status' => before['result']['status'], 'duration' => before['result']['duration']
        }
        scenario['steps'] ||= []
        scenario['steps'].each { |step|
          step['result']['duration'] ||= 0
          duration = step['result']['duration']
          status = step['result']['status']
          step['after'].each { |after|
            after['result']['duration'] ||= 0
            duration += after['result']['duration']
            status = 'failed' if after['result']['status'] == 'failed'
            after.merge! 'status' => after['result']['status'], 'duration' => after['result']['duration']
          } if step['after']
          step.merge! 'status' => status, 'duration' => duration
        }
        scenario['after'] ||= []
        scenario['after'].each { |after|
          after['result']['duration'] ||= 0
          after.merge! 'status' => after['result']['status'], 'duration' => after['result']['duration']
        }
        scenario.merge! 'status' => scenario_status(scenario), 'duration' => total_time(scenario['before']) + total_time(scenario['steps']) + total_time(scenario['after'])
      }
      feature.merge! 'status' => feature_status(feature), 'duration' => total_time(feature['elements'])
    }
  end

end

def html_from_json_main(argv=[]) #2018Ago19 am, permite nao receber parametros
# Ex 1:
    write_rsi_log "html_from_json_main(), argv=#{argv}"
    base_report_path = (argv[0] || 'reports')
    puts "base_report_path=@@#{base_report_path}@@@"

    ReportBuilder.configure do |config|
      config.json_path = base_report_path+'/' #2018Set13, corrigido , melhorou para execucoes manuais de html_from_json
      config.report_path = base_report_path + '/consolidado'
      config.report_types = [:json, :html]
      config.report_tabs = [:overview, :features, :scenarios, :errors]
      config.report_title = 'Resultados - Automacao Abertura Conta Digital PF'
      config.compress_images = false
      config.additional_info = {browser: 'Chrome', environment: 'Stage 5'}
    end
    puts "configurou"
    
    begin
      puts "vai build"
        ReportBuilder.build_report
      puts "foi build"
    rescue RuntimeError => e
      #2018Ago19 pm, adicionado ignorar excecao com InvalidOrNoInputFile
        if not (e.to_s||'').include? 'InvalidOrNoInputFile'
            raise e
        else
            write_rsi_log :debug, "main_consolidar_reports, ignorando excecao com InvalidOrNoInputFile, excecao=#{e}"
        end
    end
    return
end

if ARGV.length > 0 and ARGV[0] == 'run_html_from_json'
  html_from_json_main ARGV.drop(1)
end