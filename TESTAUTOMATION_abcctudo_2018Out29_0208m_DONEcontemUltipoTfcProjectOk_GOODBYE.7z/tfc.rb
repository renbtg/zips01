require_relative 'features/support/shared_utils.rb'
require_relative 'features/support/rsi_utils.rb'

class TfcNaoSubiuPorTimeoutException < Exception
	def initialize(msg="Tfc Nao Subiu Por Timeout")
		super msg
	end
end

def tfc_full_batch
	return "#{get_automdir}/#{tfc_basic_batchname}"
end
def tfc_basic_batchname
	return "tfc_server_run.bat"
end

def tfc_cmdorigem_path
	return "#{get_automdir}/tfc_origem/tfc_cmd.properties"
end
def tfc_outorigem_path
	return "#{get_automdir}/tfc_origem/tfc_out.properties"
end
def tfc_config_path
	return "#{get_automdir}/tfc_config.properties"
end

def tfc_remove_properties
	delete_all_in_dir "#{get_automdir}/tfc_origem"
	delete_all_in_dir "#{get_automdir}/tfc_destino"
end

def tfc_filepath_upandrunning
	return "./tfc_upandrunning.properties"
end

def tfc_reiniciar_servidor_java
	ignora_excecoes{FileUtils.rm tfc_filepath_upandrunning}


	mkdir_noexist "./tfc_origem"
	mkdir_noexist "./tfc_destino"

	write_rsi_log :debug, "tfc_reiniciar_servidor_java P01"
	tfc_remove_properties

	write_rsi_log :debug, "tfc_reiniciar_servidor_java P03, tfc_cmdorigem_path=#{tfc_cmdorigem_path}"
	h = Hash.new
	h['CAMINHO_LOG']=tfc_get_property_caminho_log
	h['DIR_REPORT']="#{get_automdir}/reports/TRN#{ENV['TEST_RUN_NUM']}"
	save_java_properties tfc_cmdorigem_path, h  #FAÇA SERVIDOR TFC JAVA PROCESSAR 

	$pid_tfc_server = spawn tfc_full_batch
	tstart = Time.now
	segundos_limite = 180 #tempo só pra subir o Java e receber resposta simples do main() 
	while not File.exist? tfc_outorigem_path
		tnow = Time.now
		elapsed = tnow - tstart
		write_rsi_log "tfc_reiniciar_servidor_java, P05.0 - segundos_limite = #{segundos_limite}, elapsed=#{elapsed}, tnow=#{tnow}, tstart=#{tstart}, $pid_tfc_server=#{$pid_tfc_server}"

		if elapsed > segundos_limite 
			falhar "falhou por timeout ao subir [java -jar] servidor tfc"
		end
		sleep 10
	end
	out_hash=load_java_properties(tfc_outorigem_path)
	tfc_remove_properties #desnecessario, overkill
	write_rsi_log :debug, "tfc_reiniciar_servidor_java - achou arquivo de output, out_hash=#{out_hash}"

	write_rsi_log :debug, "tfc_reiniciar_servidor_java retornando"
end

def tfc_subir_aplicacao()

	write_rsi_log :debug, "tfc_subir_aplicacao P00"
	
	
	tfc_remove_properties
	FileUtiis.rm tfc_filepath_upandrunning rescue nil

	# DONE remnovido erro crasso: subia novamente o "spawn tfc_full_batch" (java -jar) AQUI!

	write_rsi_log :debug, "tfc_subir_aplicacao P03, tfc_cmdorigem_path=#{tfc_cmdorigem_path}"
	h = Hash.new
	h['DIR_REPORT']="#{get_automdir}/reports/TRN#{ENV['TEST_RUN_NUM']}"
	h['CAMINHO_LOG']=tfc_get_property_caminho_log
	write_rsi_log :debug, "tfc_subir_aplicacao P03.1"
	save_java_properties tfc_cmdorigem_path, h  #FAÇA SERVIDOR TFC JAVA PROCESSAR BOOT! No caso de tfc_cmd, serah mais chato, pois terei que adicionar CPF e LIMITE etc.
	write_rsi_log :debug, "tfc_subir_aplicacao P03.2"

	write_rsi_log :debug, "tfc_subir_aplicacao P04"


	tstart_checkboot = Time.now
	segundos_limite = 650 #tempo no Java de execTFC=400. Entao, incluindo login, chutei aqui 650.
	falhou_por = nil
	while not File.exist? tfc_outorigem_path
		tnow = Time.now
		elapsed = tnow - tstart_checkboot
		write_rsi_log "tfc_subir_aplicacao, P05.0 - segundos_limite = #{segundos_limite}, elapsed=#{elapsed}, tnow=#{tnow}, tstart_checkboot=#{tstart_checkboot}, $pid_tfc_server=#{$pid_tfc_server}"

		if elapsed > segundos_limite 
			write_rsi_log :error, "falhou pór timeout ao iniciar servidor tfc"
			err_fail = "tfc_subir_aplicacao: falha DE MODO FORÇOSAMENTE ABORTIVO, por timeout ao iniciar aplicacao"
			write_rsi_log :error, err_fail
			falhou_por = err_fail
			break
		end

		write_rsi_log :debug, "tfc_subir_aplicacao P05.1, dormindo"
		sleep 5
		write_rsi_log :debug, "tfc_subir_aplicacao P05.2, dormiu"
	end
	write_rsi_log :debug, "tfc_subir_aplicacao P06"
	if not falhou_por
		out_hash = load_java_properties(tfc_outorigem_path)
		tfc_remove_properties #desnecessario, overkill
		write_rsi_log :debug, "tfc_subir_aplicacao P07 - out_hash=#{out_hash}"
		if out_hash['RUN_STATUS'] != 'OK'
			#PROBLEM:O- Nao subiu ok Terminal no boot. ABORTIVO! A nao ser que vamos trabalhar sem TFC, devemos aqui e agora interromper fluxo todo. 
			err_fail = "Falha ,  impossivel fazer boot de tfc_server, RUN_STATUS=#{out_hash['RUN_STATUS']}, MENSAGEM=#{out_hash['MENSAGEM']}"
			write_rsi_log :error, err_fail
			falhou_por = err_fail
		end

	end

	if falhou_por
		falhar falhou_por #qualquer tipo de erro em subida da java-webstart-app TFC vai fazer RAISE de EXCEPTION
	end

	write_rsi_log :debug, "tfc_subir_aplicacao - retornando"

end

def tfc_is_desabilitado?
	desabilitado=(load_java_properties(tfc_config_path)['DESABILITADO'])||'0'
	return desabilitado=='1'
end

def tfc_do_server_kill
	if tfc_is_desabilitado?
		write_rsi_log :debug, "tfc_do_server_kill, nem precisa matar nada , SERVIDOR TFC DESABILITADO"
		return
	end
	kill_and_watch ['javaw.exe', 'tfcrun.jar'], 128 #2018Abr13 - apenas javaw.exe e tfcrun.jar já dão conta de matar java-like de tfc
	return
end


def tfc_do_server_boot
	if false
		50.times {write_rsi_log :debug, "DUMMY DEBUG , Nao vou subir TFC"}
		sleep 30
		return
	end

#
#    TODO 2018Mar19 - esta estratégia é boa e simples para zs_proc. Porém,
# para o gera_e_executa.bat tradicional, em caso de lentiddao extrema 
# e/ou falha do TFC no startup, vamos ficar em loop , falhando sempre
# por nao ter subido completamente, até consumir todas as features e seus
# reprocessamentos. Apenas uma inbterrupcao forçada seguida de
# "reinicia_execucao.bat" vai fazer o servidor/aplicacao TFC subir no-
# vamente. TODO 2019Mar19 - pensar em como resolver isto!! 
#
	write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P00"

	if tfc_is_desabilitado?
		write_rsi_log :debug, "tfc_do_server_boot, NAO VAI SUBIR SERVIDOR TFC, DESABILITADO"
		return
	end
	write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P00.5"

	FileUtils.rm tfc_filepath_upandrunning rescue nil
	if File.exist? 'tfc_subindo_servidor.lck'
		write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P01"
		falhar "tfc_do_server_boot, Subida de tfc_servidor nao foi concluida" if not File.exist? 'tfc_subiu_servidor.lck'
		write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P01.6"
	else
		write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P02"
		create_new_file('tfc_subindo_servidor.lck')
		write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P03"
		begin
			tfc_reiniciar_servidor_java
		rescue Exception => e
			tfc_do_server_kill #2018Abr01 21:31 - apenas matar tudo de tfc se erro nas chamadas de baixo nivel (tfc_reiniciar_servidor_java e tfc_subir_aplicacao). TENTATIVA de evitar estranha morte precode (derrubando processo javaw) do TFC
			falhar e
		end
		write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P04"
		create_new_file('tfc_subiu_servidor.lck')
		write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P05"
	end 
	write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P06"

	if File.exist? 'tfc_subindo_aplicacao.lck'
		falhar "tfc_do_server_boot, Subida de tfc_aplicacao nao foi concluida" if not File.exist? 'tfc_subiu_aplicacao.lck'
		write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P07"
	else
		write_rsi_log "tfc_do_server_boot, ENV['TEST_PROCESS_NUM']=#{ENV['TEST_PROCESS_NUM']}, P08"
		create_new_file('tfc_subindo_aplicacao.lck')
		begin
			tfc_subir_aplicacao
		rescue Exception => e
			tfc_do_server_kill #2018Abr01 21:31 - apenas matar tudo de tfc se erro nas chamadas de baixo nivel (tfc_reiniciar_servidor_java e tfc_subir_aplicacao). TENTATIVA de evitar estranha morte precode (derrubando processo javaw) do TFC
			falhar e
		end
		create_new_file('tfc_subiu_aplicacao.lck')
	end
	write_rsi_log :debug, "tfc_do_server_boot, concluida"
	return
end



def format_money(n)
	n = n.to_f #2018Out5 - aceita string em formato RUBY CRU a ser convertida em valor, e de valor para string money
	#TODO 2018Fev10 - rbattaglia - converter parametro pra Monetize, entao chama Monetize::to_money. Mais seguro que presumir que parametro é numeric. 
	I18n.config.available_locales = :en
	str_n = Money.new(n*100,'BRL').format.gsub('R$','')
	return str_n
end

def tfc_format_money(v)
	retval = nil
	f = 0.0
	if v.is_a?(String)
		#2018Mar21, string pode precisar de tratamento
		f=v.gsub('.','').gsub(',','.').to_f
	else
		f = v
	end
	retval = format_money(f)
	write_rsi_log "tfc_format_money(v=#{v}, f=#{f}, retval=#{retval}"

	return retval
end

def tfc_faz_automacao_do_cenario()
	if tfc_is_desabilitado?
		write_rsi_log :debug, "NAO VAI FAZER AUTOMACAO TFC, TFC DESABILITADO"
		return
	end

	#2018Set09 00:22 - removido "executa_exclusivo" que envolvia tfc_do_server_boot e tfc_processa_faz_automacao_do_cenario
	tfc_do_server_boot #2017Mar16 - chama BOOT em todos, boot mudou

	tfc_processa_faz_automacao_do_cenario #2017Mar16 - chama BOOT em todos, boot mudou
end


def tfc_processa_faz_automacao_do_cenario()

	#2018Set07 - HMMM, este mecanismo de rodar TFC cada vez parece menos apto a ser executado fora do processo colaborativo. Tudo bem, afinal de contas, os regressivos NUNCA são executados sem zs_proc/ProcessoColaborativo!!

	#2018Set07 - revamped e simplificado. Sempre deve estar rodando apenas tfc com paralelismo real 1: "tfc nao convive bem com outras apps/tecnologias". Além disso, a tal detecao de "tempo limite até achar q pendente" nao fazia o menos sentido (talvez tenha feito nos primórdios, em fins de 2017 ou início de 2018).

	#2017Set07 - LOOP while true inútil removido, chama uma única vez tfc_one_server_cmd

	write_rsi_log :debug, "tfc_faz_automacao_do_cenario(), entrando,  $massa['STEP_INICIAL']=#{$massa['STEP_INICIAL']}"

	out_hash = tfc_one_server_cmd
	if out_hash['RUN_STATUS']=='OK'
		return
	end
	
	falhar_agora = false
	deve_falhar_definitivo = false
	
	if true #2018Set07 - falhar_agora sempre true, já que agora sempre tfc isolado (pela logica antiga)... #if processando_apenas_tfc #2018Ago14 - COMMENT - "processando_apenas_tfc" é sempre TRUE, nao há convívio entre TFC e browsers etc.!! # 2018Abr02 99:23am, mudança de abordagem: simplesmente, nao faz retentativa de forma alguma em 'SemPropostaPendNucleoException' se STEP_INICIAL=10 (TFC)!
		falhar_agora = true
	end

	sufixo_msg = '' #2018Set11, corrigido. Faltava essta inicializacao, o que gerava erro de NIL adiante
	if (out_hash['MENSAGEM']||'').include?('SemPropostaPendNucleoException')
	    # 2018Ago01 - possivel refluxo para STEP 0 apenas quando nao encontroiu proposta pendente, sem mais variacoes!!! #or ( out_hash['INICIOU_CHECK_PROPOSTA_PENDAPROV'] =='1' and out_hash['CONCLUIU_CHECK_PROPOSTA_PENDAPROV'] !='1') 

	    #2018Set07 - ATENCAO - retirando de refluxo automatico pra step 0 do método rsi_utils.rb::reinsere_clone_reproc_feature()... ALÈM DISSO, desejo capacitar TFC a prosseguir processamento mesmo de proposta q já foi aprovada... e, para nao perder evidencias importante, TFC/JAVA deve re-visitar as telas que contam o número da AgenciaConta etc. (tudo q mostra como proposta está ANTES de aprovar deve ser revisitado para mostrar os dados após onfirmação/aprovacao... na retentativa... depois de falha por alguma razao qualquer nao-abortiva-geral da tentativa que confirmou/aprovou) 
		sufixo_msg = ', anotacaoRuby=TFC_STATUS_NOT_PENDENTE_APROV_DIGITAL'
	else
		if (out_hash['MENSAGEM']||'').include?('nao foi encontrada na pesquisa de nucleo inicial')
			deve_falhar_definitivo = true #2018Set07 - SIM, ok, nao encontrar a proposta é realmente causa de falhar_definitivo imediatamente! OK!   #2018Ago14 - falha definitivo se proposta nao encontrada nem na pesquisa de nucleo inicial 
		end
	end

	falhar "TFC ERRO CMD - falha ao processar comando, RUN_STATUS=#{out_hash['RUN_STATUS']}, MENSAGEM=#{out_hash['MENSAGEM']}" + sufixo_msg, deve_falhar_definitivo
end

def tfc_one_server_cmd
	#2018Set07 - revamping
	#2018Set07 - remivodo parametro inuti e mislerading "retry sequence"


	write_rsi_log :debug, "tfc_one_server_cmd P00"
	tfc_remove_properties
	FileUtils.rm tfc_filepath_upandrunning rescue nil
	write_rsi_log :debug, "tfc_one_server_cmd P01"

	prop_hash = Hash.new
	prop_hash['CENTRO']=ENV['TEST_TFC_CENTRO'] if ENV['TEST_TFC_CENTRO']
	#2018Out28 - tfc centro adicionado
	prop_hash['DIR_REPORT'] = "#{get_automdir}/#{get_nome_de_screenshot}" #rbtg nota-get_nome_de_screenshot retorna um nome de diretório!
	prop_hash['CAMINHO_LOG']=tfc_get_property_caminho_log
	prop_hash['CPF'] = $massa['CPF']
	prop_hash['LIMITE'] = tfc_format_money(($massa['VALOR_LIMITE_WEBAPP']||'0')) #2018Mar21 fix
	prop_hash['GLOBAL_SCENARIO_COUNT'] = $global_tfc_scenario_count # permite a servidor de TFC entender sequencia de chamada, imporantissimo para MOCK #2018Out5 - uso de LEANFT_MOCK está em desuso já há meses, pode até ser removido totalmente
	prop_hash['ARQUIVOS_INTERRUPCAO']=interrupcoes_file_names('TERMINAR').join(',')
	#2018Out10 00:04am - faltava passar propriedade ARQUIVO_INTERRUPCAO pro servidor

	#2018Out5 - reinserindo código de RENDA_INFORMADA x OUTRAS_RENDAS, que havia sido erradamente removido em merge anterior
	nMassaRenda = ($massa['RENDA'] || '0').to_f
	if nMassaRenda <= 4000
		prop_hash['RENDA_INFORMADA'] = tfc_format_money(nMassaRenda)
	else
		prop_hash['RENDA_INFORMADA'] = tfc_format_money(4001)
		prop_hash['OUTRAS_RENDAS'] = tfc_format_money(nMassaRenda)
	end

	write_rsi_log("tfc_one_server_cmd, P02, prop_hash=#{prop_hash}")
	save_java_properties tfc_cmdorigem_path, prop_hash  #FAÇA SERVIDOR TFC JAVA PROCESSAR BOOT! No caso de tfc_cmd, serah mais chato, pois terei que adicionar CPF e LIMITE.

	write_rsi_log :debug, "tfc_one_server_cmd P04"

	tstart_checkcmd = Time.now
	segundos_limite = 900
	#2018Set07 - segundos_limite aumentado para 900 segundos (15 minutos, era 400, foi 600 por) - nçao há razao de causar ABORCAO em um cenario de tfc por limite baixo
	#2018Set07 - TODO - ler, para cada maquina executora, tempo limite de arquivo dummy_cfg.rb para zs_proc. 

	

	while not File.exist? tfc_outorigem_path
		tnow = Time.now
		elapsed = tnow - tstart_checkcmd
		write_rsi_log "tfc_one_server_cmd, P05.0 - segundos_limite = #{segundos_limite}, elapsed=#{elapsed}, tnow=#{tnow}, tstart_checkcmd=#{tstart_checkcmd}"

		if elapsed > segundos_limite 
			# 2018Fev25 - BIZARRE! Chamadora reinicia servidor java, mas parece que nem sempre está protegendo bem.

			falhar "tfc_one_server_cmd - Falha de timeout TFCserver ao executar comando, em tfc_one_server_cmd. Neste instante, tela TFC pode estar instável, comportamento imprevisível. Algum método que chama este método deve fazer algum cleanup de TFC, reiniciar, matar JAVA/janelas, algo assim!!"
		end

		write_rsi_log :debug, "tfc_one_server_cmd P05.1, dormindo"
		sleep 5
		write_rsi_log :debug, "tfc_one_server_cmd P05.2, dormiu"
	end
	write_rsi_log :debug, "tfc_one_server_cmd P06"
	out_hash = load_java_properties(tfc_outorigem_path)
	tfc_remove_properties #desnecessario, overkill
	write_rsi_log :debug, "tfc_one_server_cmd retornando - out_hash=#{out_hash}"

	return out_hash
end
  
def tfc_get_log_fname
	return get_rsi_log_fname().gsub("\\","/").gsub('/Log_','/Tfc_')
end
def tfc_get_property_caminho_log
#2018Out10 am, created
#2018Out10, agora, podemos passar caminho adicional de log ao TFC server em java. Separacao por virgulas.
	return [tfc_get_log_fname,get_rsi_extra_log_fname].select{|n|n}.join(',')
end



