puts 'y.rb, chamando Kernel.exit'
Kernel.exit 1
