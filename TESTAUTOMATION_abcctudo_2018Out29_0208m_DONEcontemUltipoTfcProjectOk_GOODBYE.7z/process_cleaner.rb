require_relative './ipc_processo.rb'
require_relative 'features/support/rsi_log.rb'

assinaturas=[ #na verdade, mecanismo todo parece que precisa de ajustes p Linux
#	'chrome.exe',
#	'bash.exe'

#=begin
	### SEM ADMIN, fica pra sempre tendo java.exe chato!
	#'java.exe',
    # PARA a questao imediata de 2018Mar13, com TFC desabilitado, isso não é problema.

#2018Ago16 pm - residuo de CTRL+C/cmd_stop em "stt*act=done*.7z" aconteceu algumas vezes (COMPLEXAS DE DEBUGAR), gerando prolema em condolidador de reports (zs\zs_proc.rb consolidador). SOLUÇÂO: colocar asinaturas no método "zs_proc.rb::zs_run_parallel_process_signatures"(e outros lugares q matam forçosamente) na ordem correta, e, também, matar e esperar (em método "kill_and_watch") um a um os processos(em vez de matar_todos+esperar_todos.
	'zs_proc.rb realtime_report', 'zs_proc.rb consolidador', 'zs_proc.rb monitor', #2018Set01 - adicionados realtime_report,consolidador,monitor.
	'gera_e_executa.bat',
	'reinicia_execucao.bat',
	'reprocessa_falhas.bat',
	'run_parallel.rb',
	'consumidor_de_features.rb', 
	'cucumber', #2018Abr01, antes, era (erradamente, creio) '&& cucumber'
	'checador_erro_chrome.rb',
	'gerador_massa.rb',
		'javaw.exe', 'tfcrun.jar', #2018Abr13 - apenas javaw.exe e tfcrun.jar já dão conta de matar java-like de tfc
	'ahk_TPN',
	'chromedriver.exe',
	'chrome.exe',
#=end
]

assinaturas = ARGV[0].split(',') if ARGV.length == 1 
assinaturas = ARGV if ARGV.length > 1 

if ENV['TEST_DONT_PROCESSCLEAN_RUBY']=='1'
	write_rsi_log :debug, "process_cleaner.rb, para ZS_PROC.RB, nao vai matar gera_e_executa, ou mata a mais do q devia!"
	assinaturas = assinaturas - ['gera_e_executa.bat']
end

kill_and_watch assinaturas, 128 

if ENV['TEST_DONT_PROCESSCLEAN_RUBY']=='1'
	write_rsi_log :debug, "process_cleaner.rb, para ZS_PROC.RB, nao vai matar ruby, ou mata processos chamadores e gera conflito!"
else
	write_rsi_log :debug, "(mata até o process_cleaner.rb em si) Vai matar todos ruby"
	kill_and_watch ['ruby'], 128
	raise "NAO DEVE CHEGAR AQUI (mata até o process_cleaner.rb em si) pois matou todos ruby"
end

