# encoding: UTF-8
require './rotinas_processo.rb'

def rotina_de_interrupcao_em_log
	#2018Abr20 - adicionado método "rotina_de_interrupcao_em_log" para rápida morte
	checa_interrupcoes do |msg|
		write_rsi_log :debug,  msg
		Kernel.exit! 1
	end
end

if is_str_integer? (ARGV[0])
	quantos = ARGV[0].to_i
	deve_gerar_nice = (ARGV[1]||'0').to_i == 1 #2018Fev26, pra zs_proc PLUS nice/priorizacao
	puts "splitter.rb - vai chamar split_trns com parametros quantos=#{quantos}, deve_gerar_nice=#{deve_gerar_nice}"
	
	split_trns quantos, deve_gerar_nice, ARGV[2], ARGV[3], nil #2 e 3=feat_dir, massa_dir. Ult param nil=sem report_dir
else
	fail 'deprecated, useless'
	feature2 = ARGV[0].clone
	feature = feature2.gsub('999999999999999','88')
	puts "splitter.r, feature=#{feature}, feature.encoding=#{feature.encoding}, feature.force_encoding('UTF-8')=#{feature.force_encoding('UTF-8')}"
	split_trns 1, [feature.encode('utf-8')]
end
