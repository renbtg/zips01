require_relative './tfc.rb'


def tfc_existe_img_logon? (str_mock_or_leanft)
	exit_code = run_autohk_copia 'tfc_imglogon_find', str_mock_or_leanft
	return (exit_code==0)
end

if ARGV.length < 1
	falhar "tfc_logon_img.rb, esperado 1 parametro MOCK ou LEANFT, recebidos #{ARGV.length} parâmetros"
end
mock_or_leanft=ARGV[0].upcase
validos=['M','L']
if not validos.include? mock_or_leanft
	falhar "tfc_logon_img.rb, mock_or_leanft (#{mock_or_leanft}) invalido, deve ser um de validos (#{validos})"
end
str_mock_or_leanft=(mock_or_leanft=='M') ? 'mock' : 'leanft'

s_img_logon_encontrada = ((tfc_existe_img_logon?(str_mock_or_leanft)) ? 1 : 0).to_s
save_java_properties "#{get_automdir}/tfc_img_logon.properties",IMG_LOGON_ENCONTRADA: s_img_logon_encontrada
