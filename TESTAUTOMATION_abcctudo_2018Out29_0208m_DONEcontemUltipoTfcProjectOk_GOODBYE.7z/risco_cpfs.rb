require 'csv'

VERACIDADE_VERDE_SEM_PASTADIGITAL_0a8 = false  #deve ser FALSE em casos reais, onde usemos PastaDigital
CPF_CORTANA_ULTIMOS_DIGITOS_VALIDOS='02345678' #cpfs c/ ult digito ausente têm imagens criticadas pelo CORTANA
def condicao_veracidade(sinal_veracidade, cpf)
	#write_rsi_log :debug, "INI condicao_veracidade(sinal_veracidade=#{sinal_veracidade}, cpf=#{cpf})"
	if not $not_single_maq_zsproc_debug
		return true
	end

	if sinal_veracidade == nil
		ret = (cpf[8]!='1' and cpf[8]!='9')  
	elsif sinal_veracidade == 'verde'
		if VERACIDADE_VERDE_SEM_PASTADIGITAL_0a8
			#write_rsi_log :debug, "VERACIDADE_VERDE_SEM_PASTADIGITAL_0a8=#{VERACIDADE_VERDE_SEM_PASTADIGITAL_0a8}, entao, aceita como condicao_veracidade cpf[8] != '9'"
			ret = (cpf[8]!='9') #2017Out18 - APENAS para AberturaCC Sem Pasta
		else
			ret = (cpf[8]=='1')
		end		
	elsif sinal_veracidade == 'amarelo' #2018Out5, AMARELO apenas para gerar cpfs_risco.xls, AUTOMACAO RUBY AINDA NAO SABE LIDAR COM VERACIDADE AMARELO!
		ret = ('2345678'.include? cpf[8])
	else
		ret = (cpf[8]=='9')
	end
	write_rsi_log :debug, "condicao_veracidade(sinal_veracidade=#{sinal_veracidade}, cpf=#{cpf}, ret=#{ret})"
	return ret
end

def get_lockfile_obter_cpf_risco
	#created: 2018Fev23
	return ENV['TEST_LOCKFILE_CPFS_FISCO'] || 'LOCK_OBTER_CPF_RISCO'
end

def get_xls_cpfs_risco
	arq = ENV['TEST_XLS_CPFS_RISCO'] || "cpfs_risco.xls"
	if File.basename(arq) == arq
		arq = "#{get_automdir}/planilhas e controles/#{arq}"
		write_rsi_log "get_xls_cpfs_risco: basename #{File.basename arq} == #{arq}, retornando #{arq}"
	else
		write_rsi_log "get_xls_cpfs_risco: basename #{File.basename arq} diferente #{arq}, retornando #{arq}"
	end
	return arq
end

def rsk_cpf_cols 
	return ['CPF', 'TIPO_CREDITO', 'PROCESSADO', 'STATUS', 'DATA_ENVIADO', 'DATA_DEFINIDO', 'DATA_PROCESSADO']
end

def reescreve_xls_risco(xls_file, colnames, hash_array)
	#2017Dez13 04:29am - ABORTANDO quando processo distribuido sem cpfs_risco.xls @@
	# ESQUISITAO! "ruby joiner.rb", processo externo, cai e aí tudo se atrapalha...
	#
	#   SOLUÇÂO paliativa, enquanto IPC X "dead child precise check" não é implementado,  
	# nem tampouco tolerância a falhas ====> ignorar exceção. XGH

	begin
		if hash_array and hash_array.length > 0
			core_reescreve_xls_risco(xls_file, colnames, hash_array)		
		end
	rescue Exception => e
		write_rsi_log :error, "reescreve_xls_risco, Excecao #{e} ignorada, parametros: xls_file=#{xls_file}, colnames=#{colnames}"
	end	
	return
end

def core_reescreve_xls_risco(xls_file, colnames, hash_array)
	if false
		write_rsi_log :debug, "reescreve_xls_risco - NAO FAZENDO NADA!!!"
		return
	end

	write_rsi_log :debug, "reescreve_xls_risco(#{xls_file}) - iniciado"
	salva_arquivo_xls(xls_file, colnames, hash_array)
	return
end



def risco_liberar_cpfs_reservados
	raise '#2018Ago01 - DEPRECATED , prejudicial, nao usar mais conceito de reserva de cpf: queimar imediatamente'
end

def risco_obter_cpf(sinal_veracidade, tipo_credito)
	return nil if not File.exist? get_xls_cpfs_risco
	if not $not_single_maq_zsproc_debug
		return get_random_cpf(1)
	end
	## deve ser chamada em outro instante. 
	retval = nil

	rcpfs = ler_xls_com_id(get_xls_cpfs_risco, nil, nil, -1)

	#2018Mar14 - SOLVED NASTY BUG! cpfs com menos q 11 posicoes... brancos à direita, ou whatever, nem brancos. SOUCAO: cpf RIGHT JUSTIFIED, 11 posices. STRZERO deu no webdesktop como CPF INVALIDO!
	# NAO FUNCIONA!rcpfs = rcpfs.map{|row| row['CPF']=row['CPF'].to_i.to_s.strip.rjust(11, ' '); row}
	#
	#
	# VOU DESCONSIDERAR OS CPFS DA MASSA QUE NAO TENHAM 11 POSICOES NUMERICAS E COMEÇANDO COM != 0 !! 
	#


	rcpfs.each do |lc|
		if lc['PROCESSADO']!='0'
			#write_rsi_log :debug, "next pq lc['PROCESSADO'] = '#{lc['PROCESSADO']}'"
			next
		end
		if (strzero(lc['CPF'].to_i,11) != lc['CPF']) 
			#2018Mar14 - se nao tiver 11 posicoes numericas, ignore!
			next
		end
		if (lc['CPF'][0]== '0')
			 #201Ago10 - NAO ignora mais começar com 0
			 #next
		end
		if ascii_only_str(lc['TIPO_CREDITO']).downcase != ascii_only_str(tipo_credito).downcase
			#write_rsi_log :debug, "next pq lc['STATUS'] = '#{lc['STATUS']}' , e tipo_credito=#{ascii_only_str(tipo_credito).downcase} e lc['TIPO_CREDITO']=#{ascii_only_str(lc['TIPO_CREDITO']).downcase}"
			next
		end

		if not condicao_veracidade(sinal_veracidade,lc['CPF'])
			#write_rsi_log :debug, "(DEVERIA HAVER COLUNA SINAL VERACIDADE NO XLS DE CPF) - next pq condicao_veracidade de sinal #{sinal_veracidade} e CPF #{lc['CPF']} = #{condicao_veracidade(sinal_veracidade,lc['CPF'])}"
			next
		end

		if (not CPF_CORTANA_ULTIMOS_DIGITOS_VALIDOS.include?(lc['CPF'][10]))
			#write_rsi_log :debug, "next pq ultimo digito = '#{lc['CPF'][10]}' , e CPF_CORTANA_ULTIMOS_DIGITOS_VALIDOS=#{CPF_CORTANA_ULTIMOS_DIGITOS_VALIDOS}"
			next
		end

		lc['PROCESSADO']='1' #2018Ago01 - removido conceito de reserva , prejudicial, nao usar mais conceito de reserva de cpf: queimar imediatamente


		if File.exist? get_xls_cpfs_risco #"if" estúpido, pois soh chego aqui c arquivo CPFs existindo
			FileUtils.cp get_xls_cpfs_risco, get_xls_cpfs_risco.split('.xls')[0]+'.anterior.xls'
			write_rsi_log :debug, "manipulando lc[1PROCESSADO']='1', $rcpfs!!" 
			reescreve_xls_risco(get_xls_cpfs_risco, rsk_cpf_cols, rcpfs)
		end

		write_rsi_log "BREAK ACHOU lc['CPF']=#{lc['CPF']}"
		retval = lc['CPF']
		break #EITA NÒIS, será que o RETURN nao retornava? Só saía do bloco?
	end

	write_rsi_log "risco_obter_cpf(#{sinal_veracidade}, #{tipo_credito}) - Retornando #{retval}"
	return retval

end

def distribui_cpfs_naoqueimados(cpfs, q)
=begin
#   2017Nov26
#
#   Retorna array de Hashs de cpfs divivida em "q" partes, com TIPO_CRÈDITO 
# [Crédito, Débito e Crédito Adormecido] distribuídos igualmente qm cada uma
# das "q" partes.
#
#    Somente cpfs nao-queimados sao retornados [PROCESSADO DIFERENTE de '1']
#
# DISTIBUIÇÂO: para cada parte "de 1 a q", tenta colocar cpfs dos 3 tipos 
# de crédito. Algumas partes podem ter menos elementos.
#
#
#   TIPO DE DADO DO RETORNO: Array[q], cada elemento contém um Array de Hash
=end

	rcpfs=cpfs.clone #opera sobre cópia/clone, não adulterando parâmetro
	t=Array.new(q)
	t.each_index{|i| t[i]=Array.new}
	rcpfs.select! {|e|e['PROCESSADO'].to_i != 1 }
	rcpfs.shuffle! #embraralha cpfs nao queimados

	cr=['Múltiplo', 'Débito', 'Crédito Adormecido']
	a=Array.new(cr.length)
	cr.each_index{  |i| a[i]=rcpfs.select{  |e|e['TIPO_CREDITO']==cr[i]  }.shuffle  }
	 #shuffle dá mais aleatoriedade. Reduz distribution bias 

	while a[0].length+a[1].length+a[2].length > 0 do
		cr.length.times do |j|
			t.length.times do |k| 
		 		t[k] << a[j].pop if a[j].length > 0
		 	end
		end
	end
	t.shuffle!
	return t
end
