def qtd_execucoes_ja_existentes(diretorio)
	dirs_execucao = Dir["#{diretorio}/RUN*"]
	#puts :debug, "execucoes_ja_existentes: dirs_execucao=#{dirs_execucao}"
	a_i_execucoes = dirs_execucao.map {|d| d.split('RUN')[1].to_i}
	#puts :debug, "execucoes_ja_existentes: a_i_execucoes=#{a_i_execucoes}"
	retval = a_i_execucoes.max || 0 
	#puts :debug, "execucoes_ja_existentes: retval=#{retval}"
	return retval
end

puts qtd_execucoes_ja_existentes 'features/auto'