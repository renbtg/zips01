#encoding: UTF-8
#encoding: UTF-8
#
#
# zs_proc.rb
#
#

require_relative '../rotinas_processo.rb'
require_relative '../ipc_processo.rb'
require_relative '../features/support/shared_utils.rb'
require_relative '../features/support/rsi_utils.rb'
require_relative '../rsi_profiler.rb'
require_relative '../consolida_reports.rb' #2018Ago16 pm, adicionado require


require 'capybara/dsl'
include Capybara::DSL


def DONTUSENOW_rotina_de_interrupcao_em_log
	zs_rotina_de_interrupcao_em_log
end


ZS_MINUTOS_DELETE_ACK_ANTIGO = 10

ZS_MINUTOS_SYSTEMDOWN_RESPEITADO = 10 #tempo real deve ser de 15 a 30 minutos 
		# Devo poder configurar tempo desde último erro de sistemas externo quando devo tentar novamente executar features via [ruby zs/zs_proc.rb cmd cfg]
ZS_STATES = [
	#AGORA - nao contempla transição de chosen, waiting ou running para givenup !
	# Rotinas "get_only_SOME_stts" dependendem destra simplificada transicao sequencial.
	:chosen,
	:waiting,
	:running,
	:done
]


def rotina_de_interrupcao_em_log
	return if $zsproc_tratando_terminar 
	return if not $zs_cfg_ready 

	if not $zs_what
		#faz nada
		return
	elsif $zs_what == 'realtime_report'
		#TRATAMENTO especial para garantir que realtime_report morra imediatamente (ou o mais rapido possivel) ao detectar existencia de arquivos feature*_*_terminar.itr , criados pelas manipulações durante vôo. Reports nao foram preparados pra conviver com manipulacoes durante vôo. Idealmente, o executor deve se responsabilizar por parar o report antes de iniciar manipulacoes. OBS: Manipulações=comandos que alteram feature, por exemplo, 'ruby zs\zs_proc.rb volta_features_pra_genesis'.
		mascara = "#{zs_network_dir}/feature_*.terminar.itr"
		if Dir[mascara].length > 1
			STDOUT.puts "zs_proc::rb, rotina_de_interrupcao_em_log, P05"
			$zsproc_tratando_terminar = true
			write_rsi_log :debug, "zs_proc::rotina_de_interrupcao_em_log para realtime_report, simplificada, Processamento terminado, existem(m) arquivos de mascara=#{mascara}"
			Kernel.exit 1
		end
	else
		#faz nada
		return
	end

	return
end

def zs_write_terminate_file_for_run_parallel
	#2018Out3 - TODO - FIXME, este TERMINATE.LCK em c:\zrdirBLA\ era inútil, agora, extensao padrao é ITR: será que vai ajudar a morrer mais rápido o run_parallel? Ou este código, se modificado, continuará beirando a inutilidade e risco? 

	terminate_runparallel_file = "#{$zs_cfg[:automdir]}/TERMINATE.LCK"
	begin
		write_text_to_file terminate_runparallel_file, "" #2018Abr20 - causa morte bastante rápida de run_parallel.rb e relacionados 
	rescue SystemCallError => e
		write_rsi_log :error, "zs_write_terminate_file_for_run_parallel, ignorando excecao #{e} ao tentar escrever arquivo #{terminate_runparallel_file}"
	end

end

def zs_suicide

	write_rsi_log :error, "zs_suicide, P00"
	zs_write_terminate_file_for_run_parallel

	zs_killandwatch_run_parallel
	Kernel.exit! 1
end

def zs_main_proc
	profile_block lambda {zs_core_main_proc}
end

def zs_core_main_proc
	write_rsi_log :debug,  "zs_main_proc, startup geral"
	

	zs_read_cfgs

	set_wmic_priority #2018Mar29 - SPEED UP!
	
	zs_first_cleanup

	if zs_must_read_process_source
		#se foi requerida 'ead' via 'zs_proc.rb proc read', remonta dir de fontes do processo em todo restart
		zs_create_processsourcedir_from_cmd(zs_get_last_source_cmd) 
		#2018Set30 - queremos ultimos fontes incondicionalmente, tendo ou nao  feito ACK 
	end

	#2018Abr12 - removidas chamadas desnecessarias e fora de lugar a zs_cleanup_before_runme (que chamam, por sua vez, zs_ckleanup_previous_run)

	if not zs_stt_runme_running? 
		write_rsi_log :debug,  "zs_main_proc, tá começando do zero, zs_stt_runme_running? FALSE"
	else
		write_rsi_log :debug,  "zs_main_proc, tá REBOOTING, zs_stt_runme_running? TRUE"
		zs_exec_runme (nil)
	end

	sleep_main_proc = 5
	k = 0
	time_last_priority = Time.now
	wait_secs_last_priority = 60*3

	tempo_mainproc_sleep_automation_is_running = 30
	
	while true do 
		k=k+1
		write_rsi_log  :debug, "zs_main_proc, MAIN LOOP, vai dormir #{sleep_main_proc} e processar, k=#{k}"
		sleep sleep_main_proc

		if Time.now - time_last_priority > wait_secs_last_priority
			set_wmic_priority #2018Mar29 - SPEED UP!
			time_last_priority = Time.now
		end

		if File.exist? zs_get_runlock_filepath
			#2018Mar31 - dormindo minutos , pois automacao está rodando, e é mais prioritária até que comandos administrativos 
			write_rsi_log :debug, "zs_core_main_proc, vai dormir #{tempo_mainproc_sleep_automation_is_running} segundos antes de prosseguir, pois existe arquivo zs_get_runlock_filepath=#{zs_get_runlock_filepath}"
			sleep tempo_mainproc_sleep_automation_is_running
			write_rsi_log :debug, "zs_core_main_proc, dormiu #{tempo_mainproc_sleep_automation_is_running} segundos antes de prosseguir, pois existe arquivo zs_get_runlock_filepath=#{zs_get_runlock_filepath}"
		end	

		zs_processa_cmds

		if $zs_run_automation_pid #REAL STUFF!
			if get_pids_filhos_terminados.include? $zs_run_automation_pid
				# OH MY, DUMMY IF, SEM COMPORTAMENTO!
			end
		end	
	
	end
end

def zs_reset_chosen_count
	FileUtils.rm zs_filename_for_main_proc_data if File.exist? zs_filename_for_main_proc_data
	# vai salvar AGORA (Time.now) - causa certo delay pra processar por timeout. OK, reboot já é operação forçada e esse delay é tolerável!!
	zs_save_chosen_count 
end
def zs_ctx_lockfiles_zsproc
	"#{zs_network_dir}/LOCK_FILES_ZSPROC.LCK"
end

def zs_first_cleanup
	#zs_reset_chosen_count #2018Abr09 14:22pm - chamada a zs_reset_chosen_count movida de zs_first_cleanup para o instante exato em que vai fazer spawn do 2o processo de zs_main_automation
	if false
		#2018Out9 - nao removendo maic arquivos "*.lc*" (que incluem LCK/LOCK), pois agora manutencoes convivem com zs_proc.rb proc, a.k.a "agora podemos fazer manutenções durante vôo", que geral arquivos LCK
		FileUtils.rm(Dir["*.lc*"])
	end
	profile_block lambda {zs_deleta_arquivos_cmds_stop_restart}

	profile_block lambda {write_rsi_log "AQUI, vai fazer executa_exclusivo"}
	executa_exclusivo(nil,zs_ctx_lockfiles_zsproc) do
		mkdir_noexist zs_aux_network_dir
		mkdir_noexist zs_genesis_network_dir
	end
end	

def zs_cleanup_before_runme
	profile_block lambda {write_rsi_log "zs_cleanup_before_runme, P0000"}
	#NAO TESTADO até 2018Fev20 EOD
	$zs_run_automation_pid = nil
	
	mkdir_noexist $zs_cfg[:automdir] #adicionado 2018Fev20, nao criava sozinho "c:\zrdir", "c:\zrdir2" etc. !
	mkdir_noexist zs_local_temp_dir
	delete_all_in_dir zs_local_temp_dir
	delete_all_in_dir "#{$zs_cfg[:automdir]}/features/auto"
	delete_all_in_dir "#{$zs_cfg[:automdir]}/features/reports"
	delete_all_in_dir "#{$zs_cfg[:automdir]}/tmp" #adicionado 2018Fev20. Se OK, devo poder tirar delecao de tmp/join nas próximas linhas.

	Dir["#{$zs_cfg[:automdir]}/*.DAT"].each{|fname| FileUtils.rm(fname)} #CLEANUP
	Dir["#{$zs_cfg[:automdir]}/*.LC*"].each{|fname| FileUtils.rm(fname)} #CLEANUP
	Dir["#{$zs_cfg[:automdir]}/tmp/join/*"].each{|fname| FileUtils.rm(fname)} #Adicionado 2018Fev20

	profile_block lambda {write_rsi_log "zs_cleanup_before_runme, P0001"}

	FileUtils.rm zs_get_runlock_filepath if File.exist? zs_get_runlock_filepath #2018Abr09 - evita primeiro ciclo lento devido a pre-existencia residual de runlock em abbend/interrupt
	profile_block lambda {write_rsi_log "zs_cleanup_before_runme, P0002"}
	zs_cleanup_previous_run($zs_cfg[:maq])
	profile_block lambda {write_rsi_log "zs_cleanup_before_runme, P0003"}

end

def	zs_clean_ack_sem_aux
	agora_time = Time.now
	#Pegando todos ids dos arquivos ACKs
	todos_acks = profile_block lambda { 
	Dir["#{zs_network_dir}/ack_type=runone_id=*.ack"].map {|ackf|
		{
			:fpath => ackf,
			:id    => zs_id_field(ackf)
			#2018Mar21 am - SLOW AS HELL # :antigo => ((agora_time - File.mtime(ackf) > 60*ZS_MINUTOS_DELETE_ACK_ANTIGO) rescue nil)==true
		}
	}
	}

	todos_ids_de_aux = profile_block lambda {
	Dir["#{zs_network_dir}/aux_type=runone*.aux"].map{|a| zs_id_field(a)}
	}

	#REDUCELOGS_SPEEDUP#write_rsi_log :debug, "zs_clean_ack_sem_aux(maq=#{maq}) - TODOS ACKs DE RUNONE = #{todos_acks}"



	profile_block lambda {
	todos_acks.each { |um_ack|
		#2018Mar10 -REVAMPING!
		ack_file = um_ack[:fpath]
		id       = um_ack[:id]
		mtime    = um_ack[:mtime]
		antigo   = um_ack[:antigo]

		aux_existente = todos_ids_de_aux.find_index (id)
		#write_rsi_log "aux_existente=#{aux_existente} para ack_file=#{ack_file}"
		if (not aux_existente)
			#2018Mar21 - checa idade apenas se AUX nao existir! SPEED UP!
			antigo = ((agora_time - File.mtime(ack_file) > 60*ZS_MINUTOS_DELETE_ACK_ANTIGO) rescue nil)
			write_rsi_log :debug, "zs_clean_ack_sem_aux - Não encontrato arquivo AUX do ID #{id} - checando idade, se é antigo, se tem vários minutos... antigo=#{antigo}"
		 end
		 if (not aux_existente) and (antigo)
			write_rsi_log :debug, "zs_clean_ack_sem_aux - Não encontrato arquivo AUX do ID #{id} - Excluindo arquivo ACK antigo #{ack_file}"
			fdel = ack_file
			begin
				zs_remove_with_backup fdel if fdel
			rescue Exception => e
				write_rsi_log :debug, "zs_clean_ack_sem_aux - Não foi possivel deletar arquivo. Outra maquinha pode estar realizando o delete do mesmo!, excecao=#{e}"
				next
			end
			
		end	

	}
	}
end


def	zs_cleanup_previous_run(maq)
ret_do_metodo=profile_block lambda {
	if not (maq and maq.class== Symbol)
		raise "zs_cleanup_previous_run(maq) - parametro maq invalido, = #{maq}, deve ser != nil e de classe Symbol"
	end

	if false #debug do Renato, ainda nao implmentada
		return
	end

	#TODO 2018Fev20  código do Diogo


	if false #2018Abr09 13:09 - nao removendo mais ACK sem AUX. Utilidade rara e sujeita a conflito com zs_move_tudo_ciclo_done_para_auxdir 
		zs_clean_ack_sem_aux
	end

	#Pegando todos os arquivos AUXs da maq que não contem act done

	todos_aux_maq = Dir["#{zs_network_dir}/*type=runone_*_gottenby=#{maq}_*.aux"]

	id_todos_auxs_maq = todos_aux_maq.map {|file| 
		zs_field(file,:id).to_s
	}
	#REDUCELOGS_SPEEDUP#write_rsi_log :debug, "TODOS AUXs da MAQ = #{id_todos_auxs_maq}"

	ids_stt_done_maq=profile_block lambda {
	Dir["#{zs_network_dir}/stt*type=runone*_id=*act=done_maq=#{maq}*.*"].map{|d|zs_id_field(d)}
	}
	write_rsi_log :debug, "zs_cleanup_previous_run(maq=#{maq}), ids_stt_done_maq=#{ids_stt_done_maq}"

	profile_block lambda {
	id_todos_auxs_maq.each do |id|
		write_rsi_log :debug, "zs_cleanup_previous_run(maq=#{maq}), checando AUX de id=#{id}"
		#fmask_done ="#{zs_network_dir}/stt*type=runone*_id=#{id}*act=done*.*" 
		found_done_stts = ids_stt_done_maq.include?(id.to_sym)
		write_rsi_log :debug, "zs_cleanup_previous_run(maq=#{maq}), checando dones do aux, found_done_stts=#{found_done_stts}"
		if not found_done_stts
			fmask_del_stt="#{zs_network_dir}/stt*type=runone*_id=#{id}_*.*"

			write_rsi_log :debug,"zs_cleanup_previous_run(maq=#{maq}) - Não foi encontrado o arquivo .stt com act=done . Excluindo os STTs com id #{id}, fmask_del_stt=#{fmask_del_stt}"
			Dir[fmask_del_stt].each { |fdel|
				write_rsi_log "zs_cleanup_previous_run(maq=#{maq}) - removendo STTs de AUX sem DONE , fdel=#{fdel}"
				ignora_excecoes [SystemCallError] {zs_remove_with_backup fdel} if fdel
			}

			write_rsi_log :debug,"zs_cleanup_previous_run(maq=#{maq}) - Não foi encontrado o arquivo .stt com act=done . Excluindo também o AUX com id #{id}"
			Dir["#{zs_network_dir}/*_id=#{id}_*.aux"].each { |fdel|
				write_rsi_log "zs_cleanup_previous_run(maq=#{maq}) - removendo AUX sem DONE, fdel=#{fdel}" 
				ignora_excecoes [SystemCallError] {zs_remove_with_backup fdel} if fdel
			}

			write_rsi_log :debug,"zs_cleanup_previous_run(maq=#{maq}) - Não foi encontrado o arquivo .stt com act=done . Excluindo também o ACK cujo AUX nao tem DONE id #{id}"
			fdel = Dir["#{zs_network_dir}/*_id=#{id}*.ack"].first
			write_rsi_log "zs_cleanup_previous_run(maq=#{maq})write_rsi_log - removenndo ACK DE AUX SEM DONE, fdel=#{fdel}" 
			ignora_excecoes [SystemCallError] {zs_remove_with_backup fdel} if fdel
		end

	end
	}

	profile_block lambda {
	zs_move_tudo_ciclo_done_para_auxdir maq
	}


	return
}
return ret_do_metodo
end

def zs_remove_with_backup(fpath)
	return if not fpath
	(write_rsi_log :error, "zs_remove_with_backup(fpath=#{fpath}), fpath invalido"; return) if not fpath.is_a? String 
	bn = File.basename(fpath)
	dest_file="#{zs_aux_network_dir}/#{bn}.#{zs_new_global_id(4)}.bkp"
	write_rsi_log :debug, "zs_remove_with_backup, movendo #{fpath} para #{dest_file}"
	begin
		FileUtils.mv fpath, dest_file
	rescue SystemCallError => e
		write_rsi_log :error, "zs_remove_with_backup(fpath=#{fpath}), ignorando excecao SystemCallError, e=#{e}"
	end
	return
end

def zs_main_automation
	profile_block lambda {zs_core_main_automation}
end

def zs_core_main_automation #main
	zs_read_cfgs
	set_wmic_priority #2018Mar29 - SPEED UP!
	
	k = 0
	sleep_main_automation = 10 #2018Abr12 - dorme um pouco, aliviando pressão sore iterções demsis rápidas demais, desnecessariamente
	is_test_process_running = false
	zs_set_prev_running Array.new
	zs_set_prev_done    Array.new
	time_last_priority = Time.now
	wait_secs_last_priority = 90
	
	time_last_checar_transicoes = Time.now
	wait_secs_last_checar_transicoes = 2*60 #2017Abr12 - nao checa mais A TODA HORA, somente a cada 3 minutos: isso deve diminuir pressao sobre desempenho

	
	while true do
		write_rsi_log  :debug, "zs_core_main_automation, MAIN LOOP, vai dormir #{sleep_main_automation} e processar"
		sleep sleep_main_automation

		write_rsi_log :debug, "zs_main_automation, P00"
		k=k+1	

		write_rsi_log :debug,  "zs_main_automation, (k=#{k}) - }zs_main_automation,  is_test_process_running=#{is_test_process_running} dormindo 1"; sleep 1 #2018Mar01 - pseudopid deprecated...

		if Time.now - time_last_priority > wait_secs_last_priority
			set_wmic_priority #2018Mar29 - SPEED UP!
			time_last_priority = Time.now
		end

		if is_test_process_running
			write_rsi_log :debug, "zs_main_automation, P01"
			imprime_pids_processos [$zs_test_process_pid]

			write_rsi_log :debug, "zs_main_automation, P02"
			imprime_pids_processos [$zs_test_process_pid]
			write_rsi_log :debug, "zs_main_automation, P03"

			pids_filhos_mortos = get_pids_filhos_terminados

			if (Time.now - time_last_checar_transicoes > wait_secs_last_checar_transicoes) and not (pids_filhos_mortos.include? $zs_test_process_pid) #2018Abr12 - somente checa transicao de estados de features durante run_parallel a cada X segundos. OBS: também é checado post-mortem
				write_rsi_log :debug, "zs_main_automation, P03.1 vai chamar zs_automation_checa_transicoes_de_estado_de_features"
				zs_automation_checa_transicoes_de_estado_de_features
				write_rsi_log :debug, "zs_main_automation, P03.2 chamou zs_automation_checa_transicoes_de_estado_de_features"
				time_last_checar_transicoes = Time.now
			end


			write_rsi_log :debug, "zs_main_automation, P04"
			if pids_filhos_mortos.include? $zs_test_process_pid
				write_rsi_log :debug, "zs_main_automation, P05"
				
				excode_test_process = get_processos_filhos_terminados.select{|p|p.pid==$zs_test_process_pid}.first
				write_rsi_log :debug, "zs_main_automation, P05.4 - AGORA SIM, run_parallel está morto... excode_test_process=#{excode_test_process}. MAS, just in case, chamando o zombie-killer zs_killandwatch_run_parallel (zombies = analogia para resíduos, não necessariamente zombie-processes a-la linux/unix) . @@@@ NOTA de 2018Mar30 23:29 - antes, zs_killandwatch_run_parallel era chamado DEPOIS de zs_automation_checa_transicoes_de_estado_de_features... talvez, isso pudesse gerar algum conflito."

				zs_killandwatch_run_parallel

				write_rsi_log :debug, "zs_main_automation, P05.5 vai chamar zs_automation_checa_transicoes_de_estado_de_features"
				zs_automation_checa_transicoes_de_estado_de_features
				write_rsi_log :debug, "zs_main_automation, P05.6 chamou zs_automation_checa_transicoes_de_estado_de_features"
				time_last_checar_transicoes = Time.now


				## DEPRECATED em 2018Abr06- #deprecated_zs_ajusta_running_and_done_que_faltam

				write_rsi_log "zs_core_main_automation, CHAMANDO zs_cleanup_previous_run logo após "
				zs_cleanup_previous_run $zs_cfg[:maq] #2018Mar30 - há alguns meses não vejo zs_cleanup_previous_run falhar nem dar raise. SAFE BET.

				


				is_test_process_running = false
				$zs_test_process_pid = nil
				if true #2018Mar04 - zs_get_runlock_filepath DEPRECATED
					begin
						FileUtils.rm zs_get_runlock_filepath
					rescue Errno::ENOENT => e
						write_rsi_log :debug, "zs_main_automation() - excecao #{e} ao remover #{zs_get_runlock_filepath}, ignorando, pois pode ter sido removido pelo processo que matou PID do processo auxiliar deste método zs_main_automation() !"
					end
				end
				zs_reset_chosen_count #reiniciar timer

			end
			write_rsi_log :debug, "zs_main_automation, P08"

		else # not is_test_process_running

			if false
				#CHECAGEM DE PAUSA/SUBSISTEMAS DOWN DeSABIKITADA, AINDA INSTÀVEL! TODO 2018Mar05 
				keep_machine_awake #EVITA SCREENLOCK!

				#2018Mar23 - DESISTI de implementacao original de deteccao  
			end
			
			write_rsi_log :debug, "zs_main_automation, P09"
		#
		#
		#    GIVENUP tem complexidade adicional que nao atacarei agora, quem sabe eu 
		# conclua a tempo. AGORA, o objetivo eh mostrar o PLUGandPLAY de varias maquinas
		# sendo adicionadas ao circuito, e acelerando automacao proporcionalmente a seu
		# poder de processamento, sem MUITO overhead de degradacao da rede e das maquinas
		# pela quantidade de arquivos em DIR_REDE.

		 
			
			is_test_process_running = zs_start_automation_tests_if_needed
			if is_test_process_running
				time_last_checar_transicoes = Time.now
			end
		end
		write_rsi_log :debug, "zs_main_automation, P11"
	end
	write_rsi_log :debug, "zs_main_automation, P12"

	write_rsi_log :debug,  "END OF PROCESS de run_automation. O que será que dá??"

	# usa $zs_argv, que pode conter GUID etc.
end



def zs_get_prev_running
	if not $zs_prev_running
		$zs_prev_running = Array.new
	end 
	return $zs_prev_running
end
def zs_set_prev_running(prev)
	$zs_prev_running = prev
end
def zs_get_prev_done
	if not $zs_prev_done
		$zs_prev_done = Array.new
	end 
	return $zs_prev_done
end
def zs_set_prev_done(prev)
	$zs_prev_done = prev
end



def zs_automation_checa_transicoes_de_estado_de_features(faz_alteracoes=true)
#faz_alteracoes - usado em DEBUG EM CONSOLE para checar parcialmente o comportamento
	return profile_block lambda {
	write_rsi_log :debug,  "zs_automation_checa_transicoes_de_estado_de_features ,P00"

	write_rsi_log :debug,  "zs_automation_checa_transicoes_de_estado_de_features ,P01"

	running = zs_list_of_features_needing_state_change(:running)
	done    = zs_list_of_features_needing_state_change(:done)
	
	fmask_stt_running = "#{zs_network_dir}/stt*_type=runone*_act=running_*maq=#{$zs_cfg[:maq]}*.stt"
	stts_running = Dir[fmask_stt_running]
	features_with_stt_running = stts_running.map{|stt|zs_field(stt,:feature)}
	done_without_running = done - features_with_stt_running
	running = running + done_without_running
	write_rsi_log :debug,  "zs_automation_checa_transicoes_de_estado_de_features , BEFORE REMOVE DUPs running.length=#{running.length},running=#{running}" 
	running.uniq! #bemm... nao deveria ter tentado adicionar duplicados. Mas remove dups mesmo assim
	diff_running = running - zs_get_prev_running
	diff_done    = done    - zs_get_prev_done

	write_rsi_log :debug, "zs_automation_checa_transicoes_de_estado_da_feature, faz_alteracoes=#{faz_alteracoes}"
	if faz_alteracoes
		if diff_running.length > 0
			write_rsi_log :debug,  "zs_automation_checa_transicoes_de_estado_de_features ,P07.1, chamando zs_change_feature_state_to(stt=:running, stts=#{diff_running}"
			zs_change_feature_state_to(:running, diff_running)
			write_rsi_log :debug,  "zs_automation_checa_transicoes_de_estado_de_features ,P07.2, chamou zs_change_feature_state_to(stt=:running, stts=#{diff_running}"
			zs_set_prev_running (running.clone)
		end
		if diff_done.length > 0
			write_rsi_log :debug,  "zs_automation_checa_transicoes_de_estado_de_features ,P08.1, chamando zs_change_feature_state_to(stt=:done, stts=#{diff_done}"
			zs_change_feature_state_to(:done   , diff_done)    
			zs_set_prev_done (done.clone)
			write_rsi_log :debug,  "zs_automation_checa_transicoes_de_estado_de_features ,P08.2, chamando zs_change_feature_state_to(stt=:done, stts=#{diff_done}"
		

		end

		write_rsi_log :debug,  "zs_automation_checa_transicoes_de_estado_de_features ,P09"
	end

	retval = {:running => diff_running.length, :done => diff_done.length}
	write_rsi_log :debug,  "zs_automation_checa_transicoes_de_estado_de_features ,P11"

	write_rsi_log :debug,  "zs_automation_checa_transicoes_de_estado_de_features ,running.length=#{running.length}, zs_get_prev_running.length=#{zs_get_prev_running.length}, done.length=#{done.length}, zs_get_prev_done.length=#{zs_get_prev_done.length}, retval=#{retval}" 
	return retval 
	}
end



def zs_get_minutos_timeout_chosen
	return $zs_cfg[:minutos_timeout_esperando_chosen] || 5
end

def zs_get_minutos_timeout_allchosen
	return $zs_cfg[:minutos_timeout_esperando_allchosen] || 20
end

def zs_start_automation_tests_if_needed

	lets_run = false

	agora = Time.now
	proc_data = zs_get_main_proc_data
	chosen_count = proc_data['CHOSEN_COUNT'].to_i
	chosen_time = Time.at(proc_data['CHOSEN_TIME_SECONDS'].to_f)
	start_chosing_time = Time.at(proc_data['START_CHOSING_TIME_SECONDS'].to_f)
	write_rsi_log :debug, "zs_start_automation_tests_if_needed,P02, chosen_count=#{chosen_count}, $zs_cfg[:qt_features]=#{$zs_cfg[:qt_features]}, chosen_time=#{chosen_time},start_chosing_time=#{start_chosing_time}agora=#{agora}"
	if chosen_count == 0
		# nada
	elsif chosen_count >= $zs_cfg[:qt_features]
		if chosen_count > $zs_cfg[:qt_features]
			write_rsi_log :warn, "WARNING, zs_start_automation_tests_if_needed, chosen_count = #{chosen_count} , que é maior que $zs_cfg[:qt_features]=#{$zs_cfg[:qt_features]}!              @@@@@@@           @@@@@@@@@@@@@@   R I S C O    D E    P R O B L E M A   S È R I O             @@@@@@@@@@@@@  @@@@@@"
		end
		lets_run = true
	elsif (agora.to_f - chosen_time.to_f) > 60*zs_get_minutos_timeout_chosen #2018Abr09 - timeout de um X timeout de qt_features
		write_rsi_log :debug, "zs_start_automation_tests_if_needed,P01, chosen_count=#{chosen_count}, deu timeout de um de #{zs_get_minutos_timeout_chosen} minutos, vai executar mesmo asendo < que #{$zs_cfg[:qt_features]}"
		lets_run = true
	elsif (agora.to_f - start_chosing_time.to_f) > 60*zs_get_minutos_timeout_allchosen #2018Abr09 - 2 timeout OU timeout*qt_features de first
		write_rsi_log :debug, "zs_start_automation_tests_if_needed,P01.1, chosen_count=#{chosen_count}, deu timeout de qt_features #{zs_get_minutos_timeout_allchosen} minutos, vai executar mesmo asendo < que #{$zs_cfg[:qt_features]}"
		lets_run = true
	end

	#write_rsi_log :debug, "zs_start_automation_tests_if_needed,P03,lets_run=#{lets_run}"
	if lets_run 
		zs_do_lets_run

	end
	write_rsi_log :debug, "zs_start_automation_tests_if_needed, returning lets_run=#{lets_run}"
	return lets_run
end

def zs_do_lets_run
	begin
		return profile_block lambda {
			return zs_core_do_lets_run
		}
	rescue Exception => e
		falhar "EITA NOIS Exception encontrada em zs_core_do_lets_run, e=#{e}, e.backtrace=#{e.backtrace}"
	end
end

def zs_core_do_lets_run
	write_rsi_log :debug,  "zs_start_automation_tests_if_needed, iniciando rodada de testes run_parallel.rb"

	zs_killandwatch_run_parallel #2018Set02 - adicionado, por segurtança.

	zs_create_automationsourcedir_from_cmd(zs_get_last_acked_source_cmd) #2018Abr20 - REVAMPING cmd_type=source : agora criamos/atualizamos diretorio zrdir de fontes aqui, logo antes de spawn de run_parallel.rb

	if true #2018Mar04 - zs_get_runlock_filepath DEPRECATED
		zs_create_new_file(zs_get_runlock_filepath) ######## PRIMEIRA COISA que faço é avisar que TESTS AGORA TÂO RODANDO !
	end

	sevenzdestdir=$zs_cfg[:automdir]
	if not File.exist? (sevenzdestdir)
		falhar "zs_start_automation_tests_if_needed, sevenzdestdir nao encontrado, sevenzdestdir=#{sevenzdestdir}"
	end

	sevenzdestjoinpath = "#{sevenzdestdir}/tmp/join"
	mkdir_noexist sevenzdestjoinpath
	delete_all_in_dir sevenzdestjoinpath

	guid = nil
	#
	#  BAD MOVE! pegar guid aqui. IMPEDE que role uma automacao, termine,
	# depois role outra, a nao ser q algum PURGE limpe dados. SEI LA, agora,
	# o importante é mostrar UMA AUTOMACAO ganhando alta velocidade conforme
	# quantidade de maquinas aumenta!!!
	#



	onlychosen = zs_get_runone_onlychosen_stts
	write_rsi_log :debug, "zs_core_do_lets_run, onlychosen=#{onlychosen}"
	waiting_tudo_tfc = true #2018Mar16 - vou rodar com paralelismo=1 se APENAS TFC entre os chosen
	onlychosen.each do |olc|
		write_rsi_log :debug, "zs_core_do_lets_run, olc=#{olc}"
		full_feature_name = zs_field(olc,:feature)
		feature_sem_guid_nem_nice = get_feature_sem_guid_nem_nice(full_feature_name)
		write_rsi_log :debug, "zs_core_do_lets_run, olc=#{olc}, feature_sem_guid_nem_nice=#{feature_sem_guid_nem_nice}"
		executa_exclusivo({:verbose=>true, :segundos_sleep=>5}, zs_feature_lock_filename(feature_sem_guid_nem_nice), -1) do
			#2018Out7 17:45pm - antes disso, criava errado o LOCK com nome completo da feature, com guid e nice.
			id = zs_field(olc, :id)
			write_rsi_log :debug, "zs_core_do_lets_run, olc=#{olc}, feature_sem_guid_nem_nice=#{feature_sem_guid_nem_nice}, id=#{id}"
			pular_este = false
			if zs_exists_feature_terminate_file(feature_sem_guid_nem_nice, id)
				write_rsi_log :debug, "zs_core_do_lets_run, arquivo de interrupcao #{zs_get_feature_terminate_filepath(feature_sem_guid_nem_nice)} existe, por manutenção de feature durante vôo"
				pular_este = true
			end

			if not pular_este
				olc_stillThere = Dir["#{zs_network_dir}/#{olc}"].first
				write_rsi_log :debug, "zs_core_do_lets_run, olc=#{olc}, feature_sem_guid_nem_nice=#{feature_sem_guid_nem_nice}, id=#{id}, olc_stillThere=#{olc_stillThere}"
				if olc_stillThere == nil
					write_rsi_log :debug, "zs_core_do_lets_run, arquivo chosen removido, olc=#{olc}, provavelmente removido em manutenção durante vôo"
					pular_este = true
				end
			end

			#2018Out7, 15:16 - NEXT dentro do executa_exclusivo saía totalmente do block "each" externo. Trocado "next" por variavel "pular_este"
			#2018Out6 21:28 - protecoes adicionais contra manutencao durante voo. NAO nos salvam da remocao de feature_bla*.TERMINATE.ITR por outra máquina! 
			#2018Out 7 - desde 2018Out6 22:xx pm, foi implementado criacao e uso de arquivo TERMINAR.ITR especifico para um ID, quando no momento de criar CHOSEN detectamos que há CHOSEN residual da feature em outra máquina. Isso vai garantir que processamento desse ID residual nao ocorra (seja desprezado imediatamente) no momento em que essa outra máquina for processá-lo (seja em cucumber, seja em zs_proc). GRANDE AVANÇO DE ROBUSTEZ!

			if not pular_este
				ftz_stillThere = Dir["#{zs_network_dir}/ftz*id=#{id}*ftz"].first
				write_rsi_log :debug, "zs_core_do_lets_run, olc=#{olc}, feature_sem_guid_nem_nice=#{feature_sem_guid_nem_nice}, id=#{id}, ftz_stillThere=#{ftz_stillThere}"
				if ftz_stillThere == nil
					write_rsi_log :debug, "zs_core_do_lets_run, arquivo ftz removido, ftz=#{ftz}, provavelmente removido em manutenção durante vôo"
					pular_este = true
				end
			end

			if not pular_este
				cmd_stillThere = Dir["#{zs_network_dir}/cmd*id=#{id}*.ccc"].first
				if cmd_stillThere == nil
					write_rsi_log :debug, "zs_core_do_lets_run, olc=#{olc}, feature_sem_guid_nem_nice=#{feature_sem_guid_nem_nice}, id=#{id}, cmd_stillThere=#{cmd_stillThere}"
					write_rsi_log :debug, "zs_core_do_lets_run, arquivo cmd removido, cmd=#{cmd}, provavelmente removido em manutenção durante vôo"
					pular_este = true
				end
			end

			if not pular_este
				if not guid
					guid = zs_field(olc, :guid)
				end
				if zs_field(olc,:si).to_s.to_i != NUM_STEP_TFC
					waiting_tudo_tfc = false
				end 
				sevenzsourcemask = "#{zs_network_dir}/dat*_id=#{zs_field(olc,:id)}*.7z"
				sevenzsourcepath = Dir[sevenzsourcemask].first
				if not sevenzsourcepath
					#2018Out6 - protecao extra para manutencao durante voo 
					write_rsi_log :debug, "zs_core_do_lets_run, nao encontrado o dat do chosen, provavelmente por manutencao durante voo... sevenzsourcemask=#{sevenzsourcemask}, um dos onlychosen, olc=#{olc}"
					pular_este = true
				end
			end

			if not pular_este
				begin
					FileUtils.cp sevenzsourcepath, sevenzdestjoinpath
				rescue SystemCallError => e
					write_rsi_log :debug, "zs_core_do_lets_run, excecao e=#{e} ao tentar copiar e talvez modificar arquivo #{sevenzsourcepath} para #{sevenzdestjoinpath}"
					pular_este = true
				end
			end
			
			if not pular_este	
				write_rsi_log :debug, "zs_core_do_lets_run, olc=#{olc}, feature_sem_guid_nem_nice=#{feature_sem_guid_nem_nice}, id=#{id}, copiado arquivo #{sevenzsourcepath} para #{sevenzdestjoinpath}"

				stt_waiting_fname = zs_stt_runone_fname(id:zs_field(olc,:id), act: :waiting, maq:zs_field(olc,:maq), guid:zs_field(olc,:guid), ts:zs_timestamp_str(Time.now)) #2018Mar01 - pseudopid deprecated...
				full_waiting_path = "#{zs_network_dir}/#{stt_waiting_fname}"
				zs_create_new_file full_waiting_path
				write_rsi_log :debug, "zs_core_do_lets_run, olc=#{olc},feature_sem_guid_nem_nice=#{feature_sem_guid_nem_nice}, id=#{id}, criado arquivo waiting, full_waiting_path=#{full_waiting_path}"
			end
		end
	end

	real_paralelismo = $zs_cfg[:paralelismo]
	if waiting_tudo_tfc
		real_paralelismo = 1 #2018Abr01 - pré-inicialização de TFC em run_parallel.rb está bem testada e estável. Portanto, podemos e devemos adotar real_paraleliamo=1 para TFC, o que aumenta desempennho diminui riscos, uso de memória, robustez... o único drawback é que não há tentativa de subir novamente TFC se pre-inicialização não tiver sucesso, gerando falha (mesmo que reprocessavel) em todas features CHOSEN do momento.
	end
	write_rsi_log "zs_core_do_lets_run, waiting_tudo_tfc=#{waiting_tudo_tfc}, real_paralelismo=#{real_paralelismo}"
	
	write_rsi_log :debug,  "zs_start_automation_tests_if_needed, PRONTO, copiei as coisas pra tmp/join, sevenzdestjoinpath=#{sevenzdestjoinpath}"
	write_rsi_log :debug,  "zs_start_automation_tests_if_needed, AGORA SIM, joiner.rb + reinicia_execucao.bat!"

	newautomdir="#{$zs_cfg[:automdir]}"
	zs_create_tfc_login_properties_for_runparallel(newautomdir)
	newautomdir_barrainv=newautomdir.gsub('/','\\')
	fullpath_cpfs_risco = $zs_cfg[:cpfs_risco_fullpath]||'cpfs_risco.xls'
	lockfile_cpfs_risco = $zs_cfg[:cpfs_risco_lockfile]||'LOCK_OBTER_CPF_RISCO.LCK'
	core_cmd_cd="cd #{newautomdir_barrainv}"
	core_cmd_join="ruby joiner.rb" #comment em 2018Abr01 - joiner.rb JÀ LIMPA zrdirBLA
	#2018MJun27 - agora, consumidor_de_features checa flag simples de TEST_ZS_PROC != '1' para decidir se faz ele mesmo reinsercao (em execucoes fora de processo colaborativo)

	run_parallel_test_log_file = get_rsi_log_fname.gsub('\\','/').gsub('.log','') + '.localrun.log'
	core_cmd_setenv="set TEST_TFC_CENTRO=#{$zs_cfg[:tfc_centro]}&set TEST_LOG_FILE=#{run_parallel_test_log_file}&set TEST_ZS_PROC=1&set TEST_ZS_NETWORKDIR=#{zs_network_dir}&set TEST_NETWORK_SYSTEMDOWN_PROPFILE=#{zs_network_systemdown_propfile}& set TEST_LOCKFILE_CPFS_FISCO=#{lockfile_cpfs_risco}&& set TEST_XLS_CPFS_RISCO=#{fullpath_cpfs_risco}&& set TEST_MACHINE_ID=#{get_machine_id}&& set TEST_DONT_PROCESSCLEAN_RUBY=1&& set TEST_AUTOMATION_DIR=#{newautomdir}&& set TEST_LANG=#{$zs_cfg[:lang]}"
	#2018Out10 am, passado TEST_LOG_FILE para run_parallel - AVANÇO IMPORTANTE: 
	#2018Set30 - definino sufixo do .ITR (interrupcao) para morte imediata da feature quando manipulando feature durante o vôo!
	#2018Out28 - tfc centro adicionado

	core_cmd_runparallel="del *.itr&& del *.lck&& del *.out&& ruby run_parallel.rb run_run_parallel features/auto #{real_paralelismo}" 
	#2018Set30 - adicionados .ITR (interrupcoes) a lista de limpeza
	#2018Set8, parametro de RUn q possibilita LOAD inocuo: 'run_run_parallel'

	core_cmd="#{core_cmd_setenv}&& #{core_cmd_cd}&& #{core_cmd_join}&& #{core_cmd_runparallel}"
	write_rsi_log :debug,  "zs_start_automation_tests_if_needed, core_cmd=#{core_cmd}, CHECANDO SE DEVE FAZER SPAWN (se not screen_locked e nao existe arqiivo #{zs_network_systemdown_propfile}!"



	if true

		$zs_test_process_pid = spawn(core_cmd) #ALEA JACTA EST

		#2018Out1, manutenção durante vôo: toda run_parallel mesmo sem nennum waiting: execução vazia. Até 2018Out1, ainda sem nenhuma checagem adicional aqui de "tem algo pra executar em run_parallel, ao menos uma feature"? PQ DEIXEI SEM CHECAR: pq pode ser chatinho lidar com outros trechos de código que verificam morte do PID do SPAWN de run_parallel

		write_rsi_log :debug,  "zs_start_automation_tests_if_needed, SPAWNED - $zs_test_process_pid=#{$zs_test_process_pid}"
	end
	write_rsi_log :debug, "zs_core_do_lets_run - retornando"

	return true
end

def zs_get_last_acked_source_cmd(maq=$zs_cfg[:maq])
	last_source_ack = Dir["#{zs_network_dir}/ack_type=source*_maq=#{maq}.ack"].sort{|c1,c2| File.mtime(c2) <=> File.mtime(c1)}.first

	id = zs_field(last_source_ack, :id)

	source_cmd = Dir["#{zs_network_dir}/cmd_type=source*_id=#{id}*"].first

	return source_cmd
end

def zs_get_last_unacked_source_cmd(maq=$zs_cfg[:maq])

	descending_source_7zs = Dir["#{zs_network_dir}/cmd_type=source*.7z"].sort{|c1,c2| zs_field(c2,:ts) <=> zs_field(c1,:ts)}
	last_unacked = descending_source_7zs.find{|src| id = zs_field(src,:id); not File.exist? "ack_type=source_id=#{id}_maq=#{maq}.ack"}

	return last_unacked
end

def zs_get_last_source_cmd

	descending_source_7zs = Dir["#{zs_network_dir}/cmd_type=source*.7z"].sort{|c1,c2| zs_field(c2,:ts) <=> zs_field(c1,:ts)}
	last_source = descending_source_7zs.first

	return last_source
end

def zs_network_systemdown_propfile
	return "#{zs_network_dir}/system_down.properties"
end


def zs_create_tfc_login_properties_for_runparallel(automdir)
	v_tfc_usuario = $zs_cfg[:tfc_usuario]
	v_tfc_senha   = $zs_cfg[:tfc_senha]
	#2018Out25 - adicionado: config value :tfc_centro, para que multiplos usuarios de TFC possam editar contas abertas por outros

	if (not v_tfc_usuario) or (not v_tfc_senha)
		falhar "zs_create_tfc_login_properties_for_runparallel, FALHA EM ARQUIVO DE CONFIGURACAO, não encontrados valores para :tfc_usuario ou para :tfc_senha"
	end

	save_java_properties "#{automdir}/tfc_login.properties", USUARIO: v_tfc_usuario, SENHA: v_tfc_senha

end		

def zs_change_feature_state_to(state, features)
	return profile_block lambda {
	features.each do |feature|
		featname_sem_guidnice = get_feature_sem_guid_nem_nice(feature)
		
		write_rsi_log :debug,  "zs_change_feature_state_to(state=#{state}, feature=#{feature}), vai obter lock..."

		executa_exclusivo({:verbose=>true, :segundos_sleep=>5}, zs_feature_lock_filename(featname_sem_guidnice), -1) do
			write_rsi_log :debug,  "zs_change_feature_state_to(state=#{state}, feature=#{feature}), obteve lock"

			#2018Set30 - zs_ftz_* parece protegida dentro de pq esta rotina (zs_change_feature_state_to) deverá ser PONTO DE ENTRADA que fará lock_exclusivo DA FEATURE

			ftz = zs_ftz_by_feature(feature)
			if not ftz
				write_rsi_log :debug, "zs_change_feature_state_to(state=#{state}, feature=#{feature}), nao encontrado ftz da feature #{feature} no diretório da rede #{zs_network_dir}, talvez por manutenção de feature durante vôo"
			elsif zs_exists_feature_terminate_file(featname_sem_guidnice, ftz[:id])
				write_rsi_log :debug, "zs_change_feature_state_to(state=#{state}, feature=#{feature}), arquivo de interrupcao #{zs_get_feature_terminate_filepath(featname_sem_guidnice)} existe, por manutenção de feature durante vôo"
			else
				id = ftz[:id]

				#2018Abr23 - removida checagem de arquivos de previous states, COMPLETAMENTE INUTIL E SUJEITA A FALHAS!
				if state == :done
					zs_create_stt_sevenz_done feature, id  
					#2018Set30 - COOL, todo o proceosso de criat stt*done*7z já aqui protegido por executa_exclusivo 
				else
					stt_fname = zs_stt_runone_fname(id: id, act: state, maq:$zs_cfg[:maq], guid:'0000', ts:zs_timestamp_str(Time.now)) #2018Mar01 - pseudopid deprecated...
					write_rsi_log :debug,  "zs_change_feature_state_to, criando arquivo #{stt_fname}"
					zs_create_new_file "#{zs_network_dir}/#{stt_fname}"
					#zs_create_new_file "#{zs_local_temp_dir}/#{stt_fname}" # 2018Mar01 - LOCAL BLUES! 
				end
			end
		end
	end
	}
end

def	zs_get_fmasks_and_dirs_in_sevenz(feature)
	aut_dir = $zs_cfg[:automdir]

	png_files = nil
	png_dir = nil
	raw_repdir = 'reports/TRN1'
	dir_scrshots_relative = nil
	dmsk="#{aut_dir}/#{raw_repdir}/scrshot*#{feature}*"
	dir_scrshots_fullpath = Dir[dmsk][0]
	regexp = Regexp.new(Regexp.escape("/#{raw_repdir}/"), Regexp::IGNORECASE)
	write_rsi_log :debug, "zs_get_fmasks_and_dirs_in_sevenz(feeature=#{feature}), dir_scrshots_fullpath=#{dir_scrshots_fullpath}"
	if dir_scrshots_fullpath
		dir_scrshots_relative = raw_repdir+'/'+dir_scrshots_fullpath.split(regexp)[1]
	else
		dir_scrshots_fullpath = nil
	end
	write_rsi_log :debug, "zs_get_fmasks_and_dirs_in_sevenz(feeature=#{feature}), dir_scrshots_fullpath=#{dir_scrshots_fullpath}, dir_scrshots_relative=#{dir_scrshots_relative}"
	if dir_scrshots_fullpath
		png_files = dir_scrshots_fullpath + '/*.png'
		png_dir = dir_scrshots_relative
	end
	write_rsi_log :debug, "zs_get_fmasks_and_dirs_in_sevenz(feeature=#{feature}), png_files=#{png_files}, png_dir=#{png_dir}"

	fmasks_and_dirs_in_sevenz={
		:pngs    => [
			png_files,
			png_dir
		],
		:jsons   => [
			"#{aut_dir}/reports/TRN1/*#{feature}*.json",
			"reports/TRN1"],
		:htmls   => [
			"#{aut_dir}/reports/TRN1/*#{feature}*.html",
			"reports/TRN1"],
		:logs    => [
			"#{aut_dir}/reports/TRN1/*#{feature}*.log",
		    "reports/TRN1"],
		:feature  => [
			"#{aut_dir}/features/auto/r/*#{feature}*.feature",
		    "auto/r"],
		:massa  => [
			"#{aut_dir}/features/auto/r/*#{feature}*.xls",
		    "auto/r"]
	}
	return fmasks_and_dirs_in_sevenz
end


def zs_exists_feature_terminate_file(featname, id=nil)
#2018Out6, 23:09, created
	if File.exist? zs_get_feature_terminate_filepath(featname)
		return true
	end
	if not id
		return false
	end
	return File.exist? zs_get_feature_terminate_filepath(featname, id)
end


def zs_feature_lock_filename(featname)
#created, 2018Set30, manipulação de features durante vôo
	return "#{zs_network_dir}/LOCK_FEATURE_#{featname}.LCK"
end
def zs_get_feature_terminate_filecore(featname, id=nil)
#created, 2018Set30, manipulação de features durante vôo
#2018Out6, arquivo ITR específico para um "id=" definido 

	id_piece="_id_#{id}" if id

	return "feature_#{featname}#{id_piece}"
end
def zs_get_feature_terminate_fileprefix(featname, id=nil)
#created, 2018Set30, manipulação de features durante vôo
	return "#{zs_network_dir}/#{zs_get_feature_terminate_filecore(featname, id)}"

end

def zs_get_feature_terminate_filepath(featname, id=nil)
#created, 2018Set30, manipulação de features durante vôo
	return "#{zs_get_feature_terminate_fileprefix(featname, id)}.TERMINAR.itr"
end

def zs_create_feature_terminate_file(featname, manipulation, id=nil)
#created, 2018Set30, manipulação de features durante vôo
	manipulation ||= :undef
	File.open(zs_get_feature_terminate_filepath(featname,id),"a") do |f|
		f.puts "manipulation=#{manipulation.to_s.gsub('_','')}_ts=#{zs_ts_now}_maq=#{$zs_cfg[:maq]}" 
		#2018Out6 - escreve qual manipulacao foi feita no ITR. Permite análise de ocorrencias.
	end
	return
end
def zs_remove_feature_terminate_file(featname)
#created, 2018Set30, manipulação de features durante vôo
#2018Out7 - ATENCAO - zs_proc.rb somente remove terminate file GERAL da feature. terminate files com ID ficam indefinidamente no diretorio da rede, a nao ser que cucumber local da máquina que estiver processando aquele ID residual o remova ao morrer. @@@ Se cucumber local da maquina processando o ID residual nao o remover, fica eternamente (e inofensivamente) no diretorio da rede.
#2018Out7 15:28, corrigido o parametro passado para zs_remove_with_backup, estava passando ARRAY[1] em vez de STRING
	zs_remove_with_backup Dir[zs_get_feature_terminate_filepath(featname)].first 

	return
end

def zs_volta_features_pra_genesis(features_sem_guidnice)
	features_sem_guidnice ||= []
	raise "zs_volta_features_pra_genesis, parametro features_sem_guidnice invalido,, features_sem_guidnice=#{features_sem_guidnice}" if not (features_sem_guidnice and features_sem_guidnice.is_a?(Array) and features_sem_guidnice.length > 0)
	
	write_rsi_log "2018Ago02 - zs_volta_features_pra_genesis, REDESENHADA, move tudo pra auxdir e depois traz de volta trio DAT/FTZ/CCC original!! (ainda falta tornar CREATE_STT_DONE+PUBLICA 100 PORCENTO ATOMICO, E/OU MELHOR PROTEGIDO, COM DIREITO A APAGAR DONE.7Z AUTOMATICAMENTE Q NAO ESTEJA OK... EX: AO PEGAR UM COMANDO PRA PROCESSAR, SOMENTE PROCESSA SE TUDO OK NA SEQUENCIA DA FEATURE, EVITANDO ETERNIAR PROBLEMA), ......... features_sem_guidnice.length=#{features_sem_guidnice.length}, features_sem_guidnice=#{features_sem_guidnice}"
	
		zs_clean_ack_sem_aux # aproveita que vai reinserir desistencias, que exige TODAS maquinas 100% paradas, e faz clean de ACK sem AUX 	


	total_arquivos_mover=[]
	features_sem_guidnice.each{|featname|
		executa_exclusivo({:verbose=>true, :segundos_sleep=>5}, zs_feature_lock_filename(featname), -1) do
			zs_create_feature_terminate_file(featname, :voltagenesis) 
			#2018Set30, added, executa_exclusivo+zs_create_feature_terminate_file,  manipulação de features durante vôo

			agora_ts = zs_ts_now
			zs_update_field_of_feature_list featname, ts_genesis_detalhado: agora_ts #2018Ago29, added, atualiza incondicionalmente a hora da volta pra genesis antes de começar a processar a feature, por garantia.


			# NAO CONFIAR EM FTZ!
			feature_arquivos_mover=[]
			globparam = "#{zs_network_dir}/**/*feature=*X#{featname}guid*"
			dirgenesisparam = "#{zs_genesis_network_dir}/*feature=*X#{featname}guid*"
			write_rsi_log :debug, "zs_volta_features_pra_genesis, globparam=#{globparam}"
			ids = (Dir.glob(globparam)+Dir[dirgenesisparam]).map{|filepath|filename=File.basename(filepath); filename.split("id=")[1].split("_")[0]}.uniq #sem uniq, gerava duplicidades
			ids.each{|id|
				a_mover_id = Dir["#{zs_network_dir}/*id=#{id}*"]
				total_arquivos_mover = total_arquivos_mover + a_mover_id
				feature_arquivos_mover = feature_arquivos_mover + a_mover_id
				write_rsi_log :debug, "zs_volta_features_pra_genesis, featname=#{featname}, id=#{id}, a_mover_id.length=#{a_mover_id.length}, a_mover_id=#{a_mover_id}"
				#write_rsi_log :debug, "zs_volta_features_pra_genesis, featname=#{featname}, id=#{id}, a_mover_id.uniq.length=#{a_mover_id.uniq.length}, a_mover_id.uniq=#{a_mover_id.uniq}"
				if a_mover_id.uniq.length != a_mover_id.length
					falhar "1. length nao bateu"
				end
				if feature_arquivos_mover.uniq.length != feature_arquivos_mover.length
						falhar "2. length nao bateu"
				end
				if total_arquivos_mover.uniq.length != total_arquivos_mover.length
						falhar "3. length nao bateu"
				end
				sufixo = "#{zs_new_global_id(4)}.bkgn"
				a_mover_id.each{|arquivo_de_zsnd|
					bn = File.basename(arquivo_de_zsnd)
					dest_dir = "#{zs_genesis_network_dir}" #move para diretorio paralelo a zs_network_dir que nao interfere em "dir /s @@ ls -R" (DIr.glob) que lê zs_aux_network_dir 
					dest_file = "#{dest_dir}/#{bn}.#{sufixo}"
					write_rsi_log :debug, "zs_volta_features_pra_genesis, featname=#{featname} e id=#{id}, vai mover arquivo_de_zsnd=#{arquivo_de_zsnd} para dest_file=#{dest_file}"
					# "rbattaglia - Filhadamae! 2018Ago02 - problema crasso em execucao, detectado com Roberto Boker, foi causado por (FILENAME_TOO_LONG por FEATURENAME_TOO_LONG) !por nao conseguir mover nos backups de ciclo" if false #### ENTAO, devo reduzir mais uns 15 ou 20 caracteres de tamanho maximo de RAW_FEATURE_NAME em gerador_massa.rb !!!
					if bn.start_with? 'stt' and bn.include?'=done' and bn.include? '.7z' #2018Ago19 pm, FIXED important error, start_with instead of start_with? !!!
						#2018Ago19 - protegendo potencial mv de stt*done*7z que pode estar sendo copiado por realtime_report
						zs_espera_not_eacces {FileUtils.mv arquivo_de_zsnd, dest_file}
					else
						FileUtils.mv arquivo_de_zsnd, dest_file
					end

				}
			}
			write_rsi_log :debug, "zs_volta_features_pra_genesis, featname=#{featname}, feature_arquivos_mover.length=#{feature_arquivos_mover.length}, feature_arquivos_mover=#{feature_arquivos_mover}"
			#write_rsi_log :debug, "zs_volta_features_pra_genesis, featname=#{featname}, feature_arquivos_mover.uniq.length=#{feature_arquivos_mover.uniq.length}, feature_arquivos_mover.uniq=#{feature_arquivos_mover.uniq}"
			if feature_arquivos_mover.uniq.length != feature_arquivos_mover.length
					falhar "4.length nao bateu"
			end
			if total_arquivos_mover.uniq.length != total_arquivos_mover.length
				falhar "5.length nao bateu"
			end

			zs_restaura_comando_original_da_feature(featname)
			
			write_rsi_log :debug, "zs_volta_features_pra_genesis, FEATURE #{featname} RESTAURADA COM SUCESSO PARA GENESE"

			write_rsi_log "\n\n\n\n"
		end #fim PROTECAO COM lock_exclusivo da feature, 2018Set30
		#break #DEBUG - sem BREAK, abre a porteira pra todos...
	}
	write_rsi_log :debug, "zs_volta_features_pra_genesis, total_arquivos_mover.length=#{total_arquivos_mover.length}, total_arquivos_mover=#{total_arquivos_mover}"
	#write_rsi_log :debug, "zs_volta_features_pra_genesis, total_arquivos_mover.uniq,length=#{total_arquivos_mover.uniq.length}, total_arquivos_mover.uniq=#{total_arquivos_mover.uniq}"
	if total_arquivos_mover.uniq.length != total_arquivos_mover.length
		falhar "6.length nao bateu"
	end

	return
end

def zs_restaura_comando_original_da_feature(featname)
	prim_ftz=Dir["#{zs_genesis_network_dir}/ftz*X#{featname}guid*.ftz*"].sort{|a,b| File.mtime(a) <=> File.mtime(b)}.first
	write_rsi_log :debug, "zs_restaura_comando_original_da_feature, prim_ftz=#{prim_ftz}"
	prim_id=prim_ftz.split("_id=")[1].split("_")[0]
	write_rsi_log :debug, "zs_restaura_comando_original_da_feature, prim_id=#{prim_id}"
	cmd_source_do_id=(Dir.glob("#{zs_aux_network_dir}/cmd*id=#{prim_id}*ccc*") + Dir.glob("#{zs_genesis_network_dir}/cmd*id=#{prim_id}*ccc*")).first
#		cmd_map{|f|f.split(".ccc")[0]+".ccc"}.first
	write_rsi_log :debug, "zs_restaura_comando_original_da_feature, cmd_source_do_id=#{cmd_source_do_id}"
	dat_do_id=Dir.glob("#{zs_genesis_network_dir}/dat*id=#{prim_id}*7z*").sort{|a,b| File.mtime(a) <=> File.mtime(b)}.first
	write_rsi_log :debug, "zs_restaura_comando_original_da_feature, dat_do_id=#{dat_do_id}"
	arquivos_a_restaurar = [ [prim_ftz,'.ftz'], [cmd_source_do_id,'.ccc'], [dat_do_id,'.7z'] ]
	novo_id = zs_new_global_id
	arquivos_a_restaurar.each{|a|
		arq = a[0]
		ext = a[1]
		bn = File.basename(arq).split(ext)[0]+ext
		dest_file = "#{zs_network_dir}/#{bn}"
		dest_file = dest_file.gsub(prim_id, novo_id)  #2018Set14 - simples e importante mudança: dá ID novo à cópia do trio original
		write_rsi_log :debug, "zs_restaura_comando_original_da_feature, vai restaurar arquivo original #{dest_file}, via cópia do arquivo #{arq}"
		FileUtils.cp arq, dest_file
		write_rsi_log :debug, "zs_restaura_comando_original_da_feature, restaurou arquivo original #{dest_file}, via cópia do arquivo #{arq}"
	}
	write_rsi_log :debug, "zs_restaura_comando_original_da_feature, feature #{featname}, restaurados arquivos do trio original .dat/.ccc/.ftz"
	return
end

def zs_volta_features_pra_ids(features_com_ids)
	raise 'ARRISCADO implementar, entao, cmdline vai ser chamada sempra para uma feature/id'
end

def zs_call_volta_uma_feature_pra_id(featname, id)
	executa_exclusivo({:verbose=>true, :segundos_sleep=>5}, zs_feature_lock_filename(featname), -1) do
		zs_create_feature_terminate_file(featname, "voltaid#{id}") 
		#2018Set30 INCÔMODO detectado - trava a feature mesmo q passado ID errado
		zs_volta_uma_feature_pra_id(featname, id)
		#2018Out6, fix, theId -> id (esteve errado alguns dias, creio nao ter chamado esta rotina nenquanto errado)
	end
end

def zs_volta_uma_feature_pra_id(featname, theId)
#2018Set12, created, copy-paste-change de zs_volta_features_pra_genesis
#2018Set12, comment: diferentemente de zs_volta_features_pra_genesis, deve fazer   
	raise "zs_volta_uma_feature_pra_id, parametro theId=#{theId} inválido ou sem arquivo DONE correspondente" if not (theId and theId.is_a?(String) and Dir["#{zs_network_dir}/stt*_id=#{theId}_*done*7z"].first)
	done_do_id = Dir["#{zs_network_dir}/stt*_id=#{theId}_*done*7z"].first
	raise "zs_volta_uma_feature_pra_id, parametro featname=#{featname} inválido ou sem arquivo DONE correspondente" if not (featname and featname.is_a?(String) and done_do_id and get_feature_sem_guid_nem_nice(zs_field(done_do_id,:feature))==featname)

	
	total_arquivos_mover=[]
	ts_theId = zs_field(done_do_id,:ts).to_s

	agora_ts = zs_ts_now
	zs_update_field_of_feature_list featname, ts_genesis_detalhado: agora_ts #2018Ago29, added, atualiza incondicionalmente a hora da volta pra genesis antes de começar a processar a feature, por garantia.


	# NAO CONFIAR EM FTZ!
	feature_arquivos_mover=[]
	globparam = "#{zs_network_dir}/**/*feature=*X#{featname}guid*"
	dirgenesisparam = "#{zs_genesis_network_dir}/*feature=*X#{featname}guid*"
	write_rsi_log :debug, "zs_volta_features_pra_genesis, globparam=#{globparam}, dirgenesisparam=#{dirgenesisparam}"
	all_feat_ids = (Dir.glob(globparam)+Dir[dirgenesisparam]).sort{|a,b|zs_ts_field(a).to_s<=>zs_ts_field(b).to_s}.map{|filepath|filename=File.basename(filepath); filename.split("id=")[1].split("_")[0]}.uniq #sem uniq, gerava duplicidades
	other_feat_ids = all_feat_ids - [theId]
	previous_feat_ids = other_feat_ids.select{|id| 
		is_previous = false
		stt_done = Dir["#{zs_network_dir}/stt*_id=#{id}_*done*7z"].first
		ts_theId = zs_field(done_do_id, :ts).to_s
		ts_sttDone = (zs_field(stt_done,:ts).to_s if stt_done) || zs_ts_hivalues
		if ts_sttDone < ts_theId
			is_previous = true
		end
		write_rsi_log :debug, "zs_volta_uma_feature_pra_id, featname=#{featname}, theId=#{theId}, is_previous=#{is_previous} pois ts_theId=#{ts_theId} e ts_sttDone=#{ts_sttDone} --> done_do_id=#{done_do_id}, stt_done=#{stt_done}"  
		is_previous
	}
	ids_to_remove = other_feat_ids - previous_feat_ids #2018Set12 - preserva arquivos do "id" parametro, e de "id"s referentes a stt*done*7z mais antigos/anteriores 

	ids_to_remove.each{|id|
		a_mover_id = Dir["#{zs_network_dir}/*id=#{id}*"]
		total_arquivos_mover = total_arquivos_mover + a_mover_id
		feature_arquivos_mover = feature_arquivos_mover + a_mover_id
		write_rsi_log :debug, "zs_volta_uma_feature_pra_id, featname=#{featname}, theId=#{theId}, a_mover_id.length=#{a_mover_id.length}, a_mover_id=#{a_mover_id}"
		if a_mover_id.uniq.length != a_mover_id.length
			falhar "1. length nao bateu"
		end
		if feature_arquivos_mover.uniq.length != feature_arquivos_mover.length
				falhar "2. length nao bateu"
		end
		if total_arquivos_mover.uniq.length != total_arquivos_mover.length
				falhar "3. length nao bateu"
		end
		sufixo = "#{zs_new_global_id(4)}.bkgn"
		a_mover_id.each{|arquivo_de_zsnd|
			bn = File.basename(arquivo_de_zsnd)
			dest_dir = "#{zs_genesis_network_dir}" #move para diretorio paralelo a zs_network_dir que nao interfere em "dir /s @@ ls -R" (DIr.glob) que lê zs_aux_network_dir 
			dest_file = "#{dest_dir}/#{bn}.#{sufixo}"
			# "rbattaglia - Filhadamae! 2018Ago02 - problema crasso em execucao, detectado com Roberto Boker, foi causado por (FILENAME_TOO_LONG por FEATURENAME_TOO_LONG) !por nao conseguir mover nos backups de ciclo" if false #### ENTAO, devo reduzir mais uns 15 ou 20 caracteres de tamanho maximo de RAW_FEATURE_NAME em gerador_massa.rb !!!
			if true
				write_rsi_log :debug, "zs_volta_uma_feature_pra_id, featname=#{featname} e theId=#{theId}, vai mover arquivo_de_zsnd=#{arquivo_de_zsnd} para dest_file=#{dest_file}"
				if bn.start_with? 'stt' and bn.include?'=done' and bn.include? '.7z' #2018Ago19 pm, FIXED important error, start_with instead of start_with? !!!
					#2018Ago19 - protegendo potencial mv de stt*done*7z que pode estar sendo copiado por realtime_report
					zs_espera_not_eacces {FileUtils.mv arquivo_de_zsnd, dest_file}
				else
					FileUtils.mv arquivo_de_zsnd, dest_file
				end
				write_rsi_log :debug, "zs_volta_uma_feature_pra_id, featname=#{featname} e theId=#{theId}, SIM, MOVEU arquivo_de_zsnd=#{arquivo_de_zsnd} para dest_file=#{dest_file}"
			else
				write_rsi_log :debug, "zs_volta_uma_feature_pra_id, featname=#{featname} e theId=#{theId}, NAO, nao movendo, DEBUG DUMMY CODE, arquivo_de_zsnd=#{arquivo_de_zsnd} para dest_file=#{dest_file}"
			end
		}
	}
	write_rsi_log :debug, "zs_volta_uma_feature_pra_id, featname=#{featname} e theId=#{theId}, feature_arquivos_mover.length=#{feature_arquivos_mover.length}, feature_arquivos_mover=#{feature_arquivos_mover}"
	#write_rsi_log :debug, "zs_volta_features_pra_genesis, featname=#{featname}, feature_arquivos_mover.uniq.length=#{feature_arquivos_mover.uniq.length}, feature_arquivos_mover.uniq=#{feature_arquivos_mover.uniq}"
	if feature_arquivos_mover.uniq.length != feature_arquivos_mover.length
			falhar "4.length nao bateu"
	end
	if total_arquivos_mover.uniq.length != total_arquivos_mover.length
		falhar "5.length nao bateu"
	end

	#2018Set12, aqui, diferença também importante em relacao a zs_volta_features_pra_genesis: em vez de restaurar o primeiríssimo trio FTZ/DAT/CCC, o que fazemos é reinserir para reprocessamento o stt*done*7z descrito nos parâmetro featname+theId !!
	if true
		write_rsi_log :debug, "zs_volta_uma_feature_pra_id, featname=#{featname} e theId=#{theId}, vai chamar zs_reinserir_done_para_reprocessamento(#{done_do_id}, forca_refluxo:false)"

		zs_reinserir_done_para_reprocessamento done_do_id, forca_refluxo: false 
		write_rsi_log :debug, "zs_volta_uma_feature_pra_id, featname=#{featname} e theId=#{theId},  chamou zs_reinserir_done_para_reprocessamento(#{done_do_id}, forca_refluxo:false)"
	else
		write_rsi_log :debug, "zs_volta_uma_feature_pra_id, featname=#{featname} e theId=#{theId}, NAO VAI DUMMY DEBUG chamar zs_reinserir_done_para_reprocessamento(#{done_do_id}, forca_refluxo:false)"
	end

	write_rsi_log :debug, "zs_volta_uma_feature_pra_id, total_arquivos_mover.length=#{total_arquivos_mover.length}, total_arquivos_mover=#{total_arquivos_mover}"
	if total_arquivos_mover.uniq.length != total_arquivos_mover.length
		falhar "6.length nao bateu"
	end

	return
end

def zs_parar_features(features_sem_guidnice = nil, all_sevenzs = nil, existing_features_list = nil)
# 2018Set13, created method zs_parar_features
# 2018Set13, este método nao influi nos reports/evidencias, pois apenas para onde está, sem modificar nada

	write_rsi_log :debug, "zs_parar_features() - INI P00"
	existing_features_list = existing_features_list || zs_read_feature_list.map{|fi|fi[:base_feature_name]}
	all_sevenzs = all_sevenzs || Dir["#{zs_network_dir}/stt*done*7z"]
	

	raise "zs_parar_features, parametro(s) invalido(s), features_sem_guidnice=#{features_sem_guidnice}" if not (features_sem_guidnice and features_sem_guidnice.is_a?(Array) and features_sem_guidnice.length)

	zs_clean_ack_sem_aux # aproveita que vai manipular, que exige TODAS maquinas 100% paradas, e faz clean de ACK sem AUX 	


	features_sem_guidnice.each do|featname|
		executa_exclusivo({:verbose=>true, :segundos_sleep=>5}, zs_feature_lock_filename(featname), -1) do
			zs_create_feature_terminate_file(featname,:parar) 
			zs_parar_uma_feature featname, all_sevenzs, existing_features_list
		end
	end
	return
end


def zs_parar_uma_feature(featname, all_sevenzs = nil, existing_features_list = nil)
# 2018Set13, created method zs_parar_uma_feature
# 2018Set13, este método nao influi nos reports/evidencias, pois apenas para onde está, sem modificar nada

	write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}) - INI P00"
	existing_features_list = existing_features_list || zs_read_feature_list.map{|fi|fi[:base_feature_name]}
	raise "zs_parar_uma_feature(featname=#{featname}), parametro existing_features_list=#{existing_features_list} invalido" if not (  existing_features_list and existing_features_list.is_a?(Array) and (not existing_features_list.any?{|fn|not fn.is_a?(String)})  )
	raise "zs_parar_uma_feature(featname=#{featname}), parametro featname=#{featname} invalido" if not (  featname and featname.is_a?(String) and existing_features_list.include?(featname)  )

	last_stt_done = zs_get_last_stt_done_of_one_feature(featname, all_sevenzs)
	raise "zs_parar_uma_feature(featname=#{featname}), feature nao tem nenhum arquivo stt*done*7z correspondente" if false and (last_stt_done == nil) #TODO 2018Set13 - nao esqueça: criar 7z dummy se nao houver nenhum!!  #2018Set13 - desnecessario. Se nao tiver, bastará criar um 7Z novo dummy. POEÈM, isso é um pouco complexo de se fazer ... entao, por enquanto, apenas removeremos o trio next ".dat+.ftz+.ccc", deixando a feature 'orfã' mas cumprindo a missão de parar processamento da feature.

	ids = []
	if not last_stt_done
		ftz_files = Dir["#{zs_network_dir}/ftz*X#{featname}guid*"]
		raise "zs_parar_uma_feature(featname=#{featname}), feature sem arquivo stt*done*7z correspondente E nao tem nenhum ftz!" if ftz_files.length == 0 
		raise "zs_parar_uma_feature(featname=#{featname}), feature sem arquivo stt*done*7z correspondente MAS tem mais que um arquivo ftz!" if ftz_files.length > 1 
		ids = [ zs_field(ftz_files.first,:id).to_s ]
		write_rsi_log "zs_parar_uma_feature(featname=#{featname}), nao i=tinha nenhum stt*done*7z correspondente. Vai acabar removendo totalmente os FTZ/CCC/DAT, e restará em diretório-base #{zs_network_dir} apenas os feature_list.*.csv pra falar sobre a feature. Para fazer zs_proc.rb continuar_uma_feature, neste caso, teremos que trazer trio ftz+dat+ccc do diretorio auxiliar #{zs_aux_network_dir} !!"
	else
	# elsif last_stt_done.include?('ls=0')
	#2018Set14 - mesmo que ja marcado com ls=1, faz processamento de "parar", por segurança.
		
		if last_stt_done.include?('ls=0')
			newname_stt_done = last_stt_done.gsub('ls=0','ls=1')
			write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}), arquivo stt*done*7z correspondente renomeado para 'ls=0'.  last_stt_done=#{last_stt_done}, newname_stt_done=#{newname_stt_done} ."
			zs_espera_not_eacces {FileUtils.mv last_stt_done, newname_stt_done}
		else

			write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}), arquivo stt*done*7z já tem 'ls=0'. Nao precisa ser renomeado. last_stt_done=#{last_stt_done} ."
		end
		ts_last_stt_done = zs_field(last_stt_done, :ts).to_s
		next_ftz_a = Dir["#{zs_network_dir}/ftz*X#{featname}guid*.ftz"].select{|ftz| (zs_field(ftz,:ts)||zs_timestamp_str(File.ctime ftz)).to_s >= ts_last_stt_done}
		write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}), arquivo stt*done*7z tem timestamp ts_last_stt_done=#{ts_last_stt_done}, next_ftz_a=#{next_ftz_a}"

		if next_ftz_a.length > 0
			if next_ftz_a.length > 1
				write_rsi_log :error, "zs_parar_uma_feature(featname=#{featname}), ERRO NAO FATAL - arquivo stt*done*7z tem MAIS QUE UM ftz de timestamp igual/posterior, last_stt_done=#{last_stt_done}, next_ftz_a=#{next_ftz_a}, serão deletados os trios ftz+dat+ccc"
			else
				write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}), arquivo stt*done*7z tem timestamp ts_last_stt_done=#{ts_last_stt_done}, será deletado o trio next ftz+dat+ccc igual/posterior"
			end
			ids = next_ftz_a.map{|ftz| zs_field(ftz,:id).to_s}
		else
			write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}), arquivo stt*done*7z tem timestamp ts_last_stt_done=#{ts_last_stt_done}, nao foi encontrado trio next ftz+dat+ccc posterior"
		end
	end

	write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}), INI RM, trio(s) next ftz+dat+ccc serah removido para os seguintes ids, se algum. ids=#{ids}"
	if ids and ids.length > 0
		#pode ter decidido acima por deleter mais que um trio
		ids.each do |id|
			write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}), id do trio next ftz+dat+ccc a remover=#{id}"
			ccc_del = Dir["#{zs_network_dir}/cmd*type=runone*id=#{id}*.ccc"].first;zs_remove_with_backup ccc_del if ccc_del
			ftz_del = Dir["#{zs_network_dir}/ftz*id=#{id}*.ftz"            ].first;zs_remove_with_backup ftz_del if ftz_del
			dat_del = Dir["#{zs_network_dir}/dat*id=#{id}*.7z"             ].first;zs_remove_with_backup dat_del if dat_del
			write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}), id do trio next ftz+dat+ccc removido=#{id}, ccc_del=#{ccc_del}, ftz_del=#{ftz_del}, dat_del=#{dat_del}"
		end
		write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}), FIM RM de trio(s) next, ids=#{ids}"
	end
	write_rsi_log :debug, "zs_parar_uma_feature(featname=#{featname}) - END"
	return
end

def zs_continuar_features(features_sem_guidnice = nil, all_sevenzs = nil, existing_features_list = nil)
# 2018Set13, created method zs_continuar_features
# 2018Set13, este método nao influi nos reports/evidencias, pois apenas para onde está, sem modificar nada
	write_rsi_log :debug, "zs_continuar_features() - INI P00"
	existing_features_list = existing_features_list || zs_read_feature_list.map{|fi|fi[:base_feature_name]}
	all_sevenzs = all_sevenzs || Dir["#{zs_network_dir}/stt*done*7z"]
	
	raise "zs_continuar_features, parametro(s) invalido(s), features_sem_guidnice=#{features_sem_guidnice}" if not (features_sem_guidnice and features_sem_guidnice.is_a?(Array) and features_sem_guidnice.length)
	zs_clean_ack_sem_aux # aproveita que vai manipular, que exige TODAS maquinas 100% paradas, e faz clean de ACK sem AUX 	

	features_sem_guidnice.each do|featname|
		executa_exclusivo({:verbose=>true, :segundos_sleep=>5}, zs_feature_lock_filename(featname), -1) do
			zs_create_feature_terminate_file(featname,:continuar) 

			zs_continuar_uma_feature featname, all_sevenzs, existing_features_list
		end
	end
	return
end

def zs_continuar_uma_feature(featname, all_sevenzs = nil, existing_features_list = nil)
# 2018Set13, created method zs_continuar_uma_feature
	write_rsi_log :debug, "zs_continuar_uma_feature(featname=#{featname}) - INI P00"
	existing_features_list = existing_features_list || zs_read_feature_list.map{|fi|fi[:base_feature_name]}
	raise "zs_continuar_uma_feature(featname=#{featname}), parametro existing_features_list=#{existing_features_list} invalido" if not (  existing_features_list and existing_features_list.is_a?(Array) and (not existing_features_list.any?{|fn|not fn.is_a?(String)})  )
	raise "zs_continuar_uma_feature(featname=#{featname}), parametro featname=#{featname} invalido" if not (  featname and featname.is_a?(String) and existing_features_list.include?(featname)  )

	last_stt_done = zs_get_last_stt_done_of_one_feature(featname, all_sevenzs)
	raise "zs_continuar_uma_feature(featname=#{featname}), feature nao tem nenhum arquivo stt*done*7z correspondente" if false and (last_stt_done == nil)

	id = nil
	if last_stt_done #and last_stt_done.include?('ls=0') #TOLERANTE - se algo deu errado antes, aqui, corrigimos: mesmo que a feature nao esteja "ls=1", damos chance de 
		write_rsi_log :debug, "zs_continuar_uma_feature(featname=#{featname}), vai chamar zs_reinserir_done_para_reprocessamento pois last_stt_done=#{last_stt_done}"
		reinseriu = zs_reinserir_done_para_reprocessamento last_stt_done, apenas_desistencias: false, forcar_refluxo: false
		#reinseriu será FALSE se tentarmos continuar uma feature "naturalmente concluida", por exemplo, que tenha dado certo na ultima fase
		if reinseriu
			write_rsi_log :debug, "zs_continuar_uma_feature(featname=#{featname}), fez de fato a reinsercao. Nao precisa renomear para ls=0, pois a tradicional zs_reinserir_done_para_reprocessamento já faz isso caso tenha criando trio .dat/.ccc/.ftz em publicacao de features"
		end
	else
		write_rsi_log :debug, "zs_continuar_uma_feature(featname=#{featname}), nao encontrado NENHUM arquivo stt*done*7z correspondente. Vai restaurar o trio original ftz+dat+ccc da feature"
		zs_restaura_comando_original_da_feature(featname)
		write_rsi_log :debug, "zs_continuar_uma_feature(featname=#{featname}), nao encontrado NENHUM arquivo stt*done*7z correspondente. Restaurado o trio original ftz+dat+ccc da feature"
	end

	write_rsi_log :debug, "zs_continuar_uma_feature(featname=#{featname}) - END"
	return
end

def zs_get_features_with_missing_command
	unfinished_features = zs_get_unfinished_features.sort
	features_with_pending_command = zs_get_features_with_pending_command.sort
	df = unfinished_features - features_with_pending_command
	return df
end

def zs_get_all_ftz_features
#2018Out2, renamed to zs_get_all_ftz_features
	all_ftz_features = Dir.glob("#{zs_network_dir}/**/ftz*ftz").map{|ftz| get_feature_sem_guid_nem_nice zs_field(ftz,:feature)}.uniq.sort
	return all_ftz_features
end

def zs_get_all_features
#2018Out2, created
	all_features = zs_read_feature_list.map{|h| h[:base_feature_name]}
	return all_features
end

def zs_get_unfinished_features
	all_features = zs_get_all_features
	finished_features = zs_get_finished_features
	df = all_features - finished_features
	return df
end


def zs_get_features_with_pending_command
	fts = zs_get_ftzs_of_pending_commands.map{|ftz| get_feature_sem_guid_nem_nice zs_field(ftz,:feature) if ftz}.sort
	un = fts.uniq
	df = fts - un
	if df.length > 0
		write_rsi_log :error, "zs_get_features_with_pending_command, existem features com 2 ou mais comando, df=#{df}"
	end
	if un.include?(nil)
		write_rsi_log :error, "zs_get_features_with_pending_command, existem comandos pros quais nao foram achados arquivos ftz"
	end
	return un.select{|ft| ft != nil}
end

def zs_get_ftzs_of_pending_commands
	ftzs = Dir["#{zs_network_dir}/*runone*.ccc"].map{|stt|id=zs_id_field(stt); Dir.glob("#{zs_network_dir}/**/ftz*_id=#{id}*").first}
	return ftzs
end

def zs_get_runone_commands
	fts = Dir["#{zs_network_dir}/*runone*.ccc"].map{|stt|id=zs_id_field(stt); Dir.glob("#{zs_network_dir}/**/ftz*_id=#{id}*").first}.map{|ftz| get_feature_sem_guid_nem_nice zs_field(ftz,:feature) if ftz}.sort
	un = fts.uniq
	df = fts - un
	if df.length > 0
		write_rsi_log :error, "zs_get_runone_commands, existem features com 2 ou mais comando, df=#{df}"
	end
	if un.include?(nil)
		write_rsi_log :error, "zs_get_runone_commands, existem comandos pros quais nao foram achados arquivos ftz"
	end
	return un.select{|ft| ft != nil}
end

def zs_get_finished_features
	fts = Dir["#{zs_network_dir}/stt*done*ls=1*7z"].map{|stt|get_feature_sem_guid_nem_nice zs_field(stt,:feature)}.sort
	un = fts.uniq
	df = fts - un
	if df.length > 0
		write_rsi_log :error, "zs_get_finished_features, existem features com 2 ou mais stt*done*ls=1*, df=#{df}"
	end
	return un
end

def zs_get_finished_features
	fts = Dir["#{zs_network_dir}/stt*done*ls=1*7z"].map{|stt|get_feature_sem_guid_nem_nice zs_field(stt,:feature)}.sort
	un = fts.uniq
	df = fts - un
	if df.length > 0
		write_rsi_log :error, "zs_get_finished_features, existem features com 2 ou mais stt*done*ls=1*, df=#{df}"
	end
	return un
end

def zs_get_last_stt_done_of_features(featlist=nil, all_sevenzs = nil)
	if featlist == nil
		if all_sevenzs == nil
			todos_done_sevenz = Dir["#{zs_network_dir}/stt*done*7z"]
		else
			todos_done_sevenz = all_sevenzs
		end
		featlist = todos_done_sevenz.map{|stt| zs_field(stt,:feature)}.map{|full_featname| get_feature_sem_guid_nem_nice(full_featname)}.sort.uniq
	end

	last_stt_dones = featlist.map{|featname| zs_get_last_stt_done_of_one_feature(featname, todos_done_sevenz)}
	last_stt_dones = last_stt_dones.select{|stt| stt != nil} #para evitar erro com featname inváldo na lista featlist
	return last_stt_dones
end
def zs_get_last_stt_done_of_one_feature(featname, all_sevenzs = nil)
	feature_sevenzs = []
	if all_sevenzs == nil
		feature_sevenzs = Dir["#{zs_network_dir}/stt*X#{featname}guid*.7z"]
	else
		feature_sevenzs = all_sevenzs.select{|stt| get_feature_sem_guid_nem_nice(zs_field(stt,:feature)) == featname}
	end
	fti = {
		:featname => featname,
	    :last_sevenz => 
	    	feature_sevenzs.sort{|stt_a,stt_b| zs_field(stt_a,:ts).to_s <=> zs_field(stt_b,:ts).to_s}.last
	}
	last_stt_done = fti[:last_sevenz]
	return last_stt_done
end

def zs_espera_not_eacces(max_segundos = 60*15, segundos_entre_tentativas = 2)
#2018Ago19 pm, created
#2018Set02, aumentado de 2 minutos para QUINZE(15) minutos o tempo total de espera !!!
	retval = nil
	exc_eacces = nil
	espera_condicao(max_segundos, segundos_entre_tentativas) do
		begin
			retval = yield
			exc_eacces = nil
		rescue Errno::EACCES => ea
			exc_eacces = ea
			write_rsi_log :warn, "zs_espera_not_eacces, Erro Errno::EACCES enquanto executava uma manipulacao de arquivo, exc_eacces=#{exc_eacces}"
		end
		exc_eacces == nil #ok se nao deu Errno::eacces
	end #LOOP espera_condicao
	if exc_eacces != nil
		raise exc_eacces
	end
	return retval
end

def zs_reinsere_features_para_reprocessamento(features_sem_guidnice = nil, h={:apenas_desistencias => true, :forcar_refluxo => false, :arquivo_terminate => :reinserefeature})
	h = h || {} #2018Ago17 pm - recebe opcoes que permitem escolher se reinsee apenas_desistencias e se deve :forcar_refluxo. Permite reinserir até "falsos OKs", mandando fazer algo de novo que está marcado como 100% concluido ls=1, si=FINAL/TFC/10 e failed=999!s

	raise "zs_reinsere_features_para_reprocessamento, parametro(s) invalido(s), features_sem_guidnice=#{features_sem_guidnice}, h=#{h}" if not (features_sem_guidnice and features_sem_guidnice.is_a?(Array) and features_sem_guidnice.length > 0 and h.is_a?(Hash) and h.keys.include? :apenas_desistencias and h.keys.include? :forcar_refluxo)
	write_rsi_log :debug, "zs_reinsere_features_para_reprocessamento, features_sem_guidnice.length=#{features_sem_guidnice.length}, h=#{h}"
	zs_clean_ack_sem_aux # aproveita que vai reinserir desistencias, que exige TODAS maquinas 100% paradas, e faz clean de ACK sem AUX 	

	last_sevenzs = zs_get_last_stt_done_of_features(features_sem_guidnice)

	stt_sevenzs = last_sevenzs.select{|stt| 
		# NOTA! Se pedir reinsercao de feature que já esteja 100% ok, com ls=1, si=010/TFC/FFINAL e failed=999... Entao, nesse caso, vai acabar reprocessando algo já concluído. ANYWAY, isso dá flexibilidade: se automação estiver dando "falsos OK", e corrigirmos fontes, podemos reprocessar esses falsos positivos! ISSO PE BOM!
		write_rsi_log "filtrando last_sevenzs, stt=#{stt}"
		ok = false

		bad = ( 
			h[:apenas_desistencias] and not (
				zs_field(stt, :failed).to_s.to_i != 999 and zs_field(stt,:ls).to_s == '1'
			)
		)
		
		ok = (not bad)

		ok
	}

	stt_sevenzs.each do |d|
		featname = get_feature_sem_guid_nem_nice(zs_field(d, :feature).to_s)
		executa_exclusivo({:verbose=>true, :segundos_sleep=>5}, zs_feature_lock_filename(featname), -1) do
			zs_create_feature_terminate_file(featname, h[:arquivo_terminate]) 


			zs_reinserir_done_para_reprocessamento d, h #2018Set17 - corrigido, nao passava parametro "h" #2018Set12, extraído método para generalizacao
		end
	end
	return
end


def zs_get_max_tentativas_feature
	return $zs_cfg[:max_tentativas_feature] || get_max_tentativas_feature 
	#2018Set26 pm - faltava default value get_max_tentativas_feature
	#2018Out7 - obtinha o valor alternativo max de feature_list.csv em vez do correto $zs_cfg
end

def zs_get_max_global_tentativas_feature
	return $zs_cfg[:max_global_tentativas_feature] || get_max_tentativas_feature 
	#2018Set26 pm - faltava default value get_max_tentativas_feature
	#2018Out7 - obtinha o valor alternativo max de feature_list.csv em vez do correto $zs_cfg
end

def zs_reinserir_done_para_reprocessamento(d, h)
	falhar "zs_reinseir_done_para_reprocessamento, parametro arquivo d inválido ou arquivo nao existe, d=#{d}" if not (d and File.file?(d) and File.basename(d).start_with?("stt") and File.basename(d).include?('done') and File.basename(d).end_with?('7z'))
	write_rsi_log "zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}), P000 inicio geral"

	af = zs_all_fields(d)
	write_rsi_log :debug, "af=#{af}, af[:id]=#{af[:id]}"
	#2018Set14 - removendo uso, neste método, de zs_ftz_list e "hash ftz", pois ftzs podem estar des-sincronizados/corrompidos
	s_id = zs_field(d,:id).to_s
	s_feat = zs_field(d,:feature).to_s
	tmpDatDir = "#{zs_local_temp_dir}/rdes"
	mkdir_noexist tmpDatDir
	delete_all_in_dir tmpDatDir
	pd = Dir.pwd
	Dir.chdir tmpDatDir
	cmdcore = "7za x #{d}"


	system cmdcore
	Dir.chdir pd
	ri_orig_arq_feature = Dir.glob("#{tmpDatDir}/**/*.feature").first
	
	write_rsi_log("zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}), af=#{af}, s_id=#{s_id}, s_feat=$#{s_feat}")

	ri_hash_massa   = ler_xls_com_id(Dir.glob("#{tmpDatDir}/**/*.xls").first)
	ri_feat_dir = "#{zs_local_temp_dir}/ri/auto"
	ri_massa_dir = "#{zs_local_temp_dir}/ri/auto"
	mkdir_noexist ri_feat_dir; delete_all_in_dir ri_feat_dir
	mkdir_noexist ri_massa_dir; delete_all_in_dir ri_massa_dir
	
	featname_long=get_raw_feature_name_from_feature_file(ri_orig_arq_feature)
	featname_sem_guidnice = get_feature_sem_guid_nem_nice(featname_long)
	write_rsi_log :debug, "zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}), parametros para get_test_outputs_da_feature_da_trn, de onde pegarei steps, (NAmed parameters).... ===>>> feat_dir=#{File.dirname(ri_orig_arq_feature)}, autdir=#{tmpDatDir}, featname_long=#{featname_long}, trn=1"
	o = get_test_outputs_da_feature_da_trn(File.dirname(ri_orig_arq_feature), tmpDatDir, featname_long, 1) #COMPLEXIDADe DESNECESSARIA, POOR DESIGN
	ri_json_steps = o[:steps]

	write_rsi_log "zs_reinsere_features_para_reprocessamento, parametros para reinsere_clone_reproc_feature: ri_orig_arq_feature=#{ri_orig_arq_feature}, ri_json_steps=#{ri_json_steps}, ri_hash_massa=#{ri_hash_massa}, ri_feat_dir=#{ri_feat_dir}, ri_massa_dir=#{ri_massa_dir}"

	reinseriu = reinsere_clone_reproc_feature(ri_orig_arq_feature, ri_json_steps, ri_hash_massa, ri_feat_dir, ri_massa_dir, zs_get_max_tentativas_feature, zs_get_max_global_tentativas_feature,  forcar_reinsercao: true, forcar_refluxo: h[:forcar_refluxo]) #2018Ago17 pm, adicionado :forcar_refluxo na chamada a reinsere_clone_reproc_feature #2018Mar21 - NAO PRECISAMOS MAIS aumentar get_max_tentativas_feature
	write_rsi_log "zs_reinsere_features_para_reprocessamento, CHAMOU, reinseriu=#{reinseriu} com parametros para reinsere_clone_reproc_feature: ri_orig_arq_feature=#{ri_orig_arq_feature}, ri_json_steps=#{ri_json_steps}, ri_hash_massa=#{ri_hash_massa}, ri_feat_dir=#{ri_feat_dir}, ri_massa_dir=#{ri_massa_dir}"

	if reinseriu
		write_rsi_log :debug, "zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}),: arquivo ='#{d}' tem af=#{af}"
		if zs_field(d, :ls).to_s.to_i == 1 #2018Ago17 pm, somente renomeia se tinha zs_field "ls=1"
			base_stt_fname = zs_stt_runone_fname(id: af[:id], act: :done, maq:af[:maq], guid:'0000', ts: af[:ts], failed: af[:failed], ls: '0'.to_sym, cpf: af[:cpf]) #2018Mar12 - adicionado 	
			new_stt_fname = "#{zs_network_dir}/#{base_stt_fname}.7z"
			write_rsi_log :debug, "zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}), arquivo ="
			write_rsi_log :debug, d
			write_rsi_log :debug, "serah renomeado para "
			write_rsi_log :debug, new_stt_fname
			exc_eacces = nil
			zs_espera_not_eacces do
				#2018Ago19 - protegendo contra erro EACCES causado por report_realtime estar copiando de rede pra VM
				begin
					FileUtils.mv d, new_stt_fname
				rescue SystemCallError => e
					10.times { write_rsi_log :error, "zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}), Erro exception=#{e} renomeando stt pra que nao seja mais ls=1! IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO IGNORANDO , que pode ferar mau output em zs_monitor_quicksatus (FRAGILIDADE do quickstatus, pois ls=1 nem deveria existir, (2018Mar22 TOTO) sempre devemos ver se o ultimo stt*most_basic_feature_name*done*7z de um dado si=N tem failed=99 pra dizer se passou de fase ou nao!"}
					#next
				end
			end #LOOP zs_espera_not_eacces


		end #ENDIF 

		feature_ftzs = Dir["#{zs_network_dir}/ftz*feature=*X#{featname_sem_guidnice}guid*.ftz"]   
		ids_of_feature_ftzs = feature_ftzs.map{|ftf| zs_field(ftf, :id).to_s}
		cmdfiles_of_feature_ftzs = ids_of_feature_ftzs.map{|id| Dir["#{zs_network_dir}/cmd*type=runone_*id=#{id}*.ccc"].first}.select{|cmdfile| cmdfile != nil}
		#cmdfiles_of_feature_ftzs deveria retornar apenas 1 elemento no array
		write_rsi_log :debug, "zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}, cmdfiles_of_feature_ftzs.length=#{cmdfiles_of_feature_ftzs.length}, deveria ser igual a 1, mas vou deletar todos, mesmo q gerados por bug de outro lugar"
		cmdfiles_of_feature_ftzs.each{|one_cmdfile_of_feature_ftzs|
			cmd_id_of_feature_ftzs = zs_field(one_cmdfile_of_feature_ftzs, :id).to_s
			ftz_del = Dir["#{zs_network_dir}/ftz*id=#{cmd_id_of_feature_ftzs}*.ftz"].first
			cmd_del = Dir["#{zs_network_dir}/cmd*id=#{cmd_id_of_feature_ftzs}*.ccc"].first
			dat_del = Dir["#{zs_network_dir}/dat*id=#{cmd_id_of_feature_ftzs}*.7z"].first
			write_rsi_log :debug, "zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}), removendo trio cmd+ftz+dat arquivo anterior da feature, featname_sem_guidnice=#{featname_sem_guidnice}, cmd_id_of_feature_ftzs=#{cmd_id_of_feature_ftzs},ftz_del=#{ftz_del}, ftz_del=#{ftz_del}, dat_del=#{dat_del}"
			zs_remove_with_backup cmd_del if cmd_del
			zs_remove_with_backup ftz_del if ftz_del
			zs_remove_with_backup dat_del if dat_del
			write_rsi_log :debug, "zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}),, removeu trio cmd+ftz+dat arquivo anterior da feature, featname_sem_guidnice=#{featname_sem_guidnice}, ftz_del=#{ftz_del}, ftz_del=#{ftz_del}, dat_del=#{dat_del}"
		}

		#sq_new = zs_ftz_list.select{|ftz|ftz[:id].to_s==s_id}.map{|ftz|ftz[:sq].to_s.to_i}.max + 1 #2018Set14 - removendo uso, neste método, de zs_ftz_list e "hash ftz", pois ftzs podem estar des-sincronizados/corrompidos
		sq_new = zs_field(d,:sq).to_s.to_i + 1 #2018Set14 - somente faz sentido reinserir o ultimo DONE, o que nos leva a um bom :sq (o do stt*done*7z q estamos usando)
		
		write_rsi_log :debug, "zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}), agora, vai chamar zs_synch_postcmd_publica_features, com parametros (sq_new=#{sq_new}"
		zs_synch_postcmd_publica_features(ri_feat_dir, ri_massa_dir, sq_new) if true #cria trio next .dat + .ftz + .ccc
	end
	write_rsi_log "zs_reinserir_done_para_reprocessamento(d=#{d}, h=#{h}), P999 fim geral, reinseriu=#{reinseriu}"
	return reinseriu
end

def zs_create_stt_sevenz_done(feature, id )
	aut_dir = $zs_cfg[:automdir]

		# RUBY SPLITTER.RB nao funciona para single feature X ja executada e nao movida TENHO QUE CHAMAR CMDLINE 7za MANUALMENTE!!
	fmasks_and_dirinsevenz = zs_get_fmasks_and_dirs_in_sevenz(feature)
	write_rsi_log :debug, "zs_create_stt_sevenz_done, feature=#{feature}, fmasks_and_dirinsevenz=#{fmasks_and_dirinsevenz}"

	sevenz_dir = "#{zs_local_temp_dir}/sevenz"

	sevenz_working_dir = "#{zs_local_temp_dir}/zw"


	sevenz_tmp_file = "#{sevenz_dir}/sevenz_done_#{zs_new_global_id}.7z"
	sevenz_out_txt = "#{sevenz_dir}/sevenz_output_#{zs_new_global_id}.txt"

	mkdir_noexist     sevenz_dir
	FileUtils.rm sevenz_tmp_file if File.exist? sevenz_tmp_file #2018Fev25 - faltava remoer. Tava acumulando evidencias de outras features anteriores! 
	write_rsi_log :debug, "zs_create_stt_sevenz_done, sevenz_dir=#{sevenz_dir}, sevenz_working_dir=#{sevenz_working_dir}, sevenz_tmp_file=#{sevenz_tmp_file}"

	delete_all_in_dir sevenz_dir
	mkdir_noexist     sevenz_working_dir #já nao vai existir
	delete_all_in_dir sevenz_working_dir #2018Mar03, zerando... pra evitar ficar acumulando evidencias de outra feature da mesma execucao de run_parallel.rb

	write_rsi_log :debug, "zs_create_stt_sevenz_done, feature=#{feature}, vai processar fmasks_and_dirinsevenz"
	
	fmasks_and_dirinsevenz.keys.each do |file_type|
		write_rsi_log :debug, "zs_create_stt_sevenz_done, file_type=#{file_type}"
		fmask_and_dir = fmasks_and_dirinsevenz[file_type]
		write_rsi_log :debug, "zs_create_stt_sevenz_done, fmask_and_dir=#{fmask_and_dir}"
		fmask = fmask_and_dir[0]
		write_rsi_log :debug, "zs_create_stt_sevenz_done, fmask=#{fmask} "
		dir_in_sevenz = fmask_and_dir[1]
		write_rsi_log :debug, "zs_create_stt_sevenz_done, dir_in_sevenz=#{dir_in_sevenz} "
		
		if fmask == nil or dir_in_sevenz == nil
			next
		end

		files_of_fmask = Dir[fmask]
		write_rsi_log :debug, "zs_create_stt_sevenz_done, files_of_fmask=#{files_of_fmask} "
		destpath_for_files = "#{sevenz_working_dir}/#{dir_in_sevenz}" 
		write_rsi_log :debug, "zs_create_stt_sevenz_done, destpath_for_files=#{destpath_for_files} "
		mkdir_noexist destpath_for_files 
		files_of_fmask.each {|fpath|
			write_rsi_log :debug, "zs_create_stt_sevenz_done, fpath=#{fpath} "
			FileUtils.cp fpath, destpath_for_files 
		}
		prevdir = Dir.pwd
		write_rsi_log :debug, "zs_create_stt_sevenz_done, copiados, prevdir=#{prevdir}"
		Dir.chdir sevenz_working_dir #tmp/zs/sevenz/working terá subdirs reports/TRN1 + features/auto
		write_rsi_log :debug, "zs_create_stt_sevenz_done, copiados, Dir.pwd=#{Dir.pwd}, Dir.glob('./**/**/*')=#{Dir.glob('./**/**/*')}"

		sevenz_cmdline = "7za a -mx9 #{sevenz_tmp_file.gsub('/','\\')} \"#{dir_in_sevenz.gsub('/','\\')}\""
		write_rsi_log :debug, "zs_create_stt_sevenz_done, sevenz_cmdline=#{sevenz_cmdline} > #{sevenz_out_txt}"
		system sevenz_cmdline
		o = File.read sevenz_out_txt if File.exist? sevenz_out_txt
		write_rsi_log :debug, "zs_create_stt_sevenz_done, output de sevenz_cmdline, o=#{o}"

		sevenztmp_created_listing=Dir["#{sevenz_tmp_file}"][0]
		write_rsi_log :debug, "zs_create_stt_sevenz_done, sevenztmp_created_listing=#{sevenztmp_created_listing}"

		Dir.chdir prevdir
		write_rsi_log :debug, "zs_create_stt_sevenz_done, copiados, Dir.pwd=#{Dir.pwd}"
	end
	if Dir.glob("#{sevenz_working_dir}/**/*.feature").length > 1 or Dir.glob("#{sevenz_working_dir}/**/*.json").length > 1 or Dir.glob("#{sevenz_working_dir}/**/*.html").length > 1
		#2018Ago17 am (continuacao de 2018Ago16 pm) - evita criar  stt*done*7z com features/jsons/htmls duplicados, gerador por MÁ INTERRUPÇÃO de processo colaborativo->run_parallel.rb->consumidor_de_features.rb->cucumber, que por sua vez causou dupla obtencao da mesma feature pelos consumidor_de_feature (ATÈ 2018Ago16 11:17am, nao pretendo corrigir erro na origem run_parallel->***, mas sim contornar problema em processo colaborativo->zs_proc.rb).
		write_rsi_log :error, "zs_create_stt_sevenz_done, retornando false, sem criar DONE pois existe mais que 1 arquivo de uma das extensoes .feature, .html e/ou .json - isso indica aborcao/interrupcao (fora de ordem) de trio (run_parallel + consumidor_de_features + cucumber)."
		return false
	end

	massa = nil
	xls_massa = Dir[fmasks_and_dirinsevenz[:massa][0]].first
	write_rsi_log "zs_create_stt_sevenz_done, vai ler massa do arquivo #{xls_massa}"
	if xls_massa == nil
		write_rsi_log :error, "zs_create_stt_sevenz_done, arquivo xls_massa nao encontrado para id=#{id} e feature=#{feature}"
	else
		begin
			massa = ler_xls_com_id(xls_massa)
		rescue Exception => e
			write_rsi_log :error, "zs_create_stt_sevenz_done, excecao em massa=ler_xls_com_id('#{xls_massa}' para id=#{id} e feature=#{feature}, excecao=#{e}, backtrace=#{e.backtrace}"
		end
	end
	if massa == nil
		write_rsi_log :error, "zs_create_stt_sevenz_done, retornando false, sem criar DONE pois massa eh nil, para id=#{id} e feature=#{feature}"
		return false
	end

	write_rsi_log "zs_create_stt_sevenz_done, leu massa do arquivo #{xls_massa}, massa=#{massa}, massa['CPF']=#{massa['CPF']}"

	ls = nil

###@@@@@@@@@@@@@@@@@@@@@
# INI REINSERE CLONE  
#         ** obtem as informações necessárias para reprocessamento/mudança_de_fase/desistencia
#         ** 2018Ago03 - vem antes de tudo, é inofensiva pois cria arquivos em diretorio temporario
###@@@@@@@@@@@@@@@@@@@@@
	#2018Jun27 - reinsercao/faseamento SEMPRE habilitado, nunca foi testado sem isso! Nem faz sentido!
	write_rsi_log :debug, "zs_create_stt_sevenz_done, vai fazer checagens de reproc/faseamento"

	ri_orig_arq_feature = Dir[fmasks_and_dirinsevenz[:feature][0]].first
	write_rsi_log :debug, "zs_create_stt_sevenz_done, reproc/faseamento, ri_orig_arq_feature=#{ri_orig_arq_feature}"
	ri_hash_massa   = massa
	write_rsi_log :debug, "zs_create_stt_sevenz_done, reproc/faseamento, ri_hash_massa=#{ri_hash_massa}"
	ri_feat_dir = "#{zs_local_temp_dir}/ri/auto"
	write_rsi_log :debug, "zs_create_stt_sevenz_done, reproc/faseamento, ri_feat_dir=#{ri_feat_dir}"
	ri_massa_dir = "#{zs_local_temp_dir}/ri/auto"
	write_rsi_log :debug, "zs_create_stt_sevenz_done, reproc/faseamento, ri_massa_dir=#{ri_massa_dir}"
	mkdir_noexist ri_feat_dir; delete_all_in_dir ri_feat_dir
	mkdir_noexist ri_massa_dir; delete_all_in_dir ri_massa_dir

	write_rsi_log :debug, "zs_create_stt_sevenz_done, agora, vai chamar reinsere_clones_reproc_features"
	featname=get_raw_feature_name_from_feature_file(ri_orig_arq_feature)
	featname_sem_guidnice = get_feature_sem_guid_nem_nice(featname)
	write_rsi_log :debug, "zs_create_stt_sevenz_done, featname=#{featname}"
		o = get_test_outputs_da_feature_da_trn(File.dirname(ri_orig_arq_feature), $zs_cfg[:automdir], featname, 1)  #COMPLEXIDADe DESNECESSARIA, POOR DESIGN
		ri_json_steps = o[:steps]
	write_rsi_log :debug, "zs_create_stt_sevenz_done, ri_json_steps=#{ri_json_steps}"
	reinseriu = reinsere_clone_reproc_feature(ri_orig_arq_feature, ri_json_steps, ri_hash_massa, ri_feat_dir, ri_massa_dir, zs_get_max_tentativas_feature, zs_get_max_global_tentativas_feature) #true final=apenas_debug ATIVADO
	write_rsi_log :debug, "zs_create_stt_sevenz_done, chamaou reinsere_clones_reproc_features"

	ls = (reinseriu ? '0'.to_sym : '1'.to_sym) #2018Mar12 - adicionado :ls a.k.a LAST... 0=ainda vai processar mais a feature, 1=acabou (por desistencia de muitos erros ou pq ok até o fim)
###@@@@@@@@@@@@@@@@@@@@@
# FIM REINSERE CLONE  
###@@@@@@@@@@@@@@@@@@@@@

###@@@@@@@@@@@@@@@@@@@@@
# INI CRIA E COPIA ARQUIVO STT*DONE*7Z PRA REDE,  
#         ** 2018Ago03 - movendo ccriar/copiat stt*done*7z para antes de publicacao de feature, aumenta robustez!!
###@@@@@@@@@@@@@@@@@@@@@

	write_rsi_log "zs_create_stt_sevenz_done, vai obter zs_stt_runone_fname"
	stt_fname = zs_stt_runone_fname(id:id, act: :done, maq:$zs_cfg[:maq], guid:'0000', ts:zs_timestamp_str(Time.now), failed: massa['FAILED'], ls:ls, cpf: massa['CPF']) #2018Mar12 - adicionado :ls=LAST... 0=ainda vai processar mais a feature, 1=acabou (por desistencia de muitos erros ou pq ok até o fim) 
	write_rsi_log "zs_create_stt_sevenz_done, obteve zs_stt_runone_fname, stt_fname=#{stt_fname}"

	networkdest_sevenz_path = "#{zs_network_dir}/#{stt_fname}.7z" #state DONE é um sevenz!
	networkdest_sevenz_tmp = "#{zs_network_dir}/tmp_#{zs_new_global_id}.7z"

	write_rsi_log :debug, "zs_create_stt_sevenz_done, networkdest_sevenz_tmp=#{networkdest_sevenz_tmp}, networkdest_sevenz_path=#{networkdest_sevenz_path}"
	FileUtils.cp sevenz_tmp_file, networkdest_sevenz_tmp 

	write_rsi_log :debug, "zs_create_stt_sevenz_done, STT AS 7Z, COPIOU para a rede o 7Z... achado_na_rede?='#{Dir[networkdest_sevenz_path]}'"

	write_rsi_log :debug, "zs_create_stt_sevenz_done, STT AS 7Z, vai renomear , #{networkdest_sevenz_tmp} para #{networkdest_sevenz_path}"
	FileUtils.mv networkdest_sevenz_tmp, networkdest_sevenz_path #DONE na rede! Neste instante, vários outros processos observadores começam a tomar decisões baseados na existenciam do arquivo DONE desta feature
	write_rsi_log :debug, "zs_create_stt_sevenz_done, STT AS 7Z, renomeou , #{networkdest_sevenz_tmp} para #{networkdest_sevenz_path}, neste instante, vários outros processos observadores começam a tomar decisões baseados na existenciam do arquivo DONE desta feature"
###@@@@@@@@@@@@@@@@@@@@@
# FIM CRIA E COPIA ARQUIVO STT*DONE*7Z PRA REDE,  
###@@@@@@@@@@@@@@@@@@@@@


###@@@@@@@@@@@@@@@@@@@@@
# INI PUBLICA FEATURE,  
#         ** 2018Ago03 - movida publicacao de feature para depois de ccriar/copiat stt*done*7z, aumenta robustez!!
###@@@@@@@@@@@@@@@@@@@@@

	sq_new = zs_ftz_list.select{|ftz|ftz[:id]==id}.map{|ftz|ftz[:sq].to_s.to_i}.max + 1
	#2018Out2, zs_ftz_*, NAO detectada fragilidade por manutenção duorante vôo aqui, pois aparentemente este trecho de código está protegido por lock_exclusivo da feature e já deve ter checado, na chamadora, se "ftz == nil"
	write_rsi_log :debug, "zs_create_stt_sevenz_done, agora, vai chamar zs_postcmd_call_publica_features, com parametro sq_new=#{sq_new}"
	zs_synch_postcmd_publica_features(ri_feat_dir, ri_massa_dir, sq_new)
	write_rsi_log :debug, "zs_create_stt_sevenz_done, agora, chamou zs_synch_postcmd_publica_features - REINSERÇÂO DE FEATURE 100 pct concluída"

###@@@@@@@@@@@@@@@@@@@@@
# FIM PUBLICA FEATURE
###@@@@@@@@@@@@@@@@@@@@@

	return true
	#2018Out9, adicionando boolean retval, para que chamadora trate possivel retorno falho. Chamadora tbm deveria tratar exception.
end

def zs_movable_done_files(id)
	#move: cmd (AUX e STT.STT movidos em lote via maq=#{maq}, e FTZ/ACK/DAT/DONE.&Z nao sao movidos. EM RESUMO, RETORNA APENAS CMD AQUI
	return Dir["#{zs_network_dir}/cmd_type=runone*_id=#{id}*"]

	####################### JA RETORNOU apenas CMD ACIMA! ABAIXO=deprecated
	return zs_sort_cmd_antes(
		all_but_ftz_and_done = Dir["#{zs_network_dir}/*_id=#{id}*"].
		select{|fname|
			mover = true
			bn = File.basename(fname)
			if bn.start_with? 'ftz'
				mover = false
			elsif bn.start_with? 'ack' #2018Abr08 - BAD BUG FIXED, mover ACKs era total contra-sendo. Ao fazer isso, permitíamos explicitamente que outro processo pegasse o CMD (ao ter CMD em array interno, a ausência de ACK em verificação posterior permitia processamento.) 
				mover = false
			elsif bn.start_with? 'dat' #2018Abr08 - OVERKILL? erro ao mover DAT em core_do_lets_run devia ser causado por bug de termos movido ACK. Porém, não estou 100% convencido disso, e por isso estou adicionando protecao adicional aqui.
				mover = false
			elsif bn.start_with? 'stt' and zs_field(bn,:act)==:done
				mover = false
			end
			mover
		}
	)
	
end

def zs_sort_cmd_antes(a)
	return a.sort{|f1,f2|
		#2018ABr07 23:18 - move primeiro arquivod "cmd", para que nao sejam pegos por outra máquina. SE MOVER ARQUIVO ack ANTES DE cmd gera efeito colateral de outra máquina pegar o comando de novo, gerando bugs aleatórios 
		is_f1_cmd = File.basename(f1).start_with?('cmd')
		is_f2_cmd = File.basename(f2).start_with?('cmd')
		cmp=0
		if is_f1_cmd and (not is_f2_cmd)
			cmp = -1
		elsif (not is_f1_cmd) and is_f2_cmd
			cmp = 1
		end
		cmp
	}
end

def zs_move_tudo_ciclo_done_para_auxdir(maq=$zs_cfg[:maq])
	profile_block lambda {
	dones_da_maq = Dir["#{zs_network_dir}/stt*_type=runone*_act=done*_maq=#{maq}*.stt.7z"].sort{|f1,f2| zs_field(f2,:ts) <=> zs_field(f1,:ts)}.map{|stt|zs_id_field(stt)}
	#2018Abr09 13:27 - pega os STT*DONE*7Z em ordem descrescente de timestamp/ts. Permite que movamos até nao achar algo.


	dones_da_maq.each do |id| 
		write_rsi_log :debug, "\n\n\nCHAMANDO zs_move_ciclo_done_para_auxdir #{id}"
		achou_algo = zs_move_ciclo_done_para_auxdir(id)
		if not achou_algo
			write_rsi_log :debug, "\n\n\nCONCLUINDO loop pois zs_move_ciclo_done_para_auxdir #{id} retornou false"
			break
		end
	end 
	}
	 #2018Abr06 - grande ganho de desempenho esperado, ao mover runones files para diretorio auxiliar (cmd, ack, aux, stt_chosen, stt_waiting, stt_running). CICAM: stt.7z e ftz
	profile_block lambda {
 	begin
 		FileUtils.mv Dir["#{zs_network_dir}/stt*type=runone*_maq=#{maq}*.stt"], zs_aux_network_dir
	rescue Exception => e
		write_rsi_log :error, "zs_move_tudo_ciclo_done_para_auxdir, erro ao mover stt.stt, excecao=#{e}"
	end
	}
	profile_block lambda {
 	begin
 		FileUtils.mv Dir["#{zs_network_dir}/aux*type=runone*_gottenby=#{maq}*.aux"], zs_aux_network_dir
	rescue Exception => e
		write_rsi_log :error, "zs_move_tudo_ciclo_done_para_auxdir, erro ao mover aux, excecao=#{e}"
	end
	}
	return
end

def zs_move_ciclo_done_para_auxdir(id)
	arqs_a_mover = zs_movable_done_files(id)
	if arqs_a_mover.length == 0
		return false
	end
	achou_algo = false
	arqs_a_mover.each do |fname|
		achou_algo = true
		write_rsi_log :debug, "Movendo arquivo #{fname} para #{zs_aux_network_dir}"
		FileUtils.mv fname, zs_aux_network_dir
		write_rsi_log :debug, "Movido  arquivo #{fname} para #{zs_aux_network_dir}"
	end
	return true
end

def zs_list_of_features_needing_state_change(state)
	return profile_block lambda {
	if not ([:running, :done].include? state)
		falhar "zs_list_of_features_needing_state_change, invalid parameter state=#{state}"  
	end
	list = nil
	done = lista_de_features_finalizadas_ausentes_da_fila("#{$zs_cfg[:automdir]}/features/auto").
	map{|feature|
		feature.
		gsub('.e.f.feature','') ##.
		###gsub('.i.f.feature','') #2018Abr02 - lida também comn features interrompidas, que agora sao também detectadas logo no fim de run_parallel.rb (exceto, claro, em aborção desastrosa do próprio run_parallel.rb) ############### HMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM, DESISTI de pegar as features interrompidas, pois rotina cleanup_de_features_interrompidas, até 2018br02, nao movia arquivo XLS de massa, nem é capaz de setar coluna FAILED nem nada,... pode gerar efeito colateral e necessidade de grande refactoring de zs_proc.rb (APESAR DE SEr PROMISSORA A POSSIBILIDADE, A IMPLEMENTAÇÂO IMEDIATA FOI DESCARTADA EM 2018Abr02)!!!
	}
	if state == :done
		list = done
	elsif state == :running
		running_and_done = lista_de_features_fora_da_fila("#{$zs_cfg[:automdir]}/features/auto").map{|feature|feature.gsub('.feature','')}
		list = running_and_done - done
	end
	write_rsi_log :debug, "zs_list_of_features_needing_state_change, state=#{state}, retornando list=#{list} "
	return list
	}
end


def zs_network_dir
	return $zs_cfg[:dirs_rede][0][:full_path]
end

def zs_aux_network_dir
	"#{zs_network_dir}/1"
end
def zs_genesis_network_dir
	dirpath = File.dirname zs_network_dir
	thedir = File.basename zs_network_dir
	"#{dirpath}/g#{thedir[1..-1]}"
end
def zs_set_network_dir(path)
	return $zs_cfg[:dirs_rede][0][:full_path] = path
end
def zs_local_temp_dir
	retval = "#{get_automdir}/tmp/zs"
	mkdir_noexist retval
	return retval
end
def zs_get_runlock_filepath
	if true
		#ok
	else
		falhar "zs_get_runlock_filepath DEPRECATED"
	end
	return "#{$zs_cfg[:automdir]}/ZSPROC_LOCK_AUTOM.LC2" #NAO USE EXTENSAO .LCK! OU DELETERÀ NA HORA ERRADA!
end

def zs_save_chosen_count(chosen = nil) 
	#2018Ago15 - adicionado parametro chosen, para poder debugar código sem ler da rede os arquivos chosen. Como alternativa de debug, posso chamar zs_set_main_proc_data(h) diretamente!
	if chosen == nil
		chosen = zs_get_runone_onlychosen_stts
	end
	chosen_count = chosen.length
	#executa_exclusivo {
	h = zs_get_main_proc_data
	h['CHOSEN_COUNT']="#{chosen_count}"
	h['CHOSEN_TIME_SECONDS']=Time.now.to_f.to_s
	
	if h['START_CHOSING_TIME_SECONDS'] == nil
		h['START_CHOSING_TIME_SECONDS'] = h['CHOSEN_TIME_SECONDS']
	end

	if chosen.length > 0
		h['FIRST_CHOSEN_SI']=zs_field(chosen[0],:si).to_s.to_i.to_s #to_s=string STRZERO '009', to_i=9, to_s='9'
		h['FIRST_CHOSEN_FULLNICE']=get_nice(zs_field(chosen[0],:feature)).to_s #string #2018Ago15 - salva o nice do 1o CHOSEN, pra que zs_get_cmds_to_process, via método chamado zs_extra_filter_cmds_to_process, nao pegue feature com prioridade MENOS PRIORIDADE (ainda devo permitir mistura, mas apenas se , subitamente, aparecer prioridade mais alta depois de ter escolhido prioridade baixa)!!! Ex: refluxos e reprocessamentos.
	end

	zs_set_main_proc_data h
end

def zs_save_properties(prop_file, h)
	mkdir_noexist zs_local_temp_dir
	tmp_file = "#{zs_local_temp_dir}/#{zs_new_global_id}.properties"
	save_java_properties tmp_file, h
	total_secs = 1.0
	sleep_secs = 0.2
	nof_tries = (total_secs / sleep_secs).to_i
	
	nof_tries.times do |n|
		begin
			FileUtils.mv tmp_file, prop_file
			break #success
		rescue Errno::EACCES => e
			sleep sleep_secs
		end
	end
	return
end

def zs_load_properties(prop_file)
	h = Hash.new
	begin
		h = load_java_properties(prop_file)
	rescue Errno::ENOENT
		#mais rigoroso que testar File.exist?, pois no instante seguinte a checar Fule.exist?, o arquivo pode ter sido removido
	end
	return h
end

def zs_filename_for_main_proc_data
	return "#{get_automdir}/main_data.properties" # CUI
end

def zs_get_main_proc_data
	return zs_load_properties(zs_filename_for_main_proc_data)
end

def zs_set_main_proc_data(h)
	zs_save_properties(zs_filename_for_main_proc_data, h) 
end


def zs_stt_chosen_count
	return profile_block lambda {
		return  zs_get_runone_onlychosen_stts.length
	}
end

def zs_get_runone_onlychosen_stts
	param = {:act => :chosen} #2018Mar31 - APENAS USADA para obnlychosen, OTIMIZANDO!

	stts_without_further_state = nil
	profile_block lambda {

# RETORNA: apenas os arquivos que estejam no estado desejado, e para cujo sevenz nao haja arquivos em estado mais adiantado

#
#
# AINDA incapaz de distinguir entre diferentes "guids", ou seja, diferentes comandos
# cmd_runme enviados pelo console
#



#
# POTENCIALM<ENTE lento, mas nao testei degradacao com, por exemplo, 400 sevenzs,
# cada um em 3 ou 4 estados (400 arquivos). Nem mesmo pra 50 sevenzs. POTENCIAL GARGALO. 
#
	state = nil
	#pseudopid = nil  #2018Mar01 - pseudopid deprecated...
	if param.is_a? Hash
		state = param[:act]
		#pseudopid = param[:pid].to_sym if param[:pid] #2018Mar01 - pseudopid deprecated...
		maq = (param[:maq] || $zs_cfg[:maq]).to_sym
	else
		state = param
		#pseudopid = nil #2018Mar01 - pseudopid deprecated...
		maq=$zs_cfg[:maq]
	end

	
	act_a_pegar=[:chosen, :waiting] #[:chosen, :waiting]
	extensao = 'stt' #'stt'
	filemasks = act_a_pegar.map{|act|"#{zs_network_dir}/*act=#{act}*_maq=#{maq}*.#{extensao}"} # 2018Mar01 - LOCAL BLUES! #extensao pode ser 7z, pra DONE atômico!


	base_stts_of_this_maq=[]
	filemasks.each do |filemask|
		profile_block lambda {
		write_rsi_log "zs_get_runone_onlychosen_stts, adicionando a base_stts_of_this_maq arquivos de mascara #{filemask}"
		base_stts_of_this_maq = base_stts_of_this_maq + Dir[filemask].map{|e| File.basename e}
		}
	end
	write_rsi_log "zs_get_runone_onlychosen_stts, base_stts_of_this_maq.length=#{base_stts_of_this_maq.length}"

	all_stts_of_this_maq = base_stts_of_this_maq

	stts_once_in_desired_state = profile_block lambda {
	all_stts_of_this_maq.select { |st|
		zs_field(st, :act) == state
	}
	}
	#arquivos do state (act=state), pode referir-se a sevenzs que também sejam encontrados em estados postetiores de ZS_STATES

	sevenzs_once_in_desired_state=profile_block lambda {
	stts_once_in_desired_state.map{|st|
		zs_field(st,:id)
	}.uniq
	}
	#lista de sevenzs que estejam no state desejado OU mais avançado


	desired_state_index = ZS_STATES.find_index(state)
	sevenzs_without_further_state = profile_block lambda {
	sevenzs_once_in_desired_state.select {|id|
		not all_stts_of_this_maq.any? {|st|
			in_further_state = false
			st_state = zs_field(st,:act)
			st_state_index = ZS_STATES.find_index(st_state)
			#se arquivo estiver em posicao POSTETIOR na lista de state, nao serve
			if (zs_field(st,:id) == id) and (st_state_index > desired_state_index)
				in_further_state = true
			end

			in_further_state #retorna se 
		} 
		# "not" in_further_state - exclui arquivos em estado posterior/mais avançado 
		
		#    vasculhei todos arquios de state, checando se um sevenz que está/esteve naquele
		#  state porventura nao está em estado mais adiantado
	}
	}
	#sevenzs OK, para os quais nao foram encontrados aquivos em estado POSTETIOR (ZS_STATES) 

	stts_without_further_state = profile_block lambda {
	stts_once_in_desired_state.select {|st|
		sevenzs_without_further_state.include?(zs_field(st, :id))
	}
	}
	# apenas os arquivos que estejam no estado desejado, e para cujo sevenz nao haja arquivos em estado mais adiantado

	}
	return stts_without_further_state

#	}
end



def zs_processa_cmds
	return profile_block lambda {
	
	10.times {write_rsi_log "2018Abr09 - ja melhorei um pouco, mas zs_procesa_cmds - zs_get_cmds_to_process traz carga heterogenea, misturando ADMIN com RUNONE, sendo que ficam poucos RUNONE lá dentro, exigindo nova chamada à OFENSORA DE LENTA zs_get_cmds_to_process pra pegar qt_features. ARRUME ISSO! AUMENTE QUANTIDADE DE runone LÀ DENTRO, SEM ZUAR TUDO! VIRE-SE!"}
	desta = zs_get_cmds_to_process
	#write_rsi_log :debug,  "zs_processa_cmds: P03"
	
	desta.each{|c|
		#write_rsi_log :debug,  "zs_processa_cmds: P04"
		if zs_processa_um_cmd(c) #2018Abr09 - SPEEDUP - vai retornar FALSE apenas quando deve parar loop!!!
			break
		end
		#write_rsi_log :debug,  "zs_processa_cmds: P06"
	}
	return
	}
end

def zs_timestamp_str(t) #param: ruby Time
	return timestamp_str(t)
end
def zs_time_from_str(str, adj_tz=" -2")
	return time_from_str(str,adj_tz)
end

def zs_create_new_file(fname, content = nil)
	return create_new_file(fname,content)
end

def zs_ftz_by(fld, buscar)
	raise "zs_ftz_by, parametro 'fld' tem classe #{fld.class} invalida, nos Symbol, com valor=#{fld}" if fld.class != Symbol

	if buscar.class != Symbol
		if buscar.class == String
			buscar = buscar.to_sym
		else
			raise "zs_ftz_by, parametro 'buscar' tem classe #{buscar.class} invalida com valor=#{buscar}"
		end
	end

	$zs_ftz_list_for_search = zs_ftz_list if not defined? $zs_ftz_list_for_search
	e = $zs_ftz_list_for_search.select{|ftz|ftz[fld]==buscar}.first
	if (not e) 
		$zs_ftz_list_for_search = zs_ftz_list
		e = $zs_ftz_list_for_search.select{|ftz|ftz[fld]==buscar}.first 
	end

	return e
end

def zs_ftz_by_id(id)
	return zs_ftz_by(:id, id)
end
def zs_ftz_by_feature(feature)
	return zs_ftz_by(:feature, feature)
end

def zs_processa_um_cmd(cmd)
	return profile_block lambda {
	write_rsi_log :debug,  "zs_processa_um_cmd, P00, cmd=#{cmd}"
	type = zs_field(cmd, :type)

	id = zs_field(cmd, :id)
	ack_basename = "ack_type=#{type}_id=#{id}" #ACK super simples! Nao diz nada sobre a que se refere!
	#Buenas, vamos escrever também stt, que diz a que o ack se refere
	ack_name = "#{zs_network_dir}/#{ack_basename}"
	if [:runme, :source].include? type 
		# TODO - será que devo fazer outro tipo de checagem? E o SOURCE, STOP p/ ALL? E qando for sei-la-o-que pra ANY?
		#
		# CÒDIGO AINDA FRÀGIL! Deveria checar se destinatario é ALL/ANY,
		# em vez de agir assim, fazendo ACK POR MAQUINA, pelo yipo(type_) 
		# do comando!
		#

		ack_name = "#{ack_name}_maq=#{$zs_cfg[:maq]}"
	end
	ack_fullname="#{ack_name}.ack"

	if File.exist? ack_fullname 
		write_rsi_log :debug,  "zs_processa_um_cmd, P01, cmd=#{cmd}"
		return false # SPEEDUP: CHECAGEM ADIANTADA de .ACK !! NEM DEVERIA precisar disso aqui... acho que o outro fix SPEEDUP em zs_get_acks_desta_maq e zs_get_all_acks já dariam conta... anyway, protegi também aqui!
	end

	if type == :runone
		if not $zs_run_automation_pid
			write_rsi_log :debug,  "zs_processa_um_cmd, P02, cmd=#{cmd}"
			return false # :runone antes de :runme, ignora, vai pegar depois
		end

		if (File.exist? zs_get_runlock_filepath)
			write_rsi_log :debug,  "zs_processa_um_cmd, P03.0, cmd=#{cmd}"
			return false
		end

		main_proc_data = zs_get_main_proc_data

		if main_proc_data['CHOSEN_COUNT'].to_i >= $zs_cfg[:qt_features] #2018Abr22, crrigido, de > para >=
			write_rsi_log :debug,  "zs_processa_um_cmd, QT_FEATURES ja atingido antes em CHOSEN_COUNT, retornando sem processar, P03, cmd=#{cmd}"
			return false
		end

		#2018Abr09 - REVAMPING para velocidade, pegando SI (step inicial) de PROPERTIES... e... ignorando restricoes anteriores de nice, que já são resolvidas por melhor SORTING que já existe há muitas semanas!!
		first_si = main_proc_data['FIRST_CHOSEN_SI'] 
		if first_si
			ftz = zs_ftz_by_id(zs_id_field(cmd))
			
			if not ftz
				#2018Set30, ftz_ aqui detectei e tratei fragilidade, por manutenção de feature durante vôo
				write_rsi_log :debug,  "zs_processa_um_cmd, runone, ftz nao encontrado para id=#{id}, provavalmente por manutenção de feature durante vôo"
				return false
			end

			cmd_si   = ftz[:si]
			write_rsi_log :debug,  "zs_processa_um_cmd, runone, si de FIRST_CJHOSEN_SI de properties e batendo com valor de cmd(via ftz). first_si=#{first_si}, cmd_si=#{cmd_si}"
			
			if first_si.to_s.to_i != cmd_si.to_s.to_i
				write_rsi_log :debug,  "zs_processa_um_cmd, runone, i de cmd != de first_chosen, first_si=#{first_si}, cmd_si=#{cmd_si}"
				return false
			end
		end

	end

	corecmd = cmd.split('cmd_')[1].split("_ts")[0]

	tstamp = zs_timestamp_str(Time.now)

	begin
		zs_create_new_file(ack_fullname)
		#NAO posso correr risco de reprocessar mesmo CMD. Então, crio dum jeito que dá exception se já existir, MESMO já tendo checado acima! Pois pode ser que outra máquina crie o mesmo arquivo...
	rescue SystemCallError => e
		write_rsi_log :debug,  "zs_processa_um_cmd, P04, cmd=#{cmd}"
		return false # EITA NÒIS, outra máquina pegou pra processar antes?
	end
	
	aux_fullname = "#{zs_network_dir}/aux_#{corecmd}_gottenby=#{$zs_cfg[:maq]}_tsgotten=#{tstamp}.aux" #apenas pra fins de monitoração
	zs_create_new_file aux_fullname

	cmdtype = zs_field(cmd,:type)
	
	write_rsi_log :debug,  "zs_processa_um_cmd, P05, cmd=#{cmd}"
	if cmdtype == :runme
		write_rsi_log :debug,  "zs_processa_um_cmd, P05.1, cmd=#{cmd}"
		zs_exec_runme cmd
		return true 
	elsif cmdtype == :runone
		write_rsi_log :debug,  "zs_processa_um_cmd, P05.2, cmd=#{cmd}"
		zs_exec_runone cmd
		return false #2018Abr09 - GRANDE ACELERACAO/SPEEDUP? Agora, retornar FALSE significa "processe o proximo!", true="interrompa" 
	elsif cmdtype == :stop
		write_rsi_log :debug,  "cmdtype #{cmdtype}" 
		zs_exec_stop cmd #2018Abr16 - comando simples e essencial, que fazia falta já faz tempo
		return true
	elsif cmdtype == :config
		#2018Abr20 - NEW
		zs_exec_config cmd
		return true
	elsif cmdtype == :restart
		#2018Abr20 - NEW
		zs_exec_restart cmd
		return true
	elsif cmdtype == :source
		write_rsi_log :debug,  "cmdtype #{cmdtype}" 
		zs_exec_source cmd
		return true
	else
		write_rsi_log :debug,  "cmd inválido, cmdtype #{cmdtype}" 
		return true
	end

	write_rsi_log :debug,  "zs_processa_um_cmd, P06, cmd=#{cmd}"
	return true #legal, processei
	}
end


def zs_exec_config(cmd)
	write_rsi_log :debug, "zs_exec_config(cmd=#{cmd}"
	cmd_network_filepath="#{zs_network_dir}/#{cmd}"

	local_cmd_dir = "#{get_automdir}/tmp/cfg_cmd"
	mkdir_noexist local_cmd_dir

	local_cmd_file = "#{local_cmd_dir}/cfg_#{zs_new_global_id}.rb"

	FileUtils.cp cmd_network_filepath, local_cmd_file

	load local_cmd_file
	write_rsi_log "zs_exec_config, $zs_cfg=#{$zs_cfg}"

	FileUtils.cp local_cmd_file, 'zs/dummy_cfg.rb'

	return
end

def zs_exec_stop(cmd)
	write_rsi_log :debug, "zs_exec_stop(cmd=#{cmd}"
	cmd_network_filepath="#{zs_network_dir}/#{cmd}"

	write_rsi_log :debug, "zs_exec_stop(cmd_network_filepath=#{cmd_network_filepath}, vai matar tudo e parar de vez processamento de main_proc e main_automation, entre outros"

	kill_and_watch ['zs_proc.rb realtime_report', 'zs_proc.rb consolidador', 'zs_proc.rb monitor'] #2018Set01 - adicionados realtime_report,consolidador,monitor

	begin
		Process.kill 9, $zs_run_automation_pid if $zs_run_automation_pid
	rescue Errno::ESRCH => e
		write_rsi_log :error, "zs_exec_stop, ignorando excecao #{e} ao tentar kill de $zs_run_automation_pid=#{$zs_run_automation_pid}"
	end

	begin
		FileUtils.rm zs_get_runlock_filepath
	rescue Errno::ENOENT => e
		write_rsi_log :debug, "zs_exec_stop, - excecao #{e} ao remover #{zs_get_runlock_filepath}, ignorando, pois pode ter sido removido por zs_main_automation() !"
	end

	zs_suicide
end

def zs_killandwatch(signatures, max_tempo = 360) #TEMPO ALTISSIMO pra matar RUN_PARALLEL! 180 chegou a timeoutar NA MINHA VM! ODD!
	return profile_block lambda {
		return kill_and_watch(signatures, max_tempo)
	}

end
def zs_killandwatch_run_parallel
	return profile_block lambda {
	retval = nil
	zs_write_terminate_file_for_run_parallel #2018Abr23 - acelerando mortes de run_paralel.rb - morte quase imediata por presença de TERMINATE.LCK 


	retval =  zs_killandwatch(zs_run_parallel_process_signatures)
	return retval
	}
end

def zs_exec_source(cmd)
	write_rsi_log :debug, "zs_exec_source, cmd=#{cmd}, P00"
	zs_restart_automation(true)
	write_rsi_log :debug, "zs_exec_source, cmd=#{cmd}, P01"
end


def zs_exec_restart(cmd)
	write_rsi_log :debug, "zs_exec_restart, cmd=#{cmd}, P00"
	zs_restart_automation(false)
	write_rsi_log :debug, "zs_exec_restart, cmd=#{cmd}, P01"
end


def zs_restart_automation(from_source_cmd)
	write_rsi_log :debug, "zs_restart_automation, P00"
#	kill_and_watch ['zs_proc.rb realtime_report', 'zs_proc.rb consolidador', 'zs_proc.rb monitor'] #2018Set01 - adicionados realtime_report,consolidador,monitor
	begin
		Process.kill 9, $zs_run_automation_pid if $zs_run_automation_pid
	rescue Errno::ESRCH => e
		write_rsi_log :error, "zs_restart_automation, ignorando excecao #{e} ao tentar kill de $zs_run_automation_pid=#{$zs_run_automation_pid}"
	end

	write_rsi_log :debug, "zs_restart_automation, MATOU (if any) $zs_run_automation_íd=#{$zs_run_automation_píd}. Matando agora proceos de run_parallel e depois vai rebootar automationvia zs_exec_runme"

	zs_killandwatch_run_parallel

	rebuild_source_dir = false
	if zs_must_read_process_source
		rebuild_source_dir = true 
		#se foi requerida 'ead' via 'zs_proc.rb proc read', remonta dir de fontes do processo em todo restart
	elsif from_source_cmd and not zs_mustnot_read_process_source
			#se nao foi requerida 'noread' via 'zs_proc.rb proc noread', remonta dir de fontes do processo quando fizer qualquer restart
		rebuild_source_dir = true 
	end
	if rebuild_source_dir 
		zs_create_processsourcedir_from_cmd(zs_get_last_acked_source_cmd)
	end

	begin
		FileUtils.rm zs_get_runlock_filepath
	rescue Errno::ENOENT => e
		write_rsi_log :debug, "zs_restart_automation, - excecao #{e} ao remover #{zs_get_runlock_filepath}, ignorando, pois pode ter sido removido por zs_main_automation() !"
	end
	
	if zs_stt_runme_running?
		#2018Set27, relendo configurações
		write_rsi_log :debug, "zs_restart_automation, relendo configurações"
		zs_read_cfgs

		write_rsi_log :debug, "zs_restart_automation, RESTART ME UP,vai chamar rotinas como em REBOOT"
		zs_exec_runme (nil) #2018Fev22 - é como um reboot, fazendo até zs_cleanup_previous_run antes de SPAWN de zs_proc.rb para zs_main_automation. RECOMEÇA CHOSEN DO ZERO !
		write_rsi_log :debug, "zs_restart_automation, RESTART ME UP, CHAMNOU rotinas como em REBOOT"
	end

	write_rsi_log :debug, "zs_restart_automation, CONCLUÍDA"
end

def	zs_create_automationsourcedir_from_cmd(cmd)
	profile_block lambda {
	basename = File.basename(cmd)
	cmd_network_filepath="#{zs_network_dir}/#{basename}"
	local_cmd_sevenz="#{zs_local_temp_dir}/#{basename}"
	write_rsi_log :debug, "zs_create_automationsourcedir_from_cmd(cmd_network_filepath=#{cmd_network_filepath}, copiando #{cmd_network_filepath} para #{local_cmd_sevenz}"
	FileUtils.cp cmd_network_filepath, local_cmd_sevenz
	write_rsi_log :debug, "zs_create_automationsourcedir_from_cmd(cmd_network_filepath=#{cmd_network_filepath}, COPIADO #{cmd_network_filepath} para #{local_cmd_sevenz}"

	srcdir = $zs_cfg[:automdir]
	write_rsi_log :debug, "zs_create_automationsourcedir_from_cmd(cmd=#{cmd}, apagando dir de fontes #{srcdir}"
	mkdir_noexist srcdir
	delete_all_in_dir srcdir
	write_rsi_log :debug, "zs_create_automationsourcedir_from_cmd(cmd=#{cmd}, APAGADO dir de fontes #{srcdir}"

	prevdir = Dir.pwd 
	Dir.chdir srcdir
	cmd_core="7za x #{local_cmd_sevenz}" #2018Abr21 - 7za isolado, sem push prévio, assim, posso nao precisar de PT que tem problemas em maquina sihame PTSIHA. Será que erro era por MALFORMAT de param pra pushd?  #2018Mar19 earlyAM - criando tfc_aux, tfc_origem e tfc_destino
	cmd_core = cmd_core.gsub('/','\\')
	write_rsi_log :debug, "zs_create_automationsourcedir_from_cmd(cmd=#{cmd}, des-archivando conteudo para dir de fontes #{srcdir}, cmd_core=#{cmd_core}"
	system cmd_core
	Dir.chdir prevdir

	write_rsi_log :debug, "zs_create_automationsourcedir_from_cmd(cmd=#{cmd}, DES-archivado conteudo para dir de fontes #{srcdir}, cmd_core=#{cmd_core}"
	
	dirlisting = Dir["#{srcdir}/*"]
	write_rsi_log :debug, "zs_create_automationsourcedir_from_cmd(cmd=#{cmd}, PRONTO, listagem de diretorio #{srcdir}=#{dirlisting}"
	}
	return
end

def zs_backup_processsourcedir
	base_source_dir = $zs_cfg[:sourcedir]
	source_sevenz_dir = "."
	source_sevenz_path = "#{source_sevenz_dir}/bk_source_#{zs_new_global_id}_ts=#{zs_ts_now}.7z"

	cmd_core = "pushd #{base_source_dir}& 7za a #{source_sevenz_path} #{zs_get_source_exts_and_dirs_for_archive(false)} & popd" ##cmd_core = cmd_core.gsub('/','\\')
	write_rsi_log :debug, "zs_backup_processsourcedir, cmd_core=#{cmd_core}"
	system cmd_core
	if not File.exist? source_sevenz_path
		falhar "zs_backup_processsourcedir, arquivo backup #{source_sevenz_path} nao encontrado!"
	end

	write_rsi_log :debug, "zs_backup_processsourcedir, criado backup de fontes #{source_sevenz_path}"
end

def	zs_create_processsourcedir_from_cmd(cmd)
#2018Set27 - IMPORTANT CHANGE - substitui também, diretório do processo colaborativo, de onde é executado zs_proc.rb. 
#
# OBJETIVO: queremos SEMPRE substituir os fontes locais pelos da rede. Edicoes locais em, por exemplo, zs_proc.rb serão salvas em BACKUP , e substituidos. Caso percebamos que zs_proc.rb local era melhor que o da rede, podemos nos basear no BACKUP local para recuperá-lo. 
#
#
# Isto vai nos permitir trabalhar , sem  maiores preocupacoes, em qualquer uma das VMs executoras para modificar fontes e republicá-los via 'zs_proc.rb cmd fontes', pois todas VMs tenderão a ter a última versão dos fontes no diretorio de fontes do processo (c:\arBlaBla) !!!!!!!!!!!!!!!!! Adicionalmente, salvamos em c:\arBlaBla o 7z de source que trouxemos da rede, para facilitar manipulacao e comparacao eventual com backup local.
#
#
#


	profile_block lambda {
	zs_backup_processsourcedir

	basename = File.basename(cmd)
	cmd_network_filepath="#{zs_network_dir}/#{basename}"
	local_cmd_sevenz="./#{basename}"
	write_rsi_log :debug, "zs_create_processsourcedir_from_cmd(cmd_network_filepath=#{cmd_network_filepath}, copiando #{cmd_network_filepath} para #{local_cmd_sevenz}"
	FileUtils.cp cmd_network_filepath, local_cmd_sevenz
	write_rsi_log :debug, "zs_create_processsourcedir_from_cmd(cmd_network_filepath=#{cmd_network_filepath}, COPIADO #{cmd_network_filepath} para #{local_cmd_sevenz}"

	write_rsi_log :debug, "zs_create_processsourcedir_from_cmd(cmd=#{cmd}, vai substituir fontes de ZS_PROC (a.k.a '.', diretorio corrente)"

	cmd_core="7za x -y #{local_cmd_sevenz}" #2018Abr21 - 7za isolado, sem push prévio, assim, posso nao precisar de PT que tem problemas em maquina sihame PTSIHA. Será que erro era por MALFORMAT de param pra pushd?  #2018Mar19 earlyAM - criando tfc_aux, tfc_origem e tfc_destino
	cmd_core = cmd_core.gsub('/','\\')
	write_rsi_log :debug, "zs_create_processsourcedir_from_cmd(cmd=#{cmd}, des-archivando conteudo para dir ., cmd_core=#{cmd_core}"
	system cmd_core

	write_rsi_log :debug, "zs_create_processsourcedir_from_cmd(cmd=#{cmd}, DES-archivado conteudo para dir ., cmd_core=#{cmd_core}"
	
	write_rsi_log :debug, "zs_create_processsourcedir_from_cmd(cmd=#{cmd}, reacarregando fontes/métodos"

	ARGV.clear #IMPORTANTE, ou 'load' pode chamar códogo executor dependente de ARGV
	load './reload_sources.rb'
	}
	return
end

def zs_get_prioridade_de_cmd(cmd)
	if cmd.class == Symbol
		cmdtype = cmd
	else
		cmdtype = zs_type_field(cmd)
	end

	retval = 99999999

	case cmdtype
	when :runone
		retval = 9900
	when :runme
		retval = 3200
	when :source, :restart
		retval = 3100	
	when :config #config antes de source, pode modificar processamento de source
		retval = 3000
	when :stop
		retval = 1000
	when :pause
		retval = 1100
	end
	#REDUCELOGS_SPEEDUP#write_rsi_log :debug, "zs_get_prioridade, cmd=#{cmd}, cmdtype=#{cmdtype}, cmdtype.class=#{cmdtype.class},retval=#{retval}"
	return retval
end

def zs_get_all_cmds
	return profile_block lambda {
	cmds = []
	#DUMB ASS 2018Mar10#$zs_cfg[:dirs_rede].each { |d|
	#DUMB ASS 2018Mar10#	p = d[:full_path
	#DUMB ASS 2018Mar10#	#write_rsi_log :debug,  "p=#{p}"
		#DUMB ASS 2018Mar10# cmds = cmds | Dir["#{p}/cmd*_id*_ts*.*"].map{ |c| File.basename(c) }
		cmds = Dir["#{zs_network_dir}/cmd*_id*_ts*.*"].map{ |c| File.basename(c) }
	#DUMB ASS 2018Mar10#}

#
#
# 2018Mar10 - DUMB ASS! Sorts sequenciais podem desordenar o array, pois RUBY nao garan-
#te preservacao de ordem quando retornamos 0!
#
# REVAMPING para ter varios lambdas avaliados em um únicchamada a Array.sort !!!!!
#
#

	sort_lambdas = []

	sort_lambdas << lambda {|c1,c2| 
		#write_rsi_log :debug,  "c1=#{c1}, c2=#{c2}"
		
		# Priorizando :runone contra :runme
		cmp = 0

		c1_type = zs_field(c1, :type); c2_type=zs_field(c2,:type)
		if c1_type == c2_type
			#nada
		else
			c1_pri = zs_get_prioridade_de_cmd(c1_type)
			c2_pri = zs_get_prioridade_de_cmd(c2_type)
			cmp = (c1_pri <=> c2_pri)
		end
		cmp

	} #RUNME antes de RUNONE. E... TIMESTAMP SEQUENCIAL 

	sort_lambdas << lambda {|c1,c2|
		#2010Fev26-sort de runone (FEATURE!), por prioridade. Mais alta executa primeiro
		cmp = 0
		c1_type = zs_field(c1, :type); c2_type = zs_field(c2,:type)
		if c1_type == :runone and c2_type == :runone
			n1  = zs_field(c1,:nice); n2  = zs_field(c2,:nice)
			cmp = (n1.to_s||0).to_i/1000 <=> (n2.to_s||0).to_i/1000 #2018Abr6 - FIXED BAD BUG, comparava "/1000" com "/100" !!!!!!!!!!

 			#2018Mar21 - 01:38 - sort pela parte "/1000"="priorizacao do cliente", ignorando solenemente x100 e x200 que, historicamente (legado) coloco/coloquei para "reproc/phase change"!! E... nao leva em consideracao "si" (step inicial), permitindo que TFCs de 1os webdesk+pasta que foram bem concluam fluxo da automacao antes de reprocessamentos de webdesk e pasta. BOA, isso acelera liberação de evidencias "tal e tal feature já foram concluídas"... !!! BOM!  ################ 2018Jun20 - nota: acredito que isto nao interfere na NOVA filtragem de "nao misturar nice-base: nao faz nada de nice mais alto enquanto nice maix baixo nao tiver processado 100%... que coloquei em zs_extra_filter_cmds_to_process"
		end
		cmp
	}


	sort_lambdas << lambda {|c1,c2|
		t1=zs_field(c1,:ts); t2=zs_field(c2,:ts)
		cmp = t1 <=> t2
		cmp #ordem de chegada, mais antigo pra mais novo, TIMESTAMP SEQUENCIAL
	}

	cmds.sort!{|c1,c2|
		cmp = 0
		sort_lambdas.length.times {| lambda_num |
			sort_lambda = sort_lambdas[lambda_num]
			cmp = sort_lambda.call(c1,c2)
			if cmp != 0
				#REDUCELOGS_SPEEDUP#write_rsi_log :debug, "sort multi-lambda, lambda_num=#{lambda_num}, retornando #{cmp} para c1=#{c1} e c2=#{c2}"
				break
			end
		}
		cmp
	}

	#REDUCELOGS_SPEEDUP#write_rsi_log "zs_get_all_cmds(), retornando, cmds=#{cmds}"
	return cmds
	}
end

def zs_get_acks_desta_maq
	return profile_block lambda {
	#
	# SPEEDUP - NEM CHEGAVA AQUI, pois zs_get_all_acks retornava sempre EMPTY ARRAY! 
	# 
	#

	acks = zs_get_all_acks
	acks.select! {|a| 
		maq=zs_field(a,:maq)
		ok = ((not maq) or (maq==$zs_cfg[:maq]))
		if false #ONDE EU TAVA COM A CABEÇA! NADA A VER, ESTE CÒDIGO AQUI !!
			if ok
				if (zs_field(cmd,:type) == :runme) and (not $zs_run_automation_pid)
					# UGLY DESIGN HACK: ignora cmd_type=runone se nao tá processando type=runme!!
					ok = false
				end
			end
		end
		ok
	}



	return acks
	}
end

def zs_get_all_acks
	return profile_block lambda {
	#
	# SPEEDUP, tava zuado, retornava sempre EMPTY ARRAY!
	#

	acks = Dir["#{zs_network_dir}/*.ack"].map{ |a| File.basename(a) }

	return acks
	}
end

def zs_is_cmd_desta_maq?(cmd)
	maq_cmd =zs_get_cmd_maq(cmd) #comandos têm q ser p ANY/ ALL ou MAQ
#REDUCELOGS_SPEEDUP#
	if	(maq_cmd != $zs_cfg[:maq] ) and (not [:all, :any].include? maq_cmd )
		#write_rsi_log :debug, "zs_is_cmd_desta_maq?, cmd=#{cmd}, $zs_cfg[:maq]=#{$zs_cfg[:maq]}, maq_cmd=#{maq_cmd}, returning false P00"
		return false
	end


	if (zs_field(cmd, :type)==:runone) 
		ftz = zs_ftz_by_id(zs_id_field(cmd))

		if not ftz
			#2018Out1, zs_ftz_*, detectada e atacada fragilidade por manutenção durante vôo
			write_rsi_log :debug, "zs_is_cmd_desta_maq?(cmd=#{cmd}, ftz eh nil , provavelmente por manutenção durannte vôo"
			return false
		end
		if (not $zs_cfg[:steps_iniciais_habilitados].include? ftz[:si].to_s.to_i)
			#REDUCELOGS_SPEEDUP#write_rsi_log :debug, "zs_is_cmd_desta_maq? retornando false pra cmd=#{cmd} pois $zs_cfg[:steps_iniciais_habilitados]=#{$zs_cfg[:steps_iniciais_habilitados]} e zs_field(cmd,:si).to_s.to_i=#{zs_field(cmd,:si).to_s.to_i}"
			return false
		end
	end
	return true
end

def zs_get_cmd_maq(cmd)
	if not cmd.start_with?('cmd_')
		falhar "parametro invalido: tem q começar com cmd, zs_get_cmd_maq(cmd=#{cmd})"
	end

	maq = zs_field(cmd,:maq)
	if not maq
		#COMANDOS que nao especificamos destino: vai ter :any ou :all como default
		type=zs_field(cmd,:type) 
		if type == :runone
			maq = :any
		elsif type == :runme
			maq = :all
		elsif type == :stop #SEMPRE FORCE IMMEDIATE, AGORA
			maq = :all
		elsif type == :restart #SEMPRE FORCE IMMEDIATE, AGORA
			maq = :all
		elsif type == :source
			maq = :all
		elsif type == :giveup #giveup - PRA GERAL - faz sentido?
			falhar "parametro invalido: type == :giveup, sempre tem q ser pra uma maq. , zs_get_cmd_maq(cmd=#{cmd})"
		else
			falhar "parametro invalido: type == :#{type}, sem maq, nao sei o que fazer , zs_get_cmd_maq(cmd=#{cmd})"
		end
	end

	
	return maq
end

def zs_ack_matches_cmd? (ack, cmd)
 #cmd tem ser previamente filtrado como DESTA MAQ, all/any/maq=CFG
	maq_ack = zs_field(ack, :maq) #ack é de JMA MAQ ou SEM MAQ (lock)
	id_ack = zs_field(ack, :id) 

	maq_cmd =zs_get_cmd_maq(cmd) #comandos têm q ser p ANY/ ALL ou MAQ
	id_cmd = zs_field(cmd, :id) 
	type_cmd = zs_field(cmd, :type)

	#write_rsi_log :debug,  "zs_ack_matches_cmd? (ack=#{ack}, cmd=#{cmd}), maq_ack=#{maq_ack}, id_ack=#{id_ack}, maq_cmd=#{maq_cmd}, id_cmd=#{id_cmd}, type_cmd=#{type_cmd}"

	retval = false

	if not zs_is_cmd_desta_maq?(cmd)
		#write_rsi_log :debug,  "zs_ack_matches_cmd?, P02"
		#falhar "zs_ack_matches_cmd(ack=#{ack,}cmd=#{cmd}) : cmd invalido! esta maq=#{$zs_cfg[:maq]}, maq_cmd=#{maq_cmd}"
	elsif id_ack == id_cmd
		#write_rsi_log :debug,  "zs_ack_matches_cmd?, P03"
		if (not maq_ack) or ([:any, :all].include? maq_ack) # EITA NOIS! maq_ack NUNCA é diferente de INEXISTENTE ou UMA_MAQUINA!!!
			#write_rsi_log :debug,  "zs_ack_matches_cmd?, P04"
			retval = true #ack nao fala de qual maquina, bateu e pronto!!
		elsif maq_ack == maq_cmd
			#write_rsi_log :debug,  "zs_ack_matches_cmd?, P05"
			retval = true # a unica alternativa é ACk "por maquina", se NOT NIL
		elsif  [:any, :all].include? maq_cmd
			#TODO AGORA - ELSIF - nao bem planejado, pode ser errorprone! ESTE MÈTODO INTEIRO ESTÀ DEIXANDO A DESEJAR!
			#write_rsi_log :debug,  "zs_ack_matches_cmd?, P06"
			retval = true
		end
	end

	#write_rsi_log :debug,  "zs_ack_matches_cmd? (ack=#{ack}, cmd=#{cmd}), returning #{retval}"

	return retval
end

def zs_get_cmds_desta_maq() 
	cmds = zs_get_all_cmds
	cmds_desta = cmds.select {|c| zs_is_cmd_desta_maq?(c)}
	#write_rsi_log :debug,  "zs_get_cmds_desta_maq() - cmds_desta=#{cmds_desta}"
	return cmds_desta
end

def zs_deleta_arquivos_cmds_stop_restart(maq=$zs_cfg[:maq])
	types_to_delete=[:stop,:restart]
	types_to_delete.each{|ttd|
		arqs_del =  Dir["#{zs_network_dir}/cmd*type=#{ttd}*_maq=#{maq}*"]	
		arqs_del.each{|fdel|
			zs_remove_with_backup fdel
		} 
	}
	return
end

def zs_exclui_cmds_antigos(cmds)
	#2018Abr23 - exclui source, restart e stop que nao sejam os mais recentes

	#2018Abr23 - exclui cmds stop e restart emitidos há mais que X minutos. :stop e :restart São comandos imediatos em essencia, e devemos ignorar solenemente os "antigos"

#@@@@@@@@@@@@@@@@@@
#2018Abr23 - ENTAO, agora, quero que stop/restart soh tenha max 1 pendente.
#Isto eh, quando pegar 1 stop/restart pra processar, deve marcar todos como ACK! Só que processando apenas um... TEM JEITO?

#ISTO EH, um usuario apressadinho manda 2 stop com invervalos de apenas 1 minutos
#Nessa brincadeira, vai morrer 2 vezes.

#SOLUCAO SIMPLES: mover para auxdir todos comandos stop/restart quando subir a aplicacao!!
#@@@@@@@@@@@@@@@@@@@@@@



	max_ts = {:source => '0', :stop=> '0', :restart => '0'}
		

	ret = cmds
	ret.each do |c|
		f=zs_all_fields(c)
		if [:source, :restart, :stop].include? f[:type] and f[:ts].to_s > max_ts[f[:type]]
			max_ts[f[:type]] = f[:ts].to_s
		end
	end
	write_rsi_log :debug, "zs_exclui_cmds_antigos, max_ts=#{max_ts}"

	ret=ret.select do |c|
		ok = true
		f=zs_all_fields(c)
		if [:source, :restart, :stop].include? f[:type] and f[:ts].to_s != max_ts[f[:type]]
			write_rsi_log :debug, "zs_exclui_cmds_antigos, excluindo #{f[:type]} antigo, f=#{f}"
			ok = false
		elsif [:restart, :stop].include? f[:type] and Time.now - zs_time_from_str(f[:ts].to_s,' -3') > max_segundos_stop_restart
			write_rsi_log :debug, "zs_exclui_cmds_antigos, excluindo #{f[:type]} nao-imediato, f=#{f}, Time.now=#{Time.now}, f[:ts].to_s=#{f[:ts].to_s}, zs_time_from_str(f[:ts].to_s,' -3')=#{zs_time_from_str(f[:ts].to_s,' -3')}"
			ok = false
		end
		ok
	end

	return ret
end

def zs_get_core_cmds_to_process
	#REDUCELOGS_SPEEDUP#write_rsi_log :debug, "zs_get_cmds_to_process,  - cmds_desta=#{cmds_desta}"

	
	cmds_desta_base = zs_get_cmds_desta_maq
	write_rsi_log :debug, "zs_get_core_cmds_to_process, cmds_desta.length após zs_get_cmds_desta_maq=#{cmds_desta_base.length}"
	cmds_desta = zs_exclui_cmds_antigos(cmds_desta_base)
	write_rsi_log :debug, "zs_get_core_cmds_to_process, cmds_desta.length após zs_exclui_cmds_antigos=#{cmds_desta.length}"

	acks_desta = zs_get_acks_desta_maq #GRANDE OFENSOR, causado principalmente pela interna zs_get_all_acks
	write_rsi_log :debug, "zs_get_core_cmds_to_process, acks_desta.length=#{acks_desta.length}"
	#REDUCELOGS_SPEEDUP#write_rsi_log :debug, "zs_get_cmds_to_process,  - ackds_desta=#{acks_desta}"



#REALLY TODO NOW
#	** já fiz "deixar de checar em cada zs_processa_um_cmd , via leitura de zs_stt_onlychosen_stt da vida, se nao misturou prioridades"
#	** TODO NOW TOP - benchmarkear em CONSOLE o loop de zs_ack_matches_cmd. OFENSOR? 

	cmds_to_process = cmds_desta.select{|cmd|	not acks_desta.any? {|ack| zs_ack_matches_cmd?(ack,cmd) }   }

	write_rsi_log :debug, "zs_get_core_cmds_to_process, length do retval cmds_to_process=#{cmds_to_process.length}"

	#REDUCELOGS_SPEEDUP#write_rsi_log :debug, "zs_get_cmds_to_process,  - cmds_to_process=#{cmds_to_process}"
 	return cmds_to_process
end

def zs_get_cmds_to_process
	cmds_to_process = nil
	profile_block lambda {
	cmds_to_process_base = zs_get_core_cmds_to_process
	write_rsi_log :debug, "zs_get_cmds_to_process, length de variavel cmds_to_process_base=#{cmds_to_process_base.length}"
	cmds_to_process = zs_extra_filter_cmds_to_process(cmds_to_process_base)
	write_rsi_log :debug, "zs_get_cmds_to_process, length de retorno cmds_to_process=#{cmds_to_process.length}"
	}


	return cmds_to_process
end

def zs_extra_filter_cmds_to_process(cmds_to_process)
	#2018Ago15, full revamp, para nao pegar nice menos prioritario depois de ter pego mais prioritario. Pode haver ainda MISTURA DE NICEs se pegar um menos inmportante e depois um mais importante (nao vou impedir um mais importante de rodar só pra nao misturar nices!!!!!!)
	
	base_nice_lowest = nil

	first_chosen_fullnice = nil
	base_nice_maindata = nil
	main_proc_data = zs_get_main_proc_data
	s_first_chosen_fullnice = main_proc_data['FIRST_CHOSEN_FULLNICE']
	
	if s_first_chosen_fullnice
		first_chosen_fullnice = s_first_chosen_fullnice.to_s.to_i
		base_nice_maindata = first_chosen_fullnice / 1000
	else
		base_nice_maindata = 999999999*1000 #2018Ago22
	end

	o_1o_runone = cmds_to_process.find {|c|
		tp = zs_type_field(c)
			#write_rsi_log "select pra o_1o_runone, c=#{c}, tp=#{tp}"
		tp == :runone
	}
	
	base_nice_1o_runone = nil
	ftz_1o_runone = nil
	if o_1o_runone
		id = zs_id_field(o_1o_runone)
		ftz_1o_runone = zs_ftz_by_id(id)
		if ftz_1o_runone
			#2018Out2, zs_ftz_*, detectada e atacada fragilidade por manutenção durante vôo
			base_nice_1o_runone = ftz_1o_runone[:nice].to_s.to_i / 1000 
		end
	end
	#2018Out7 - protegendo base_nice_1o_runone de possivel inexistencia de ftz_1o_runone
	base_nice_1o_runone ||= 999999999*1000 #2018Ago22 
	

	base_nice_lowest = [base_nice_maindata, base_nice_1o_runone].min


	f1 = cmds_to_process.select {|cmd|
		type = zs_field(cmd,:type)
		ftz = zs_ftz_by_id(zs_id_field(cmd)) if type == :runone
		ok = true

		if type != :runone
			ok = true
		elsif not ftz
			#2018Out2, zs_ftz_*, detectada e atacada fragilidade por manutenção durante vôo
			#2018Out7 - de 2018Out2 a 2018Out6 existiu erro de nao pegar comandos exceto RUNONE, corrigido
			ok = false
		else
			si = ftz[:si].to_s.to_i

			base_nice = ftz[:nice].to_s.to_i / 1000

			if base_nice > base_nice_lowest #2018Ago15 - naopega nice menos prioritario depois de ter pego um mais prioritario. Mas pode pegar o mais prioritario DEPOIS de er pego um menos prioritario. Porém, se o 1o escolhido (DE FATO/ack/chosen.stt) foi de nice menos prioritario, na conseguimos impedir que algum outro comando de nem tanta prioridade seja escolhido , no curto espaço de tempo de MONTR CHOSEN LIST (tempo = minutos_timeout_esperando_chosenXminutos_timeout_esperando_allchosen ). TUDO BEM! Já é grande avanço!!  
				ok = false
			end
		end
		ok
	}

	qt_runone = 0
	f2 = f1.select {|cmd| 
		#2018Dez13 06:20am - filtro simples SPEEDUP onlychosen blues: pega no maximo $zs_cfg[qt_features] runone!
		type = zs_field(cmd,:type)
		ok = true
		if (type == :runone)
			qt_runone = qt_runone + 1
			if qt_runone > $zs_cfg[:qt_features] ############ CÒDIGO FRÀGIL!
				ok = false  ############ 
			end
		end
		ok
	}

	return f2

end


def zs_parse_cfg(global_and_local)
#created, 2018Set27
	g = global_and_local[:global]
	$zs_cfg = g
	l = global_and_local[:local]
	lm = nil
	if l
		lm = l.find{|c| c[:localmaq].to_s == g[:maq].to_s}
	end
	lm = lm || {}


	$zs_cfg = $zs_cfg.merge(lm)

	return
end

def zs_read_cfgs
	$zs_cfg_ready = false
#created, 2018Set27
	load "#{get_automdir}/zs/cfg.rb"
	source_cfg = zs_get_cfg
	zs_parse_cfg(source_cfg) 
	network_cfg_file = "#{zs_network_dir}/cfg.rb"
	executa_exclusivo(nil, zs_get_lockfile_cfg) do
		if File.exist? network_cfg_file
			load network_cfg_file
			network_cfg = zs_get_cfg
			zs_parse_cfg(network_cfg) 
		end
	end
	$zs_cfg_ready = true
	return
end


def zs_send_cfg(filename=nil)
#created, 2018Set27
	filename = filename || "#{get_automdir}/zs/cfg.rb"
	executa_exclusivo(nil, zs_get_lockfile_cfg) do
		FileUtils.cp filename, "#{zs_network_dir}/cfg.rb"
	end
end

def zs_slow_maqs(minutes_without_done=20, now=Time.now) #"now" parameter=debug tests only
	#parametro: minutes_dine, se nato tiver state DONE nos ultimos minutes_without_done minutos, então a máquina é considerada lenta.
	#
	# Logicamente, inclui as máquinas sem absolutamente nenhum arquivo DONE

	#old_time = zs_time_from_str('2001-01-01 00:00:00')
	last_stt_done_each_maq = zs_last_stt_done_each_maq
	slow_maqs = zs_all_working_maqs.select {|wkm|
		stt = last_stt_done_each_maq.find{|stt| zs_field(stt,:maq) == wkm}
		slow = false
		#write_rsi_log :debug,  "stt pra maq=#{wkm} = #{stt}"
		network_time = nil
		if not stt 
			# neste caso, só considero a maquina lenta se o ultimo (único, por AGORA) ACK de runme da máquina tiver ocorrido há mais que (minutes_without_done+3) minutos, dando um chute embasado de que entre ACK e começo de processamento pode levar uns 3 minutos
			#
			#
			# Talvez eu mande uns giveup pra máquinas que de tao zuadas nem tem "runones" sendo processados, sem crise.
			#

			last_ack = Dir["#{zs_network_dir}/ack_type=runme*maq=#{wkm}*.ack"].
			sort {|ack_1, ack_2| 
			#ffiltra ctime de File.state mais recente
				ctime_1 = zs_time_file_created(ack_1)
				ctime_2 = zs_time_file_created(ack_2)
				ctime_1 <=> ctime_2
			}.first
			
			comparison_time = zs_time_file_created(last_ack)
		else
			comparison_time = zs_time_from_str(zs_field(stt,:ts))
		end

		diff = now - comparison_time
		if diff >= 60*minutes_without_done
			slow = true
		end
		slow
	}

	return slow_maqs
end

def zs_all_working_maqs
	all_working_mqqs = Dir["#{zs_network_dir}/aux*type=runme*"].map {|g|
		zs_field(g, :gottenby) 
	}.uniq 
	#todas máquinas que já fizeram ACK de runme
end

def zs_last_stt_done_each_maq
	return profile_block lambda {
	all_done_stts = Dir["#{zs_network_dir}/stt*type=runone*act=done*"].
	map{|stt| 
		File.basename(stt)
	}.
	select {|stt| 
		zs_field(stt, :act) == :done
	}

	last_stt_done_each_maq = Array.new
	prev_maq = nil
	
	all_done_stts.
	sort{|stt_a, stt_b| 
		ord = zs_field(stt_a,:maq) <=> zs_field(stt_b,:maq)
		if ord == 0
			ord = zs_field(stt_a,:ts) <=> zs_field(stt_b,:ts)
			ord = ord * -1 #DESC
		end
		ord
	}. #SQL ANALOGY: order by MAQ, TS desc
	each {|stt|
		#   para cada stadus DONE em ordem de MAQ e TIMESTAMP desc, popula
		# last_done_each_maq toda vez que mudar a maquina (a.k.a TIMESTAMP MAIS RECENTE!)
		stt_maq = zs_field(stt,:maq)
		if stt_maq != prev_maq
			prev_maq = stt_maq
			last_stt_done_each_maq << stt
		end
	} 

	return last_stt_done_each_maq
	}
end



def zs_time_file_created(fpath)
	retval = nil
	begin
		retval = File.stat(fpath).ctime
	rescue SystemCallError => e
		retval = nil
	end
	return retval
end 

def zs_field(str, field)
	s=File.basename(str).gsub('.','_')
	#write_rsi_log :debug,  "P00 zs_field, s=#{s}, field=#{field}"
	spl=s.split("_#{field}=")[1] #field por ser passado como symbol
	#write_rsi_log :debug,  "P01 zs_field, s=#{s}, field=#{field}, spl=#{spl}"
	return nil if not spl
	sp2 = spl.split('_')[0]
	#write_rsi_log :debug,  "P02 zs_field, s=#{s}, field=#{field}, spl=#{spl}, sp2=#{sp2}"
	
	return sp2.to_sym
end
def zs_all_fields(str)
	s=File.basename(str).gsub('.','_')
	spl=s.split('_')[1..-2]
	return nil if not spl
	fields = Hash.new
	spl.each{|s| pair=s.split('='); k=pair[0].to_sym; v=pair[1]; fields[k]=(v ? v.to_sym: nil)}
	return fields #Array of Hash
end
def zs_nice_field(s)
	return zs_field(s, :nice)
end
def zs_id_field(s)
	return zs_field(s, :id)
end
def zs_type_field(s)
	return zs_field(s, :type)
end
def zs_ts_now
	ts_now
end
def zs_ts_zeros
	return ts_zeros
end
def zs_ts_hivalues
	return ts_hivalues
end

def zs_ts_field(s)
	return zs_field(s, :ts)
end
def zs_maq_field(s)
	return zs_field(s, :maq)
end
def zs_guid_field(s)
	return zs_field(s, :guid)
end
def zs_gottenby_field(s)
	return zs_field(s, :gottenby)
end

def zs_stt_runme_fname(fields)
	act=fields[:act]
	maq=fields[:maq]
	guid='0000'.to_sym; #fields[:guid]
	ts=fields[:ts]

	fname = "stt_type=runme_act=#{act}_maq=#{maq}_guid=0000_ts=#{ts}.stt" 
	#IMPORTANTE! .stt como extensao default aqui, depois eu adultero o nome pra .7Z quando for criar arquivo DONE!
end

def zs_stt_runme_done? #AGORA = nao recebe nem percebe ainda GUID e AUTO 
	
	filemask = "#{zs_network_dir}/stt_type=runme_maq=#{$zs_cfg[:maq]}*.*"
	all_stt_runme = Dir[filemask]
	tem_done = all_stt_runme.any? {|st| st.include? 'act=done'} 
	return tem_done
end

def zs_stt_runme_running? #AGORA = nao recebe nem percebe ainda GUID e AUTO 
	
	filemask = "#{zs_network_dir}/stt*type=runme_*act=*maq=#{$zs_cfg[:maq]}*.*"
	all_stt_runme = Dir[filemask]
	tem_running = all_stt_runme.any? {|st| st.include? 'act=running'} 
	tem_done = all_stt_runme.any? {|st| st.include? 'act=done'} 
	return (tem_running and (not tem_done))

	#
	# AGORA = nao existe metodo que diga se JA "ESTEVE RUNNING, PODENDO ESTAR DONE" 
 	#
end

def zs_stt_createfile_runme_running(cmd) #deve ser chamada apenas se "not zs_stt_runme_running?"
	act= :running
	maq=$zs_cfg[:maq]
	guid='0000'.to_sym; #zs_field(cmd,:guid)
	ts=zs_timestamp_str(Time.new)

	
	filepath = "#{zs_network_dir}/#{zs_stt_runme_fname(act:act, maq:maq, guid:guid, ts:ts)}"
	zs_create_new_file filepath
	return filepath #apenas para DEBUG em console, nao usado em fluxo
end 

def zs_stt_runone_fname(fields)
	id=fields[:id]
	act=fields[:act]
	maq=fields[:maq]
	guid='0000'.to_sym; #fields[:guid]
	ts=fields[:ts]
	
	failed = (fields[:failed] || step_strzero(get_step_maxval_notfailed)).to_sym if act == :done #failed=999,HIVALUES indica sucesso. failed=XX somente útil em act=done. 
	ftz = zs_ftz_by_id(id)
	if not ftz
		#2018Out1, manipulação durante vôo
		write_rsi_log :debug, "zs_stt_runone_fname, retornando nil pois nao encontrou ftz_by_id para id=#{id}, fields=#{fields}"
		return nil
	end

	si  = ftz[:si]
	sf  = ftz[:sf]
	sq  = ftz[:sq]
	te  = ftz[:te]
	gt  = ftz[:gt]
	cpf = fields[:cpf] || ftz[:cpf]

	ls = fields[:ls] if act == :done #2018Mar12, 21:03 - :ls indica que é a última execucao. Atributo exclusivo de arquivos de stt, mais especificamente, do stt*type=runone*act=done*.7z, pois nos status anteriores ainda nao sabemos o resultado de cucumber/FAILED. Exemplo? dir "z:\zs\zs_a\stt*act=done*ls=1*.7z" nos traz todas as features cujo processamento foi de fato encerrado, seja por falha, seja por conclusao ok. 
	feature = ftz[:feature] #2018Mar12, 21:03 - adicionado o núcleo do nome da feature a arquivos STT, permite fácil acompanhamento de execução SEM CONSULTAR FTZ

	ls_fragment    = "_ls=#{          strzero(    ls.to_s.to_i,1)}" if ls
	si_fragment    = "_si=#{     step_strzero(    si.to_s.to_i  )}" if si
	sf_fragment    = "_sf=#{     step_strzero(    sf.to_s.to_i  )}" if sf
	sq_fragment    = "_sq=#{          strzero(    sq.to_s.to_i,2)}" if sq #2018Ago29, :sq aumentado de 2 para 3 posicoes, até 999 processamentos da mesma meature. Deve bastar para as mais extremamente problemáticas execucoes.   
	te_fragment    = "_te=#{          strzero(    te.to_s.to_i,2)}" if te
	gt_fragment    = "_gt=#{          strzero(    gt.to_s.to_i,2)}" if gt  #2018Ago29, :gt aumentado de 2 para 3 posicoes, até 999 processamentos da mesma meature. Deve bastar para as mais extremamente problemáticas execucoes.   
	failed_fragment = "_failed=#{step_strzero(failed.to_s.to_i  )}" if failed
	cpf_fragment    = "_cpf=#{cpf}"                                 if cpf
	cpf_fragment    = "_cpf=#{cpf}"                                 if cpf

	reproc_fragment = "#{ls_fragment}#{sq_fragment}#{cpf_fragment}#{si_fragment}#{sf_fragment}#{te_fragment}#{gt_fragment}#{failed_fragment}" 

	fname = "stt_type=runone_feature=#{feature}_id=#{id}_act=#{act}_maq=#{maq}_guid=0000_ts=#{ts}#{reproc_fragment}.stt" #end #2018Mar01 - pseudopid deprecated...
	return fname
end

def zs_ler_um_excel_de_7z(sevenz_fullpath)
	return ler_um_excel_de_7z(sevenz_fullpath)
end

def zs_modificar_um_excel_de_7z(sevenz_fullpath)
	if ( (not File.exist? sevenz_fullpath) or (not block_given?) ) 
		raise "zs_modificar_um_excel_de_7z, nao existe arquivo #{sevenz_fullpath}, E/OU nenhum bloco de código foi passado para modificar hash do sevenz"
	end


	tmpd = "#{get_automtmpdir}/umexcel#{zs_new_global_id}"
	mkdir_noexist tmpd; delete_all_in_dir tmpd
	pwd = Dir.pwd
	excecao = nil

	h = nil

	begin
		Dir.chdir tmpd
		sevenz_cmdline = "7za x #{sevenz_fullpath}"
		write_rsi_log :debug, "zs_modificar_um_excel_de_7z, vai fazer extrair 7z, Dir.pwd=#{Dir.pwd}, sevenz_cmdline=#{sevenz_cmdline}"
		o = comando_sistema(sevenz_cmdline)
		write_rsi_log :debug, "zs_modificar_um_excel_de_7z, e=fez extracao de 7z, output de sevenz_cmdline=#{sevenz_cmdline}, o=#{o}"

		xlsfile = Dir.glob("**/*.xls").first
		h = ler_xls_com_id(xlsfile) 
		yield h #passa h para o block de código recebido, e o bloco deve receber h e modificá-lo.
		write_rsi_log "zs_modificar_um_excel_de_7z, vai chamar escreve_xls_de_hash(xlsfile=#{xlsfile}, h=#{h})"
		escreve_xls_de_hash(xlsfile,h)
		write_rsi_log "zs_modificar_um_excel_de_7z, chamou escreve_xls_de_hash(xlsfile=#{xlsfile}, h=#{h})"
		sevenz_cmdline = "7za a -mx9 \"#{sevenz_fullpath}\" \"#{xlsfile}\""
		write_rsi_log :debug, "zs_modificar_um_excel_de_7z, vai fazer readicionar xls em 7z, Dir.pwd=#{Dir.pwd}, sevenz_cmdline=#{sevenz_cmdline}"
		o = comando_sistema(sevenz_cmdline)
		write_rsi_log :debug, "zs_modificar_um_excel_de_7z, e=fez readicionar xls em, output de sevenz_cmdline=#{sevenz_cmdline}, o=#{o}"
	rescue Exception => e
		excecao = e
	ensure
		Dir.chdir pwd if pwd
		FileUtils.rm_rf tmpd if tmpd
	end
	if excecao
		raise excecao
	end
	return h
end

def zs_runone_cmd_has_related_files(id)
#created, 2018Set30
	retval = false
	dat_files = Dir["#{zs_network_dir}/dat*id=#{id}*"]
	ftz_files = Dir["#{zs_network_dir}/ftz*id=#{id}*"]
	ccc_files = Dir["#{zs_network_dir}/cmd*type=runone*id=#{id}*"]

	if dat_files.length == 1 and ftz_files.length == 1 and ccc_files.length == 1
		retval = true
	end

	return retval
end

def zs_exec_runone(cmd)
	ts=zs_timestamp_str(Time.now)
	guid='0000'.to_sym; #zs_field(cmd,:guid)
	id = zs_field(cmd, :id)

	type = :runone
	maq=$zs_cfg[:maq]
	

	stt_fname = zs_stt_runone_fname(id:id, act: :chosen, maq:maq, guid:guid, ts:ts)

	if not stt_fname
		write_rsi_log :debug, "zs_exec_ronone, stt_fname para id=#{id} retornou nil, provavelmente por manipulação durante vôo"
		return
	end

	full_featname = zs_field(stt_fname,:feature)
	featname = get_feature_sem_guid_nem_nice(full_featname)
	if not zs_runone_cmd_has_related_files(id)
		write_rsi_log :debug, "zs_exec_ronone, nao foram encontrados."
		return
	end

	executa_exclusivo({:verbose=>true, :segundos_sleep=>5}, zs_feature_lock_filename(featname), -1) do
#2018Set30 - se comando cmd.*runone.*ccc tem todos arquivos ok... deleta marcacao TERMINAR. Manutenção de features durante vôo 
		featname = get_feature_sem_guid_nem_nice(zs_field(stt_fname, :feature))
		#2018Out6 22:00 - se já existe chosen de outra máquina, cria arquivo feature_bla_#{chosenId}.TERMINATE.ITR para que 
		residual_chosen_stts = Dir["#{zs_network_dir}/stt*type=runone*feature=*X#{featname}guid**act=chosen*.stt"].map{|stt|File.basename stt}.select{|stt| zs_field(stt,:id).to_s != id.to_s} 
		write_rsi_log :debug, "zs_exec_runone(cmd=#{cmd}), featname=#{featname}), residual_chosen_stts=#{residual_chosen_stts}"

		#pode haver chosen residuais até desta mesma máquina, em manutenções durante vôo pra mesma feature várias vezes na sequencia, como no caso de múltiplas chamadas seguidas a "ruby zs\zs_proc.rb forca_refluxo uma_certa_feature" !!!!!!! Nesse caso, num mesmo ciclo de fazendo CHOSEN, o TERMINATE.ITR será criado para o ID anterior, causando a desejado e esperada interrupcao do processamento para aquele ID residual. 
		residual_ids = []

		if residual_chosen_stts.length == 0
			#faz nada, OK, sem residuos
		else
			residual_ids = residual_chosen_stts.map do |one_residual|
				zs_field(one_residual, :id)
			end
		end

		write_rsi_log :debug, "zs_exec_runone(cmd=#{cmd}), featname=#{featname}), vai remover o TERMINATE.ITR da feature como um todo"
		zs_remove_feature_terminate_file(featname) 
		write_rsi_log :debug, "zs_exec_runone(cmd=#{cmd}), featname=#{featname}), removeu o TERMINATE.ITR da feature como um todo"

		if residual_ids and residual_ids.length > 0
			#2018Out7, 22:07 - adaptado para IDs residuais de multiplas outras máquinas
			#2018Out 7 - desde 2018Out6 22:xx pm, foi implementado criacao e uso de arquivo TERMINAR.ITR especifico para um ID, quando no momento de criar CHOSEN detectamos que há CHOSEN residuais da feature em outras máquinas. Isso vai garantir que processamento desses IDs residuais nao ocorra (seja desprezado imediatamente) no momento em que essas outras máquina forem processá-lo s(seja em cucumber, seja em zs_proc). GRANDE AVANÇO DE ROBUSTEZ!
			write_rsi_log :debug, "zs_exec_runone(cmd=#{cmd}), featname=#{featname}), detectados chosen residuais, daqui a instantes serao criados arquivos TERMINATE.ITR pros IDs desses chosen residuais. residual_chosen_stts=#{residual_chosen_stts}, residual_ids=#{residual_ids}"
			residual_ids.each do |one_residual_id| 
				write_rsi_log :debug, "zs_exec_runone(cmd=#{cmd}), featname=#{featname}), vai criar arquivo TERMINATE.ITR para ID residual #{one_residual_id}"
				zs_create_feature_terminate_file featname, "chose", one_residual_id
				write_rsi_log :debug, "zs_exec_runone(cmd=#{cmd}), featname=#{featname}), criou arquivo TERMINATE.ITR para ID residual #{one_residual_id}"
			
				#2018Out8 - bugfix. Faltava adicionar coluna com o arquivo TERMINATE ao dat*7z do chosen residual.
				sevenzsourcemask = "#{zs_network_dir}/dat*_id=#{one_residual_id}*.7z"
				sevenzsourcepath = Dir[sevenzsourcemask].first
				if not sevenzsourcepath
					write_rsi_log :debug, "zs_exec_runone(cmd=#{cmd}), featname=#{featname}), nao encontrado o dat do chosen, provavelmente por manutencao durante voo... one_residual_id=#{one_residual_id}, sevenzsourcemask=#{sevenzsourcemask}"
				else
					zs_modificar_um_excel_de_7z(sevenzsourcepath) do
						|m| m['TERMINATE_FILE_PREFIX'] = zs_get_feature_terminate_fileprefix(featname, one_residual_id)
					end
				end

			end
			write_rsi_log :debug, "zs_exec_runone(cmd=#{cmd}), featname=#{featname}), detectados chosen residuais, foram criados arquivos TERMINAT.ITR para esses ids, residual_chosen_stts=#{residual_chosen_stts}, residual_ids=#{residual_ids}"
		end

		write_rsi_log :debug, "zs_exec_runone(cmd=#{cmd}), featname=#{featname}, vai criar waiting e salvar chosen count"
		zs_create_new_file("#{zs_network_dir}/#{stt_fname}")
		zs_save_chosen_count 
		#TODO 2018Out7 22:43 - TALVEZ, deva refinar o zs_save_choseb_count (e/ou métodos chamados por ela) para que nao leve em conta as features/ids interrompidos!
		write_rsi_log :debug, "zs_exec_runone(cmd=#{cmd}), featname=#{featname}, criou waiting e salvou chosen count"
	end
	return
end

#def zs_get_fpath_pseudopid #2018Mar01 - pseudopid deprecated...
#	return "#{$zs_cfg[:automdir]}/ZSPROC_PSEUDOPID.LC2"  #NAO USE EXTENSAO .LCK! OU DELETERÀ NA HORA ERRADA! #2018Mar01 - pseudopid deprecated...

	 # FRÀGIL! Depende de ambor ZRDIR e AUTOM terem mesma cfg! TODO FUTURO=revamp it!
#end #2018Mar01 - pseudopid deprecated...

#def zs_write_pseudopid(pseudopid = nil) #PARAMETRO: apenas para DEBUG, nunca passado #2018Mar01 - pseudopid deprecated...
#	pseudopid = pseudopid || zs_new_global_id #2018Mar01 - pseudopid deprecated...
#	FileUtils.rm zs_get_fpath_pseudopid if File.exist? zs_get_fpath_pseudopid #2018Mar01 - pseudopid deprecated...-
#	zs_create_new_file(zs_get_fpath_pseudopid,pseudopid) #DUMB: poderia criar sem ligar se existe #2018Mar01 - pseudopid deprecated...
#	return pseudopid #2018Mar01 - pseudopid deprecated...
#end #2018Mar01 - pseudopid deprecated...
#def zs_read_pseudopid #2018Mar01 - pseudopid deprecated...
#	pseudopid = nil #2018Mar01 - pseudopid deprecated...
#	begin #2018Mar01 - pseudopid deprecated...
#		pseudopid = File.read(zs_get_fpath_pseudopid)#2018Mar01 - pseudopid deprecated...
#	rescue SystemCallError => e#2018Mar01 - pseudopid deprecated...
#		# não faça nada, deixa continuar nil#2018Mar01 - pseudopid deprecated...
#	end#2018Mar01 - pseudopid deprecated...
#	return pseudopid#2018Mar01 - pseudopid deprecated...
#end#2018Mar01 - pseudopid deprecated...

def zs_run_parallel_process_signatures
	return [] if (not $not_single_maq_zsproc_debug)

	return [ #2018Ago16 pm - residuo de CTRL+C/cmd_stop em "stt*act=done*.7z" aconteceu algumas vezes (COMPLEXAS DE DEBUGAR), gerando prolema em condolidador de reports (zs\zs_proc.rb consolidador). SOLUÇÂO: colocar asinaturas no método "zs_proc.rb::zs_run_parallel_process_signatures" na ordem correta, e, também, matar e esperar (em método "kill_and_watch") um a um os processos(em vez de matar_todos+esperar_todos.
		'run_parallel.rb',
		'consumidor_de_features.rb', 
		'cucumber',  #apenas para windows
		'javaw.exe', 'tfcrun.jar', #2018Abr12 - ajustado, de 'tfc_server_run' para 'tfcrun.jar'
		#'splitter.rb', #2018Out1, splitter e joiner potencialmente em zs_proc.rb "manutenção durante vôo"
		#//'joiner.rb', #2018Out1, splitter e joiner potencialmente em zs_proc.rb "manutenção durante vôo"
		'checador_erro_chrome.rb',
		'ahk_TPN',
		'chromedriver.exe',
		'chrome.exe',
	]
end


def zs_is_run_parallel_dead?
	return is_dead(zs_run_parallel_process_signatures)
end

def zs_kill(assinaturas)

	just_kill assinaturas
	
	return
end



def zs_exec_runme(cmd)
	zs_cleanup_before_runme #2018Abr12 - zs_cleanup_before_runme - chamada movida para cá

	if cmd
		if zs_stt_runme_running?
			falhar "zs_exec_runme, BAD PARAMETER, cmd=NOT nil enquanto zs_stt_runme_running? eh TRUE"
		end
		guid="0000".to_sym #zs_field(cmd, :guid)
	
		fname = zs_stt_createfile_runme_running(cmd) #cmd deve ter valor, neste caso
		write_rsi_log :debug,  "zs_exec_runme(cmd='#{cmd}' - zs_stt_runme_running? FALSE ! sim criou arquivo #{fname}, guid=0000"
	
	else
		if not zs_stt_runme_running?
			falhar "zs_exec_runme, BAD PARAMETER, cmd=nil enquanto zs_stt_runme_running? eh FALSE"
		end

		guid='0000' #TODO AGORA - melhore-me, obtenha GUID do RUNNING !!!
		write_rsi_log :debug,  "zs_exec_runme(cmd='#{cmd}' - zs_stt_runme_running? TRUE ! nao criou arquivo, e guid=0000"
		# ATENCAO - deve cair aqui com dmd == nil !
	end


	zs_reset_chosen_count #2018Abr09 14:22pm - chamada a zs_reset_chosen_count movida de zs_first_cleanup para o instante exato em que vai fazer spawn do 2o processo de zs_main_automation

	cmdcore = "ruby zs/zs_proc.rb automation 0000" #{guid}
	#nao to conseguindo passar env_vars pro SPAWN...
	write_rsi_log :debug,  "zs_exec_runme() : vai fazer spawn de cmdcore=#{cmdcore}" #2018Mar01 - pseudopid deprecated...
	$zs_run_automation_pid = spawn cmdcore
	write_rsi_log :debug,  "zs_exec_runme() : SPAWNED , SPAWNED cmdcore=#{cmdcore},  $zs_exec_autom_pid=#{$zs_run_automation_pid}"#2018Mar01 - pseudopid deprecated...
end

def zs_ftz_list
	#return $zs_list_of_ftzs if $zs_list_of_ftzs

	list_of_ftzs = Dir["#{zs_network_dir}/*.ftz"].map {|ftz_file| 
		ftz=File.basename(ftz_file,'.ftz') #retira extensao
		id = zs_id_field(ftz)
		{
			:id => zs_id_field(ftz),
			:feature => zs_field(ftz, :feature),
			:nice => get_nice(zs_field(ftz, :feature)),
			:si  => zs_field(ftz, :si),
			:sf  => zs_field(ftz, :sf),
			:te  => zs_field(ftz, :te),
			:gt  => zs_field(ftz, :gt),
			:sq  => zs_field(ftz, :sq),
			:cpf => zs_field(ftz, :cpf)
		}
	}
	return list_of_ftzs
end



def zs_new_global_id(nchars=6)
	return obtem_alphanum_guid(nchars)
end

def zs_main_cmd
	profile_block lambda {zs_core_main_cmd}
end

def zs_core_main_cmd
	mkdir_noexist "#{zs_network_dir}"


	cmd = $zs_argv[0]
	if cmd and cmd.start_with? 'features' #lida com features\ causado por autocompletar
		zs_synch_postcmd_publica_features
	elsif cmd == 'runme'
		zs_postcmd_runme
	elsif cmd == 'restart'
		dest_maq = $zs_argv[1]
		zs_postcmd_restart dest_maq #2018Abr21
	elsif cmd == 'config'
		raise 'nao uso no dia-a-dia, estava recém-concluido quando parei'
		dest_maq = $zs_argv[1]
		ruby_cfg = $zs_argv[2]
		zs_postcmd_config dest_maq, ruby_cfg #2018Abr21
	elsif cmd == 'fontes'
		dest_maq = $zs_argv[1]
		zs_postcmd_publica_fontes dest_maq #uma maquina, ou all 
	elsif cmd == 'stop'
		dest_maq = $zs_argv[1]
		zs_postcmd_stop dest_maq #SEMPRE APENAS UMA MAQUINA - nao sabemos mandar/tratar comandos ALL, o que requereria controle seletivo de ACKs. Além disso, por exemplo, no caso de "stop" teriamos que ignorar stops antigos (10 minutos?). ANYWAY, nao sabemos lidar com isso.
		################# COMENTÀRIO SOBRE 'stop' - ao enviar STOP para uma maquina que não foi capaz de processá-lo, esse comando STOP ficará pendente, assombrando e parando possíveis execucoes da maquina destino. CUIDADO! CUIDADO! CUIDADO! CUIDADO! CUIDADO! CUIDADO! CUIDADO!
	else
		falhar "Comando '#{cmd}' nao reconhecido"
	end 

end

def zs_get_first_split_sevenz(num_7z)
	fmask = "#{get_automtmpdir}/split/#{num_7z}/*.7z*"
	retval =  Dir[fmask].first
	write_rsi_log :debug, "zs_get_first_split_sevenz(num_7z=#{num_7z}), fmask=#{fmask}, retval=#{retval}"
	return retval
end

def zs_get_lock_publica_features
#2018Out10, correcao: nome melhor pra metodo que traz lock de publica features
	return "#{get_automdir}/PUBLICAFEATURES.LCK"
end

def zs_synch_postcmd_publica_features(feat_dir='features/auto', massa_dir='massas_feature', sq_i=1)
#2018Out8, adicionado, conflito em PUBLICAFEATURES de diretorio "tmp/dosplt/blabla", para o qual nao achei solucao onde guid desambiguasse. Entao, vamos sincronizar via executa_exclusivo com LOCK de arquivo local do diretorio de fontes do zs_proc.
#2018Out10, BUGFIX: chamava 2x zs_postcmd_publica_features, em vez de obter lock
	executa_exclusivo({:verbose=>true, :segundos_sleep=>5}, zs_get_lock_publica_features, -1) do
		zs_postcmd_publica_features(feat_dir, massa_dir, sq_i)
	end
	return
end

def zs_postcmd_publica_features(feat_dir='features/auto', massa_dir='massas_feature', sq_i=1)
	write_rsi_log :debug, "zs_postcmd_publica_features, feat_dir=#{feat_dir}, massa_dir=#{massa_dir}, sq_i=#{sq_i}"
	cmd_splitter = "ruby splitter.rb #{Dir[feat_dir+'/*.feature'].length} 1 #{feat_dir} #{massa_dir}" 
	write_rsi_log :debug, "zs_postcmd_publica_features, cmd_splitter=#{cmd_splitter}"
	o_splt = out_system (cmd_splitter)
	write_rsi_log :debug, "zs_postcmd_publica_features, output de comando splitter.rb =#{o_splt}"
	#2018Mar11 - sabe receber parametros adicionais para feat_dir e massa_dir. Assim, a reinsercao de features reaproveita TODA a lógica de publicação de features, pois, em e

	#2018Fev26 - páram extra pra splitter.rb, 1coloca "nice" da primeira feature que for adicionar no nome do .7z, com marcador "_nice=90_" , pra ficar facil parsear com zs_field aqui! GAMBIARRA, amarrando splitter com zs_proc.rb. De boa,  Nao ofende quem nao passar parametro "1" adicional

	dummy_guid='0000'

	sevenz_and_feature = Dir.glob("#{get_automtmpdir}/dosplt/*/*/*").select{|f|f.include? '/auto/'}.map{|f| {:sevenz => f.split('dosplt/')[1].split('/')[0].to_i , :feature => f.split('/auto/')[1].gsub('.feature','') } }
	
	sevenz_and_feature.sort! {|a,b| 
		a[:sevenz] <=> b[:sevenz]
	} #nao embaralha e ainda faz sort, pra vermos copy pra rede rolando em sequencia!

	feature_count = sevenz_and_feature.length
	nchars = feature_count.to_s.length
	tschangeme='TSCHANGEME'

	
	k=0
	full_sevenz_array = sevenz_and_feature.map{|zf|
		write_rsi_log :debug, "zf=#{zf}"
		k = k + 1
		id = zs_new_global_id
		feature = zf[:feature]
		

		source_sevenz = zs_get_first_split_sevenz(k)
		write_rsi_log :debug, "source_sevenz=#{source_sevenz}"

		massa = zs_modificar_um_excel_de_7z(source_sevenz) do |massa|
			massa.delete 'TS_INI'
			massa.delete 'TS_FIM'
			massa.delete 'TERMINATE_FILE_PREFIX'
			massa.delete 'ERROR_AJUSTES'
			massa.delete 'ERROR_CODE'
			massa.delete 'ERROR_BASE'
			massa.delete 'ERROR_MESSAGE'
		end
		#nem previsava ter lido a massa, esses valores são default. Mas, quem sabe, assim fico mais perto de futura adaptação pra projetos distintos etc.
		sq=     strzero((sq_i.to_s.to_i       ||1                         ).to_i,2)  #2018Ago29, :sq aumentado de 2 para 3 posicoes, até 999 processamentos da mesma meature. Deve bastar para as mais extremamente problemáticas execucoes.   
		si=step_strzero((massa['STEP_INICIAL']||0                         ).to_i  )
		sf=step_strzero((massa['STEP_FINAL']  ||NUM_ULTIMO_STEP_FINAL_AUTOMACAO ).to_i  )
		te=strzero((massa['TENTATIVA']        ||1                         ).to_i,2)
		gt=strzero((massa['GLOBAL_TENTATIVA'] ||1                         ).to_i,2)  #2018Ago29, :gt aumentado de 2 para 3 posicoes, até 999 processamentos da mesma meature. Deve bastar para as mais extremamente problemáticas execucoes.    
		cpf = massa['CPF']

		zf_enhanced = {
			:id => id,
			:feature => feature,
			:source_sevenz => source_sevenz,
			:dest_sevenz => "#{zs_network_dir}/dat_guid=0000_id=#{id}_ts=#{tschangeme}.7z",
			
			:dest_feature_sevenz_descr => "#{zs_network_dir}/ftz_id=#{id}_feature=#{feature}_sq=#{sq}_si=#{si}_sf=#{sf}_te=#{te}_gt=#{gt}_cpf=#{cpf}_ts=#{tschangeme}.ftz",
			#2018Set14 - adicionado field timestamp, ts, ao ftz
	
			:cmd_run_one => "#{zs_network_dir}/cmd_type=runone_guid=0000_id=#{id}_nice=#{zs_nice_field(source_sevenz)}_ts=#{tschangeme}.ccc"
		}
		zf_enhanced
	}

	full_sevenz_array.each{|zf|
		write_rsi_log :debug,  "zs_postcmd_publica_features, copiando para rede sevenz identificado como: #{zf[:dest_feature_sevenz_descr]}"


		tsnow = zs_timestamp_str(Time.now)
		
		dest_ftz = zf[:dest_feature_sevenz_descr].gsub(tschangeme,tsnow) #2018Set14 - adicionado field timestamp, ts, ao ftz
 
		zs_create_new_file dest_ftz

		dest_sevenz = zf[:dest_sevenz].gsub(tschangeme, tsnow) 	
		FileUtils.cp zf[:source_sevenz], dest_sevenz

		cmd_run_one = zf[:cmd_run_one].gsub(tschangeme, tsnow)
		zs_create_new_file cmd_run_one
	}

	return
end


def zs_feature_list_filename
#2018Ago18 pm, created
	return "feature_list.csv"
end
def zs_feature_list_filepath
#2018Ago18 pm, created
	return "#{zs_network_dir}/#{zs_feature_list_filename}"
end
def zs_keep_hasharray_keys(hash_array, preserve_keys)
	#2018Ago29, added
	return hash_array.map {|h|zs_keep_hash_keys(h, preserve_keys)}
end
def zs_keep_hash_keys(h, preserve_keys)
	#2018Ago29, added
	return h.select {|k,v| preserve_keys.include?(k) }
end
def zs_read_hash_array_from_csv(file_path)
#2018Ago18 pm, created
	column_lines = (File.readlines file_path).map{|l|l.gsub  "\n",""}.map{|l|l.split ";"}
	#array of arrays, [0]=keys, [1..N]=values
	raise "zs_reade_hash_array_from_csv, conteudo de arquivo invalido, menos que 2 linhas" if column_lines.length < 2

	keys = column_lines.first.map{|c| c.to_sym}

	hash_array = []
	column_lines.drop(1).each {|line|
		h = {}
		keys.each_index{|i|
			h[keys[i]] = line[i]
		}	
		hash_array << h
	}
	return hash_array
end

def zs_write_hash_array_to_csv(file_path, hash_array)
#2018Ago18 pm, created
	raise "zs_write_hash_array_to_csv, hash_array invalida, vazia ou nula" if (hash_array||[]).length == 0

	first_hash = hash_array.first
	keys = first_hash.keys

	contents=''
	keys.each_index{|i|
		contents = contents + keys[i].to_s
		contents = contents + ';' if i < keys.length-1
	}
	contents = contents + "\n"
	hash_array.each_index{|a_i|
		h = hash_array[a_i]
		keys.each_index{|i|
			contents = contents + h[keys[i]].to_s
			contents = contents + ";" if i < keys.length-1
		}
		contents = contents + "\n" if a_i < hash_array.length-1
	}
	dirname = File.dirname(file_path)
	network_tmpfile_path = "#{dirname}/#{zs_new_global_id}.tmp"
	File.open(network_tmpfile_path, "wt") { |f| f.puts contents }
  	FileUtils.mv network_tmpfile_path,  file_path
  	return
end

def zs_timestamp_featurelist_field(tipo_de_consolidador)
	throw "zs_timestamp_featurelist_field(tipo_de_consolidador=#{tipo_de_consolidador}), parametro invalido" if not ([:resumido,:detalhado].include? tipo_de_consolidador)
	tipo_de_consolidador = tipo_de_consolidador.to_sym
	if tipo_de_consolidador == :resumido
		return :ts_resumido
	else
		return :ts_detalhado
	end
end

def zs_get_lockfile_cfg
	return "#{zs_network_dir}/LOCK_CFG.LCK"
end
def zs_get_lockfile_feature_list
	return "#{zs_network_dir}/LOCK_FEATURELIST.LCK"
end

def zs_create_feature_list(feature_list)
#2018Ago18 pm, created
	executa_exclusivo(nil, zs_get_lockfile_feature_list) do
		zs_write_hash_array_to_csv zs_feature_list_filepath, feature_list
	end
end

def zs_read_feature_list
#2018Set17, revamped FULLY: agora tem apenas 1 feature_list.csv, com campos :base_feature_name, :ts_resumido, :ts_detalhado, :ts_genesis_+resumido. :ts_genesis_detalhado, :max_tentativas, :max_global_tentativas. Código modificado em vários lugares para lidar com nova estrutura de dados.
#2018Ago18 pm, created

#################
#
#    SUSTENTACAO: basta remover de zs_network_dir (z:\zs\vla) os arquivos TRN1.*.7z e features_list.*.csv
# para causar remontagem completa do relatorio consolidado na proxima iteracao de realtime_report!
#
#########
	retval = nil
	executa_exclusivo(nil, zs_get_lockfile_feature_list) do
		begin
			fpath = zs_feature_list_filepath
			retval = zs_espera_not_eacces {zs_read_hash_array_from_csv fpath}
		rescue SystemCallError => e
			msgerr = "zs_read_feature_list, erro ao ler arquivo #{fpath}, excecao = #{e}. Portanto, vai montar lista COMO SE NUNCA TIVESSE ATUALIZADO, lista nova"
			falhar e
		end
	end
	return retval
end

def zs_update_field_of_feature_list(featname, h)
#2018Ago29, added
	write_rsi_log :debug, "zs_update_field_of_feature_list, init P00"
	ft_list = zs_read_feature_list
	fti = ft_list.find{|e| e[:base_feature_name] == featname}
	h.each do |field_key, value|
		old_value = fti[field_key]
		fti[field_key] = value
		write_rsi_log :debug, "zs_update_field_of_feature_list, vai atualizar campo #{field_key} de feature_list, de '#{old_value}' para '#{value}'"
	end
	zs_create_feature_list(ft_list)
	write_rsi_log :debug, "zs_update_field_of_feature_list, atualizou ok"
	return
end

def zs_get_field_of_hash_array_by_key(hash_array, search_pkey, search_value, which_field)
#2018Ago29, added
	hash_array = Array.new if not hash_array
	h = hash_array.find{|e| e[search_pkey] == search_value} 
	h = Hash.new if not h
	retval = h[which_field]

	return retval
end	




def	zs_bootstrap_cleanup_network_dir
#2018Ago18 pm, created
	write_rsi_log :debug, "zs_bootstrap_cleanup_network_dir P00"
	basic_masks=["dat*.*","cmd*.*","stt*.*","aux*.*","ack*.*","ftz*.*",
		"*.csv","*.tmp", "*.7z", '*.itr', 'cfg.rb'  
		#2018Out04 am, deleting '*.itr' = interruption, like 'feature_someFeatureName.TERMINAR.ITR'
		#2018Set26 pm, not deleting '*.lc*', lck files may contain some for feature_list. Should I remove .LCK files?
		#2018Ago18 pm, added
	]
	basic_masks.each {|m| 
		write_rsi_log "Limpando mascara #{m}"
		arqs=Dir["#{zs_network_dir}/#{m}"]
		write_rsi_log "Arqs de  mascara #{m}=#{arqs}"

		arqs.each{|fname| 
			write_rsi_log :debug, "apagando #{fname}" 
			FileUtils.rm fname
		}

	} #2018Abr06 - rm_rf em vez de rm . Isto remove eventuais subdiretorios encontrados.
	basic_masks.each {|m|  falhar "diretorio #{zs_network_dir} nao foi limpado com sucesso, existem arquivos com mascara #{m}" if Dir["#{zs_network_dir}/#{m}"].length > 0}
	write_rsi_log "Apagando via rm_rf #{zs_aux_network_dir}"
	FileUtils.rm_rf zs_aux_network_dir
	write_rsi_log "Apagando via rm_rf #{zs_genesis_network_dir}"
	FileUtils.rm_rf zs_genesis_network_dir
	return
end


def zs_bk7z_networkdir
	#2018Set17 - para SANITY BACKUP, se perder config original de algo, busca no backup	
	dest_7z = "#{zs_genesis_network_dir}/bk7z.#{zs_new_global_id}.#{zs_timestamp_str Time.now}.7z"
	FileUtils.rm Dir[dest_7z]
	prevd = Dir.pwd
	Dir.chdir zs_network_dir
	sevenz_cmdline = "7za a -mx9 #{dest_7z} ."
	write_rsi_log :debug, "zs_bk7z_networkdir, vai fazer backup, Dir.pwd=#{Dir.pwd}, sevenz_cmdline=#{sevenz_cmdline}"
	o = comando_sistema(sevenz_cmdline)
	Dir.chdir prevd
	write_rsi_log :debug, "zs_bk7z_networkdir, output de sevenz_cmdline=#{sevenz_cmdline}, o=#{o}"

	return
end

def zs_bootstrap_postallcmds
	zs_bootstrap_cleanup_network_dir

	zs_postcmd_publica_fontes :all

	qtd_feat = ($zs_argv[0] || '0').to_i
	write_rsi_log :debug, "zs_bootstrap_postallcmds(qtd_feat=#{qtd_feat})"

	if qtd_feat >= 0
		cmd_core = "set TEST_DONT_PROCESSCLEAN_RUBY=1&& gera_e_executa.bat #{qtd_feat} 0"
		write_rsi_log :debug, "zs_bootstrap_postallcmds(qtd_feat=#{qtd_feat}), cmd_core=#{cmd_core}"
		system cmd_core
	else
		write_rsi_log :debug, "zs_bootstrap_postallcmds - qtd_feat < 0, nao vai gerar: prosseguirá com features previamente geradas"

	end

	zs_synch_postcmd_publica_features

	#2018Ago18 pm - adicionado criacao de feature_list
	zs_create_feature_list(
		zs_ftz_list.map{|ftz| 
			get_feature_sem_guid_nem_nice(ftz[:feature])}.uniq.map{|base_feature_name|{:base_feature_name => base_feature_name, :ts_resumido => zs_ts_zeros, :ts_detalhado => zs_ts_zeros, :ts_genesis_detalhado  => zs_ts_zeros}})

	zs_bk7z_networkdir  #2018Set17 - para SANITY BACKUP, se perder config original de algo, busca no backup


	zs_postcmd_runme

	return
end

def zs_get_source_exts_and_dirs_for_archive(include_jar = true)
	jar_piece = ''
	jar_piece = '*.jar' if include_jar
	return "*.bat *.rb *.yml *.cfg *.properties *.html *.txt #{jar_piece} features\\page features\\step_definitions features\\support features\\ahk tfc_project tfc_aux tfc_origem tfc_destino zs  \"planilhas e controles\"" 
end


def zs_postcmd_publica_fontes(dest_maq='all')
	dest_maq = dest_maq.to_s

	base_source_dir = $zs_cfg[:sourcedir]
	source_sevenz_dir = "#{get_automtmpdir}/source_sevenz"
	source_sevenz_path = "#{source_sevenz_dir}/#{zs_new_global_id}.7z"
	#CUIDADO! Devemos modificar dummy_cfg.rb::dirs_rede pra AUTOM SEGREGADA

	#pushd c:\asrc&& del /q tmp\bla\bla.7z& 7za a tmp\bla\bla.7z *.bat *.rb features zs  "planilhas e controles\" && popd 

	mkdir_noexist source_sevenz_dir
	delete_all_in_dir source_sevenz_dir #fized 2018Fev16, antes, nao limpava!
	cmd_core = "pushd #{base_source_dir}& 7za a #{source_sevenz_path} #{zs_get_source_exts_and_dirs_for_archive} & popd" #2018Fev17 - adicionando *.txt e *.html, tá ficando chato, devia haver dir segregado... #2018Fev10 - tfc - adicionado *.properties e *.jar e tfc_project
	cmd_core = cmd_core.gsub('/','\\')
	write_rsi_log :debug, "zs_postcmd_publica_fontes(dest_maq='#{dest_maq}'), cmd_core=#{cmd_core}"
	system cmd_core
	if not File.exist? source_sevenz_path
		falhar "zs_postcmd_publica_fontes, arquivo temporario #{source_sevenz_path} nao encontrado!"
	end

	network_tmpfile_path = "#{zs_network_dir}/#{zs_new_global_id}.7z"
	write_rsi_log :debug, "zs_postcmd_publica_fontes(dest_maq='#{dest_maq}'), copiando #{source_sevenz_path} para #{network_tmpfile_path}"
	FileUtils.cp source_sevenz_path, network_tmpfile_path
	write_rsi_log :debug, "zs_postcmd_publica_fontes(dest_maq='#{dest_maq}'), COPIADO #{source_sevenz_path} para #{network_tmpfile_path}"

	network_dest_sevenz_and_cmd = "#{zs_network_dir}/cmd_type=source_id=#{zs_new_global_id}_guid=0000_ts=#{zs_ts_now}.7z" #2018Ago31, zs_ts_now agora manda só o conteúdo, nao o prefixo "ts="
	write_rsi_log :debug, "zs_postcmd_publica_fontes(dest_maq='#{dest_maq}'), movendo #{network_tmpfile_path} para #{network_dest_sevenz_and_cmd}"
	FileUtils.mv network_tmpfile_path, network_dest_sevenz_and_cmd
	write_rsi_log :debug, "zs_postcmd_publica_fontes(dest_maq='#{dest_maq}'), MOVIDO #{network_tmpfile_path} para #{network_dest_sevenz_and_cmd}. ALEA JACTA EST"
end


def zs_postcmd_runme
	
	fpath_cmd_run_me = "#{zs_network_dir}/cmd_type=runme_guid=0000_id=#{zs_new_global_id}_ts=#{zs_timestamp_str(Time.now)}.ccc"
	zs_create_new_file fpath_cmd_run_me
	write_rsi_log :debug,  "zs_postcmd_runme, criado arquivo de comando que libera execucoes remotas: #{fpath_cmd_run_me}"
end
def zs_postcmd_restart(dest_maq)
	fpath_cmd = "#{zs_network_dir}/cmd_type=restart_guid=0000_id=#{zs_new_global_id}_maq=#{dest_maq}_ts=#{zs_timestamp_str(Time.now)}.ccc"
	zs_create_new_file fpath_cmd
	write_rsi_log :debug,  "zs_postcmd_restart, criado arquivo fpath_cmd=#{fpath_cmd}"
end

def zs_postcmd_config(dest_maq, ruby_config_file)
	write_rsi_log :debug, "zs_postcmd_config, dest_maq=#{dest_maq}, ruby_config_file=#{ruby_config_file}"
	fpath_cmd = "#{zs_network_dir}/cmd_type=config_guid=0000_id=#{zs_new_global_id}_maq=#{dest_maq}_ts=#{zs_timestamp_str(Time.now)}.rb"
	write_rsi_log :debug, "zs_postcmd_config, dest_maq=#{dest_maq}, ruby_config_file=#{ruby_config_file}, fpath_cmd=#{fpath_cmd}"
	FileUtils.cp ruby_config_file, fpath_cmd
	write_rsi_log :debug,  "zs_postcmd_config, criado arquivo fpath_cmd=#{fpath_cmd}"
end

def zs_postcmd_stop(dest_maq)
	fpath_cmd_stop = "#{zs_network_dir}/cmd_type=stop_guid=0000_id=#{zs_new_global_id}_maq=#{dest_maq}_ts=#{zs_timestamp_str(Time.now)}.ccc"
	zs_create_new_file fpath_cmd_stop
	write_rsi_log :debug,  "zs_postcmd_stop, criado arquivo de aborta processamento na maquina #{dest_maq}, fpath_cmd_stop=#{fpath_cmd_stop}"
end

def zs_monitor_quickstatus
	#system 'cls'

	ft_list = zs_read_feature_list
	#2018Set24, adicionada info de QTD TOTAL de features, simples, via zs_read_feature_list

	STDOUT.puts "\nQUICK STATUS , QTD=#{ft_list.length}, now=#{Time.now}"
	STDOUT.puts   "==================================================="

	fs = Dir["#{zs_network_dir}/stt*type=runone*"]

	fs.select! {|path|stt = File.basename(path); stt.start_with? 'stt'  and zs_field(stt,:type)== :runone }


	fs.select{|path|
		stt=File.basename(path)
		stt.start_with? 'stt' and zs_field(stt,:type)==:runone
	}.
	map{|path|
		stt=File.basename(path)
		maq=zs_field(stt,:maq)
		act=zs_field(stt,:act)
		ts=zs_field(stt,:ts)
		si=zs_field(stt,:si)
		nice=strzero(get_nice(zs_field(stt,:feature)).to_s.to_i/1000,2) #2018Ago15, vai dizer o nice . PODe SEr diferente o nice de CHOSEN, WAITING, RUNNING e do DONE (done=perene, pega todos). VIRE-SE!
		maphash = {
			:ts => ts,
			:maq => maq,
			:act => act,
			:nice => nice,
			:si => si
		}
		maphash
	}.
	group_by {|d| 
		rethash= {
			:maq=> d[:maq] , 
			:act=> (
						d[:act]==:chosen ? 'A' : 
						(
							d[:act]==:waiting ? 'B' : 
							(
								d[:act]==:running ? 'C' : 
								'D'
							)
						)
					) + d[:act].to_s,
			:si => d[:act]==:done ? 'NA'.to_sym : d[:si],
			:nice => d[:act]==:done ? 'NA' : d[:nice] #2018Ago15, NICE: max 99000 !
		}
		rethash
	}.map{|e| 
		{:grupo => e[0].to_s, :elementos => e[1].length.to_s, :mints => e[1].map{|x|x[:ts].to_s}.min, :maxts => e[1].map{|x|x[:ts].to_s}.max }
	}.sort {|h1, h2|
		c = (h1[:grupo].to_s <=> h2[:grupo])
		c
	}.each {|e|
		STDOUT.puts "stt=#{e[:grupo]}, qt=#{e[:elementos]}, ini=#{e[:mints][6..-1]}, atu=#{e[:maxts][6..-1]}"
	}
	
	STDOUT.puts '# # # # # # # # # #'

	fs.select{|path|
		stt=File.basename(path)
		stt.start_with? 'stt' and zs_field(stt,:type)==:runone and zs_field(stt, :act) == :done and zs_field(stt, :ls) == '1'.to_sym
	}.
	map{|path|
		stt=File.basename(path)
		sucess_or_failed = (zs_field(stt,:failed)=='999'.to_sym ? 'success' : 'failed')
		id = zs_field(stt,:id)
		ts=zs_field(stt,:ts)
		nice = strzero(get_nice(zs_field(stt,:feature)).to_s.to_i/1000,2)
		maphash = {
			:ts => ts,
			:id => id,
			:sucess_or_failed => sucess_or_failed,
			:nice => nice
		}
		maphash
	}.
	group_by {|d| 
		rethash= {
			:sucess_or_failed=> d[:sucess_or_failed] , 
			:nice => d[:nice]
		}
		rethash
	}.map{|e| 
		{:grupo => e[0].to_s, :elementos => e[1].length.to_s, :mints => e[1].map{|x|x[:ts].to_s}.min, :maxts => e[1].map{|x|x[:ts].to_s}.max }
	}.sort {|h1, h2|
		c = (h1[:grupo].to_s <=> h2[:grupo])
		c
	}.each {|e|
		STDOUT.puts "result=#{e[:grupo]}, qt=#{e[:elementos]}, ini=#{e[:mints][6..-1]}, atu=#{e[:maxts][6..-1]}"
	}

	STDOUT.puts '# # # # # # # # # #'
	ftz_list = zs_ftz_list
	#2018Out2, zs_ftz_*, NAO detectada fragilidade por manutenção durante vôo: monitor convive com manipulações desde sempre.

	xctrl={
		0 => 0, 9 => 0, NUM_STEP_TFC => 0
	}
	notfailed = fs.select{|path|
		stt=File.basename(path)
		stt.start_with? 'stt' and zs_field(stt,:type)==:runone and zs_field(stt, :act) == :done and zs_field(stt, :failed) == step_strzero(get_step_maxval_notfailed).to_sym #and zs_field(stt,:si).to_s.to_i == 10
	}
	nfcs=[0,9,10].map{|i_si| [i_si, notfailed.select{|stt| zs_field(stt,:si).to_s.to_i==i_si}.length]}
	#puts nfcs

	notfailed.select {|path|
		#write_rsi_log "#{Time.now}"
		stt=File.basename(path)
		#2019Mar19 - exclui os que tiverem mesmo :si com :ts maior,	pois isso indica que houve retrocesso de dase. Como no caso do TFC-LIMITE DIFERENTE erroneamente registrado como FALHAR_DEFINITIVO nos dias 2018Mar16 e 2018Mar17
		# CAS venhamos a implementar "falha em checar status veracidade deve voltar pra STEP 0", será útil também nesse caso
		id = zs_field(stt,:id)
		si = zs_field(stt,:si)
		ts = zs_field(stt,:ts)
		feat_sem_guidnice = get_feature_sem_guid_nem_nice(zs_field(stt,:feature).to_s)
 		
 		#write_rsi_log "feat_sem_guidnice=#{feat_sem_guidnice}"
 		t = nil

 		ok2 = true or (not ftz_list.any? {|ftz| get_feature_sem_guid_nem_nice(ftz[:feature].to_s) == feat_sem_guidnice and ftz[:ts].to_s > ts.to_s}) #2019Mar22 - regra mais simples, e mais fácil, e mais precisa! Se algo foi inseriro pra processamento mais recentemente que o DONE.7Z em questao, significa que devemos ignorá-lo 
 		ok3 = (not fs.any? {|tpath|
 			t=File.basename(tpath) 
 			############# TODO 2019Mar19 - refinar... enquanto nao começa processamento CHOSEN da reinsercao com retrocesso de fase, mesmo depois de reinserir_clone pra fase anterior, continuamos achando que avançou a fase que na verdade voltou. DEVO CORRIGIR ISSO! 
 			algo = false
 			if not (t.start_with? 'stt' and zs_field(t,:type)==:runone) 
 				#nada
 			else
 				algo = (zs_field(t,:si).to_s.to_i <= si.to_s.to_i and zs_field(t,:ts) > ts and get_feature_sem_guid_nem_nice(zs_field(t,:feature).to_s) == feat_sem_guidnice)
 				if algo and si.to_s.to_i == 10
 					#STDOUT.puts "ODDITY - algo=true si=10 para stt=#{stt}, t=#{t}" #2018Ago17 pm, comando "zs_proc.rb forca_refluxo" tornou NORMAL ter stt*7z mais recente que um outro "si=010 e failed=999"!!! Entao, nada de mensagem alerta de "ODDITY"
 				end
 			end
 			algo
 		})
 		#write_rsi_log "ok=#{ok} para stt=#{stt}"
 		

 		ok = (ok2 and ok3)
 		if ok
 			xctrl[si.to_s.to_i] = xctrl[si.to_s.to_i] + 1
 			if false
 				write_rsi_log "SIM conderando  stt=#{stt}, xctrl=#{xctrl}"
 			end
 		else
 			if false
 				write_rsi_log "desconsiderando stt=#{stt}"
 				write_rsi_log "pois existe       t=#{t  }"
 			end
 		end
 		ok
	}.map{|path|
		stt=File.basename(path)
		si = zs_field(stt,:si)
		fase_concluida = nil
		if not si
			fase_concluida = 'undef'
		elsif si == "000".to_sym
			fase_concluida = 'webd+verac'
		elsif  si == "009".to_sym
			fase_concluida='PAD+pastaDig'
		elsif  si == "010".to_sym
			fase_concluida='tfc'
		else
			fase_concluida=si.to_s
		end

		id = zs_field(stt,:id)
		ts=zs_field(stt,:ts)
		maphash = {
			:ts => ts,
			:id => id,
			:fase_concluida => fase_concluida
		}
		maphash
	}.
	group_by {|d| 
		rethash= {
			:fase_concluida=> d[:fase_concluida]  
		}
		rethash
	}.map{|e| 
		{:grupo => e[0].to_s, :elementos => e[1].length.to_s, :mints => e[1].map{|x|x[:ts].to_s}.min, :maxts => e[1].map{|x|x[:ts].to_s}.max }
	}.sort {|h1, h2|
		c = (h1[:grupo].to_s <=> h2[:grupo])
		c
	}.each {|e|
		STDOUT.puts "fase=#{e[:grupo]}, qt=#{e[:elementos]}, ini=#{e[:mints][6..-1]}, atu=#{e[:maxts][6..-1]}"
	}

	return
end

def zs_selenium_setup(browser_symbol = :internet_explorer)
	#puts 'Antes de register_driver'

	if true
		Capybara.register_driver :selenium do |app|
	#	  100.times {puts "capybara.rb, dentro de bloco register_driver"}
		  client = Selenium::WebDriver::Remote::Http::Default.new
	  	client.timeout = 120 #2018Ago13 - visit, mais timeout: passar client em httpc_lient pra Capybara::Selenium::Driver.new 
		  retval = Capybara::Selenium::Driver.new(app, :browser => browser_symbol, :http_client =>client)
	#	  puts "register_driver, retval.class=#{retval.class}"
		  retval
		end


		Capybara.default_driver = browser_symbol
		Capybara.javascript_driver = browser_symbol

		Capybara.configure do |config|
			#10.times {puts "capybara.rb, bloco em Capybara.configure"}
			#Capybara.current_driver = :selenium
			config.default_max_wait_time = 20 #PRA ATUALIZACOES AJAX
			
		end

	end

end

def zs_main_monitor #main
	#write_rsi_log :debug,  "zs_main_monitor, iniciando"
	##STDOUT.puts "zs_main_monitor P000"
	zs_read_cfgs
	if $zs_argv.length > 0
		zs_set_network_dir $zs_argv[0]
	end
	if false
		zs_selenium_setup :internet_explorer #usa outro browser, pois processo sempre mata o Chrome
		abre_janela_browser# (nil) #NIL = HACK, GAMBIARRA, design feio: para nao usar checador_erro_chrome.b
	end

	##STDOUT.puts "zs_main_monitor P001"
	prev_fs=[]
	prev_done_fs=[]
	diff_fs = []
	$zs_monitor_consolidation_pid = nil
	$zs_monitor_fs = []
	mkdir_noexist "#{get_automtmpdir}/join"
	delete_all_in_dir "#{get_automtmpdir}/join"

	prev_consolid_tmp=nil
	nof_consolids = 0
	while true do
		##STDOUT.puts "zs_main_monitor LOOP P050.1"

		zs_monitor_quickstatus
		sleep 5 

	end

end


def zs_direntry_newname(dir_entry)#created 2018Ago19 pm
	seqlen = 4
	new_seq = 1

	numeros = []
	if File.exist? dir_entry
		numeros << 1
	end

	Dir["#{File.dirname dir_entry}/new*_#{File.basename dir_entry}"].each{|fname|
		e = File.basename fname
		afternew = e[3..-1]
		#write_rsi_log :debug, "zs_direntry_newname, afternew=#{afternew}"
		num = afternew[0..seqlen-1]
		#write_rsi_log :debug, "zs_direntry_newname, num=#{num}"
		underline = afternew[seqlen]
		#write_rsi_log :debug, "zs_direntry_newname, underline=#{underline}"
		afternum = afternew[seqlen+1..-1]
		#write_rsi_log :debug, "zs_direntry_newname, afternum=#{afternum}"
		ok = false
		if underline == '_' and is_str_integer?(num) and afternum == File.basename(dir_entry)
			#write_rsi_log :debug, "zs_direntry_newname, adicionando a numeros, num.to_i=#{num.to_i}"
			numeros << num.to_i
		end
		ok
	}
	if numeros.length > 0 
		newseq = "_new#{strzero(numeros.max+1,seqlen)}"
		#2018Set02 - _new9999 no fim do nome, e nao no comeco. Bom para moves de diretorios e nomes que checo, pelo começop do nome, se bate com máscara... em zs_main_realtime_report
	else
		newseq = ''
	end
	#write_rsi_log "zs_direntry_newname, newseq=#{newseq}"

	retval = "#{File.dirname dir_entry}/#{File.basename dir_entry}#{newseq}"
	return retval
end

def zs_delete_images_from_cucumber_json(cucumber_json)
	data = JSON.parse(File.read(cucumber_json, :encoding =>'UTF-8')); nil
	data[0]['elements'][0]['after'][0].delete 'embeddings'; nil
	kk = JSON.pretty_generate data; nil
	tmpout = "#{zs_local_temp_dir}/#{zs_new_global_id}.json"
	File.open(tmpout,"wt", :enconding => 'utf-8'){|f| f.puts kk}
	zs_espera_not_eacces {FileUtils.mv tmpout, cucumber_json} #2018Set02 - ser[a zs_espera_not_eacces aqui exagero, prejudicial ou enganoso?? #TODO 2018Set01 - entender pq precisa de zs_espera_not_eacces. 
	return nil
end

def zs_lock_realtime_report(tipo_de_consolidador)
	lock_fhandle = File.open("#{zs_network_dir}/realtime.#{tipo_de_consolidador}.control.lck","w")
	is_locked = lock_fhandle.flock(File::LOCK_NB|File::LOCK_EX)
	if not is_locked
		begin
			locked_by_machine = nil; File.open("#{zs_network_dir}/realtime.#{tipo_de_consolidador}.machine.lck",'r'){|f| locked_by_machine = (f.readline||'maquina_nao_identificada').gsub("\n",'').strip}
		rescue SystemCallError => e
			nil
		end

		raise "zs_lock_realtime_report, tipo_de_consolidador=#{tipo_de_consolidador}, report realtime já sendo executado pela máquina=#{locked_by_machine}"
	end
	File.open("#{zs_network_dir}/realtime.#{tipo_de_consolidador}.machine.lck","w"){|f| f.puts $zs_cfg[:maq]}
	return lock_fhandle
end

def zs_realtime_report_clean(tipo_de_consolidador)
	cfg_report_dir = $zs_cfg[:dir_reports_consolidados][tipo_de_consolidador]
	write_rsi_log :debug, "*******************************************************************************"
	write_rsi_log :debug, "**                                                                            *"
	write_rsi_log :debug, "**  realtime reports, tipo_de_consolidador=#{tipo_de_consolidador}, CLEAN"
	write_rsi_log :debug, "**                                                                            *"
	if false
		raise "2018Set17 - Nao deve fazer FileUtils.rm_rf zs_feature_list_filepath, pois agora soh tem 1 feature_list.csv, tem q ter sido criado no bootstrap"
	else
		#2018Out3 - adicionado, reescreve a feature_list, fazendo reset de campos relevantes para tipo_de_conolidador
		feature_list = zs_read_feature_list
		nova_feature_list = feature_list.map{|ftt|
			ftt[zs_timestamp_featurelist_field(tipo_de_consolidador)] = zs_ts_zeros
			ftt[:ts_genesis_detalhado] = zs_ts_zeros
			#2018Out3 - REGRA - :ts_genesis_detalhado, nao existe :ts_genesis_resumido PROPOSITALMENTE, já que apenas para REALTIMEREPORT DETALHADO é que se torna relevante a checagem de timestamp de manipulacao de feature que potencialmente cria/apaga/muda stt*7z (genericamente chamado de genesis)
			ftt
		}
		write_rsi_log :debug, "zs_realtime_report_clean(tipo_de_consolidador=#{tipo_de_consolidador}), chamando zs_create_feature_list com nova_feature_list=#{nova_feature_list}"
		zs_espera_not_eacces {zs_create_feature_list nova_feature_list}
	end
	FileUtils.rm_rf "#{zs_network_dir}/TRN1.#{tipo_de_consolidador}.7z"
	FileUtils.rm_rf (File.dirname(cfg_report_dir)+'/mini_'+File.basename(cfg_report_dir))
	FileUtils.rm_rf (File.dirname(cfg_report_dir)+'/mini_'+File.basename(cfg_report_dir)+'.xls')
	write_rsi_log :debug, "**  OK, limpou 7z de trn1, csv de feature_list, (reports + mini)->(dir+xls)"
	write_rsi_log :debug, "**                                                                            *"
	write_rsi_log :debug, "*******************************************************************************"
	return
end

def zs_realtime_report_sanity_check
	raise '2018Set17 - ainda nao sei o que fazer em sanity-check!!'
end

def zs_main_realtime_report(tipo_de_consolidador, clean = false)
	raise "zs_main_realtime_report, tipo_de_consolidador=#{tipo_de_consolidador} inválido, deve ser :resumido ou :detalhado" if not [:detalhado, :resumido].include? tipo_de_consolidador
	#2018Ago18 pm, created

	lock_fhandle = zs_lock_realtime_report(tipo_de_consolidador)

	cfg_report_dir = $zs_cfg[:dir_reports_consolidados][tipo_de_consolidador]

	write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), P00, clean=#{clean}"
	if clean
		zs_realtime_report_clean tipo_de_consolidador
	end


	niter = 0
	while true
		niter = niter + 1
		raise 'DEBUG - apenas uma iteracao' if niter > 1 and false
		profile_block lambda {


		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), INICIO DE CICLO"

		if false and not zs_realtime_report_sanity_check(tipo_de_consolidador)
			#zs_realtime_report_clean
		end 

		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), main loop, P01"
		feature_list = zs_read_feature_list
		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), feature_list=#{feature_list}"

		all_done_stts = Dir["#{zs_network_dir}/stt*done*7z"] #2018Set6 - grande acelaracao: obtem lista de todos stt*done*7z apenas uma vez aqui, e entao passa pra uso em zs_get_last_stt_done_of_one_feature .
		ultimos_done_ts = profile_block lambda { feature_list.map{|ftt| ftt[:base_feature_name]}.map{|base_feature| {:base_feature_name => base_feature, :last_done_ts => zs_ts_field(zs_get_last_stt_done_of_one_feature(base_feature,all_done_stts) ||"_ts=#{zs_ts_zeros}")} } }
		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), ultimos_done_ts=#{ultimos_done_ts}"
		mais_recentes = ultimos_done_ts.select{|ult| feature_list.find{|ftt| ftt[:base_feature_name]==ult[:base_feature_name]}[zs_timestamp_featurelist_field tipo_de_consolidador].to_s != ult[:last_done_ts].to_s}
		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), mais_recentes=#{mais_recentes}"


		if mais_recentes.length == 0
			write_rsi_log :warn, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), mais_recentes.length=0,nada a fazer por enquanto"
			write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), FIM DE CICLO"
			if true
				sleep $zs_cfg[:realtime_report_segundos_sleep][tipo_de_consolidador] || 600 
			else
				print "press any key"
				STDIN.getch
				print "            \r"
			end
			next
		end
		


		core_feature_names = mais_recentes.map{|mr| mr[:base_feature_name]}
		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), core_feature_names=#{core_feature_names}"


		ja_havia_report_anterior = File.exist? "#{zs_network_dir}/TRN1.#{tipo_de_consolidador}.7z"

		dir_exec_reports_consolidado = nil
		realOrigXlsData = []
		inclui_refluxo = (tipo_de_consolidador == :detalhado)
		if not ja_havia_report_anterior
			#curto-circuito, executa diretamente o report o diretorio real
			dir_exec_reports_consolidado = cfg_report_dir
			zs_main_consolidador tipo_de_consolidador, core_feature_names: core_feature_names, inclui_refluxo: inclui_refluxo #2018Ago29 - apenas para core_feature_names recém detectadas, evita gerar pra features que ganharam stt*done*.7z nos poucos segundos/minutos entre deteccao e processamento de zs_main_consolidador  
		else

			begin
				realOrigXlsData = zs_espera_not_eacces {ler_xls_com_id("#{cfg_report_dir}.xls", nil, nil, -1) } 
			rescue Errno::ENOENT => e
				to_mv = "#{cfg_report_dir}.xls"
				from_mv = "#{File.dirname cfg_report_dir}/old_#{File.basename cfg_report_dir}.xls"
				zs_espera_not_eacces {FileUtils.mv from_mv, to_mv} 
				#2018Set02 19:52 - CRASH RECOVERY, considera que houve queda enquanto XLS estava temporariamente renomeado pra OLD, restaura e tenta prosseguir, desta vez. sem esperar zs_espera_eacces
				realOrigXlsData = ler_xls_com_id("#{cfg_report_dir}.xls", nil, nil, -1)
			end

			#2018Set02 - nada de rescue. Se nao conseguir ler arquivo, é que deu problema sério. 
			#TODO 2018Set02 - se necessário, posso ter rotina de recuperação que reinicie geracao do report realtime, que detecte erros destas EXCEPTIONS lançadas neste nucleo e q seja capaz de fazer sanity-check e healing otimizado, sem regerar tudo desnecessariamente MAS com robuztes.: "MELHOR UM REPORT LERDO DO Q UM ERRADO"... 

			dir_exec_reports_consolidado = File.dirname(cfg_report_dir)+'/mini_'+File.basename(cfg_report_dir) 
			prev_consolidado_dir = cfg_report_dir
			$zs_cfg[:dir_reports_consolidados][tipo_de_consolidador] = dir_exec_reports_consolidado
			#executa mini-consolidador em diretorio mini_*, e depois manda alteraçães para diretorio real
			extrap_feature_list_pra_main_consoliidador = nil
			if tipo_de_consolidador == :detalhado #2018Ago30, protege código de report nao-detalhado de mudanças para checar ts_genesis_detalhado
				extrap_feature_list_pra_main_consoliidador = feature_list 
			end
			zs_main_consolidador tipo_de_consolidador, core_feature_names: core_feature_names, inclui_refluxo: inclui_refluxo, feature_list: extrap_feature_list_pra_main_consoliidador

		 	$zs_cfg[:dir_reports_consolidados][tipo_de_consolidador] = prev_consolidado_dir

		end

		if not File.exist? "#{dir_exec_reports_consolidado}.xls" #vazio, mas existente, quando apenas remocoes completas de feature dos 7z ocorreram por causa de volta_features_pra_genesis
			write_rsi_log :error, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), arquivo XLS nao encontrado, #{dir_exec_reports_consolidado}.xls, ALGUM ERRO OCORREU, nada a fazer por enquanto"
			write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), FIM DE CICLO"
			if true
				sleep $zs_cfg[:realtime_report_segundos_sleep][tipo_de_consolidador] || 600 
			else
				print "press any key"
				STDIN.getch
				print "            \r"
			end
			next
		else
			mkdir_noexist dir_exec_reports_consolidado #2018Ago27 - workaround para report SEM NENHUM CENAR/FEATURE concluído, onde até gera XLS vazio mas nao gera diretorio de evidencias/consolidado 
		end


		
		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), core_feature_names=#{core_feature_names}"

		merge_tmpd = "#{zs_local_temp_dir}/mrg_realt_#{zs_new_global_id}"
		mkdir_noexist merge_tmpd; delete_all_in_dir merge_tmpd
		if ja_havia_report_anterior
			write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), vai pre-popular diretorio merge_tmpd=#{merge_tmpd} com arquivos de TRN1.#{tipo_de_consolidador}.7z da rede"
			tmp_trn1_fromnetwork_file = "#{zs_local_temp_dir}/TRN1.da_rede.#{zs_new_global_id}.7z"
			FileUtils.rm tmp_trn1_fromnetwork_file if File.exist? tmp_trn1_fromnetwork_file
			FileUtils.cp "#{zs_network_dir}/TRN1.#{tipo_de_consolidador}.7z", tmp_trn1_fromnetwork_file
			#TR1.7z contem caminho reports/TRN/&""
			prevd = Dir.pwd

			Dir.chdir merge_tmpd
			sevenz_cmdline = "7za x  #{tmp_trn1_fromnetwork_file}"
			o = comando_sistema(sevenz_cmdline)
			write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), output de sevenz_cmdline=#{sevenz_cmdline}, o=#{o}"
			Dir.chdir prevd
			FileUtils.rm tmp_trn1_fromnetwork_file
			
			jsons_antes_de_rm_features_modificadas = Dir["#{merge_tmpd}/reports/TRN1/*.json"]
			write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), TRN1-mini-merge, antes de apagar JSONs das features modificadas, tem length = #{jsons_antes_de_rm_features_modificadas.length} e os seguintes jsons: #{jsons_antes_de_rm_features_modificadas}"
			
			zs_realtime_delete_jsons_modificados_de_trn1(tipo_de_consolidador, merge_tmpd, core_feature_names, feature_list)
			jsons_depois_de_rm_features_modificadas = Dir["#{merge_tmpd}/reports/TRN1/*.json"]
			write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), TRN1-mini-merge, depois de apagar JSONs das features modificadas, tem length = #{jsons_depois_de_rm_features_modificadas.length} e os seguintes jsons: #{jsons_depois_de_rm_features_modificadas}"
		end


		mkdir_noexist "#{merge_tmpd}/reports/TRN1/"
		FileUtils.cp_r Dir["reports/TRN1/."], "#{merge_tmpd}/reports/TRN1/" #copia novos jsons para merge_tmpd
		jsons_depois_de_copiar_features_modificadas = Dir["#{merge_tmpd}/reports/TRN1/*.json"]
		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), TRN1-mini-merge, depois de copiar jsons das features modificadas, tem length = #{jsons_depois_de_copiar_features_modificadas.length} e os seguintes jsons: #{jsons_depois_de_copiar_features_modificadas}"

		if ja_havia_report_anterior
			FileUtils.rm Dir["reports/c/consolidado.*"] if false #2018Ago27 - ??? Inócuo??? ####deixa lá , de bovo
			html_from_json_main ["#{merge_tmpd}/reports"] #gera BOM novo consolidado.html com tudo
			zs_espera_not_eacces {FileUtils.cp Dir["#{merge_tmpd}/reports/consolidado.*"], "#{dir_exec_reports_consolidado}/"} #precisa mesmo de zs_espera_not_eacces?  #2018ago27 - IMPORTANTE, e movi erado. Pois mais adiante vai mover, de MINI, consolidado.[html+json] sobre o real. CP em vez e MV, pois to mandando de VM pra REDE...   #move sobre mini-consolidado
		end


		##########################
		#
		# Cria INCONDICIONAMENTE o TRN1.#{tipo_de_consolidador}.7z temporário local, para depois enviar pra rede
		#
		#####################
		if true
			# TODO - encontrar momendo mais rápido e eficaz para tirar as imagens do report :detalhado, ou até decidir se queremos removeer imagens até do report :resumido. Se decidirmos por remover definitifamente as imagens embutidas dos JSON/HTML de cucumber, nao precisaremos mais disto, e entao devemos ter configuracao que escolha SE/qUANDO/COMO remover imagens embutidas. 
			Dir["#{merge_tmpd}/reports/TRN1/*.json"].each{|cucumber_json| zs_espera_not_eacces {zs_delete_images_from_cucumber_json cucumber_json}} #precisa mesmo de zs_espera_not_eacces
 			#TODO - 2018Set01 - EITA NÒIS, quando debugando no console, por vezes, dá excecao EACCES de nao conseguir modificar jsons. E na 2a execucao, passa ok. CUIDADO! Garanta que isso nao vai ocorrer em execucoes reais. 
		end
		prevd = Dir.pwd
		Dir.chdir merge_tmpd  # !!!!!!!!!!! tmp/zs/mrg_realt contém a base para novo TNR1 !
		local_trn1_file = "#{zs_local_temp_dir}/TRN1.local.#{zs_new_global_id}.7z"
		FileUtils.rm local_trn1_file if File.exist? local_trn1_file

		sevenz_cmdline = "7za a -r #{local_trn1_file} reports/TRN1/*.json"
		o = comando_sistema(sevenz_cmdline) #Cria NOVO TRN1.zip completo, localmente, com todos json
		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), zevenz_cmdline=#{sevenz_cmdline}, output de sevenz_cmdline, o=#{o}"
		Dir.chdir prevd

		#AINDA nada foi de fato manipulado em.. #{zs_network_dir}\TRN1.#{tipo_de_consolidador}.7z, nem em $zs_cfg[:dir_reports_consolidados]
		# agora, eomeçamos as maniulacoes:
		#
		#
		#1. Primeiramente, mandamos (com prefixo new_), os diretorios de evidencias
		#
		#2. Depois, mandamos, com prefixo new_, o consolidado.html
		#
		#3. Entao, TRN1.#{tipo_de_consolidador}.7z
		#
		#4. Por ultimo, o features_list.csv
		#
		#5. Entao, vamos renomeando arquivos/diretorios, de NORMAL para OLD, de NEW para NORMAL.
		
		if ja_havia_report_anterior #se nao houver, ja terá criado $zs_cfg[:dir_reports_consolidados] OK!
			# MANIPULACOES no report da rede apenas se já há report prévio lá
		

			###################3
			#
			# REVAMPING NECESSIDADE E USO DE old, 2018Set02, 19:42pm
			# TODO 2018Set02 - rollbac,  voltando OLD pra REAL na deteccao de execucao incompleta!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			#
			#################s
			if true #2018Set02, será q devo fazer mesmo  rename do report XLS para old aqui?
				zs_rename_report_xls_para_old(tipo_de_consolidador, cfg_report_dir)
			end #end if true/false #2018Set02, devou ou nao fazer rename do XLS real para old?

			masks = core_feature_names.map{|cfn|cfn+'*'}+['consolidado.json','consolidado.html']
			entries = []
			masks.each do |mask|
				ms = "#{cfg_report_dir}/#{mask}"
				ini_es = Dir[ms]
				ini_es = ini_es.select{|ef|not ef.include? '.trash'} #2018Set02 23:30pm, nao renomeando pra old os marcadores ".trash"
				
				es = ini_es
				if tipo_de_consolidador == :detalhado #2018Ago30, protege código de report nao-detalhado de mudanças para checar ts_genesis_detalhado

					es = ini_es.select { |e| old = (not (     File.directory?(e) and (   zs_timestamp_str(File.ctime e) > zs_get_field_of_hash_array_by_key(feature_list, :base_feature_name, get_feature_sem_guid_nem_nice(e), :ts_genesis_detalhado)   )     ))}
				end
				entries = entries + es
				write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), adicionadas es=#{es}, por Dir[#{ms}], às entries" 
			end
			entries.each do |real_entry|
				from_mv = real_entry
				to_mv = "#{cfg_report_dir}/old_#{File.basename real_entry}"
				write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), vai fazer mv de #{from_mv} para #{to_mv}"
				if File.file? from_mv
					ignora_excecoes [SystemCallError] {
						FileUtils.mv from_mv, to_mv
						write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), conseguiu fazer mv de #{from_mv} para #{to_mv}"
					}
					#consolidado.*, posso, sim, me frustrar em mover pra OLD e, provavelmente, me frustrar em gerar novo, tendo que gerar BLA_new9999.*
				else #diretorio
					FileUtils.rm_rf to_mv #nao pode haver OLD desse diretorio. Se houver residuo, apaga solenemente, sem nenhuma protecao contra exception.
					
					#Agora, ao MV: usuario pode estar consultando evidencias em diretorio real. A volta pra genesis utiliza mesmo GUID, pois nao é feita comando 100% novo. DUPLA GERAÇÂO DE EXATAMENTE MESMO STT*DONE*7Z, com memos IDs pra tudo! Então, CORRIGINDO ISSO em 2018Set02 20:29pm, pra QUE A VOLTA PRA GENESIS GERE NOVOS IDs. Enquanto isso nao acontece... protegendo aqui!
						## PROSSEGUINDO: hmmmmmmmmm, é muito difícil proteger contra dupla-geracao-de-mesmo-guid de STT*done*7z
							## ao nao conseguir mover pra OLD, por arquivo de evidencia sendo consultado, nao conseguirei tampouco criar novo DIRETORIO REAL (mas conseguirei criar NEW)

					
					begin
						FileUtils.mv from_mv, to_mv
						write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), conseguiu fazer mv de #{from_mv} para #{to_mv}"
					rescue SystemCallError => e
						ignora_excecoes [SystemCallError] { File.open("#{from_mv}.trash","w"){|fh|} }
					end
					#potencialmente, lockado por consulta a evidencia. Deixe estar, vai continuar existindo e ganhará nome com sufixo "new" com novos dados. (CREIO q esse conflito só existirá para aberracao de volta_features_pra_genesis que agté 2018Set02 20:41pm ainda gera mesmo 7z multiplas vezes)

				end
			end

			###################3
			#
			# adicionando/substiuindo features, mandando de mini_execucao para report completo   
			#
			#################
			#realOrigXlsData
			miniXlsData = zs_espera_not_eacces{ler_xls_com_id("#{dir_exec_reports_consolidado}.xls", nil, nil, -1)} #2018Set02, nada de rescue. Tem que existir! zs_main_consolidador, mesmo sem "stt*done*7z" disponiveis no diretorio, sempre cria o XLS
			mergedXlsData = []
			if tipo_de_consolidador == :detalhado  #2018Ago30, protege código de report nao-detalhado de mudanças para checar ts_genesis_detalhado
				mergedXlsData = realOrigXlsData.select do |m|
					keep_this = false
					ts_genesis_detalhado = zs_get_field_of_hash_array_by_key(feature_list, :base_feature_name, m['FEATURE_NAME'], :ts_genesis_detalhado)
					#json_time = zs_get_field_of_hash_array_by_key(sevenz_content_list, :json_cucumber_guid, ])
					#TODO 2018Ago30 - acelerar: em vez de ir multiplas vezes ao zs_network_dir, devo ter lista CVS pre-montada contendo APENAS a listagem completa de todos done*7z que UM DIA JA EXISTIRAM (com ou sem volta_pra_genesis). Essa lista deverá atualizada antes de criar 7z em zs_create_stt_sevenz_done com LOCK_EXCLUSIVO(ctx='UPD_STT_DONE_HISTORY.LCK').. e aí eu apenas leio (também com lock exclusivo ctx=UPD_bla) aqui em realtime report, logo antes de ler CSV das features, e SEGUE O ENTERRO! COMO BOM EFEITO COLATERAL DESTA SOLUCAO, NAO PRECISMO MAIS TER default 00000000000 pra quandop nao acha stt*done*7z.
					fg = m['FEATURE_ORDER'].split('g').last; ts = Dir["#{zs_network_dir}/stt*guid#{fg}*.7z"].map{|e|zs_ts_field(e).to_s}.first || zs_ts_zeros #2018Ago30 - quick hack de baixo desempenho para achar hora em que 7z que contém esse json-original-cucumber foi criado. TODO - leia TODO grande acima com proposta de solução de alto desempenho. 				
					if ts <= ts_genesis_detalhado
						write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), SIM ESTOU excluindo do XLS a linha de FEATURE_NAME=#{m['FEATURE_NAME']} e FEATURE_ORDER=#{m['FEATURE_ORDER']}, pois ts <= ts_genesis_detalhado, ts=#{ts}, ts_genesis_detalhado=#{ts_genesis_detalhado}"
						keep_this = false
					else
						write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), nao estou excluindo do XLS a linha de FEATURE_NAME=#{m['FEATURE_NAME']} e FEATURE_ORDER=#{m['FEATURE_ORDER']}, pois ts >  ts_genesis_detalhado, ts=#{ts}, ts_genesis_detalhado=#{ts_genesis_detalhado}"
						keep_this = true
					end

					keep_this
				end
			else # tipo_de_consolidador == :resumido
				mergedXlsData = realOrigXlsData.select{|e| not core_feature_names.include? e['FEATURE_NAME']} #substitui dados originais das features modificadas pelos novos
			end
			mergedXlsData = mergedXlsData + miniXlsData
			mergedXlsData = mergedXlsData.sort{|x1,x2| (x1['FEATURE_NAME']+x1['FEATURE_ORDER']) <=> (x2['FEATURE_NAME']+x2['FEATURE_ORDER'])} #2018Set03, deixando em ordem. Nada muda do conteúdo.

			salva_arquivo_xls("#{dir_exec_reports_consolidado}.xls",mergedXlsData.first.keys, mergedXlsData)
			
			from_mv = "#{dir_exec_reports_consolidado}.xls"
			to_mv = zs_direntry_newname("#{cfg_report_dir}.xls") #2018Set02 40:43pm - nao precisaria proteger com newname, pois forçosamente nao terei arquivo lockado ao chegar aqui
			write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), vai fazer mv de #{from_mv}.xls para #{to_mv}" 
			begin
				FileUtils.mv from_mv, to_mv 
			rescue Errno::EACCES => ea
				zs_espera_not_eacces {FileUtils.cp_r from_mv, to_mv} #2018Set02 - quase 100% safe. cp mais lkento, q nao falha se from_mv aberto, caso mv falhe com EACCES
			end
			entries = []
			masks.each do |mask|
				ms = "#{dir_exec_reports_consolidado}/#{mask}"
				es = Dir[ms]
				entries = entries + es
				write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), adicionaas es=#{es}, por Dir[#{ms}], às entries" 
			end
			entries.each do |mini_entry|
				from_mv = mini_entry; to_mv = zs_direntry_newname("#{cfg_report_dir}/#{File.basename mini_entry}")
				write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), vai fazer mv de #{from_mv} para #{to_mv}" 
				begin
					FileUtils.mv from_mv, to_mv
				rescue Errno::EACCES => ea  
					#se mini_ebtry da rede nao pode ser movido por EACCES, apela pra cp_r... OPA, mas isso só aconteceria (já que ninguem pode brincar com mini) em casos de NOVO NOME_bla(dir ou arquivo) ter sido aberto pra consulta no curto intervalo de tempo entre "detectar q nao existir, ou novo nome) VERSUS "gerar entry real"!!!!!!!!!! __________________________ AINDA HÀ POSSÌVEL CRASH IRRECUPERÀVEL AQUI em TODO 2018Set02 20:47pm...caso extremo, mas possível, e shit always happens. 
					zs_espera_not_eacces {FileUtils.cp_r from_mv, to_mv}  
					#2018Set02 - quase 100% safe. cp mais lkento, q nao falha se from_mv aberto, caso mv falhe com EACCES.
				end
			end ##para cada feature modificada, apaga jsons da feature 

		
			###################3
			#
			# apagando arquivos old_*, pois já consguimos copiar arquivos novos  
			#       ##TODO 2018Set02 20:53 - a cada ciclo, tentar lidar com new_*, renomeando pra real etc. 
 			#################
			write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), vai remover todas entradas old de diretório real"

			dn = File.dirname(cfg_report_dir); bn = File.basename(cfg_report_dir);to_rm = "#{dn}/old_#{bn}.xls"
			ignora_excecoes [SystemCallError] {FileUtils.rm_f Dir[to_rm]} 
			#2018Set02 - que se dane se nao conseguir remover old xls, deixe lá old e numa outra iteracao, se ainda estiver lá, quem save consiga remover

			to_rm = "#{cfg_report_dir}/old_*"
			ignora_excecoes [SystemCallError] {FileUtils.rm_rf Dir[to_rm]} 
			#2018Set02 - que se dane se nao conseguir remover old dirs, deixe lá old e numa outra iteracao, se ainda estiverem lá, quem save consiga remover
		
			######################
			#
			# REMOVE mini dir, deve estar vazio
			#
			###############
			ignora_excecoes [SystemCallError] {FileUtils.rm_rf dir_exec_reports_consolidado}
			#2018Set02 - que se dane se nao conseguir remover o mini, na proxima iteracao dará pau (se precisar de proxima iteracao), deixe tratar lá
			
			######################################
			#
			# PRONTO! concluida atualalizacao de report completo com dados de mini
			#
			###############
			write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), concluida atualalizacao de report completo com dados de mini" 
		end #end if ja_havia_report_anterior


		tmp_network_trn1_zip = "#{zs_network_dir}/TRN1.#{tipo_de_consolidador}.tmp.#{zs_new_global_id}.7z"
		FileUtils.cp "#{local_trn1_file}", "#{tmp_network_trn1_zip}"
		FileUtils.rm local_trn1_file if File.exist? local_trn1_file #apaga temporario criado localmente
		zs_espera_not_eacces { FileUtils.mv "#{tmp_network_trn1_zip}", "#{zs_network_dir}/TRN1.#{tipo_de_consolidador}.7z" } #renomeia para nome FINA na rede

		ignora_excecoes [SystemCallError] {FileUtils.rm_rf merge_tmpd} #apaga diretorio temporario de trn1

		#TODO 2018Ago19 am - feature_list pode e deve ser HASH simples, em vez de array de hash, já que guardo como informação apenas o timestamp :ts !!!!!!!!!!!!!
		#atualiza feature_list com os modificados
		mais_recentes.each{|e| e[:last_done_ts] ||= zs_ts_zeros} #ajusta pra facilitar setar zeros
		nova_feature_list = feature_list.map{|ftt|
			ftt[zs_timestamp_featurelist_field(tipo_de_consolidador)]=(
				(
					mais_recentes.find{|m|m[:base_feature_name]==ftt[:base_feature_name]} || {}
				)[:last_done_ts]
			) || ftt[zs_timestamp_featurelist_field(tipo_de_consolidador)]
			ftt
		}
		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), chamando zs_create_feature_list com nova_feature_list=#{nova_feature_list}"
		zs_espera_not_eacces {zs_create_feature_list nova_feature_list}

		write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), FIM DE CICLO"
		

		


		} #fim de profile_block lambda

		if true
			sleep $zs_cfg[:realtime_report_segundos_sleep][tipo_de_consolidador] || 600
		else
			print "press any key"
			STDIN.getch
			print "            \r"
		end

	end

end

def zs_rename_report_xls_para_old(tipo_de_consolidador, cfg_report_dir)
	from_mv = "#{cfg_report_dir}.xls"; dn = File.dirname cfg_report_dir; bn = File.basename( cfg_report_dir); to_mv = "#{dn}/old_#{bn}.xls"
	write_rsi_log :debug, "zs_main_realtime_report(tipo_de_consolidador=#{tipo_de_consolidador}), vai fazer mv de #{from_mv} para #{to_mv}"
	 
	begin
		FileUtils.mv from_mv, to_mv
	rescue Erro::EACCES => ea
		#2018Set02 18:50pm - se erro ao mover report XLS pra old, apenas copia e ignora erro
		ignora_excecoes [SystemCallError] {FileUtils.cp from_mv, to_mv}
	end
	return
end

def zs_realtime_delete_jsons_modificados_de_trn1(tipo_de_consolidador, merge_tmpd, core_feature_names, feature_list)
	core_feature_names.each do|core_feature_name| ##para cada feature modificada, apaga jsons da feature modificada
		zs_realtime_delete_feature_jsons_modificads_da_trn1(tipo_de_consolidador, merge_tmpd, core_feature_name, feature_list)
	end
end

def zs_realtime_delete_feature_jsons_modificads_da_trn1(tipo_de_consolidador, merge_tmpd, core_feature_name, feature_list)
	if tipo_de_consolidador == :detalhado #2018Ago30, protege código de report nao-detalhado de mudanças para checar ts_genesis_detalhado
		ts_genesis_detalhado = zs_get_field_of_hash_array_by_key(feature_list, :base_feature_name, core_feature_name, :ts_genesis_detalhado)
		Dir["#{merge_tmpd}/reports/TRN1/*#{core_feature_name}*.json"].each do|json_path|
			#json_time = zs_get_field_of_hash_array_by_key(sevenz_content_list, :json_cucumber_guid, ])
			#TODO 2018Ago30 - acelerar: em vez de ir multiplas vezes ao zs_network_dir, devo ter lista CVS pre-montada contendo APENAS a listagem completa de todos done*7z que UM DIA JA EXISTIRAM (com ou sem volta_pra_genesis). Essa lista deverá atualizada antes de criar 7z em zs_create_stt_sevenz_done com LOCK_EXCLUSIVO(ctx='UPD_STT_DONE_HISTORY.LCK').. e aí eu apenas leio (também com lock exclusivo ctx=UPD_bla) aqui em realtime report, logo antes de ler CSV das features, e SEGUE O ENTERRO! COMO BOM EFEITO COLATERAL DESTA SOLUCAO, NAO PRECISMO MAIS TER default 00000000000 pra quandop nao acha stt*done*7z. 
			fg = File.basename(json_path,'.json').split('g').last
			stt_7z = Dir["#{zs_network_dir}/stt*guid#{fg}*.7Z"].first
			ts = (zs_ts_field(stt_7z).to_s if stt_7z)|| zs_ts_zeros #2018Ago30 - quick hack de baixo desempenho para achar hora em que 7z que contém esse json-original-cucumber foi criado. TODO - leia TODO grande acima com proposta de solução de alto desempenho.()
			write_rsi_log :debug, "zs_realtime_delete_feature_jsons_modificads_da_trn1(tipo_de_consolidador=#{tipo_de_consolidador}, core_feature_name=#{core_feature_name}), json_path=#{json_path}, fg=#{fg}, stt_7z=#{stt_7z}, ts=#{ts}, ts_genesis_detalhado=#{ts_genesis_detalhado}"
			if ts <= ts_genesis_detalhado
				write_rsi_log :debug, "zs_realtime_delete_feature_jsons_modificads_da_trn1(tipo_de_consolidador=#{tipo_de_consolidador}, core_feature_name=#{core_feature_name}), SIM ESTOU removendo de lista de jsons de TRN1 o json de basename=#{File.basename(json_path)} pois ts <= ts_genesis_detalhado, ts=#{ts}, ts_genesis_detalhado=#{ts_genesis_detalhado}"
				ignora_excecoes [SystemCallError] {FileUtils.rm json_path}
			else 
				write_rsi_log :debug, "zs_realtime_delete_feature_jsons_modificads_da_trn1(tipo_de_consolidador=#{tipo_de_consolidador}, core_feature_name=#{core_feature_name}), nao estou removendo de lista de jsons de TRN1 o json de basename=#{File.basename(json_path)} pois ts >  ts_genesis_detalhado, ts=#{ts}, ts_genesis_detalhado=#{ts_genesis_detalhado}"
			end
		end #end Dir.each 
	else #tipo_de_consolidador == :resumido
		write_rsi_log :debug, "zs_realtime_delete_feature_jsons_modificads_da_trn1(tipo_de_consolidador=#{tipo_de_consolidador}, core_feature_name=#{core_feature_name}), resumido... removendo todos jsons da feature incondicionalmente"
		FileUtils.rm_rf Dir["#{merge_tmpd}/reports/TRN1/*#{core_feature_name}*.json"]
	end #endd if tipo_de_consolidador

end

def zs_call_main_consolidador
	tipo_de_consolidador = :resumido
	extrap = nil
	puts 'p00'

=begin
@@@@@@@@@@@ TODO 2018Mai5 18:44
	TÀ LINDA, a checagem de core_feature_names a filtrar!

	Agora, quero poder filtrar :core_feature_names mesmo quando resumido
(para o caso de checagem rapidissima de erro)

	COMO? R: pegar pelo conteudo em vez de por posicao de parametro,
a partir de $zs_argv[1]/se_len+>=2. Se true/false=:inclui_refluxo, else,
presumo q é lista de features.
	*** E... somente aceita, como ja fazia, o true/false de :inclui_refluxo
(DEFAULT=false) pro resumido. No caso do detalhado, nao aceita.

	E.... LASTS BUT NOT LEAST, quero sequenciar dentro de DEST_DIR_CONSOLID
cada geracao: se já existia bla/001, cria bla/002 etc. etc.

	E... na raiz do diretorio de destino salvo TXT de descricao do consolidado.,
com os parametros q foram passados.  
@@@@@@@@@@@@
=end

	if $zs_argv.length >= 1
		puts 'p01'
		tipo_de_consolidador = $zs_argv[0].to_sym
		extrap = nil

		if tipo_de_consolidador == :detalhado
			write_rsi_log :debug, "###############################"
			write_rsi_log :debug, "### tipo_de_consolidador=detalhado"
			write_rsi_log :debug, "###"
			write_rsi_log :debug, "### para analise por automatizadores"
			write_rsi_log :debug, "###"
			write_rsi_log :debug, "###############################"
			sleep 30
		end
	end
	if $zs_argv.length >= 2
		puts 'p02'
		if tipo_de_consolidador == :resumido
			puts 'p03'
			write_rsi_log :debug, "###############################"
			write_rsi_log :debug, "### inclui_refluxo=true     ##"
			write_rsi_log :debug, "###bagunça err_count em consolidado.html"
			write_rsi_log :debug, "###"
			write_rsi_log :debug, "###PORÈM, permite boa análise"
			write_rsi_log :debug, "###"
			write_rsi_log :debug, "###############################"
			sleep 30
			extrap = {:inclui_refluxo => $zs_argv[1] == 'true' }
		else 
			if ['true', 'false'].include? $zs_argv[1]
				raise "zs_call_main_consolidador, detalhado, parametro adicional boolean incorreto - parametro adicional somente pode ser lista de CORE_FEATURE_NAMEs (depois de nice e antes de guid, como checavel em DIR de #{zs_network_dir}) separadas por virgulas"
			end
			extrap = {:core_feature_names => $zs_argv[1].split(',') }

		end
	end 
	puts 'p04'
	write_rsi_log "zs_call_main_consolidador, vai chamar zs_main_consolidador,  tipo_de_consolidador=#{tipo_de_consolidador}, extrap=#{extrap}"
	zs_main_consolidador tipo_de_consolidador, extrap
end
def zs_main_consolidador(tipo_de_consolidador = :resumido, extrap=nil) 
	#tipo_de_consolidador - valores válidos: >resumido (default) ou :detalhado
	#extrap - extra parameters, deve ser Hash
	extrap = extrap || Hash.new
	raise 'zs_main_consolidador, parametros invalidos' if tipo_de_consolidador.class != Symbol or extrap.class != Hash
	if not extrap.keys.include? :inclui_refluxo
		extrap[:inclui_refluxo] = false
	end

	cfg_report_dir = $zs_cfg[:dir_reports_consolidados][tipo_de_consolidador]


	write_rsi_log :debug, "###############################################"
	write_rsi_log :debug, "########### INICIANDO CONSOLIDADOR ############"
	write_rsi_log :debug, "###############################################"
	pular_etapa_se_ja_existe = false
	comecar_do_zero = true

	if comecar_do_zero
		write_rsi_log :debug, "###############################################"
		write_rsi_log :debug, "########### COMEÇANDO DO ZERO - APAGANDO    ###"
		write_rsi_log :debug, "###############################################"

		FileUtils.rm_rf 'reports/c'
		FileUtils.rm_rf 'reports/TRN1/'
		FileUtils.rm_rf 'auto/'
		FileUtils.rm_rf 'features/auto/'
		#FileUtils.rm_rf 'tmp/'  #2018Ago19 pm, causava conflito entr zs_proc.rb realtime_report e  zs_proc.rb proc!
		FileUtils.rm_rf cfg_report_dir
		FileUtils.rm_rf (cfg_report_dir+'.xls')
	end

	if pular_etapa_se_ja_existe and File.exist? 'reports/c' #2018Abr34 - permite apenas reiniciar cópia para rede, ou até copiar pra outro local de rede consolidacao já gerada mas que caiu por falha no isco de rede, trocando destino
			write_rsi_log "########## PULANDO etapa de consolidacao inicial"
	else
		arquivos7z = []

		write_rsi_log :debug, "###############################################"
		write_rsi_log :debug, "########### CALCULANDO ARQUIVOS A PROCESSAR ###"
		write_rsi_log :debug, "###############################################"

		zcgs = zs_consolidacao_get_sevenzs(tipo_de_consolidador, extrap)
		zcgs.map {|e| arquivos7z << "#{zs_network_dir}/#{e[:stt_filename].to_s}"}

		write_rsi_log :debug, "Quantidade de Arquivos encontrados.length= #{arquivos7z.length}"	
		write_rsi_log :debug, "Quantidade de Arquivos encontrados= #{arquivos7z}"	

		dest_dir = "#{get_automdir}/tmp/csjoin" #2018May3 - comment: nao faz "ruby joiner.rb", em vez disso, mais abaixo, faz unzip via 7za.exe ! 
		mkdir_noexist dest_dir
		delete_all_in_dir dest_dir #2018Ago19 pm, já que nao fazermos mais remocao de todo "tmp" pra evitar conflito entre 'zs\zs_proc.rb realtime_reports' e 'zs\zs_proc.rb proc'

		arquivos7z.each { |arquivo|  

			if File.exist? arquivo
				#basename_arquivo = File.basename arquivo	
				no_destino = "#{dest_dir}/#{File.basename(arquivo)}"
				write_rsi_log :debug, "no_destino=#{no_destino}"
				if !File.exist? no_destino
					write_rsi_log :debug, "NAO, nao existe o tal do basename no destdir, no_destino=#{no_destino}"
	
					write_rsi_log :debug, "zs_main_consolidador copiando arquivo #{arquivo} para #{dest_dir}"
					FileUtils.cp arquivo, dest_dir
				else
					write_rsi_log :debug, "SIM, ja existe no_destino=#{no_destino}"
					write_rsi_log :debug, "*****Arquivo #{arquivo} ja existe no diretorio #{dest_dir}*****"
				end
				write_rsi_log :debug, "Ja fiz o que tinha que fazer quando 'Sim, existe #{arquivo}'"
			else
				write_rsi_log :debug, "zs_main_consolidador ARQUIVO NAO ENCONTRADO - #{arquivo}"
				raise "zs_main_consolidador ARQUIVO NAO ENCONTRADO - #{arquivo}"
			end

			if false
				write_rsi_log :debug, "DEBUG GAMBIARRA - SAINDO DE LOOP DEPOIS DE COPIA 1o ARQUIVO PRA TESTAR MUDANCA DE GUID"
				break
			end
		}


		pathLocal = "#{dest_dir}/stt_*act=done*.7z"
		arquivosLocal = Dir[pathLocal]
		#write_rsi_log :debug, "pathLocal=#{pathLocal}, arquivosLocal=#{arquivosLocal}"

		extract_dir = "#{get_automdir}/tmp/csex"
		todas_massas = []
		arquivosLocal.each { |e|  

			#2018Mai03 - extraindo para diretorio auxiliar, para depois manipular guid em conteúdos de json +  html, além de nomes de arquivo, permitindo devida ordenação no report consolidado 
			FileUtils.rm_rf extract_dir
			mkdir_noexist extract_dir
			prev_d=Dir.pwd
			Dir.chdir extract_dir



			basename = File.basename(e)

			cmd_core = '7za.exe x -y "' + e + '"'
			cmd_core = cmd_core.gsub('/','\\')
			write_rsi_log :debug, "Iniciando extração de arquivos zipados..., cmd_core=#{cmd_core}, Dir.pwd=#{Dir.pwd}"
			system cmd_core
			write_rsi_log :debug, "Arquivos extraidos!"

			#### 2018Mai03 - modificando nome da feature, para que guid seja prefixado por sequenciador "n" e qual o step inicial "s" (que ajuda a discernir entre WEBDESKTOP, PASTA DIGITAL e TFC)  

			id = zs_field(basename, :id)
			if false #2018Ago29
				n = zcgs.find_index{|zcg| zs_field(zcg[:stt_filename],:id)==id} 
			else
				#2018Agp29 - usando :sq como numerador sequencial, apenas intra-feature. OK, afinal de contas, a própria idéia de reonear feature para que guid contenha numerador serve apenas para colocar em ordem alfabética no relatório do cucumber... conceito original foi respeitado.

				n = zs_field(e, :sq).to_s.to_i
				write_rsi_log :debug, "NUMERACAO VIA :sq, n=#{n}, e=#{e}"
			end

			write_rsi_log :debug, "obtido n=#{n} (sequencia) de arquivo #{basename} cujo id eh #{id}"
			si = zs_field(basename,:si).to_s.to_i
			write_rsi_log "basename=#{basename}, si=#{si}"
			orig_feat_guid = get_last_guid(zs_field(basename,:feature).to_s)
			new_feat_guid="n#{strzero(n,4)}s#{strzero(si,3)}g#{orig_feat_guid}"
			write_rsi_log :debug, "orig_feat_guid=#{orig_feat_guid}, new_feat_guid=#{new_feat_guid}"

			json_fpath = Dir.glob("./**/*.json").first
			html_fpath = Dir.glob("./**/*.html").first
			feature_fpath = Dir.glob("./**/*.feature").first
			[json_fpath, html_fpath, feature_fpath].each {|f|
				write_rsi_log "trocando conteudo de guid em json/html/feature file=#{f}"
				
				text = File.read(f) if f and File.exist? f
				new_contents = text.gsub(orig_feat_guid, new_feat_guid) if text
				File.open(f, 'w') {|file| file.puts new_contents} if new_contents
			}
			while true #loop necessario? Ou bastaria apenas 1 iteracao?
				orig_guid_files = Dir.glob("./**/*guid#{orig_feat_guid}*")
				break if orig_guid_files.length == 0
				orig_guid_files.each{|orig_guid_file|
					new_guid_file = orig_guid_file.gsub(orig_feat_guid, new_feat_guid)
					write_rsi_log :debug, "renomeando arquivo #{orig_guid_file} para #{new_guid_file}"
					FileUtils.mv orig_guid_file, new_guid_file
				}
			end
			
			#### 2018Mai12 INI - geracao de excel com todas massas
			feature_name_semguidnice = get_feature_sem_guid_nem_nice(feature_fpath)
			m = ler_xls_com_id(Dir.glob("./**/*.xls").first)
			massa = {
				'FEATURE_NAME' => feature_name_semguidnice,
				'FEATURE_ORDER' => new_feat_guid
			} #preppend feature_name to massa
			
			m.keys.each{|k| massa[k] = m[k]}
			todas_massas << massa
			#### 2018Mai12 FIM - geracao de excel com todas massas

			Dir.chdir prev_d

			write_rsi_log :debug, "vai fazer merge de conteudo de diretorio de extracao com diretorio base, para os arquivos extraidos e manipulados oriundos de sevenz=#{e}"
			FileUtils.cp_r "#{extract_dir}/.", "."
			write_rsi_log :debug, "concluido merge de conteudo de diretorio de extracao com diretorio base, para os arquivos extraidos e manipulados oriundos de sevenz=#{e}"
		
			if false
				write_rsi_log :debug, "DEBUG GAMBIARRA - SAINDO DE LOOP DEPOIS DE EXTRAIR E MUDAR GUID DE ARQUIVOS PRA TESTAR MUDANCA DE GUID"
				break
			end
		}
		excel_com_todas_massas = "#{cfg_report_dir}.xls"
		if pular_etapa_se_ja_existe and File.exist? excel_com_todas_massas

			write_rsi_log "########## PULANDO etapa de gerar Excel com todas massas=#{excel_com_todas_massas}"
		else
			write_rsi_log "########## NAO ESTOU PULANDO etapa de gerar Excel com todas massas=#{excel_com_todas_massas}"

			todas_massas.sort! {|m1,m2| 
				cmp = m1['FEATURE_NAME'] <=> m2['FEATURE_NAME']
				cmp = m1['FEATURE_ORDER'] <=> m2['FEATURE_ORDER'] if cmp == 0
				cmp
			}
			salva_arquivo_xls(excel_com_todas_massas, nil, todas_massas)
			#raise "salvou arquivo xls - veja output abrindo arquivo #{excel_com_todas_massas}"
		end


		auto = Dir["#{get_automdir}/auto/r/*"]
		dirFeatures = "#{get_automdir}/features/auto/r/"
		mkdir_noexist dirFeatures

		auto.each { |e| 

			if File.exist? e
				if !File.exist? "#{dirFeatures}/#{File.basename(e)}"
					write_rsi_log :debug, "zs_main_consolidador copiando arquivo #{e} para #{dirFeatures} - Diretorio correto para gerar o consolidado."
					FileUtils.cp e, dirFeatures
				else
					write_rsi_log :debug, "*****Arquivo ja existe no diretorio #{dirFeatures}*****"
				end
			else
				write_rsi_log :debug, "zs_main_consolidador ARQUIVO NAO ENCONTRADO - #{e}"
			end

		}

		write_rsi_log :debug, "Iniciando o consolidador de reports..."
		main_consolidar_reports #2018Ago16 pm, evita ocultar possível excecao
		write_rsi_log :debug, "Consolidado gerado com sucesso!"
	end #end if not File.exist? 'reports/c' #2018Abr34 - permite apenas reiniciar 


	pular_copiar_rede = false
	if pular_etapa_se_ja_existe and File.directory? cfg_report_dir
		if true
			write_rsi_log :debug, "GAMBIARRA - nao pulando etapa de copiar para rede mesmo ja existindo diretorio #{cfg_report_dir}"
		else
			write_rsi_log "########## PULANDO etapa de copiar para rede"
			pular_copiar_rede = true
		end
	end

	if not pular_copiar_rede
		write_rsi_log "########## NAO ESTOU PULANDO etapa de copiar para rede"
		consolidado_files = Dir["#{get_automdir}/reports/c/*"]
		
		consolidado_files.each { |e| 

			if Dir.exist? e
				dir = e.split "/c/"
				dirDestino = "#{cfg_report_dir}/#{dir[1]}"
				mkdir_noexist dirDestino
				arquivosSubDir = Dir["#{e}/*"]
				arquivosSubDir.each { |s|  

					if Dir.exist? s

						subDir = s.split "/c/"
						dirDestino = "#{cfg_report_dir}/#{subDir[1]}"

						mkdir_noexist dirDestino

						screenshots = Dir["#{s}/*"]
						screenshots.each { |screenshot|  

							if File.exist? screenshot
								if !File.exist? "#{dirDestino}/#{File.basename(screenshot)}"
									write_rsi_log :debug, "zs_main_consolidador copiando arquivo #{screenshot} para #{dirDestino}"
								FileUtils.cp screenshot, dirDestino
								else
									write_rsi_log :debug, "*****Arquivo ja existe no diretorio #{dirDestino}*****"
								end
							else
								write_rsi_log :debug, "zs_main_consolidador ARQUIVO NAO ENCONTRADO - #{screenshot}"
							end

						}

					else
						if File.exist? s
							if !File.exist? "#{dirDestino}/#{File.basename(s)}"
								write_rsi_log :debug, "zs_main_consolidador copiando arquivo #{s} para #{dirDestino}"
								FileUtils.cp s, dirDestino

							else
								write_rsi_log :debug, "*****Arquivo #{File.basename(s)} ja existe no diretorio #{dirDestino}*****"
							end
							
						else
							write_rsi_log :debug, "zs_main_consolidador ARQUIVO NAO ENCONTRADO - #{s}"
						end
					end
				}
			elsif File.exist? e
				if !File.exist? "#{dirDestino}/#{File.basename(e)}"
					dirDestino = cfg_report_dir
					mkdir_noexist dirDestino #rbattaglia-2018Abr06 14:24, para quando quisermos mandar pra destinos alternativos que ainda nao esiwstam
					write_rsi_log :debug, "zs_main_consolidador copiando arquivo #{e} para #{dirDestino}"
					FileUtils.cp e, dirDestino

				else
					write_rsi_log :debug, "*****Arquivo #{File.basename(e)} ja existe no diretorio #{dirDestino}*****"
				end


			else
				write_rsi_log :debug, "zs_main_consolidador ARQUIVO NAO ENCONTRADO - #{e}"
			end
		}
	end 
	
	#2018Abr24 - renomeando diretorios para nome sequenciavel prpriamente. Ainda não é op ideal, pois não se trata de feature name 100% legível
	write_rsi_log :debug, "###############################################"
	write_rsi_log :debug, "#### FAZENDO RENAME FINAL DOS DIRETORIOS #####"
	write_rsi_log :debug, "###############################################"
	Dir["#{cfg_report_dir}/Nice*"].each{|diretorio|
		if File.directory? diretorio
			bn = File.basename(diretorio)
			bn_sem_nice = get_feature_sem_nice(bn)
			dir_sem_nice = "#{File.dirname(diretorio)}/#{bn_sem_nice}"
			write_rsi_log "zs_main_consolidador, renomeando diretorio=#{diretorio} para dir_sem_nice=#{dir_sem_nice}"
			FileUtils.mv diretorio, dir_sem_nice
		end
	}


	write_rsi_log :debug, "###############################################"
	write_rsi_log :debug, "########### CONSOLIDADOR EXECUTADO! ###########"
	write_rsi_log :debug, "###############################################"

end

def zs_locate_dup_in_stt_done
	#all_done = Dir["#{zs_network_dir}/stt*type=runone*7z"]
	all_done = Dir["#{zs_network_dir}/tinha*7z"]

	all_dups = Array.new
	all_done.length.times do |i|
		fnum = i + 1
		stt = all_done[i]
		write_rsi_log :debug, "zs_locate_dup_in_stt_done, comeco, fnum=#{fnum} de #{all_done.length}, Arquivo #{stt}"
		tmpd = "#{get_automtmpdir}/zsdonedups/#{zs_new_global_id}"
		mkdir_noexist tmpd; delete_all_in_dir tmpd
		pwd = Dir.pwd
		Dir.chdir tmpd
		system "7za x #{stt}"
		Dir.chdir pwd
		masks = {
			:xls => "*.xls",
			:html => "*.html",
			:json => "*.json",
			:feature => "*.feature",
		}
		found = Hash.new
		dups = Hash.new
		any_dups = false
		masks.keys.each do |k|
			found[k] = Dir.glob "#{tmpd}/**/#{masks[k]}"
			dups[k] = found[k].length > 1
			if not any_dups and dups[k]
				any_dups = true
			end
		end

		write_rsi_log :debug, "zs_locate_dup_in_stt_done, resumo, Arquivo #{stt} tem any_dups=#{any_dups}"
		write_rsi_log :debug, "zs_locate_dup_in_stt_done, detail, Arquivo #{stt} tem any_dups=#{any_dups}, dups=#{dups}, found=#{found}"

		if any_dups
			all_dups << {:any_dups => any_dups, :found => found, :dups => dups}
		end

	end
	return all_dups
end




def zs_main_ack_cleanup
	falhar "número de parâmetros inválidos para cleanup, esperado 0 parâmetros" if $zs_argv.length != 0
	zs_clean_ack_sem_aux
	return
end

def zs_main_cleanup
	falhar "número de parâmetros inválidos para cleanup, esperado 1 parâmetro, ID da máquina" if $zs_argv.length != 1
	maquina = $zs_argv[0].to_sym
	zs_cleanup_previous_run(maquina)
	return
end

def zs_reinsere_desistencias(features_sem_guinice)
	zs_reinsere_features_para_reprocessamento features_sem_guinice , apenas_desistencias: true, forcar_refluxo: false, arquivo_terminate: :reinseredesistencia
end

def zs_forca_refluxo(refluxo_step_inicial, refluxo_step_final, features_sem_guidnice)
#2018Ago17 pm, created

	zs_reinsere_features_para_reprocessamento features_sem_guidnice , apenas_desistencias: false, forcar_refluxo: true, refluxo_step_inicial: refluxo_step_inicial, refluxo_step_final: refluxo_step_final, arquivo_terminate: :forcarefluxo
end


def zs_stt_tem_outro_mais_recente(stt_p, arquivos_stt, inclui_refluxo)
#
# aceita receber array de campos a la "zs_field", vindo de zs_all_fields, ou
# o nome (base name ou completo) do arquivo "stt_*"
#
	#write_rsi_log :debug, "zs_stt_tem_outro_mais_recente, stt_p=#{stt_p}, arquivos_stt APENAS 3=#{arquivos_stt.first(3)}"

	raise "zs_stt_tem_outro_mais_recente, Parametro stt_p incorreto, Hash deve ser oriundo de zs_all_fields ou processo similar" if not (stt_p.class == String or (stt_p.class == Hash and stt_p.values.first.class == Symbol and stt_p.keys.first.class == Symbol))

	raise "zs_stt_tem_outro_mais_recente, Parametro arquivos_stt incorreto, deve ser do tipo/class Array de Hash, sendo que cada elemento Hash deve ser oriundo de zs_all_fields ou processo similar" if arquivos_stt.class != Array or arquivos_stt.first.class != Hash or not (arquivos_stt.first.values.first.class == Symbol and arquivos_stt.first.keys.first.class == Symbol)

	if stt_p.class == Hash
		stt = stt_p #ja veio ok
	elsif stt_p.class == String
		stt = zs_all_fields(stt_p)
	else
		raise "zs_stt_tem_outro_mais_recente, algum outro erro de parametros"
	end


	retval = ( arquivos_stt.any? { |um|
		tem_mais_recente = false
		#LÒGIVCA INVERTIDA - NINHO DE IFs abaixo diz "quando NAO eh mais recente"
		if um[:id] == stt[:id] #outro?
			#write_rsi_log "id bateu, stt / um #{um[:id]} / #{stt[:id]}"
		elsif um[:ts] < stt[:ts] #mais recente?
			#write_rsi_log "ts anterior, stt / um #{um[:ts]} / #{stt[:ts]}"
		elsif (not inclui_refluxo) and um[:si].to_s.to_i > stt[:si].to_s.to_i  #inclui_refluxo FALSE quer dizer "deve ignorar se achar step anterior com timestamp maior"
		elsif inclui_refluxo and um[:si] != stt[:si] #inclui_refluxo TRUE quer dizer "somente deve ignorar se achar  mais recente do mesmo SI exato"
		elsif get_feature_sem_guid_nem_nice(um[:feature]) != get_feature_sem_guid_nem_nice(stt[:feature]) #mesma "feature basica", mesmo teste, ignorando detalhes técnicos de nice e desambiguador guid?. CHECANDO POR ULTIMO pq esta comparacao eh lenta 
			#write_rsi_log "feature nao bateu"
		else
			write_rsi_log :debug, "arquivo stt=#{stt} sim, tem_mais_recente, um=#{um}"
			tem_mais_recente = true #entao, realmente, a feature foi reprocessada 

		end
		tem_mais_recente
	})
	return retval
end

def zs_consolidacao_get_sevenzs(tipo_de_consolidador, extrap)
#
# Reorno: array de hash, onde cada elemento do array contém hash com ...
#  :feature_sem_guid_nem_nice , "FEATURE BÀSICA, NÙCLEO DO NOME DO ARQUIVO .FEATURE"
#  :si                        , "STEP INICIAL, FASE": 0, 9 ou 10
#  :stt_filename              , "BASENAME DO STT*DONE*7Z", a trazer de zs_network_dir


	retval = nil
	profile_block lambda {

	unfiltered_raw_stts = []
	raw_stts = []
	unfiltered_raw_stts = Dir["#{zs_network_dir}/stt*runone*7z"] #2018Mai05 16:16 - alterado pra pegar apenas 7z. Afinal, utros stt*runone* já são mesmo movidos pra auxdir pelo fluxo: nenhuma mudança de comportamento é esperada.

	write_rsi_log :debug, "zs_consolidacao_get_sevenzs, unfiltered_raw_stts=#{unfiltered_raw_stts}"  if true
	if not extrap[:core_feature_names]
		raw_stts = unfiltered_raw_stts
	else
		write_rsi_log "zs_consolidacao_get_sevenzs, filtro adicional :core_feature_names presente em extrap, extrap=#{extrap}"
		raw_stts = unfiltered_raw_stts.select{|ufrs|
			ufrs_feature_name = zs_field(ufrs,:feature).to_s
			ufrs_core_feat = get_feature_sem_guid_nem_nice(ufrs_feature_name)
			if tipo_de_consolidador == :detalhado #2018Ago30, protege código de report nao-detalhado de mudanças para checar ts
				feature_list = extrap[:feature_list] 
				ts = zs_ts_field(ufrs).to_s if feature_list
				ts_done = zs_get_field_of_hash_array_by_key(feature_list, :base_feature_name, ufrs_core_feat, zs_timestamp_featurelist_field(tipo_de_consolidador)) if feature_list
				#write_rsi_log "zs_consolidacao_get_sevenzs, detalhado, ufrs_core_feat=#{ufrs_core_feat},ts=#{ts}, ts_done=#{ts_done}"
			end
			ok = true
			if not extrap[:core_feature_names].include? ufrs_core_feat
				ok = false #nao queremos gerar report pra esta feature 
			elsif tipo_de_consolidador == :detalhado and feature_list and ts <= ts_done
				#added 2018Ago29
				ok = false #nao gera report se stt*done*7z não é mais novo que o ultimo do report anterior
			end
			ok
		}
	end
	write_rsi_log :debug, "zs_consolidacao_get_sevenzs, raw_stts=#{raw_stts}"  if true


	stts = raw_stts.map{|f|zs_all_fields(f)}
	write_rsi_log :debug, "zs_consolidacao_get_sevenzs, stts=#{stts}"  if true

	done_flds=profile_block lambda {
	stts.select{|flds|flds[:act]==:done}.map {|flds|
		#   2018Mar22 - Adiciona novo field :feature_sem_guid_nem_nice, 
		# class Symbol, pra manter regra de zs_field ser sempre Symbol.
		#   Bem que eu poderia ter, desde o início, ter adicionado esse field...
		#
		flds[:feature_sem_guid_nem_nice] = get_feature_sem_guid_nem_nice(flds[:feature])
		flds
	}
	} #end profile_block
	write_rsi_log :debug, "zs_consolidacao_get_sevenzs, done_flds=#{done_flds}" if true

	#write_rsi_log "done_flds.length=#{done_flds.length}"

	retval = profile_block lambda {
	done_flds.select {|d|
		ok = true
		if tipo_de_consolidador != :detalhado
			ok = (not zs_stt_tem_outro_mais_recente(d, done_flds, extrap[:inclui_refluxo]))
			#2018Mai03 - busca apenas DONE mais recente, done_flds. Antes, buscava stts
			#write_rsi_log "Filtrando #{d}, inclui_refluxo=#{inclui_refluxo}, ok=#{ok}"
		end
		ok
	}.map {|d|
		#    Remonta o array, convertendo cada elemento em Hash descrita em 
		# comentário no início deete método. 
		h = {
			:feature_sem_guid_nem_nice => d[:feature_sem_guid_nem_nice].to_s,
			:si                        => d[:si                       ].to_s.to_i,
			:ts                        => d[:ts],
			#:stt_filename              => "#{zs_stt_runone_fname(d)}.7z"
			#2018Set30, ftz_* (via zs_stt_runone_fname) aqui detectei e tratei fragilidade, por manutenção de feature durante vôo
			:stt_filename              => Dir["#{zs_network_dir}/stt*type=runone*id=#{d[:id]}*act=done*7z"].map{|filepath|File.basename filepath}.first
		}
		h
	}.sort{|d1, d2|
		cmp = 0
		#sort by :feature_sem_guid_nem_nice, :si
		cmp = d1[:feature_sem_guid_nem_nice] <=> d2[:feature_sem_guid_nem_nice] if cmp == 0
		cmp = d1[:ts                       ] <=> d2[:ts                       ] if cmp == 0 #2018Mai03 - sort por timestamp, sempre, dentro da mesma feature. Permite que filtro que possivelmente inclua refluxo, trazendo, por exemplo, [(si=0),(si=9),(si=10)]
		cmp
	}	
	} #end profile_block
	write_rsi_log :debug, "zs_consolidacao_get_sevenzs, retval=#{retval}" if true

	} #end profile_block

	#write_rsi_log "retval.length=#{retval.length}"
	return retval
end

def zs_mustnot_read_process_source
	return ($zs_readcfg_process_source and $zs_readcfg_process_source == 'noread')
end

def zs_must_read_process_source
	return ($zs_readcfg_process_source and $zs_readcfg_process_source == 'read')
end

if ARGV.length > 0
	$zs_cfg_ready = false

	profile_block lambda {
	what = ARGV[0]
	ENV['TEST_AUTOMATION_DIR']=nil #2018Mar04 - Bug dificílimo de corrigir, por ter setado em linha de comando...
	zs_read_cfgs
	puts "$zs_cfg=#{$zs_cfg}"
	puts "zs_network_dir=#{zs_network_dir}"
	$zs_argv = ARGV.drop(1)
	$zs_what = what

	if what == 'proc'
		if ($zs_argv.length > 0)
			if $zs_argv.length !=1 or (not ['read','noread'].include? $zs_argv[0])
				raise "zs_proc.rb proc ERRO - parametro adicional aceito é [read] ou [noread], para [remontar sempre diretorio] de fontes ou [nunca remontar]" 
			end
		end
		$zs_readcfg_process_source = $zs_argv[0]
		zs_main_proc
	elsif what == 'automation' 
		zs_main_automation
	elsif what == 'reinsere_desistencias'
		#DAREDEVIL - somente chame comando de cleanup com TODAS MAQUINAS devidamente paradas!!!
		fts = $zs_argv[0] || ''
		zs_reinsere_desistencias  fts.split(',').map{|e|e.strip} 
	elsif what == 'forca_refluxo'
		#2018Ago16 - causa refluxo das features passadas, NAO IMPORTA EM QUAL SITUACAO ESTEJAM, pois pode ser q tenham dado até FALSO OK no passo.
		if $zs_argv.length != 1 and $zs_argv.length != 3
			raise 'forca_refluxo - deve ter 1 parametro (lista de features) ou 3 parametros (step_inicial, step_final, lista_de_features)!'
		elsif $zs_argv.length == 3 and not ( is_str_integer?($zs_argv[0]) and is_str_integer?($zs_argv[1]) )
			raise 'forca_refluxo - 3 parametros, os 2 primeiros parametros devem ser numeros inteiros positivos (step_inicial + ste_final), e o ultimo deve ser lista de features entre aspas'
		end

		if $zs_argv.length == 1
			si = '0'; sf = '8'; fts = $zs_argv[0]
		else
			si = $zs_argv[0]; sf = $zs_argv[1]; fts = $zs_argv[2]
		end

		zs_forca_refluxo si, sf, fts.split(',').map{|e|e.strip} 
	elsif what == 'volta_features_pra_genesis'
		#2018Set13, já há algumas semanas o mecanismo de volta_features_pra-Genesis está mais simples e confiável
		fts = $zs_argv[0] || '' 
		zs_volta_features_pra_genesis fts.split(',').map{|e|e.strip}
	elsif what == 'parar_features' #SERVE PARA PAUSAR, TAMBÈM!
		#2018Set13, created, mecanismo de parar_features. 
		#2018Set24 - serve também para pausar! Remove trio-next 
		fts = $zs_argv[0] || '' 
		zs_parar_features fts.split(',').map{|e|e.strip}
	elsif what == 'continuar_features'
		#2018Set13, created, mecanismo de continuar_features
		fts = $zs_argv[0] || '' 
		zs_continuar_features fts.split(',').map{|e|e.strip}
	elsif what == 'volta_uma_feature_pra_id'
		#2018Set13, criado  'volta_uma_feature_pra_id'
		 
		
		zs_call_volta_uma_feature_pra_id $zs_argv[0], $zs_argv[1]
	elsif what == 'emptydir' 
		#DAREDEVIL - somente chamer comando de cleanup com a máquina devidamente parada!!!
		zs_bootstrap_cleanup_network_dir 
	elsif what == 'cleanup' 
		#DAREDEVIL - somente chame comando de cleanup com a máquina devidamente parada!!!
		zs_main_cleanup
	elsif what == 'ack_clean' 
		#DAREDEVIL - somente chame comando de cleanup com TODAS MAQUINAS devidamente paradas!!!
		zs_main_ack_cleanup #2018Julho27 - zs_cleanup_previous_run perdeu trecho de deletar ACK sem AUX. que agora deve rodar apenas com todas maquinas paradas. TODO 2018Julho27 - evoluir isso, aumentando confiabilidade para que possa limpar .ACM sem .AUX mesmo em zs_cleanup_previous_run !
	elsif what == 'cmd'
		zs_main_cmd
	elsif what == 'monitor'
		zs_main_monitor
	elsif what == 'consolidador'
			zs_call_main_consolidador
	elsif what == 'realtime_report'
			#2018Ago18 pm, added.
			#2018Ago28 - recebe parametro da linha de comando. "detalhado" ou "resumido"
			clean = false
			if $zs_argv.length == 2
				clean = ($zs_argv[1].to_s.downcase == 'clean')
			end
			zs_main_realtime_report $zs_argv[0].to_sym, clean 
			#fica em loop atualizando , chama internamente componentes de consolidador de reports
	elsif what == 'bootstrap'
		zs_bootstrap_postallcmds  #uma maquina, ou all 
	elsif what == 'inner'
		puts send $zs_argv[0]  #uma maquina, ou all 
	elsif what == 'send_cfg'
		#2018Set27 - created
		zs_send_cfg $zs_argv[0] 
	elsif what == 'read_source'
		#2018Set30, created
		zs_create_processsourcedir_from_cmd(zs_get_last_source_cmd)
	else
		falhar 'paremtro invalido para execucao de zs_proc.rb'
	end


	}
end
