﻿# 2018Set27
#
# USO - se arquivo cfg.rb (q define método zs_get_cfg) for encontrado na rede, entao, o arquivo da rede 
# é relido via 'load', valores retornados por zs_get_cfg do arquivo da rede substituirão os de FONTES\zs\ .
#       OBS: inicializacao BOOTSTRAP copia zs\cfg.rb pra rede, e a partir desse momento, usamos o da rede.
#       OBS 2: não devemos editar cfg.rb diferamente na rede. Ao invés disso, devemos copiá-lo pra um nome
#       qulquer, editar, e então substituir cfg.rb com a linha de comando...
#             ruby zs\zs_proc.rb set_cfg NOME_ARQ_CFG_RB
#       sendo que valor default , se nao passarmos parametro NOME_ARQ_CFG_RB, é zs\cfg.rb  
#
#
#
# Contém configuração global em chave :global, e ARRAY com configuração de cada máquina em :local. 
#          ** Chave :local_maq de cada elemento do array de hashes :local é usada para identifiar a qual máquina
#          essa config se refere. 
#
#
#
#    Nenhuma ação imediata é tomada na execucao da cmdline zs\zs_proc.rb set_cfg. Para que uma dada VM releia a
# configuração, deve ser feito restart da mesma, pela cmdline
#             ruby zs\zs_proc.rb restart maq
#


def zs_get_cfg
	return {
		:global => zs_get_global_cfg,
		:local => zs_get_local_cfg
	}
end


def zs_get_global_cfg
#
#3 PRIMEIRAS LINHAS PREVINEM "BOM CHARACTERS" em edicao com encoding mismatch
#
	zs_dummydir = "zs/renOut28" #cpfs_risco em VMRENATO, 2018Set6, c:\zs6
	zs_dummydisk = "z:"
	zs_dummycfg_basedir = "#{zs_dummydisk}/#{zs_dummydir}"

	retval = {
		:dir_reports_consolidados => {:detalhado => '//huispvwdv0757/dirrede/reports/fewEm2018Out24det', :resumido => '//huispvwdv0757/dirrede/reports/fewEm2018Out24res'},
		#:dir_reports_consolidados => {:resumido => 'c:/ccons', :detalhado => 'c:/cdet'},
		#:dir_reports_consolidados => '//bsbrsp1010/evidencias/aberturaccpf/dummyReportName',
		:realtime_report_segundos_sleep => {:resumido => 60, :detalhado => 60}, #TODO 2018Set06-deixar rolar resumido (nao está interferindo) em uma das VMs. Pode ser na VMRenato, q tem mais memória.  #resumido deve ser acima de 600 segundos (>10 minutos), em execucoes reais! 600! E, para :detalhado, devemos dar tempo nessa ordem de grandeza, algo entre 10 e 30 minutos(600 a 1800 segundos)

		#:maq => get_alphanumeric('Renato').to_sym,  #NOME tem que ser alphanumerico !!!
		#:maq => get_alphanumeric('Renato').to_sym,  #NOME tem que ser alphanumerico !!!
		:maq => get_alphanumeric("#{get_automdir}".downcase.gsub('autom', 'mx').gsub('ar','mx')).to_sym, #gambiarra de ### 2018Julho17 - ATENCAO - suspeito que usar valor fixo, como :rbattaglia, vause problemas em execucao!!!

		:pad_bypassed => 'BOBAGEM', #2018Ago01 - faz zs_proc setar ENVVAR TEST_PAD_BYPASSED para '1' (default='1'=bypassed, '0'=sem bypass, executa)., . Quando BYPASSED, nao chama PAD, e precisa que massa esteja sensibilizada  ############ HMMM, NAO FAZ SENTIDO , pois sempre q chamar PAD vai chamar PASTA DIGITAL JUNTO. !!!!!!!!!!!!!!!!!!!!!!!! BASTA, entao, nao habilitar step 9 em steps_iniciais_habilitados!!!!!!!!

		:steps_iniciais_habilitados => [0,9,10],

		:tfc_usuario => 'dummy',
		:tfc_senha => 'dummy', #tfc ok VMRENATO 2018Set6
		:tfc_centro => '9999', #2018Out25 - :tfc_centro adicionado. nil=nao alterar (nao desejamos ou nao podemos)
		:tfc_retomada_usuarios => nil, #2018Out25 - nil=todos, []=nenhum, nem o proprio da maquina, ['some','some2']=retoma de usuarios som e som2.
=begin
		@@@@@@@@@@@@@@@@@@
		*
		 * 2018Out25 - T802HA8 nao pode mudar centro. Seah q dah certo eu setar entao centro pra 7376 (do A8) pra
		 * outros usuarios (T802HA1 e T802H65)? HMMMMMMMMMM, com multiplos usuarios "nao poderosos", que nem mesmo
		 * consigam definr o proprio centro, posso ter, sim, conflitos!
		 * 	** SOLUCAO - pra zs_proc.rb
		 	** KCT, posso ter q mudar CHOSENs da vida!
		 	** novo zs_field: tfcuser (ftz=da ultima execucao default='obterusr', stt*(sttOUtz)=escolhido+real+desta)
		 	
		 	** AIH... variavel cfg GERAL RUBY serah..
		 		** tfc_compat_users=[
		 		    {
		 		                   ?????? 
		 		                   EMBACADAO DE DEFINIR!
		 		                   
		 		                   Pode ser mais jogo ter 2 coisas:
		 		                	   ** 1) esquema atual de CENTRO, setar se der pra quem definir e quiser
		 		                	   ** 2) Além de (1), uma flag ":tfc_outro_retoma => true/false, 1/0"
										** ENTAO, se tfc_outro_retoma=FALSE, usa zs_field novo tfcuser

@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@										
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@										
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@										
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@										
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@										
	** novo zs_field: tfcuser (ftz=da ultima execucao default='obterusr', stt*(sttOUtz)=escolhido+real+desta)
										*** HMMM, além de novo zs_field tfcuser maquina a maquina, 
										** podemos APENAS ter, em vez de "boolean :tfc_outro_retoma",
										um array :tfc_retomada_usuarios => ['SAMETFCUSER','T802HXX', 'T802HZZ', '*']...
										AÌH, se for '*', esta maquina se mete a retomar de qquer outra.
										***********
										AÌH, se tfcusr for 'obterusr', é q tá comecando, entao, de boa,
										pode pegar.
										AÌ, esse "pode pegar S/N" é durante MECANISMO DE CHOSE!!
										
										
										TODO NOW - JUST CODE IT!
										TODO NOW - JUST CODE IT!
										TODO NOW - JUST CODE IT!
										TODO NOW - JUST CODE IT!
										]
		 				
		 *
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@										
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@										
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@										
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@										
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@										
=end

		:max_tentativas_feature => 1, #2018Set27 - novo, configuracao deve ser GLOBAL: nao faz sentido ser diferença entre VMs
		:max_global_tentativas_feature => 3, #2018Set27 - novo, configuracao deve ser GLOBAL: nao faz sentido ser diferença entre VMs


		:max_segundos_stop_restart => 3*60, #2018Jun19, configurável. 3*60 é tempo razoável para VM Huawei de usuario x140824 (Renato Battaglia). Em máquinas significantemente mais lentas ou rápida, este dempo deve ser aumentado ou diminuído para evitar que comandos STOP/RESTART sejam ignorados por nao chegar ao processamento desses comandos a tempo. 
		:minutos_timeout_esperando_chosen => 1,
		:minutos_timeout_esperando_allchosen => 10,
		:cpfs_risco_fullpath => "#{zs_dummycfg_basedir}/cpfs_risco.xls", #DESABILITADA A GAMBI #gambiarra pra contornar estranho erro SYSOPEN EINVAL em executa_exclusivo ao criar File.open("w") o arquivo de LOCK na rede!! Mandarei um cpfs_risco parcial para cada uma das máquinas executoras
		:cpfs_risco_lockfile => "#{zs_dummycfg_basedir}/LOCK_OBTER_CPF_RISCO.LCK",

		:dirs_rede => [
			# SEM ESPELHAMENTO, AGORA! FUTURO=espelhamento, escreve/lê sempre de dois ou mais dirs. ??? OU... pesquise espelhamento realmente robusto.
			{ # [0]
				:full_path => zs_dummycfg_basedir,
				:disk_quota_mb => 0.3, #quota baixissima, pra provar o que rola quando enche
				:min_free_mb => nil #nil=sem limite
			}
=begin
#
#
# GAP TÈCNICO: apenas um diretório, por enquanto. Dependo de comportamento de "CRIAR ARQUIVO VIA LOW-LEVEL API QUE DÊ ERRO SE JÀ EXISTIR", e isso não seria possível com espelhamento de diretórios!!!
#

			,{ #[1]
				:full_path => '\\\\bsbrsp1010/evidencias/rbattaglia/zs/zs_b',
				:disk_quota => 1024, #1024 megabytes, cota tolerante
				:min_free_mb => 685 #2017Dez6 22:47 tinha 686253 mb livres, também estoura logo
			},
			{ #[2]
				:full_path => '\\\\bsbrsp1010/evidencias/rbattaglia/zs/zs_c',
				:disk_quota => 1024, #1024 megabytes, cota tolerante
				:min_free_mb => 512 #2017Dez6 - nao podemos tomar diskspace compartilhado
			}
=end
		],
		:paralelismo => 2, #4 browsers como default. Antes de 2018Mare31, eu tava tentando paralelismo 6 e qt_deatures 12.
		:qt_features => 2, #quantas features pega de cada vez da rede para executar localmente. Espera até ter escolhido esta quantidade, ou que um timeout ocorra para iniciar testes locais.
		:automdir => "#{get_automdir}".downcase.gsub('autom', 'zrdir').gsub('ar','zrdir'), #gambiarra de debug SEM cmd_configs da vida: basta haver diretorio previamente instalado com os fontes da automacao... um diretorio é do PROCESSO (c:\autom OU ar, c:\autom2 OU ar2, c:\automN OU arN), e o DIR de execucao deve se chamar c:\sr_dir, c:\zr_dir2, c:\zedir_x e por aí vai !!! E, enquanto nao temos comando cmd_source, temos que ´pré-instalar c:zrdir etc. SEM CRISE, pra POC tá bom! 
		:sourcedir => '.', ### DEVE SER ALTERADO quando formos enviar fontes distintos
		:lang => 'en'
	}

	return retval
end

def zs_get_local_cfg
	retval = [
		{
			:localmaq => 'cmxplayren', #nome que aparece em zs_proc.rb monitor, HARDCODE, simples
			:steps_iniciais_habilitados => [0,9,10],
			:tfc_usuario => 'T802H65', #newtest=T802HA1
			:tfc_senha => 'treina10',
			:tfc_centro => '0001'  #2018Out25 - :tfc_centro adicionado. nil=nao alterar (nao desejamos ou nao podemos)
		},
		{
			:localmaq => "cmxplayrob", #nome que aparece em zs_proc.rb monitor, HARDCODE, simples
			:steps_iniciais_habilitados => [0,9,10],
			:tfc_usuario => 'T802HA1', #T802HA1
			:tfc_senha => '12treina',
			:tfc_centro => '6474'
		},
		{
			:localmaq => "cmxplaysih", #nome que aparece em zs_proc.rb monitor, HARDCODE, simples
			:steps_iniciais_habilitados => [0,9,10],
			:tfc_usuario => 'T802HA8', #also, T802H69, treina10
			:tfc_senha => 'treina10'
			#:tfc_centro => '7376' , #2018Out25 - :tfc_centro adicionado. nil=nao alterar (nao desejamos ou nao podemos)
			#tfc user T802HA8 nao consegue definir centro, nao tem privilegios suficientes
		},
		{
			:localmaq => "cmxplayden", #nome que aparece em zs_proc.rb monitor, HARDCODE, simples
			:steps_iniciais_habilitados => [0,9]
		},
		{
			:localmaq => "cmxplayjon", #nome que aparece em zs_proc.rb monitor, HARDCODE, simples
			:steps_iniciais_habilitados => []
		}
	]

	return retval
end


