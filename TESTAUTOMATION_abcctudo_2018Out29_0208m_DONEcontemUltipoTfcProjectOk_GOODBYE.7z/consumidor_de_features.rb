# encoding: UTF-8
require 'FileUtils'
require_relative './rotinas_processo.rb'
require_relative 'features/support/rsi_utils.rb'

def rotina_de_interrupcao_em_log
	checa_interrupcoes do |msg|
		write_rsi_log :debug,  msg
		Kernel.exit! 1
	end
end

write_rsi_log "consumidor_de_features.rb, PX001, ENV.inspect=#{ENV.inspect}"

write_rsi_log :debug, "ARGV=#{ARGV}"
param_feat_dir=ARGV[0]
write_rsi_log :debug, "param_feat_dir=#{param_feat_dir}"


test_process_num=ARGV[1].to_i
ENV['TEST_PROCESS_NUM']=test_process_num.to_s #2017Set16 03:49am
write_rsi_log :debug, "test_process_num=#{test_process_num}, ENV['TEST_PROCESS_NUM]=#{ENV['TEST_PROCESS_NUM']}"

test_process_count=ENV['TEST_PROCESS_COUNT'].to_i
write_rsi_log :debug, "test_process_count=#{test_process_count}"

test_paralelismo=ENV['TEST_PARALELISMO'].to_i
write_rsi_log :debug, "test_paralelismo=#{test_paralelismo}"

write_rsi_log :debug, "consumidor_de_features.rb - param_feat_dir=#{param_feat_dir}, test_process_num=#{test_process_num}"

#consumer_dir = "#{param_feat_dir}/TRN#{ENV['TEST_RUN_NUM']}/subprocessos/#{test_process_num}"
consumer_dir = "#{param_feat_dir}/r" #2017Nov20, reduzindo tamanho arqs/dirs
consumer_dir = "#{param_feat_dir}/r" #2017Nov20, reduzindo tamanho arqs/dirs
write_rsi_log "consumer_dir=#{consumer_dir}"
mkdir_noexist consumer_dir

#
## 2017Set01 - TODO - TOP - salvar ZIP DOS FONTES em cada TRN* !! 
##    Assim, se corrigirmos algo no codigo entre uma execucao e outra, temos
## certeza ABSOLUTA do que foi executado em cada TRN*! SIM!
#
#File.open("#{consumer_dir}/zip_dos_fontes_TODO2017Set01.zip","w") {}
#
# TODO 2017Set6 am - COMO E ONDE SALVAR ESSES FONTES PRA REPRODUTIBILIDADE E CHECK???
#
#


#delete_all_in_dir consumer_dir NAO DELETE MAIS, unsafe, 2017Ago23

i_seq = 0

tmq=get_machine_id

test_network_systemdown_propfile=ENV['TEST_NETWORK_SYSTEMDOWN_PROPFILE']
write_rsi_log :debug, "consumidor_de_features.rb, test_network_systemdown_propfile=#{test_network_systemdown_propfile}"

while true do

	if test_network_systemdown_propfile and (File.exist? test_network_systemdown_propfile)
		write_rsi_log :debug, "consumidor_de_features.rb, detectado system down por existencia de arquivo #{test_network_systemdown_propfile}, consumo de features temporariamente interrompido" 
		sleep 1
		next
	end

	idteste="TPN#{test_process_num}_TSQ#{i_seq}_TMQ#{tmq}"

#	todos_base = lista_de_arquivos_feature_na_fila(param_feat_dir)
#	if todos_base.length == 0
#		write_rsi_log :debug, "ACABOU, diretorio-fonte de features, #{param_feat_dir}, estah vazio!"
#		break
#	end

	#lowest_nice = todos_base.map{|f| get_nice(f)}.uniq.sort.first #nice, 1 de cada, em ordem, primeiro

	#todos_lowest_nice = todos_base.select {|f| get_nice(f) == lowest_nice}

	#todos_shuffled = todos_lowest_nice.shuffle

	#sem_guid_em_execucao = lista_de_features_em_execucao(param_feat_dir).map{|f| f.split('guid').first}

	#todos = todos_shuffled.select {|f|
	#	f_sem_guid = f.split('guid').first
	#	not (sem_guid_em_execucao.find_index f_sem_guid)
	#}

#	todos_shuffled = todos_base.shuffle




#	write_rsi_log("consumidor_features.rb - lowest_nice=#{lowest_nice}, todos_base=#{todos_base}, t#odos_lowest_nice=#{todos_lowest_nice} todos_shuffled=#{todos_shuffled}, s#em_guid_em_execucao=#{sem_guid_em_execucao}, todos=#{todos}")

	todos_fora = lista_de_arquivos_feature_na_fila(param_feat_dir).shuffle
	write_rsi_log "consumidor_de_features.rb, todos_fora=#{todos_fora}"
	if todos_fora.length == 0
		write_rsi_log :debug, "ACABOU, diretorio-fonte de features, #{param_feat_dir}, estah vazio!"
		break
	end
	valor_lowest_nice = todos_fora.map{|f| get_nice(f)}.uniq.sort.first #nice, um de cada, em ordem, primeiro
	write_rsi_log "consumidor_de_features.rb, valor_lowest_nice=#{valor_lowest_nice}"
	lowest_nices = todos_fora.select{|f| get_nice(f) == valor_lowest_nice}.shuffle
	write_rsi_log "consumidor_de_features.rb, lowest_nices=#{lowest_nices}"
	uniq_lowest_fora = lowest_nices.map{|f| f.split('guid').first}.uniq.shuffle
	write_rsi_log "consumidor_de_features.rb, uniq_lowest_fora=#{uniq_lowest_fora}"
	
	todos = uniq_lowest_fora.map{ |sem_guid| 
		todos_fora.find {|t|
			t.include? sem_guid
		}
	}.shuffle
	
	write_rsi_log "consumidor_de_features.rb, todos=#{todos}"


	i_seq = i_seq + 1
	qual_feature_file = todos[0]
	if false
		feature_filepath = renomeia_featurefile_e_massa_poe_sufixo(qual_feature_file)
#renomeia_featurefile_e_massa_poe_sufixo
		if feature_filepath == nil
			write_rsi_log :warn, "consumidor_de_feature.rb - nao foi possivel renomear/mover arquivo de features, qual_feature_file=#{qual_feature_file}, provavelmente foi movido por outro processo consumidor"
			next
		end
	else
		feature_filepath = qual_feature_file

		write_rsi_log :error, "2018Mar04 - DESATIVEI algum estranho comportamento. Em renomeia_featurefile_e_massa_poe_sufixo(qual_feature_file) , algo causava ABBEND ocasional aqui em consumidor_de_features.rb. Entao, parei de chamar. Esse rename adicionava timestamp e guid. GUID já tem sempre (feature já única), e [ts]=timestamp, nao é tao necessário. LOW RISK!"
	end


	write_rsi_log :debug, "feature_filepath=#{feature_filepath}"
	feature_basename_sem_ext = File.basename feature_filepath, '.feature'
	write_rsi_log :debug, "feature_basename_sem_ext=#{feature_basename_sem_ext}"

	runTid="_#{idteste}"
	if ENV['TEST_RUN_NUM']==nil # 2017Set01, comment: PERMITE execucao isolada CUCUMBER !
		runFname=""
	else
		runFname='TRN'+ENV['TEST_RUN_NUM']
	end
	#. #{runFname}#{runTid}
	arq_feature_consumir="#{consumer_dir}/#{feature_basename_sem_ext}.#{runFname}#{runTid}.feature"
	write_rsi_log :debug, "arq_feature_consumir=#{arq_feature_consumir}"

	#
	#2017Set01 - salvando massa de cada TRN de cada feature
	#
	arq_massa_orig="massas_feature/V #{feature_basename_sem_ext}/massa.xls"
	write_rsi_log :debug, "arq_massa_orig=#{arq_massa_orig}"
	arq_massa_trn="#{consumer_dir}/V #{feature_basename_sem_ext}.massa_#{runFname}#{runTid}.xls"
	write_rsi_log :debug, "arq_massa_trn=#{arq_massa_trn}"

	begin
		FileUtils.mv feature_filepath, arq_feature_consumir	
		
		#
		##
		## 2017Set01 - copia arquivo de massas.xls 
		##      de ... massas_features/#{feature_name}/massa.xls
		##      p/ ... para mesmo TRN* da feature.
		#       PQ? R: permite fácil checagem de massa de cada execucao de cada feature

	rescue Exception => e
		write_rsi_log :error, "consumidor_de_features.rb:  Excecao #{e.message} ao tentar mover arquivo #{feature_filepath} para #{consumer_dir}, DEVERIA ser erro ABORTIVO, mas estou sendo tolerante e indo pra proximo"
		next
	end

	if not File.exist? arq_feature_consumir
		falhar "consumidor_de_features.rb: (ESTADO DESCONHECIDO, ERRO) - nao encontrado arquivo #{arq_feature_consumir} que deveria ter movido pro diretorio"
	end

#2018Mar14 early am - ADICIONAR SEQUENCIADOR EM NOME DE FEATURE: a cargo do CONSOLIDADOR! Era completa bobagem adiccionar TM ao nome do !!ARQUIVO!! de feature, rolling it back
#	full_feature_name = parse_gherkin_feature_name(arq_feature_consumir)
#	new_full_feature_name =  full_feature_name;split('guid')[0] 
#	cria_arquivo_feature('webdesktop', arq_feature_consumir, new_full_feature_name)

	write_rsi_log "consumidor_de_features.rb, arquivo #{arq_feature_consumir} está pronto para ser consumido"

	FileUtils.cp arq_massa_orig, arq_massa_trn
	write_rsi_log "consumidor_de_features.rb, copiado arquivo de massa #{arq_massa_orig} para #{arq_massa_trn}"
	

=begin		
TODO RESEARCH 2017Ago01, 23:38pm: 
	** como controlar as janelas escondidas, ao usar WINDOWSCMD start OU WINDOWSCMD start /b
		** Nesse caso, eu precisarei de PID do windows, ou HANDLE DE JANELA, pra ver se acabou
		** se uso SPAWN direto, espera terminar o cucumber
		** Tem q ser SPAWN de CMD-START("/b??")
		** BEM, PESQUISE MAIS!
=end 

	
	alphanum_featurename = feature_basename_sem_ext #2018Mar03 - já é perfeitamente alphanum e curta.
	write_rsi_log "consumidor_de_features.rb, alphanum_featurename=#{alphanum_featurename}"

	featurename_sem_guidnice = get_feature_sem_guid_nem_nice(alphanum_featurename)
	write_rsi_log "consumidor_de_features.rb, featurename_sem_guidnice=#{featurename_sem_guidnice}"
	test_interrupcoes_prefixo = "#{get_automdir}/"
	write_rsi_log "consumidor_de_features.rb, primeiro test_interrupcoes_prefixo=#{test_interrupcoes_prefixo}"
	if ENV['TEST_ZS_PROC']=='1'
		test_interrupcoes_prefixo="#{ENV['TEST_ZS_NETWORKDIR']}/feature_#{featurename_sem_guidnice}"
		write_rsi_log "consumidor_de_features.rb, segundo test_interrupcoes_prefixo=#{test_interrupcoes_prefixo}"
	else
		write_rsi_log "ENV['TEST_ZS_PROC'] nao eh igual a '1', valor entre aspas simples='#{ENV['TEST_ZS_PROC']}'"
	end


	#2018Abr01 - removido "cmd /c" que iniciava "comando". 
	#2018Out9 - recebendo e passando adiante TEST_LOG_FILE,a que deve deve logar adicionalmente tudo de write_rsi_log. Usa aqui, e passa adiante para filho(s)  
	comando="set TEST_LOG_FILE=#{ENV['TEST_LOG_FILE']}&&set TST_ZS_PROC=#{ENV['TEST_ZS_PROC']}&&set TST_ZS_NETWORKDIR=#{ENV['TEST_ZS_NETWORKDIR']}&&set TEST_INTERRUPCOES_PREFIXO=#{test_interrupcoes_prefixo}&&set TEST_ALPHANUM_FEATURENAME=#{alphanum_featurename}&& set TEST_PARALELISMO=#{test_paralelismo}&& set TEST_PROCESS_COUNT=#{test_process_count} && set TEST_PROCESS_NUM=#{test_process_num} && set TEST_ID='#{idteste}' && cucumber '#{arq_feature_consumir}'" + '"'
	#2018Set30 - passado prefixo (incluindo dirpath) a arquivos de interrupcao ITR (antigos LCK), para morte/etc. imediata de feature
	write_rsi_log :debug, "consumidor_de_features.rb - comando (NEM PEGO PID AINDA) pra system=#{comando}"

=begin
	#
	#
	#            !!!!!!! 2017Set16 03:49am - GOTCHA?????? Será?  !!
	#       O remove_fila_lock era chamado dentro de consumidor_features, erroneamente, 
	#   sem que VARIAVEL AMBIENT "EBV" ['TEST_PROCESS_NUM'] tivesse sido setada.
	#       Isso fazia com que get_process_num retornasse 1. So far, so good.
	#
	#       SUSPEITA EMBASADA: Todos processos de consumidor_features.rb acabavam tentando 
	#   remover LAST.LOCK_BROWSER_WINDOW.1.FILA.LCK (corrompendo o TEST_PROCESS_NUM 1 !!!)    
	#
	#
	#       CORREÇÂO: SETANDO VARIAVEL De AMBIENTE AQUI, EM consumidor_features.rb!
	#   Não é uma correção ótima. Melhor ainda seria a propagação simplificada dessa  
	#   variável a partir de run_parallel.rb, que a setaria antes de chamar
	#   consumidor_features.rb (preservando idéia geral do uso de variavel de ambiente)
    #
	#       Solução, imagino, ainda melhor, seria colocar remove_fila_lock na entrada
 	#   e na saída do cucumber, via BEFORE_HOOK e AT_EXIT
	#
=end
  	desocupar_slot_de_janela_do_tpn(test_process_num)
	remove_fila_lock('LOCK_BROWSER_WINDOW','consumidor_features.rb-ANTES de system cucumber') 
	system comando
	remove_fila_lock('LOCK_BROWSER_WINDOW','consumidor_features.rb-DEPOIS de system cucumber') 
  	desocupar_slot_de_janela_do_tpn(test_process_num)




	dn=File.dirname arq_feature_consumir
	bn=File.basename arq_feature_consumir,'.feature'
	arq_feature_consumir_encerrado=dn+'/'+bn+".e.f.feature"
	write_rsi_log "consumidor_de_features.rb, NAO SABE QUANDO FALHOU OU FOI TERMINATED, vai mover #{arq_feature_consumir} para #{arq_feature_consumir_encerrado} - OBS: ainda nao sei ver se deu OK ou FAILURE"
 	#c = 'move "' + arq_feature_consumir + '" ' + arq_feature_consumir_encerrado + '"'
 	#write_rsi_log "consumidor_de_features.rb - command shell pra mover=#{c}"
 	#system c # WTF! Dava erro quando eu chamava API do Ruby, tive que chamar SYSTEM CMD !!!
	

	FileUtils.mv arq_feature_consumir, arq_feature_consumir_encerrado

	if ENV['TEST_ZS_PROC'] != '1' #2018Jun27 - reinsere pra reprocessamento obedecendo  constantes NUM_ULTIMO_STEP_FINAL_AUTOMACAO, MAX_TENTATIVAS_FEATURE e MAX_GLOBAL_TENTATIVAS_FEATURE se nao estiver rodando no ZS_PROC.RB (processo colaborativo)
		falhar "ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO - ATENCAO -desde meados de abril de 2018, código da automação tem se distanciado da execucao sem o processo colaborativo/ZS_PROC. Muito provavelmente, estranhos erros ocorreção ao chamar RUN_PARALLEL.RB fora desse contexto!!"


		write_rsi_log :debug, "consumidor_de_features.rb, fora de processo colaborativo, vai tratar reinsere_clone_reproc_feature"
		ri_arq_feature = arq_feature_consumir_encerrado
		write_rsi_log :debug, "consumidor_de_features.rb, reprocessamento, P01 - ri_arq_feature=#{ri_arq_feature}"
 		strn = ENV['TEST_RUN_NUM']
 		if strn 
 			trn = strn.to_i
 		else
 			trn = nil
 		end
		write_rsi_log :debug, "consumidor_de_features.rb, reprocessamento, P01 - trn=#{trn}"
		
		featname=get_raw_feature_name_from_feature_file(ri_arq_feature)
		write_rsi_log :debug, "consumidor_de_features.rb, reprocessamento, P01 - featname=#{featname}"
 		o = get_test_outputs_da_feature_da_trn(File.dirname(ri_arq_feature), get_automdir, featname, trn)  #COMPLEXIDADe DESNECESSARIA, POOR DESIGN
 		write_rsi_log :debug, "consumidor_de_features.rb, reprocessamento, P01 - o=#{o}"
 		ri_json_steps = o[:steps]
		write_rsi_log :debug, "cori_hash_massa.rb, reprocessamento, P01 - ri_json_steps=#{ri_json_steps}"
 
		massa_mask = "features/auto/r/V #{get_raw_feature_name_from_feature_file(ri_arq_feature)}*.xls"
		write_rsi_log :debug, "consumidor_de_features.rb, reprocessamento, P01 - massa_mask=#{massa_mask}"
		arq_massa = Dir[massa_mask].first
		ri_hash_massa = ler_xls_com_id(arq_massa)
		write_rsi_log :debug, "consumidor_de_features.rb, reprocessamento, P01 - ri_hash_massa=#{ri_hash_massa}"
		ri_feat_dir = param_feat_dir
		write_rsi_log :debug, "consumidor_de_features.rb, reprocessamento, P01 - ri_feat_dir=#{ri_feat_dir}"
		ri_massa_dir = 'massas_feature'
		write_rsi_log :debug, "consumidor_de_features.rb, reprocessamento, P01 - ri_massa_dir=#{ri_massa_dir}"
		reinsere_clone_reproc_feature(ri_arq_feature, ri_json_steps, ri_hash_massa, ri_feat_dir, ri_massa_dir)
	end

  	del_exes_ahk_processo #2017Set20, CLEANUP de executaveis auto-hotkey
end 
write_rsi_log :debug, "Processamento do filho concluido"
