#
#BLA_SEND_CFG.Rb !!!
	zs_dummydisk = "z:"
	#zs_dummydisk = "c:"
	#zs_dummydisk="\\\\bsbrsp1010/evidencias/rbattaglia"
	#zs_dummydir = "zrede_aux"
	zs_dummydir = "zs/zs_a"

	zs_dummycfg_basedir = "#{zs_dummydisk}/#{zs_dummydir}"

	$zs_cfg = {
		#:dir_reports_consolidados => '\\\\bsbrsp1010/Evidencias/aberturaccpf/reports',
		:dir_reports_consolidados => 'z:/consolid_tst/2018Abr18_tst',

		#:maq => get_alphanumeric('Renato').to_sym,  #NOME tem que ser alphanumerico !!!
		#:maq => get_alphanumeric('Renato').to_sym,  #NOME tem que ser alphanumerico !!!
		:maq => get_alphanumeric("#{get_automdir}".downcase.gsub('autom', 'mx').gsub('ar','mx')).to_sym, #gambiarra de 

		:steps_iniciais_habilitados => [0,9,10], #2018Abr04 - LFTRUNTIME.EXE NAO ESTÀ SUBINDO EM VM DE RENATO! NAO SEI A CAUSA!! DESABILITANDO TFC EM MAQ RENATO!! ###maq do Diogo, sem pasta (9), Maqs completas = [0,9,10]. Maq do Renato em mar16-sem TFC=[0.9]. Entao, maqs de Diogo e Renato se completam, sendo q Diogo fica com carga maism pesada do TFC. DIOGO 2018Mar19 - caiu o privilegio de admin, SEM TFC nem pasta (que ja nao tinha, pois LDAP nao configurado p Diogo)
		#pra DIGGO = [0,10],sem pasta
		#pra Will=[0,9]=sem tfc


		:tfc_usuario => 'T802blablaHA1', #T802HA8=usu tfc de Renato
		#2018Mar30 10:30am, TFC_SENHAS, Hash Usuario=>Senha, criar, escolher apenas usuario. T*02HA8=treina04, das outras, é 03treina !
		:tfc_senha => '03treinablabla',


		:minutos_timeout_esperando_chosen => 5,
		:minutos_timeout_esperando_allchosen => 10,
		:cpfs_risco_fullpath => "#{zs_dummycfg_basedir}/cpfs_risco.xls", #DESABILITADA A GAMBI #gambiarra pra contornar estranho erro SYSOPEN EINVAL em executa_exclusivo ao criar File.open("w") o arquivo de LOCK na rede!! Mandarei um cpfs_risco parcial para cada uma das máquinas executoras
		:cpfs_risco_lockfile => "#{zs_dummycfg_basedir}/LOCK_OBTER_CPF_RISCO.LCK",

		:dirs_rede => [
			# SEM ESPELHAMENTO, AGORA! FUTURO=espelhamento, escreve/lê sempre de dois ou mais dirs. ??? OU... pesquise espelhamento realmente robusto.
			{ # [0]
				:full_path => zs_dummycfg_basedir,
				:disk_quota_mb => 0.3, #quota baixissima, pra provar o que rola quando enche
				:min_free_mb => nil #nil=sem limite
			}
=begin
#
#
# GAP TÈCNICO: apenas um diretório, por enquanto. Dependo de comportamento de "CRIAR ARQUIVO VIA LOW-LEVEL API QUE DÊ ERRO SE JÀ EXISTIR", e isso não seria possível com espelhamento de diretórios!!!
#
			,{ #[1]
				:full_path => '\\\\bsbrsp1010/evidencias/rbattaglia/zs/zs_b',
				:disk_quota => 1024, #1024 megabytes, cota tolerante
				:min_free_mb => 685 #2017Dez6 22:47 tinha 686253 mb livres, também estoura logo
			},
			{ #[2]
				:full_path => '\\\\bsbrsp1010/evidencias/rbattaglia/zs/zs_c',
				:disk_quota => 1024, #1024 megabytes, cota tolerante
				:min_free_mb => 512 #2017Dez6 - nao podemos tomar diskspace compartilhado
			}
=end
		],
		:paralelismo => 1, #4 browsers como default. Antes de 2018Mare31, eu tava tentando paralelismo 6 e qt_deatures 12.
		:qt_features => 2, #10=bom qt_features p 20 minutos de timeout chosen em DEMO p Banco!! # Deve ficar entre 2x e 3x paralelismo. HI-SPEED AND RISK=5x. Quanto mais alto qt_features, menos overhead temos da subida inicial de TFC x automação. Porém, em caso de crash do servidor e/ou zs_proc, temos mais features/cenários que ficarão sem executar a não ser que HEALING/reprocessamento/whatever seja ativado/implementado.
		:automdir => "#{get_automdir}".downcase.gsub('autom', 'zrdir').gsub('ar','zrdir'), #gambiarra de debug SEM cmd_configs da vida: basta haver diretorio previamente instalado com os fontes da automacao... um diretorio é do PROCESSO (c:\autom OU ar, c:\autom2 OU ar2, c:\automN OU arN), e o DIR de execucao deve se chamar c:\sr_dir, c:\zr_dir2, c:\zedir_x e por aí vai !!! E, enquanto nao temos comando cmd_source, temos que ´pré-instalar c:zrdir etc. SEM CRISE, pra POC tá bom! 
		:sourcedir => '.', ### DEVE SER ALTERADO quando formos enviar fontes distintos
		:lang => 'en'
	}
