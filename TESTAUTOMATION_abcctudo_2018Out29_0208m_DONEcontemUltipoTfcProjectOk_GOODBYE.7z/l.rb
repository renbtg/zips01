load './pra_console.rb'
def faz_seis_passos
	fazer_login; chama_passo PrimeiroPasso; chama_passo SegundoPasso; chama_passo TerceiroPasso; chama_passo QuartoPasso; chama_passo QuintoPasso; chama_passo SextoPasso
end
def faz_todos_passos
	fazer_login; chama_passo PrimeiroPasso; chama_passo SegundoPasso
	chama_passo TerceiroPasso; chama_passo QuartoPasso; chama_passo QuintoPasso
	chama_passo SextoPasso
	chama_passo EnvioDaSolicitacao
end


#!/usr/bin/ruby

def func1
   i = 0
   while i<=2
      puts "func1 at: #{Time.now}"
      sleep(2)
      i = i+1
   end
end

def func2
   j = 0
   while j<=2
      puts "func2 at: #{Time.now}"
      sleep(1)
      j = j+1
   end
end

def tfunc
	puts "Started At #{Time.now}"
	t1 = Thread.new{func1()}
	t2 = Thread.new{func2()}
	t1.join
	t2.join
	puts "End at #{Time.now}"
end


def processo_estah_vivo? pid
puts "devo ter array com processos_pids vivos que eu SPAWNEEI"
	begin
	  Process.getpgid( pid )
	  true
	rescue Errno::ESRCH
	  false
	end
end





def test_reabre_2017SetLate(tpn, paralelismo=3)
	ENV['TEST_PROCESS_NUM']=tpn.to_s
	ENV['TEST_PARALELISMO']=paralelismo.to_s
	5.times do |k|
		log_chrome_port
		abre_janela_browser
		log_chrome_port
		visit 'c:'
		log_chrome_port
		fecha_janela_browser
		log_chrome_port
		uri=Capybara.page.driver.inspect.split("")
		log_chrome_port
		write_rsi_log :debug, "Sessao URI"
		log_chrome_port
		sleep 10
		log_chrome_port
		reabre_janela_browser
		log_chrome_port
		begin
			log_chrome_port
			Capybara.page.driver.visit 'https://en.wikipedia.org/wiki/Main_Page'
			log_chrome_port
		rescue Exception =>e
			log_chrome_port
			write_rsi_log :debug, "Excecao #{e} em visit wikipedia"
			next
		end

		begin
			log_chrome_port
			Capybara.page.driver.has_content? 'abracadabra'

=begin	
			NAO ADIANTOU NADA, CONTINUA se perdendo (sendo roubado?) a Sessao
				prefixiar cmd com Capybara.page.driver foi VÂ ESPERANÇÂ!!
			EM VEZ DE page.save_screenshot ?????????????? SERAH? 2017Set18 19:31
			
				ENTAO... ACABEI de visitar, mandei imprimir porta, dá um valor.


			AÍ.
			:_OBTENHO_ESTUPIDA_EXCECAO_DE_QUE_TENTOU_127_0_0_1_EM_OUTRA_PORTA,
			ou até mesmo
			:END_OF_FILE_REACHED
			que no fim das contas
			:DAO_NO_MESMO_POIS_EOF_PODE_SER_leuDecaraErrado

			** TODO TOP - COMO FAZER PRO DESGRACIATO FAZER has_content etc. E save_screenshot
			NO driver/bla CORRETO?

			** TODO TOP - COMO deixar isso transparente pra meus PageObjects??
=end


			log_chrome_port
		rescue Exception =>e
			log_chrome_port
			write_rsi_log :debug, "Excecao #{e} em has_content?"
			next
		end

		begin
			log_chrome_port
			Capybara.page.driver.save_screenshot "#{ENV['TEST_PROCESS_NUM']}.#{Time.now.to_f.to_s}.png" 
		
			log_chrome_port
		rescue Exception=>e
			log_chrome_port
			write_rsi_log :debug,"Excecao #{e} em save_screenshot"  
		end
		log_chrome_port
		fecha_janela_browser
		log_chrome_port
	end
end

def teste_queima_cpf
	zs_read_cfgs
	set_massa_cen 'V Nice1000XRnd5001100SnvrstrCntnvrstrSNTNDRPLYMltplCsdguid4d6f95cc'
	fullpath_cpfs_risco = $zs_cfg[:cpfs_risco_fullpath]||'cpfs_risco.xls'
	ENV['TEST_XLS_CPFS_RISCO']=fullpath_cpfs_risco
	lockfile_cpfs_risco = $zs_cfg[:cpfs_risco_lockfile]||'LOCK_OBTER_CPF_RISCO.LCK'
	ENV['EST_LOCKFILE_CPFS_FISCO']=lockfile_cpfs_risco

	$a_teste_queima_cpf = [] if not $a_teste_queima_cpf
	ant = ler_xls_com_id(get_xls_cpfs_risco, nil, nil, -1) 
	$massa['CPF']='obterorisco'
	deve_queimar_cpf = reserva_cpf_pra_massa()
	queima_cpf_da_massa
	novo = ler_xls_com_id(get_xls_cpfs_risco, nil, nil, -1)
	puts $massa['CPF']
	puts ant - novo
	$a_teste_queima_cpf << $massa['CPF']
	{
		:a_teste_queima_cpf => $a_teste_queima_cpf,
		:ant_menos_novo => ant - novo,
		:massa_cpf => $massa['CPF'] 	
	}
end

def queima_zpfs_de_netdir
	cpfs_de_netdir = [
	'11354727185',
	'11612214177',
	'12055369148',
	'12651143154',
	'13191073116',
	'13718749130',
	'13724482175',
	'14406552197',
	'15126803115',
	'15243028134',
	'16516225150',
	'16828491122',
	'17075887165',
	'17217136113',
	'17324506178',
	'17945813160',
	'18073364174',
	'18150779132',
	'18324134115',
	'18433683152',
	'18941375150',
	'19135557125',
	'19484827110',
	'19745241164',
	'21518023100',
	'21808543157',
	'22261217145',
	'22744243140',
	'22827466198',
	'22872017186',
	'23275555154',
	'23347427165',
	'25472496187',
	'25766471114',
	'26744276123',
	'27152670102',
	'27911187134',
	'29504557198',
	'32042943150',
	'33034215100',
	'33144244180',
	'33567331175',
	'35412150110',
	'35549563177',
	'36534312123',
	'36753664130',
	'37288825183',
	'39584076175',
	'40425128105',
	'40519363175',
	'41272712133',
	'41861375107',
	'42269398165',
	'43407287135',
	'44306622150',
	'45196208135',
	'45535650137',
	'46346389165',
	'47119115103',
	'47132515187',
	'47515555106',
	'47876474152',
	'48025844153',
	'48666289104',
	'50565944150',
	'50899827160',
	'51130726134',
	'51336331143',
	'51663831173',
	'52029828106',
	'52718143193',
	'53745347188',
	'54124688105',
	'54154942190',
	'54375544198',
	'55220797115',
	'55475857180',
	'57284116145',
	'57358431170',
	'57511426166',
	'57605787154',
	'58182668182',
	'58381575184',
	'59143650155',
	'59792695176',
	'60343774127',
	'61938735110',
	'62121416145',
	'62673130187',
	'62686284110',
	'62811472193',
	'63443341187',
	'63453659120',
	'63713276153',
	'64538353124',
	'64668646180',
	'64759822100',
	'64800812186',
	'64856746162',
	'65283654150',
	'67369765105',
	'69897159100',
	'70231134100',
	'71471320170',
	'72103452135',
	'72443464172',
	'72616537133',
	'72656821142',
	'72932536133',
	'73837783162',
	'74050048140',
	'76842533104',
	'77055910145',
	'77335966108',
	'77378425192',
	'80122493168',
	'80413633187',
	'81076116167',
	'81212608178',
	'82088619100',
	'83826109198',
	'85286176100',
	'85297342112',
	'85531436190',
	'87874616170',
	'88118095177',
	'88297750108',
	'89497181116',
	'89838415162',
	'91417399147',
	'92168146160',
	'92578657114',
	'93186742102',
	'94170681134',
	'98678174196',
	'99148438162',
	'99335647144',
	'99746559192'
]

	zs_read_cfgs
	set_massa_cen 'V Nice1000XRnd5001100SnvrstrCntnvrstrSNTNDRPLYMltplCsdguid4d6f95cc'
	fullpath_cpfs_risco = $zs_cfg[:cpfs_risco_fullpath]||'cpfs_risco.xls'
	ENV['TEST_XLS_CPFS_RISCO']=fullpath_cpfs_risco
	lockfile_cpfs_risco = $zs_cfg[:cpfs_risco_lockfile]||'LOCK_OBTER_CPF_RISCO.LCK'
	ENV['EST_LOCKFILE_CPFS_FISCO']=lockfile_cpfs_risco

	rcpfs = ler_xls_com_id(get_xls_cpfs_risco, nil, nil, -1)
	mudou = false
	rcpfs.each do |lc|
		if lc['PROCESSADO'].to_i != 0 #ignora apenas os ja marcados como processados
			#puts 'ja processado'
			next
		end

		#if lc['PROCESSADO'].to_i == -1
		#	raise "-1 para lc=#{lc}"
		#end

		h_found =  cpfs_de_netdir.bsearch {|c| c == lc['CPF']}

		if h_found
			write_rsi_log :debug, "h_found=#{h_found} para lc=#{lc}, DEVE MARCAR COMO JA PROCESSADO"
			#break
			lc['PROCESSADO'] = '1'
			mudou = true
		else
		#	puts "h_found NOT para #{lc}"
		end
	end

	if mudou
		write_rsi_log :debug, "reescrevendo #{get_xls_cpfs_risco}"
		reescreve_xls_risco(get_xls_cpfs_risco, rsk_cpf_cols, rcpfs)
	end
	nil
end
