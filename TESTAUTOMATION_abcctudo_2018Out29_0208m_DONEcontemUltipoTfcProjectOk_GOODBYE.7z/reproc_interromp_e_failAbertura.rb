require_relative './rotinas_processo.rb'

def deve_reprocessar(feature_name, all_outputs)
	if false
		return "reprocessando todo mundo na marra"
	end


	retval = nil
			
	razao_result=nil

	#write_rsi_log "all_outputs=#{all_outputs}, all_outputs.last=#{all_outputs.last}"
	

	#all_feat_files_and_trn=all_outputs.map{|o| {o[:trn]=>o[:outputs][:feature]}}
	#write_rsi_log "all_feat_files_and_trn=#{all_feat_files_and_trn}"



	#write_rsi_log "ffile_best=#{ffile_best}"

	maxtrn = all_outputs.max{|o1,o2| o1[:trn] <=> o2[:trn]} [:trn] #2017Set01, FIX, "[:trn]" ao fim!!
	maxtrn_passed = nil

	max_step_passed = -1
	max_step = -1

	all_outputs.each { |o|
		o[:outputs][:steps].each_index { |k|
			if k >= max_step #DUMMY, conta steps
				max_step = k
			end

			stp = o[:outputs][:steps][k]
			
			if "#{stp['result']['status']}" == 'passed'
				if k >= max_step_passed #>=, privilegia mais recente reexecucao com mesma condicao
					max_step_passed = k
					maxtrn_passed = o[:trn]
				end
			end
		}
	}
	best_trn = maxtrn_passed || maxtrn
	best_output = all_outputs.select{|o|o[:trn]==best_trn} [0]
	write_rsi_log :debug, "maxtrn=#{maxtrn}, best_trn=#{best_trn}, maxtrn=#{maxtrn}"
	write_rsi_log :debug, "max_step=#{max_step},max_step_passed=#{max_step_passed}"
	write_rsi_log :debug, "best_output=#{best_output}"
	write_rsi_log :debug, "best_output[:outputs]=#{best_output[:outputs]}"
	write_rsi_log :debug, "best_output[:outputs][:feature]=#{best_output[:outputs][:feature]}"
	ffile_best = best_output [:outputs][:feature]


	# AQUI.sei QUAL O MAX STEP OK (max_step_passed), em qual trn (maxtrn_passed)
	if max_step_passed == max_step
		write_rsi_log :info, "reproc_BLA.rb: nao precisa reprocessar, 100 pct ok, feature_name=#{feature_name}, ffile_best=#{ffile_best}, PORQUE max_step=#{max_step_passed} EH IGUAL A #{max_step}"
		return nil #significa ALGUMA EXECUCAO FUNCIONOU ATEH ULTIMO STEP, 100% OK
	end


	if ffile_best.include? 'interrompid'
		#write_rsi_log :debug, "reproc_BLA.rb: ULTIMA INTERORMPIDA. ffile_best=#{ffile_best}"
		razao_result="interrompida" 
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end
	
	o=best_output
	stt = ''
	begin
		stt=o[:outputs][:steps] [0]['result']['status'] if o[:outputs][:steps]
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end
	if stt == 'failed' #falhou
		razao_result = "Passo zero, o mais inicial: passo[0], vulgo Login/visitar, nao passou"
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end

	o=best_output
	stt = ''
	begin
		stt=o[:outputs][:steps] [1]['result']['status'] if o[:outputs][:steps]
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end
	if stt == 'failed' #falhou
		razao_result = "Passo de Abertura: passo[1], vulgo PassoUm, nao passou"
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end

	o=best_output
	stt = ''
	begin
		stt=o[:outputs][:steps] [3]['result']['status'] if o[:outputs][:steps]
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end			
	if stt=='failed'
		razao_result = 'passo3: falhou, por qualquer razao, talvez, fileupload'
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end

	o=best_output
	msg = ''
	begin
		msg=o[:outputs][:steps] [4]['result']['error_message'] if o[:outputs][:steps]
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end			
	if (msg||'').include? 'elemento botao_quero_essa nao estah presente'
		razao_result = 'passo4: elemento botao_quero_essa nao estah presente'
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end

	o=best_output
	msg = ''
	begin
		msg=o[:outputs][:steps][max_step_passed+1]['result']['error_message'] 
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end			
	if (msg||'').include? 'Elemento de botao salvar nao estah presente na tela'
		razao_result = "Passo #{max_step_passed+1} - Elemento de botao salvar nao estah presente na tela"
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end

	o=best_output
	msg = ''
	begin
		msg=o[:outputs][:steps][max_step_passed+1]['result']['error_message'] 
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end			
	if (msg||'').include? 'ncompatible character encodings'
		razao_result = "Passo #{max_step_passed+1} - incompatible character encodings"
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end

	o=best_output
	msg = ''
	begin
		msg=o[:outputs][:steps][max_step_passed+1]['result']['error_message'] 
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end			
	if (msg||'').include? 'Elemento label_passo_4 nao estah presente na tela'
		razao_result = "Passo #{max_step_passed+1} - Elemento label_passo_4 nao estah presente na tela"
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end

	o=best_output
	msg = ''
	begin
		msg=o[:outputs][:steps][max_step_passed+1]['result']['error_message'] 
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end			
	if (msg||'').include? 'LOCK EXCLUSIVO nao obtido depois de '
		razao_result = "Passo #{max_step_passed+1} - LOCK EXCLUSIVO nao obtido"
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end

	o=best_output
	msg = ''
	begin
		msg=o[:outputs][:steps][max_step_passed+1]['result']['error_message'] 
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end			
	if (msg||'').include? 'stale element reference'
		razao_result = "Passo #{max_step_passed+1} - stale element reference"
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end


	o=best_output
	msg = ''
	begin
		msg=o[:outputs][:steps][max_step_passed+1]['result']['error_message'] 
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end			
	if (msg||'').include? 'run_autohk_copia: execucao nao concluida no tempo limite'
		razao_result = "Passo #{max_step_passed+1} - run_autohk_copia: execucao nao concluida no tempo limite"
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end

	o=best_output
	msg = ''
	begin
		msg=o[:outputs][:steps][max_step_passed+1]['result']['error_message'] 
	rescue Exception => e
		write_rsi_log :warn, "reproc_BLA.rb: nao foi possivel obter steps"
	end			
	if (msg||'').include? 'fazendo alguns ajustes'
		razao_result = "Passo #{max_step_passed+1} - desculpe-nos, estamos fazendo alguns ajustes"
		write_rsi_log :debug, "reproc_BLA.rb:  vai reprocessar, razao_result=#{razao_result}, feature_name=#{feature_name}, ffile_best=#{ffile_best}"
		return razao_result
	end

	write_rsi_log :info, "reproc_BLA.rb: CASE ELSE FINAL, nao precisa reprocessar, feature_name=#{feature_name}"
	return nil
end

def qual_trn_reportar(feature_name, all_outputs)
	maxtrn = all_outputs.max{|o1,o2| o1[:trn] <=> o2[:trn]}
	maxtrn_passed = nil

	max_step_passed = -1
	all_outputs.each { |o|
		o[:outputs][:steps].each_index { |k|
			stp = o[:outputs][:steps][k]
			
			if "#{stp['result']['status']}" == 'passed'
				if k >= max_step_passed #>=, privilegia mais recente reexecucao com mesma condicao
					max_step_passed = k
					maxtrn_passed = o[:trn]
				end
			end
		}
	}

	return maxtrn_passed || maxtrn
end