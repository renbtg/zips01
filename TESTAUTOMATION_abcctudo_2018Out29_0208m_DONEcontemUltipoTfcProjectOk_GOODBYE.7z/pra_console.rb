require 'rspec'
require 'cucumber'
require 'selenium/webdriver'
require 'capybara/dsl'
require 'site_prism'

load 'features/support/shared_utils.rb'
load './rotinas_processo.rb'
load './risco_cpfs.rb'
load './cpf_utils.rb'
load './tfc.rb'
load 'zs/zs_proc.rb'
load 'features/support/interrupcoes.rb'
load 'features/support/rsi_log.rb'
load 'features/support/basic_utils.rb'
load 'features/support/rsi_utils.rb'
load 'features/support/rsi_spreadsheet.rb'
load 'features/support/methods_of_app_life_cycle_hooks.rb'

load 'features/page/AcessarPastaDigital.rb'
load 'features/page/AcessarPad.rb'

load 'features/page/webdesk/WebDeskAcessarAbertura.rb'
load 'features/page/webdesk/WebDeskPrimeiraParte.rb'
load 'features/page/webdesk/WebDeskSegundaParte.rb'
load 'features/page/webdesk/WebDeskTerceiraParte.rb'
load 'features/page/webdesk/WebDeskQuartaParte.rb'
load 'features/page/webdesk/WebDeskQuintaParte.rb'
load 'features/page/webdesk/WebDeskSextaParte.rb'
load 'features/page/webdesk/WebDeskEnvioDeSolicitacao.rb'
load 'ipc_processo.rb'
load 'rotinas_processo.rb'

def rotina_de_interrupcao_em_log
	checa_interrupcoes do |msg|
		write_rsi_log :debug,  msg
	end
end

def fazer_login(url=nil)
	if $massa['QUALAPP']=='mob'
		aberturaContaDigital = AberturaContasDigital.new
		aberturaContaDigital.acessarLink url
		aberturaContaDigital.iniciarAbertura
	else
		WebdesktopAcessarAbertura.new.processa		
	end
end

def chama_alguns_passos(a)
	a.each do |i|
		write_rsi_log "chamando passo #{i}"
		chama_passo i
	end

end

def chama_passo(classe_passo)
	$numero_step_atual = classe_passo if classe_passo.class == Fixnum
	write_rsi_log "chama_passo, parametro classe_passo=#{classe_passo}"
	

	write_rsi_log "P00 classe_passo.to_s=#{classe_passo.to_s}"
	if classe_passo.is_a? Fixnum and classe_passo >= 8
		if classe_passo == 8
			(status, msg_excecao) = espera_status_veracidade
			return [status, msg_excecao]
		elsif classe_passo == 9
			pastaDigital = AcessarPastaDigital.new
			pastaDigital.acessarPasta
			pastaDigital.iniciarBusca
			pastaDigital.analiseDocumentacoes
		elsif classe_passo == 10
			tfc_faz_automacao_do_cenario
		else
			falhar 'pra_console.rb :::: chama_passo -> classe_passo numerica invalida' 
		end
	end
	write_rsi_log "P01 classe_passo.to_s=#{classe_passo.to_s}"


	if classe_passo.is_a? Fixnum
	
		if $massa['QUALAPP']=='webdesktop'
			classe_passo = case classe_passo
				when 0 then WebdesktopAcessarAbertura
				when 1 then PrimeiraParte
				when 2 then SegundaParte
				when 3 then TerceiraParte
				when 4 then QuartaParte
				when 5 then QuintaParte
				when 6 then SextaParte
				when 7 then WebdesktopEnvioDaSolicitacao
				else nil
			end
		elsif
			classe_passo = case classe_passo
				when 0 then AberturaContasDigital
				when 1 then PrimeiroPasso
				when 2 then SegundoPasso
				when 3 then TerceiroPasso
				when 4 then QuartoPasso
				when 5 then QuintoPasso
				when 6 then SextoPasso
				when 7 then EnvioDaSolicitacao
				else nil
			end
		else
			if classe_passo == 8
				(status, msg_excecao) = espera_status_veracidade
			elsif classe_passo 

			end
		end
		 
	end
	write_rsi_log "P02 classe_passo.to_s=#{classe_passo.to_s}"

	classe_passo.new.processa if classe_passo and classe_passo.class == Class 
end
