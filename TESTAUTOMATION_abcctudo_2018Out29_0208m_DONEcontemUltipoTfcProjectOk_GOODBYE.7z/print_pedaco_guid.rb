require_relative 'features/support/shared_utils.rb'
#Nao posso, nem quero, deixar que mesma feature_name seja distribuída pra 2 ou mais máquinas!!
#puts "ARGV=#{ARGV}"
if ARGV.length >= 1
	puts obtem_alphanum_guid ARGV[0].to_i #obtem_id_maquina
else
	puts obtem_alphanum_guid 
end