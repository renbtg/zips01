require_relative 'features/support/rsi_log.rb'

def profile_block(l)
	retval = nil
	
	tini = Time.now
	begin
		retval = l.call
	rescue Exception => e
		write_rsi_log :error, "profile_block interceptou excecao, e.class=#{e.class}, e.message=#{e.message}, e.backtrace=#{e.backtrace}"
		falhar e
	end
	tfim = Time.now
	profile_duracao = tfim - tini
	write_rsi_log :debug, "profile_block, chamadora=#{caller[0]}, profile_duracao=#{profile_duracao}"
	return retval
end

def zzzz_minha_func
	zzzz_base_func
end

def zzzz_base_func
	profile_block lambda {
		puts 'essa eh o minha func'
		sleep 10
		return 33
	}
end

#zzzz_minha_func