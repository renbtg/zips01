# encoding: UTF-8
require './rotinas_processo.rb'

def rotina_de_interrupcao_em_log
	#2018Abr20 - adicionado método "rotina_de_interrupcao_em_log" para rápida morte
	checa_interrupcoes do |msg|
		write_rsi_log :debug,  msg
	end
end

join_trns
