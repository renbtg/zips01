require  'os'
require_relative  './rsi_spreadsheet.rb'

def get_test_process_num
	return get_process_num
end

def is_str_integer?(str)
	return false if not str
	return str.scan(/\D/).empty?
end
def is_str_alpha?(str)
	return false if not str
	return str.match(/^[[:alpha:]]+$/) != nil
end
def is_str_alphanumeric?(str)
	return false if not str
	return str == get_alphanumeric(str)
end

def get_alphanumeric(str)
	return nil if not str
	return str.gsub(/[^0-9a-z]/i, '')
end

def get_alphanumcenario(nome_cenario)
	#NUNCA EM HIPOTESE NENHUMA CHAm write_rsi_log aqui, pois write_rsi_log chama esta rotina!
	retval=""
	begin
		if ENV['TEST_ALPHANUM_FEATURENAME']
			retval = "V #{ENV['TEST_ALPHANUM_FEATURENAME']}"
		else
			alphacen = 'V ' + get_alphanumeric( nome_cenario[('V '.length)..(-1)])
			retval = alphacen
		end
	rescue StandardError #=> e
		#nada
	end
	return retval
end



def get_paralelismo
	return (ENV['TEST_PARALELISMO']||'1').to_i
end

def get_process_num
	return (ENV['TEST_PROCESS_NUM']||'1').to_i
end

def get_test_reabertura_rapida 
	#2017Set29, talvez sempre true para Veracidade/PastaDigutal em larga escala 
	return ((ENV['TEST_REABERTURA_RAPIDA']||'0').to_i)==1 #2017Out18 - default=SEM REABERTURA RÀPIDA
end


def get_tpn_do_arq_slot(arq)
	tpn=arq.split('TPN_').last.split('_').first.to_i
	return tpn
end

def get_slot_do_arq_slot(arq)
	slot=arq.split('JANELA_').last.split('.LCK').first.to_i
	return slot
end

def get_handle_da_janela_do_tpn(tpn=nil)
	tpn = tpn || get_process_num
	arq=get_arq_slot_da_janela(tpn)
	handle=get_handle_do_arq_slot(arq)
	return handle
end

def get_handle_do_arq_slot(arq)
	browser_handle_janela = File.read(arq)
	return browser_handle_janela
end

def get_arq_slot_da_janela(tpn=nil)
	tpn = tpn || get_process_num
	slot_file = Dir["#{get_automdir}/TPN_#{tpn}_SLOT_JANELA_*.LCK"].first
	return slot_file
end


def get_num_processo_janela(slot)
	arq = Dir["#{get_automdir}/TPN_*_SLOT_JANELA_#{slot}.LCK"].first
	return nil if not arq
	retval = get_tpn_do_arq_slot(arq)
	return retval
end

def get_num_janela_processo(tpn=nil)
	tpn = tpn || get_process_num
	arq = Dir["#{get_automdir}/TPN_#{tpn}_SLOT_JANELA_*.LCK"].first
	return nil if not arq
	retval = get_slot_do_arq_slot(arq)
	return retval
end

def get_arq_rectangle_do_slot
	slot = get_num_janela_processo
	return "#{get_automdir}/PARALELISMO_#{get_paralelismo}_SLOT_#{slot}_RECTANGLE.DAT" 
	#extensao .DAT nao eh removida automaticamente por iniciadores de processo.
	#  ISTO PERMITE que usuário decida posicoes de rectangle de browser boas pra ele,
	# e preserve essas posicoes entre execucoes de reinicia_execucao.bat etc. !
end


def obtem_guid
 	real_guid=SecureRandom.uuid
 	return real_guid
end

def obtem_alphanum_guid(nchars=nil)
 	if nchars==0
 		nchars=nil
 	end
 	real_guid=obtem_guid
 	fullguid= real_guid.gsub('-','')
 	nchars=nchars || (fullguid.length)
 	#puts "fullguid=#{fullguid}"
 	#puts "nchars=#{nchars}"
 	return fullguid[(-1*nchars)..-1]
end
 	
def obtem_guid_reduzido()
 	real_guid=obtem_guid
 	return real_guid.split('-').last[-3..0]
end


def delete_all_in_dir(dir_path)
	#write_rsi_log :debug, "delete_all_in_dir pra dir_path=#{dir_path} chamada" 
	FileUtils.rm_rf Dir.glob("#{dir_path}/*")
end	

def criadir_senaoexistir(some_path)
	FileUtils.mkdir_p(some_path)
end
def mkdir_noexist(some_path)
	FileUtils.mkdir_p(some_path)
end

def get_automlanguage
	#Pra VM do Renato, Huaweii, por exemplo, deve set TEST_LANG=en
	return ENV['TEST_LANG'] || 'pt'
end

def get_automdir()
	planilhas_e_controles='planilhas e controles'
	diretorio=ENV['TEST_AUTOMATION_DIR'] 
	if not ENV['TEST_AUTOMATION_DIR']
		#2017Set28 - adicionado usar diretorio corrente ou, se estiver em planilhas, o ".."
		diretorio = diretorio || Dir.pwd 
		if diretorio.include? "/#{planilhas_e_controles}"
			diretorio = diretorio.split("/#{planilhas_e_controles}").last 
		end
		#raise 'get_automdir - INDEFINIDO!' if not diretorio
		diretorio = diretorio.gsub("\\","/") #trata barra invertida

		ENV['TEST_AUTOMATION_DIR']=diretorio
	end 
	
	return ENV['TEST_AUTOMATION_DIR']
end

def get_automdir_barra()
	return get_automdir + '/'
end

def get_automtmpdir
	return  ENV['TEST_TMP_DIR'] || "#{get_automdir}/tmp"	
end

def salva_arquivo_xls(xls_file, colnames, hash_array)
	sep=';'

	if colnames == nil
		todas_chaves=[]
		hash_array.each do |h| 
			# nao podemos ter linhas com hash de strutura diferente
			todas_chaves = todas_chaves | h.keys
		end
		hash_array.each do |h|
			#equalizamos aqui os hashs, devem todos ter as mesmas chaves
			chaves_ausentes = todas_chaves - h.keys
			chaves_ausentes.each do |ausente|
				h[ausente] = '' #adiciona chave ausente, sel valor
			end 
		end
		colnames = todas_chaves
		n_hash_array = Array.new
		hash_array.each do |h|
			#remonta o hash array com dodas as chaves presentes e em mesma ordem
			nh = Hash.new
			colnames.each do |colname|
				nh[colname] = h[colname]
			end
			n_hash_array << nh
		end
		hash_array = n_hash_array

	end

	dir_arqs=File.dirname xls_file
	nome_xls = dir_arqs + '/' + File.basename(xls_file)
	nome_csv = dir_arqs + '/' + File.basename(xls_file,'.xls')+'.'+obtem_alphanum_guid+".csv"
	# nao usa diretorio, sempre em Planilhas e Controles

	#write_rsi_log :debug, "reescreve_xls_risco: nome_xls=#{nome_xls}, nome_csv=#{nome_csv}"
	f_m=nil
	begin
	 	f_m = File.open(nome_csv, "wt")

		f_m.puts colnames.join(';')

		hash_array.each do |linha|
			vlrs = Array.new
			colnames.each do |col|
				#write_rsi_log :debug, "adicionando col=#{col}"
				#write_rsi_log :debug, "adicionando linha=#{linha}"
				vlrs << linha [col]
			end
			f_m.puts vlrs.join ';'
		end
	rescue StandardError => e
		f_m.close if f_m != nil
		falhar e
	ensure
		f_m.close if f_m != nil
	end

	book = Spreadsheet::Workbook.new
	sheet1 = book.create_worksheet
	header_format = Spreadsheet::Format.new(
	  :weight => :bold,
	  :horizontal_align => :center,
	  #:bottom => true, #exemplo q vi bottom invalido
	  :locked => true
	)
	sheet1.row(0).default_format = header_format
	#system 'type csv_massa.txt'
	#write_rsi_log :debug, "vai manipular csv"
	CSV.open(nome_csv, 'r', :col_sep=>sep) do |csv|
		csv.each_with_index do |row, i|
	    	#write_rsi_log :debug, "manipulando linha #{i}"
	    	sheet1.row(i).replace row
	  	end
	end
	FileUtils.rm nome_csv
	book.write(nome_xls)
	return
end

def comando_sistema(s_cmd, extrap={:cmd_type => :system})
#2018Set01 - created
#TODO 2018Set01 - adicionar opcao :cmd_type==:spawn, com controle de timeout. Nao deve aceitar spawn sem timeout? Talvez... talvez, deva aceitar, só que precisaria de BLOCK a ser executado em cada iteracao de checagem, algo assim.

	raise "comando_sistema, apenas opcao :system sem timeout implementada até 2018Set01" if not (extrap and extrap.is_a? Hash and extrap.keys.length == 1 and extrap[:cmd_type]==:system)
	cmd_out_txt = "#{get_automtmpdir}/cmd_output_#{obtem_alphanum_guid(6)}.txt".gsub('/','\\')
	#2018Out8 - bugfix, cmd_out_txt deve usar barras invertidas '\' do Windows
	full_cmdline = "#{s_cmd} > #{cmd_out_txt} 2>&1"
	write_rsi_log :debug, "comando_sistema(s_cmd=#{s_cmd}), full_cmdline=#{full_cmdline}"
	system full_cmdline #TENHO: TRN1 anterior unzipado em diretorio temporario  
	o = File.read cmd_out_txt if File.exist? cmd_out_txt
	FileUtils.rm cmd_out_txt if File.exist? cmd_out_txt
	return o
end

def ignora_excecoes(exc_class_array=[StandardError]) 
	#2018Set02, method created
	raise 'ignora_excecoes, parametro exc_class_array invalido' if not (   exc_class_array and exc_class_array.is_a?(Array) and (not exc_class_array.any? {|c|not c.is_a? Class})   )
	raise 'ignora_excecoes, nenhum block de codigo passado' if not block_given?
	retval = nil
	begin
		retval = yield
	rescue StandardError => e 
		if exc_class_array.any? {|c|e.is_a? c}
			nil
		else
			raise e
		end
	end
	return retval
end

def timestamp_str(t)
#created, 2018Set29
	return t.strftime('%Y%m%d%H%M%S')
end
def time_from_str(str, adj_tz=" -2")
#created, 2018Set29
	return time_from_str(str, adj_tz)
end
def ts_zeros
#created, 2018Set29
	return strzero(0,14)
end
def ts_hivalues
#created, 2018Set29
	return '20380118201407'
	 #Mon Jan 18 20:14:07 MST 2038, the maximum timestamp in ruby. Poderia ser strzero(9,14), creio eu, já que ts_zeros também tem funcionado!
end
def ts_now
#created, 2018Set29
	return "#{timestamp_str(Time.now)}"
end
