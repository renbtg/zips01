require 'logger'
require 'FileUtils'
require_relative './rsi_utils.rb'
require_relative './shared_utils.rb'
require_relative './interrupcoes.rb'
#require_relative './shared_utils.rb'
#require_relative './rsi_utils.rb'


$LOG = nil
$LOG_FNAME=nil
$EXTRA_LOG = nil
$EXTRA_LOG_FNAME=nil
$LOG_SYMLEVEL=:debug #2017Set24 - REVAMPED! IMPORTANTE! FALHAVa em trace etc.

def get_rsi_log_fname
	runTpn = nil

	if Thread.current[:nome_cenario_corrente]==nil
		runScen=""
	else
		runScen='_'+get_alphanumcenario(Thread.current[:nome_cenario_corrente])
	end
	if ENV['TEST_ID']==nil
		#2017Set26 - Ja que TEST_ID null, adiciona apenas o que tiver de 
		#TMQ=TEST_MACHINE_ID e TPN=test_process_num
		if ENV['TEST_PROCESS_NUM'] != nil
			runTpn = "_TPN#{ENV['TEST_PROCESS_NUM']}"
		end
		runTmq="_TMQ#{get_machine_id}"
		runTid = "#{runTpn}#{runTmq}"
#####
# 2017Set26
#  Logs são todos sufixados , em caso de nao ter TEST_ID, por TMQ (ao fim)
#        De Log.log para Log_TMQmeupc
#        De Log_TRN1.log LOG_TNN1_TMQmeupc
#  ISSO vai permitir que FULL_LOG (principalmente) trafegue sem adulteracoes
# entre maquoinas nos casos de split_trns, enviar, e join_trns
#
#  Mudança correspondente deve ser feita em get_test_outputs_da_feature_da_trn       
#############


	else
		runTid='_'+ENV['TEST_ID']
	end
	if ENV['TEST_RUN_NUM']==nil
		runNum=""
		runFname=""
	else
		runNum="\\TRN#{ENV['TEST_RUN_NUM']}"
		runFname='_TRN'+ENV['TEST_RUN_NUM']
	end
	fname = "#{get_automdir}\\reports#{runNum}\\Log#{runFname}#{runTid}#{runScen}.log"
	#STDOUT.puts "rsi_log: fname=#{fname}"

	return fname
end
def get_rsi_log()
# TODO 2017Ago16, 13:07 - PROBLEMA: excecoes nao-tratadas nao vao pro log, acabam indo pro console.

	fname = get_rsi_log_fname()
	criadir_senaoexistir (File.dirname fname)
	if fname != $LOG_FNAME
		$LOG = Logger.new(fname, 0, 100 * 1024 * 1024 * 1024)
		$LOG_FNAME=fname
		$LOG.level = to_loglevel($LOG_SYMLEVEL)
	end


	return $LOG 
end

def get_rsi_extra_log_fname()
	return ENV['TEST_LOG_FILE']
end

def get_rsi_extra_log()
	fname = get_rsi_extra_log_fname
	return if not fname
	#2018Out9, log adicional em ENV VAR
	criadir_senaoexistir (File.dirname fname)
	if fname != $EXTRA_LOG_FNAME
		$EXTRA_LOG = Logger.new(fname, 0, 100 * 1024 * 1024 * 1024)
		$EXTRA_LOG_FNAME=fname
		$EXTRA_LOG.level = to_loglevel($LOG_SYMLEVEL)
	end


	return $EXTRA_LOG 
end

def to_symlevel(level)
	if level.is_a? Symbol
		retval = level
	elsif level == Logger::FATAL 
		retval = :fatal
	elsif level == Logger::ERROR
		retval = :error
	elsif level == Logger::WARN 
		retval = :warn
	elsif level == Logger::INFO
		retval = :info
	elsif level == Logger::DEBUG 
		retval = :debug
	elsif level == Logger::UNKNOWN
		retval = :unknown
	else
		fail "erro em to_symlevel(#{level}"
	end

	#puts "to_symlevel(#{level}) retornando #{retval}"
	return retval
end

def to_loglevel(sym)
	if not sym.is_a? Symbol
		retval = sym
	elsif sym == :unknown
		retval = Logger::UNKNOWN
	elsif sym == :fatal
		retval = Logger::FATAL
	elsif sym == :error
		retval = Logger::ERROR
	elsif sym == :warn
		retval = Logger::WARN
	elsif sym == :info
		retval = Logger::INFO
	elsif sym == :debug
		retval = Logger::DEBUG
	elsif sym == :trace
		retval = Logger::DEBUG
	else
		raise "erro em to_loglevel(#{sym}"
	end
	#puts "to_loglevel(#{sym}) retornando #{retval}"
	return retval
end



def write_rsi_log(p1, p2=nil)
	#protege contra chamada a write_rsi_log SEm o parametro :LEVEL inicial
	if p1.is_a? Symbol
		level=p1
		msg=p2
	else
		level=p2 || :debug
		msg=p1
	end
	
	prefixo = "#{Time.now} ,"
	#2018Abr01 - aidcionado PID= a msg_mais
	msg_mais = "PID=#{Process.pid} TPN=#{ENV['TEST_PROCESS_NUM']} de #{ENV['TEST_PROCESS_COUNT']} (PAR=#{ENV['TEST_PARALELISMO']}) #{msg}"
	full_msg="#{prefixo} => #{msg_mais}"
	
	if to_symlevel(level) == :trace and $LOG_SYMLEVEL == :debug
		#puts "hmm, ignorando msg #{to_symlevel(level)} pq $LOG_SYMLEVEL=#{$LOG_SYMLEVEL}"
		# NADA, cado de excecao, omite detalhes :trace
	else
		#puts "adicionando ao LOG , level=#{level}, to_loglevel(level)=#{to_loglevel(level)}"
		get_rsi_log.add to_loglevel(level), msg_mais
		if to_loglevel(level) >= to_loglevel($LOG_SYMLEVEL)
			STDOUT.puts full_msg #STDOUT - nao vai pra log do cucumber 
			if get_rsi_extra_log
				#2018Out9, log adicional em ENV VAR
	 			get_rsi_extra_log.add to_loglevel(level), msg_mais	
	 		end
	 	else
	 		#puts "rsi_log nao escreve, to_loglevel(level)=#{to_loglevel(level)}, e to_loglevel($LOG_SYMLEVEL)=#{to_loglevel($LOG_SYMLEVEL)}"
	 	end
	end

	if defined? rotina_de_interrupcao_em_log
		if false #hyper debugging interrupcoes
			get_rsi_log.add Logger::ERROR, 'rotina_de_interrupcao_em_log estah definida '
			STDOUT.puts 'rotina_de_interrupcao_em_log estah definida '
			if get_rsi_extra_log
				#2018Out9, log adicional em ENV VAR
	 			get_rsi_extra_log.add to_loglevel(level), Logger::ERROR, 'rotina_de_interrupcao_em_log estah definida '	
	 		end
		end
		if not Thread.current.backtrace.any?{|e| e.include? 'rotina_de_interrupcao_em_log'}
			if false #hyper debugging interrupcoes
				get_rsi_log.add Logger::ERROR, 'vai chamar rotina_de_interrupcao_em_log '
				STDOUT.puts 'vai chamar rotina_de_interrupcao_em_log '
				if get_rsi_extra_log
					#2018Out9, log adicional em ENV VAR
		 			get_rsi_extra_log.add to_loglevel(level), Logger::ERROR, 'vai chamar rotina_de_interrupcao_em_log '
		 		end
			end
			rotina_de_interrupcao_em_log #2018Out02 - estava, estranhamente, 'checa_interrupcoes' em vez de 'rotina_de_interrupcao_em_log'  #2018Abr19 - AGORA PODE chamar write_rsi_log em rotina_de_interrupcao_em_log, pois evito com IF acima a recursividade.
			if false #hyper debugging interrupcoes
				get_rsi_log.add Logger::ERROR, 'chamou rotina_de_interrupcao_em_log '
				STDOUT.puts 'chamou rotina_de_interrupcao_em_log '
				if get_rsi_extra_log
					#2018Out9, log adicional em ENV VAR
		 			get_rsi_extra_log.add to_loglevel(level), Logger::ERROR, 'chamou rotina_de_interrupcao_em_log '
		 		end
			end
		end
	else
		if false #hyper debugging interrupcoes
			STDOUT.puts "NAO DEFINIDA rotina_de_interrupcao_em_log"
			get_rsi_log.add Logger::ERROR, "NAO DEFINIDA rotina_de_interrupcao_em_log" 
			if get_rsi_extra_log
				#2018Out9, log adicional em ENV VAR
	 			get_rsi_extra_log.add to_loglevel(level), Logger::ERROR, 'NAO DEFINIDA rotina_de_interrupcao_em_log'
	 		end
		end

	end

end

def write_rsi_log_debug(msg)
	write_rsi_log :debug, msg
end

def write_rsi_log_fatal(msg)
	write_rsi_log :fatal, msg
end

def write_rsi_log_info(msg)
	write_rsi_log :info, msg
end

def write_rsi_log_warn(msg)
	write_rsi_log :warn, msg
end

def write_rsi_log_unknown(msg)
	write_rsi_log :trace, msg
end

def criadir_senaoexistir(some_path)
	FileUtils.mkdir_p(some_path)
end


