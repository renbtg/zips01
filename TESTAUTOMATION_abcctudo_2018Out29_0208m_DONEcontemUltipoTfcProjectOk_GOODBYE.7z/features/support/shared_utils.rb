require 'win32/screenshot'
require_relative './basic_utils.rb'
require_relative './rsi_utils.rb'
require_relative './rsi_log.rb'
require_relative './ahk_utils.rb'

if false 
	#DEBUG HACK pra testar sempre como se fosse em VM com problemas de AUTOMATION EXTENSION	 
	$ambiente_erra_automation_ext = true
end
$superdigital_outrosistema = true #2017Mar9 - Superdigital não é mais aberta por outro sistema? Bem, parece que ainda é.
$not_single_maq_zsproc_debug = true #DEVE SER TRUE! DEVE SER TRUE! DEVE SER TRUE!   #TOP - para testes de ZS_PROC.rb PROC em várias janelas do mesmo PC. Basta nao abrir browser nem chamar VISIT nem , até 2018Mar01, deixar TFC-CONFIG.PROPERTIES com DESABILITADO=0 !! Tem q ser DESABILITADO=1!


raise "PLAY SAFE! $not_single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}" if not $not_single_maq_zsproc_debug and false #and false=desabilita EXCEPTION, true=HABILITA


require 'securerandom'
require 'timeout'
require 'os'
require 'money'


CONST_LOCK_EXCLUSIVO_GUI = 'LOCK_EXCLUSIVO_GUI'

class ExcecaoTimeoutBasica < Timeout::Error #2017Set28 - hmm, sempre deveria ter sido Timeout::error !! ??
	def initialize(msg="Timeout na automacao")
		super msg
	end
end
class TimeoutDeLockExclusivoxception < ExcecaoTimeoutBasica
	def initialize(msg="Timeout em lock exclusivo de processos nativos (DESKTOP/GUI, por exemplo)")
		write_rsi_log msg if false #apenas para evitar erro unused argument do ruby-lint
		super #msg?
	end
end
class TimeoutDeVeracidade < ExcecaoTimeoutBasica
	def initialize(msg="Timeout de veracidade")
		write_rsi_log msg if false #apenas para evitar erro unused argument do ruby-lint
		super #msg?
	end
end

class TimeoutDeRunAutohkCopia < ExcecaoTimeoutBasica
	def initialize(msg="Timeout em run_autohk_copia")
		write_rsi_log msg if false #apenas para evitar erro unused argument do 		super #msg?
	end
end

def get_machine_id
	return ENV['TEST_MACHINE_ID'] if ENV['TEST_MACHINE_ID']
	return get_numero_mac_address(15)
end
def get_numero_mac_address(nof_tries=10)
  return get_alphanumeric(get_automdir) #2018Mar04 - PUTZ, obtencao de ipconfig dá tora ora EAGAIN! Entao, isso pode complicar OLD STYLE zplit/merge baseado em MACADDRESS de maquina sem nome! Sem crise, pro Processo Colaborativo, esta abordage, dá conta de boa. E pra gera_e_executa tradicional também.

  c="#{(OS.windows?) ? 'ipconfig /all' : 'ifconfig'}"
  #puts "c=#{c}"
  output = run_command_retry_eagain(c, nof_tries)
  if OS.linux?
      #puts "linux"
      return $1 if output =~ /en1.*?(([A-F0-9]{2}:){5}[A-F0-9]{2})/im
  elsif OS.windows?
      #puts "windows"
    lins=output.force_encoding('CP850').split("\n")
    first_addr = lins.find{|l|
      ret=false
      #puts "l=#{l}"
      ret=true if l =~ /Physical Address.*?(([A-F0-9]{2}-){5}[A-F0-9]{2})/im 
      ret=true if l =~ /Endere.*sico.*?(([A-F0-9]{2}-){5}[A-F0-9]{2})/im
      ret
    } 
    first_addr = first_addr || ''
    retval = first_addr.split(" : ")[1]
    return retval
  else 
    return nil
  end
end

def tempo_tfc_operacao_exclusiva
	t_tfc_um_simplista = 250 #caramba! Tudo isso? ENTAO: TODO 2018Fev10 - eu spero que seja possivel ter lock_exclusivo no Java/TFC/LeanFT, isso somente será viável se as janelas / dialogs que apareçam na app TFC fiquem dentro da tela dele, nao causando JANELA VIR PARA FOREGROUND aleatoriamente.!!! Se for possível, lindo: aí, nao terei operações longuíssimas do TFC bloqueando outras oprações de UI (como screenshots-web, fileupload-web, abre_janela_browser etc.). Aí, a implementacao JAVA seria idêntica à daqui, mesma lógica 100%, exceto talvez por nao ter trazer_pra_topo, maximixe etc.
	return t_tfc_um_simplista * (get_paralelismo - 1)
end


def get_segundos_fila_lock_exclusivo(ctx='LOCK_EXCLUSIVO_GUI')	
	# TODO 2018Fev10 - definir algoritmo melhor. POR FAVOR, REFINE! Timesouts de paralelismo estão todos meio chutados, sem muito método. Devem levar em conta performance da máquina e tudo, algum aqruivo CFG que pode até ser mais refinado com auto-detecção (ZS_PROC? setado manual? ANYWAY: POR FAVOR, REFINE!)
	tempo_default_operacao_exclusiva = 60*3

	if ctx == CONST_LOCK_EXCLUSIVO_GUI
		#paralelismo = get_paralelismo
		#tout = 60 * paralelismo #4 processos=4 min... 16=16min  !! ?? NAO SERIA MELHOR FOREVER? 100000?
		#tout = [tout, tempo_tfc_operacao_exclusiva].max #2018Fev10, TFC
		
		#return tout
		return 750 #um coitado tá esperando 3 TFCs meio-lerdos... de 250 segs cada

####EITA PREUGA! 2018Fev25 - Que TEMPO foi aquele que fez "desistir" de LOCK no TFC, deixando outras pagias web passarem por cima em conflito? 

	elsif ctx == 'LOCK_FILEMANAGER'
		return 30*3 #30 segundos, que exagero! CREIO que posso reduzir pra 5... TENTAR, se performance tiver gargalo por isso! 
	end
	return tempo_default_operacao_exclusiva 
end

def get_lock_file_name(ctx)
	return "#{get_automdir}/LAST.#{ctx}.#{get_process_num}.FILA.LCK"
end
def get_todos_lock_file_names(ctx)
	ret=nil
	executa_exclusivo(nil, 'LOCK_MANAGER') do
		ret = Dir["#{get_automdir}/LAST.#{ctx}.*.FILA.LCK"]
	end
	return ret
end

def registra_atendendo_fila_lock(ctx)
	executa_exclusivo(nil, 'LOCK_MANAGER') do
		fname = get_lock_file_name(ctx)
		(ordem_precedencia , ftime)=File.read(fname).split(";").map(&:strip)
		write_rsi_log :debug, "registra_atendendo_fila_lock(#{ctx}): trocando a ordem_precedencia que era #{ordem_precedencia} para ZERO(0)=primeirissima precedencia"
		File.open(fname,'w') { |f| f.puts "%09d;%018.6f" % [0,ftime] }
	end
end


def registra_fila_lock(ctx, ordem_precedencia=0)
	executa_exclusivo(nil, 'LOCK_MANAGER') do
		fname = get_lock_file_name(ctx)

		loop do 
			excecao = nil
			begin
				File.open(fname,'w') {|f|
					f.puts "%09d;%018.6f" % [ordem_precedencia,Time.now.to_f] 
					# já grava em formato bom para SORT simplificado, ao comparar
					#conteúdo de vários arquivos
					#
					#ordem_precedencia: é checada antes, quando menor 
				}
			rescue Exception => e
				excecao = e
			end
			if excecao
				write_rsi_log :warn, "registra_fila_lock(#{ctx}, #{ordem_precedencia}): tentando de novo, excecao #{e} ao criar/escrever arquivo #{fname}"
			else
				break
			end
		end
	end
end

def remove_fila_lock(ctx, chamadora=nil)
	executa_exclusivo(nil, 'LOCK_MANAGER') do
		fname = get_lock_file_name(ctx)
		excecao = nil
		begin
			if File.file? fname 
				FileUtils.rm fname
			else
				write_rsi_log :debug, "remove_fila_lock(#{ctx}, #{chamadora}): nao encontrado arquivo #{fname}"
			end
		rescue Exception => e
			excecao = e
			write_rsi_log :debug, "remove_fila_lock(#{ctx}, #{chamadora}): NAO TENTAREI DE NOVO, ignorando excecao, excecao #{e}"
		end
	end
end

def remove_todos_fila_lock
	executa_exclusivo(nil, 'LOCK_MANAGER') do
		Dir["#{get_automdir}/*.FILA.LCK"].each{|fname|
			FileUtils.rm fname 
		}
	end
end

def obtem_lock(ctx, ordem_precedencia=1) #nem passa parametro TIMEOUT, obtido internameente
	#
	#
	#    **  P O R   F A V O R, A T E N C A O
	#  
	#    ** N A O   C E R Q U E   T O D O    E S T E    M È T O D O   
	#       ------ 
	#       ------ 
	#    C O M    executa_exclusivo   ! ! ! !
	#


	write_rsi_log :debug, "obtem_lock: P00"
	hora_inicio_espera=Time.now
	
	executa_exclusivo(nil, 'LOCK_MANAGER') {
		registra_fila_lock(ctx, ordem_precedencia)
	
		# em paralelismo 3, os 9 processos podem se colocar na fila
	}
	
	if not File.exist? get_lock_file_name(ctx)
		write_rsi_log :error, "ASSERTION FAILED: obtem_lock: Acabou de registrar E NAO EXISTE ARQUIVO LOCK!!! #{get_lock_file_name(ctx)}" if not File.exist? get_lock_file_name(ctx)
		File.open("#{get_automdir}/TERMINAR.LCK","w") {} rescue nil #RADICAL? ABORTA TODA A AUTOMACAO?
	end
	falhar "ASSERTION FAILED: obtem_lock: Acabou de registrar E NAO EXISTE ARQUIVO LOCK!!! #{get_lock_file_name(ctx)}" if not File.exist? get_lock_file_name(ctx)

	loop do
		ok = false
		write_rsi_log :debug, "obtem_lock: processo #{get_process_num} aguardando até ser o mais prioritario esperando, desde aproximadamente #{hora_inicio_espera}" 
		executa_exclusivo(nil, 'LOCK_MANAGER') { 
			#SIM! Lock granular a cada tentativa
			#
			# Ao ter CHECA e REGISTRA_SUCESSO dentro do mesmo LOCK, evita conflitos entre
			# os arquivos de controle, ao ser removidos/reescritos/abertos etc. por
			# outros processos

			ok =  checa_sou_prioritario_fila_lock(ctx,get_paralelismo)
			if ok
				write_rsi_log :trace, "obtem_lock: ok, funcao checa_sou_prioritario_fila_lock retornou true" 
				registra_atendendo_fila_lock ctx #OBRIGATORIO que registra_atendendo_fila_lock esteja em mesmo executa_exclusivo que checa!
			end
		}
		break if ok
		sleep 0.5
	end

end

def checa_sou_prioritario_fila_lock(ctx, entre_quantos_mais_prioritarios)
	ret = nil
	executa_exclusivo(nil, 'LOCK_MANAGER') do
		ret = core_checa_sou_prioritario_fila_lock(ctx, entre_quantos_mais_prioritarios) 
	end

	return ret
end

def core_checa_sou_prioritario_fila_lock(ctx, entre_quantos_mais_prioritarios)
	a = get_todos_lock_file_names(ctx).map { |fname| 
		ret=nil
		fname.upcase!
		#write_rsi_log "checa_sou_prioritario_fila_lock: fname=#{fname}"
		fnum=fname.split(".FILA.LCK").first.split(".").last.to_i
		File.open(fname) { |fhandle|
			#write_rsi_log "checa_sou_prioritario_fila_lock: wanna-be fnum=#{fnum}"
			ret = {
				:fnum=>fnum,
				:conteudo=>fhandle.readline
			} 
		}

		ret
	}.select{ |e|
		e != nil
	}.sort { |e1, e2|
		c1=e1[:conteudo]
		c2=e2[:conteudo]
		#write_rsi_log :debug, "checa_sou_prioritario_fila_lock: comparacao, e1=#{e1}, c2=#{c2}"
		ret=c1 <=> c2
		#write_rsi_log :debug, "checa_sou_prioritario_fila_lock: ret=#{ret} pra comparacao entre #{e1} e #{e2} "
		ret
	}
	#write_rsi_log :debug, "checa_sou_prioritario_fila_lock: a=#{a}"
	my_test_process_num=get_process_num
	my_index=a.find_index{|e| e[:fnum] == my_test_process_num}
	#se nao encontrar, significa que nunca teve sucesso
	#write_rsi_log :debug, "checa_sou_prioritario_fila_lock: my_index=#{my_index}, my_test_process_num=#{my_test_process_num}, entre_quantos_mais_prioritarios=#{entre_quantos_mais_prioritarios}"
	
	if my_index == nil
		falhar "ASSERTION FAILED: checa_sou_prioritario_fila_lock: nem achei eu mesmo, my_test_process_num=#{my_test_process_num}, entre os que esperam"
	end

	if my_index < entre_quantos_mais_prioritarios
		#TUDO OK, sou um dos mais prioritarios
		write_rsi_log :trace, "checa_sou_prioritario_fila_lock: eu mesmo, my_test_process_num=#{my_test_process_num}, eh um dos #{entre_quantos_mais_prioritarios} mais prioritarios, OK!, my_index=#{my_index}"
		return true
	end

	#write_rsi_log :debug, "checa_sou_prioritario_fila_lock: eu mesmo, my_test_process_num=#{my_test_process_num}, NAO EH NAO um dos #{entre_quantos_mais_prioritarios} mais prioritarios, , my_index=#{my_index}"
	return false
end

def falhar(msg, definitivo=false)
	if (not msg.is_a? String)
		msg = msg.to_s
	else
		#nada
	end

	deve_regravar_massa = ($massa and $massa.is_a? Hash and $massa.keys.length > 0)

	fullErrorMessage = nil 
	if true #2018Set6 - usa codigo e mensagem de erro 500 webdesktop... errorCode,errorBase,errorMessage,fullErrorMessage. XLS IMPROVED!
		if (deve_regravar_massa and $massa['ERROR_AJUSTES']||'')=='' and $massa['QUALAPP']=='webdesktop' and ($numero_step_atual||0) >=1 and ($numero_step_atual||0) <= 7
			#2018Set8 am, causava subida de browser errada por variavel errada q eu usava $num_step_atual em vez de $numero_step_atual
			errorAjustes=''; errorCode = ''; errorBase = ''; errorMessage = ''; fullErrorMessage = ''
			begin 
				el500 = Capybara.page.first('error-500')
				errorAjustes='1' if el500
				elCode = el500.first('.errorCode') if el500 
				errorCode = elCode.text if elCode 
				errorBase = errorCode.split(' ').first || ''

				(sleep 10; elMessage = el500.first('.errorMessage')) if el500 #dorme 10 segundos pra dar tempo de aparecer excecao 
				fullErrorMessage = (elMessage.text||'') if elMessage
				errorMessage = fullErrorMessage[0..511] if fullErrorMessage
				 
			rescue StandardError => e
				write_rsi_log :debug, "Ignorando erro #{e} ao tentar obter codigos de erro de webdesktop. $num_step_atual=#{$num_step_atual}, errorCode=#{errorCode}, errorBase=#{errorBase}, errorMessage=#{errorMessage}, fullErrorMessage=#{fullErrorMessage}"
			end
			$massa['ERROR_AJUSTES']=errorAjustes
			$massa['ERROR_CODE']=errorCode
			$massa['ERROR_BASE']=errorBase
			$massa['ERROR_MESSAGE']=errorMessage
		end
	end

	if true #2018Set6 - usa codigo e mensagem de erro 500 webdesktop
		if deve_regravar_massa and $massa['QUALAPP']=='webdesktop' and ($num_step_atual||0) >=0 and ($num_step_atual||0) <= 7
			if ($massa['ERROR_AJUSTES']||'') != ''
				msg = "WEBDESK_FAZENDO_AJUSTES : WEBDESK_ERROR_BASE=#{$massa['ERROR_BASE']} : #{msg} : WEBDESK_ERROR_CODE=#{$massa['ERROR_CODE']} : WEBDESK_ERROR_MESSAGE=#{$massa['ERROR_MESSAGE']}"
			end
		end
	end

	if definitivo
		msg = "DEFINITIVO: #{msg}" if not msg.include? 'DEFINITIVO:' 
		if deve_regravar_massa
			$massa['FAIL_DEFINITIVO']='1'
		end
	end


	new_msg=ascii_only_str(msg) #2017Nov14, protege tambem diretamente aqui

	new_msg=add_app_prefix_to_msg(new_msg)

	write_rsi_log :error, "#{new_msg}#{' fullErrorMessage='+fullErrorMessage if fullErrorMessage}"

	if deve_regravar_massa
		$massa['FAILED']=($numero_step_atual||'') #2018Mar26 - error in Mar2x refactoring... fixed, from STEP_FAILED to FAILED
		begin
			write_rsi_log :debug, "falhar, imediatamente antes de chamar regrava_arquivo_massa , $massa=#{$massa}"
			regrava_arquivo_massa
			write_rsi_log :debug, "falhar, imediatamente depois de chamar, sem exception, regrava_arquivo_massa , $massa=#{$massa}"
		rescue Exception => e
			write_rsi_log :error, "falhar, erro ao regravar em regrava_arquivo_massa, excecao=#{e}"
		end
	end

	fail new_msg
end

def falhar_definitivo(msg)
	falhar(msg,true)
end

def maximiza_este_browser
	if last_lock_exclusivo_falhou
		write_rsi_log :error, "maximiza_este_browser, last_lock_exclusivo_falhou=true, retornando sem chamar run_maximiza_este_browser"
		return
	end
	run_maximiza_este_browser
end

def run_maximiza_este_browser(deve_salvar_rectangle=true)
	if deve_salvar_rectangle and (not janelas_sempre_maximizadas?)
		salva_rectangle_deste_browser
	end 
	#2017Out4 - preservar ajustes manuais de rectangle
	#
	# Em toda vez que maximizar, aproveita a oportunidade e salva antes o rectangle
	#
	#    NUNCA apaga o arquivo salvo, durante todo o processo: assim, quaisquer ajustes
	# sao preservados, MESMO SE browser cair forçosamente (usuário humano interferir
	# e fechar janela ou bug em algum ponto do código da automação)
	#
	#   Em algumas situacoes como, por exemplo, ajustar rectangle e, antes de um maxi-
	# mize forçar close da janela, nao terá salvo novo rectangle. Acabará usando
	# rectangle salvo anterirmente ou, se antes do primeiro maximize, usará cálculo
	# padrão de acordo com SLOT/JANELA e PARALELISMO
	#
	#
	# TODOout5 ENHANCEMENT: injetar "como se fosse interrupcao" em write_rsi_log o código
	# que salvará rectangle de X em X segundos (ex: a cada 90 segundos)
	#
	# TODoout5: CUIDADO TOP TOP: diretorios de .LCK e .DAT, nao devem existir em hora errada! PENSE!
	#
	# TODOout5 DEVOPS/SEM-INTERVENCAO-HUMANA: setar variaval TEST_NO_USER_INTERVENTION=1...
	# (essa variável de ambiente desativa os comportamentos que servem para observação 
	# e intervenção de usuários humanos: GANHO DE PErFORMANCE EM GRANDES EXECUCOES E
	# DEVOPS!)
	#
	#   TODOout5 perenidade: usar extensao diferente de .LCK para RECTANGLE, algo como .DAR...
	# assim, mesmo entre diferentes reinicia_execucao, mantém os tamahos anteriores.
	#           ***** MUITO CUIDADO NISSO, pra que um reinicia_execucao com paralelismo
	#             4 nao pegue posicoes definidas pra PARALELISMO 6: a responsa de
	#             limpar seletivamente os *RECTANGLE*.DAT fica por conta de reinicia/
	#             reprocessa... E... TECH NOTE: pra isto, precisa de PARALELISMO
	#             NO NOME DO ARQ DE RECTANGLE .DAT !!
 

	if (detected_automation_ext_erro?)
		autohk_maximiza_este_browser
	else
		begin
			Capybara.page.driver.browser.manage.window.maximize #MAXIMIZE funcionou
		rescue Exception => e 
			falhar e
=begin
			if not e.inspect.include? 'automation'
				#TODO 2017Set9-checar a exception exata de CANNOT LOAD AUTOMATION EXTENSION da VM
				raise e
			end
			$ambiente_erra_automation_ext = true
			autohk_maximiza_este_browser
=end
		end
	end
end


def seta_rectangle_este_browser(x, y=nil, largura=nil, altura=nil)
	if x and x.is_a? Array
		x,y,largura,altura=x
	end

	write_rsi_log :trace, "seta_rectangle_este_browser, vai chamar autohk_seta_rectangle_este_browser [x,y,altura,largura]=#{[x,y,altura,largura]}"
	autohk_seta_rectangle_este_browser x, y, largura, altura 

end

def seta_rectangle_janela_numero(numero_janela)
	if janelas_sempre_maximizadas?
		#2017Nov29
		return
	end


=begin
	1.OBTEM_TAMANHO_DO_DESKTOP
	2.PRO_RATEIA_TAM_E_POS_POR get_paralelismo
	3.seta_rectangle_este_browser(x, y, width, height) 
	seta_rectangle_janela_numero $numero_desta_janela

	(OBS_Se_get_paralelismo != 1)=entao_deve_maximizar
	(OBS2_esta_func_deve_ser_chamada_apenas_de core_abre_jan)
=end

	reorganizar_topo = false

	write_rsi_log :trace, "seta_rectangle_janela_numero-START"
	if false and get_paralelismo == 1 # FALSE: nao quero maximizar incondicionalmente
		write_rsi_log :trace, "seta_rectangle_janela_numero-P02"
		maximiza_este_browser
		write_rsi_log :trace, "seta_rectangle_janela_numero-P03"
	else
		# DUMMY POSITIONS, até calcular o pro-rateamento
		 
		write_rsi_log :trace, "seta_rectangle_janela_numero-P04"
		w,h = autohk_get_desktop_dimensions
		if get_paralelismo <= 4
			write_rsi_log :trace, "seta_rectangle_janela_numero-P05"
			# sem sobreposicao
			tam_cada = w/get_paralelismo
			fim=0
			get_paralelismo.times do |k|
				ini = fim + 1
				fim = ini + tam_cada -1
				
				if k == numero_janela-1
					seta_rectangle_este_browser (le_rectangle_deste_browser || [ini,10,tam_cada,h-20])
					reorganizar_topo = true
				end
			end

		else
			write_rsi_log :trace, "seta_rectangle_janela_numero-P06"
			#sobreposicao 50%
			tam_cada = 2*w/(1+get_paralelismo)
			write_rsi_log :trace, "w=#{w}"
			fim=0
			get_paralelismo.times do |k|
				write_rsi_log :trace, "seta_rectangle_janela_numero-P07"
				ini = fim + 1
				fim = ini + (tam_cada/2) -1
				write_rsi_log :trace, "ini=#{ini}, fim#=#{fim}"

				if k == numero_janela-1
					write_rsi_log :trace, "vai chamar seta_rectangle_este_browser"
					seta_rectangle_este_browser seta_rectangle_este_browser (le_rectangle_deste_browser || [ini,10,tam_cada,h-20])
					write_rsi_log :trace, "chamou seta_rectangle_este_browser"
					reorganizar_topo = true
				end
			end
			write_rsi_log :trace, "seta_rectangle_janela_numero-P08"

			# nível de paralelismo MUITO alto... ?? Quew fazer? Bem, faça igual
			#a paralelismo entre 5 e 8 mesmo...

		end	

		write_rsi_log :trace, "seta_rectangle_janela_numero-P09"

		if reorganizar_topo
			write_rsi_log :trace, "deve reorganizar_topo"
			reorganiza_janelas_topo
		end
=begin
Se cada janela comer metade da anterior...
123456789012345678901234567890
12345678
********
*
********
123456789012345678901234567890
    12345678
    ********
    *
    ********
123456789012345678901234567890
        12345678
        ********
        *
        ********
123456789012345678901234567890
            12345678
            ********
            *
            ********

___________________ s+((s/2)*(j-1)=w
w=20
j=4

s+((s/2)*3)=20

s+1.5s=20
2.5s=20
s=20/2.5
s=8

*** BOM! 5 janelas a max=30
s+((s/2)*4)=30
s+2s=30
3s=30
s=10

123456789012345678901234567890
**********
*
**********
123456789012345678901234567890
     **********
     *
     **********
123456789012345678901234567890
          **********
          *
          **********
123456789012345678901234567890
               **********
               *
               **********
123456789012345678901234567890
                    **********
                    *
                    **********

OK!!! s+((s/2)*(j-1))=w
PORTANTO, pra obter s...
	s +( s * (j-1)) = w
	     -
	     2 
    2s  + sj-s = 2w
    --    ----   --
    2     2      2 

    2s+sj-s=2w
    s+sj=2w
    s(1+j)=2w
    s= 2w
      ---
      1+j
    ____ FORMULA: s=2w/(1+j)
    
    s=60/(1+5), 60/6=10, OK!

   

=end
	end
			
	write_rsi_log :trace, "seta_rectangle_janela_numero-END"
end

def reorganiza_janelas_topo
	num_janela_este_processo = get_num_janela_processo
	write_rsi_log :trace, "num_janela_este_processo=#{num_janela_este_processo}"
	quantas_trazer_topo = 0
	s_janelas=''
	if num_janela_este_processo < get_paralelismo #se esta=a mais à direita, desnecessário...
		arqs=Dir["#{get_automdir}/TPN_*_SLOT_JANELA_*.LCK"]
		arqs.select { |arq|
			#tpn=get_tpn_do_arq_slot(arq)
			slot=get_slot_do_arq_slot(arq)
			slot > num_janela_este_processo
			true #2017Out4, MUDANÇA: sempre traz todas , em ordem, pro topo
		}.sort {|arq1,arq2|
			#tpn1=get_tpn_do_arq_slot(arq1)
			slot1=get_slot_do_arq_slot(arq1)
			#tpn2=get_tpn_do_arq_slot(arq2)
			slot2=get_slot_do_arq_slot(arq2)
			slot1 <=> slot2
		}.each{|arq|
			#tpn=get_tpn_do_arq_slot(arq)
			#slot=get_slot_do_arq_slot(arq)
			browser_handle_janela = get_handle_do_arq_slot(arq)
			quantas_trazer_topo = quantas_trazer_topo + 1

			s_janelas = s_janelas + '@' if quantas_trazer_topo > 1
			#nome_janela = get_nome_janela(tpn)
			#s_janelas = s_janelas + nome_janela + ' - Google Chrome'
			s_janelas = s_janelas + browser_handle_janela
		}
	end
	traz_janela_pra_topo(s_janelas)
end

def get_rectangle_este_browser
	if true #(detected_automation_ext_ok?)
		return autohk_get_rectangle_este_browser
	else
		begin
			sz=Capybara.page.driver.browser.manage.window.size
			return [sz.width, sz.height] 
		rescue Exception => e 
			raise e
=begin
			if not e.inspect.include? 'automation'
				#TODO 2017Set9-checar a exception exata de CANNOT LOAD AUTOMATION EXTENSION da VM
				raise e
			end
			$ambiente_erra_automation_ext = true
			return get_rectangle_este_browser
=end
		end
	end
end


def has_lock_exclusivo(ctx = CONST_LOCK_EXCLUSIVO_GUI)
	return ($already_locked||{})[ctx] == true
end
def last_lock_exclusivo_falhou(ctx = CONST_LOCK_EXCLUSIVO_GUI)
	return ($lock_exclusivo_falhou||{})[ctx] == true
end

def executa_exclusivo(hash_param=nil, ctx=nil, segundos_espera_flock = nil)
# executa_exclusivo hash_param: :maximizar_janela_antes , :trazer_janela_para_topo_antes, :restore_janela_depois	# executa_exclusivo hash_param: :maximizar_janela_antes , :trazer_janela_para_topo_antes, :restore_janela_depois# executa_exclusivo hash_param: :maximizar_janela_antes , :trazer_janela_para_topo_antes, :restore_janela_depois
	ctx ||= CONST_LOCK_EXCLUSIVO_GUI

	hash_param ||= {}

	$already_locked ||= {}
	$lock_exclusivo_falhou ||= {}
	
	$lock_exclusivo_falhou[ctx] = false  

	valid_hash_keys=[
			:maximizar_janela_antes , 
			:trazer_janela_para_topo_antes, 
			:restore_janela_depois,
			:verbose,
			:segundos_sleep

	]

	useless_keys = []
	if janelas_sempre_maximizadas?
		useless_keys = useless_keys + [
			:maximizar_janela_antes , 
			#2018Jan19 - :trazer_janela_para_topo_antes, 
			:restore_janela_depois
		]
	end
	
	if not $not_single_maq_zsproc_debug
		useless_keys = valid_hash_keys
	end

	
	useless_keys.each {|k| hash_param[k] = false if hash_param[k] != nil}

	hash_param.keys.each do |key|
		if not valid_hash_keys.include? key
			falhar "executa_exclusivo - Erro - chave errada (class,value)=(#{key.class},#{key}) no hash de parametros, chaves validas=#{valid_hash_keys}"
		end	
	end

	dirpath_lock_exclusivo_semaforo = ''; suffix_lock_exclusivo_semaforo = ''; dirpath_lock_exclusivo_semaforo = "#{get_automdir}/" if File.basename(ctx) == ctx; suffix_lock_exclusivo_semaforo = ".LCK"  if File.extname(ctx) == ''; nomearq_lock_exclusivo_semaforo = dirpath_lock_exclusivo_semaforo + ctx + suffix_lock_exclusivo_semaforo
	
	#write_rsi_log :trace, "executa_exclusivo(ctx=#{ctx}): 00 = defined? #{$already_locked} = #{defined? $already_locked}"
	if $already_locked[ctx] == nil
		write_rsi_log :trace, "executa_exclusivo: $already_locked[#{ctx} INDEFINIDO" if false #2018Set26 - menos log
		$already_locked[ctx] = false
	end
	write_rsi_log :trace, "executa_exclusivo(ctx=#{ctx}): 01 = $already_locked #{$already_locked}"  if false #2018Set26 - menos log

	hash_param = hash_param || Hash.new
	
	fez_lock_agora = false

	if not $already_locked[ctx]
		segundos_espera_flock ||= get_segundos_fila_lock_exclusivo(ctx)
		if segundos_espera_flock == -1
			segundos_espera_flock = 365*24*60*20 #um ano, 30 dias, 24 horas, 60 minutos, 60 segundos
		end
		write_rsi_log :trace, "executa_exclusivo:  antes de tentar abrir/criar arquivo #{nomearq_lock_exclusivo_semaforo}"  if false #2018Set26 - menos log 
		f = File.open(nomearq_lock_exclusivo_semaforo, "w")
		write_rsi_log :trace, "executa_exclusivo: depois de tentar abrir/criar arquivo #{nomearq_lock_exclusivo_semaforo}, f handle ficou = #{f}"  if false #2018Set26 - menos log

		t_inicio = Time.now
		segundos_decorridos = 0
		while not fez_lock_agora
			#2018Out6 - hash_param ganhou chaves :verbose e :segundos_sleep 
			t_agora = Time.now
			segundos_decorridos = t_agora - t_inicio
			segundos_sleep = hash_param[:segundos_sleep] || 1
			#2018Set30 - revamp, nao usar Timeout::timeout
			if f.flock(File::LOCK_NB|File::LOCK_EX)
				fez_lock_agora = true
				$already_locked[ctx] = true
			elsif segundos_decorridos > segundos_espera_flock
				$lock_exclusivo_falhou[ctx] = true  
				write_rsi_log :error, "executa_exclusivo:LOCK EXCLUSIVO nao obtido depois de #{segundos_espera_flock} segundos por , arquivo=#{nomearq_lock_exclusivo_semaforo}"
			end
			if hash_param[:verbose]
				write_rsi_log :debug, "executa_exclusivo: Esperando #{segundos_espera_flock} segundos por LOCK_EXCLUSIVO, segundos_decorridos = #{segundos_decorridos}, segundos_sleep=#{segundos_sleep}, arquivo=#{nomearq_lock_exclusivo_semaforo}" 
			end
			sleep segundos_sleep
		end
		if not $lock_exclusivo_falhou[ctx]
			if hash_param[:verbose]
				write_rsi_log :debug, "executa_exclusivo:SUCESSO em obter lock do arquivo de LOCK_EXCLUSIVO, arquivo=#{nomearq_lock_exclusivo_semaforo}, segundos_decorridos=#{segundos_decorridos}, segundos_espera_flock=#{segundos_espera_flock}" 
			end
		end
	end

	x=y=largura=altura=nil
	excecao_inicial = nil
	begin
		write_rsi_log :debug, "executa_exclusivo:iniciado trecho de execucao"  if false #2018Set26 - menos log
		if hash_param[:restore_janela_depois]  # RIBY: 
			write_rsi_log :trace, "executa_exclusivo:vai chamar get_rectangle_este_browser pra obter x,y,w,h "  if false #2018Set26 - menos log
			begin
				x,y,largura,altura = get_rectangle_este_browser
			rescue Exception => e
				write_rsi_log :warn, "executa_exclusivo: erro em get_rectangle_estr_browser, excecao=#{e}"
			end
			write_rsi_log :trace, "executa_exclusivo:chamou get_rectangle_este_browser e obteve x #{x} e y #{y} e altura #{altura} e largura #{largura} da janela antes de yield "  if false #2018Set26 - menos log
		end
		if hash_param[:maximizar_janela_antes]  # RIBY: 
			begin
				run_maximiza_este_browser 
				#2018Mar23 - se chegou parametro para maximizar, chama DIRETO o nucleo de run_maximixa_este_browser, a chamadora deve saber o que está fazendo... afinal de contas, estou muito provavelmente DENTRO DE LOCK EXCLUSIVO COM SUCESSO!
			rescue Exception => e
				write_rsi_log :warn, "executa_exclusivo: erro em maximima_este_browser, excecao=#{e}"
			end
			write_rsi_log :trace, "executa_exclusivo:maximizou janela antes de yield "  if false #2018Set26 - menos log
		end
	
		if hash_param[:trazer_janela_para_topo_antes]  # RIBY: 
			write_rsi_log :trace, "executa_exclusivo:vai trazer janela pro topo antes de yield "  if false #2018Set26 - menos log
			begin
				traz_esta_janela_pra_topo
			rescue Exception => e
				write_rsi_log :warn, "executa_exclusivo: erro em traz_esta_janela_pra_topo, excecao=#{e}"
			end
			write_rsi_log :trace, "executa_exclusivo:trouxe janela pro topo antes de yield "  if false #2018Set26 - menos log
		end
		dormir_yield=0
		write_rsi_log :trace, "executa_exclusivo:imediatamente antes de yield, dormirah #{dormir_yield}"  if false #2018Set26 - menos log
		sleep dormir_yield if dormir_yield > 0
		#begin; raise 'veja stack trace'; rescue Exception =>e; write_rsi_log :trace, e.backtrace; end
		ret = yield # SEM CONTROLE DE TIMEOUT na execucao do
		write_rsi_log :debug, "executa_exclusivo:imediatamente depois de yield, dormiu #{dormir_yield}"  if false #2018Set26 - menos log
		sleep dormir_yield if dormir_yield > 0
	rescue Exception => e
		write_rsi_log :error, "executa_exclusivo: excecao qye relancarei obtida nas proximidades de yield, excecao=#{e}, full exception backtrace=#{e.backtrace}"
		excecao_inicial = e
		raise e
	ensure
		excecao_no_ensure = nil
		begin
			write_rsi_log :debug, "executa_exclusivo:ensure"  if false #2018Set26 - menos log
			if hash_param[:restore_janela_depois]  # 2017Set9 - RESIZE ANTES DE UNLOCK!!! 
				write_rsi_log :trace, "executa_exclusivo:ensure, vai restaurar size de janela"  if false #2018Set26 - menos log
				
				begin
					if x
						#2017Out27 - fix "nao restaurava tamanho", passando x,y,largura,altura
						seta_rectangle_este_browser x,y,largura,altura  
					end
					reorganiza_janelas_topo				
				rescue Exception => e
					write_rsi_log :warn, "executa_exclusivo: erro em seta_rectangle_este_browser ou reorganiza_janelas_topo, excecao=#{e}" 
				end
				write_rsi_log :trace, "executa_exclusivo:ensure, restaurou size de janela e reorganizou topo"  if false #2018Set26 - menos log
			end
		rescue Exception => e
			write_rsi_log :trace, "executa_exclusivo:excecao em ensure de execua_exclusivo, excecao=#{e.inspect}"
			excecao_no_ensure = e
		end
		if fez_lock_agora #se nao entrou aqui já lockado, e tentou e conseguiu lockar
			write_rsi_log :trace, "executa_exclusivo:ensure, vai liberar lock - ( $already_locked[#{ctx}] = false + flock(File::LOCK_UN)"  if false #2018Set26 - menos log
			$already_locked[ctx] = false #2017Set10 am, faltava @$already_locked=false@ 
			f.flock(File::LOCK_UN)
			write_rsi_log :trace, "executa_exclusivo:ensure, liberou lock - ( $already_locked[#{ctx}] = false + flock(File::LOCK_UN)"  if false #2018Set26 - menos log
		end
		raise excecao_no_ensure if (excecao_no_ensure and not excecao_inicial)
	end

	write_rsi_log :debug, "executa_exclusivo:retornando, nao mostrando variavel ret aqui, retorno final, $already_locked[ctx] = #{$already_locked[ctx]}, $lock_exclusivo_falhou[ctx]=#{$lock_exclusivo_falhou[ctx]}"  if false #2018Set26 - menos log
	return ret 
end

def salva_rectangle_deste_browser(x=nil,y=nil,w=nil,h=nil)
	write_rsi_log :trace, "chamou salva_rectangle_deste_browser, [x,y,w,h]=#{[x,y,w,h]}"
	if not x
		x,y,w,h = get_rectangle_este_browser
	end
	FileUtils.rm get_arq_rectangle_do_slot if File.exist? get_arq_rectangle_do_slot
	File.write(get_arq_rectangle_do_slot,"#{x}@#{y}@#{w}@#{h}")
end

def le_rectangle_deste_browser
	x,y,w,h=nil
	retval = nil
	arq = get_arq_rectangle_do_slot
	if File.exist? arq
		x,y,w,h = File.read(arq).split("@")
		#FileUtils.rm get_arq_rectangle_do_slot
		retval =  [x.to_i,y.to_i,w.to_i, h.to_i]
	end
	write_rsi_log :trace, "chamou le_rectangle_deste_browser, arq=#{arq}, retval=#{retval}"
	return retval
end

def desocupar_slot_de_janela_do_tpn(tpn = nil)
	tpn = tpn || get_process_num
	slot_file = get_arq_slot_da_janela(tpn)
	if slot_file
		FileUtils.rm(slot_file)
	end
	return slot_file
end	

def ocupar_slot_de_janela_do_tpn(browser_window_handle)
	write_rsi_log :trace, "START ocupar_slot_de_janela_do_tpn, browser_window_handle=#{browser_window_handle}"
	meu_slot_file = get_arq_slot_da_janela
	write_rsi_log :trace, "P02 ocupar_slot_de_janela_do_tpn"
	if meu_slot_file
		write_rsi_log :trace, "P03 ocupar_slot_de_janela_do_tpn"
		#deveria falhar, está reocupando slot sem ter fechado corretamente, desocupando
		#write_rsi_log :error, "ocupar_slot_de_janela_do_tpn(tpn=#{tpn}) - jah estah ocupando um slot"
		#Kernel.exit! 1
		falhar "ocupar_slot_de_janela_do_tpn(get_process_num=#{get_process_num}) - jah estah ocupando um slot, arquivo de slot=#{meu_slot_file}"
	end

	write_rsi_log :trace, "P04 ocupar_slot_de_janela_do_tpn"
	slot_files_ocupados = Dir["#{get_automdir}/TPN*_SLOT_JANELA_*.LCK"]
	slot_numbers_ocupados = slot_files_ocupados.map do |nmarq|
		write_rsi_log :trace, "P05 ocupar_slot_de_janela_do_tpn"
		slot_num = get_slot_do_arq_slot(nmarq)
		write_rsi_log :trace, "P06 ocupar_slot_de_janela_do_tpn"
		slot_num
	end
	write_rsi_log :trace, "P07 ocupar_slot_de_janela_do_tpn"
	slot_livre = nil
	get_paralelismo.times do |k|
		write_rsi_log :trace, "P08 ocupar_slot_de_janela_do_tpn"
		slot = k + 1
		if not (slot_numbers_ocupados.include?(slot))
			slot_livre = slot
			break
		end
	end
	write_rsi_log :trace, "P09 ocupar_slot_de_janela_do_tpn"
	if not slot_livre
		write_rsi_log :trace, "P10 ocupar_slot_de_janela_do_tpn"
		falhar "ASSERTION FAILED - Nao existe slot livre de numero de janela de browser"		
	end

	write_rsi_log :trace, "P11 ocupar_slot_de_janela_do_tpn"
	novo_arq_slot = "#{get_automdir}/TPN_#{get_process_num}_SLOT_JANELA_#{slot_livre}.LCK"
	File.open(novo_arq_slot,"w") {
		|f| 
		write_rsi_log :trace, "P12 ocupar_slot_de_janela_do_tpn"
		f.write browser_window_handle 
	}
	write_rsi_log :trace, "END ocupar_slot_de_janela_do_tpn"
	return slot_livre #deve ser inteiro, numero sequencial da janela de 1 até paralelismo 
end




def get_prefixo_ahk_processo
	return "ahk_TPN#{get_process_num}_"
end
def get_prefixo_ahk_geral
	return "ahk_TPN"
end

def del_exes_ahk_processo
	write_rsi_log :debug, "AHK running del todos do processo"
	c= "del features\\ahk\\#{get_prefixo_ahk_processo}*.exe"; write_rsi_log :debug, c; system c
end

def del_exes_ahk_geral
	write_rsi_log :debug, "AHK running del todos de todos processos"
	c= "del features\\ahk\\#{get_prefixo_ahk_geral}*.exe"; write_rsi_log :debug, c; system c
end


#2017Out25 - Notebook do Kaio nao tem dialog inicial erro, mas falha por AUTOMATION em
#outras chamadas a maximize etc !!
#
# Portanto, e POR DEFAULT, será mantido arquivo AMBIENTE_ERRO_AUTOMATION_EXT.CFG , sendo
# considerado parte dos fontes. Nos raros casos em que detectarmos que esse é danoso,
#além de desnecessário, podemos removê-lo. Atualmente, 2017Out25, sua presença nunca é
#severamente danosa, gerando tênue lentidão em notebooks de Renato Battaglia e Júlia Vieira.


def detected_automation_ext_erro?
	return File.exist? "#{get_automdir}/AMBIENTE_ERRO_AUTOMATION_EXT.CFG"
end
def do_detect_automation_ext_erro
	File.write "#{get_automdir}/AMBIENTE_ERRO_AUTOMATION_EXT.CFG",'erro'
end
def detected_automation_ext_ok?
	return File.exist? "#{get_automdir}/AMBIENTE_OK_AUTOMATION_EXT.CFG"
end
def do_detect_automation_ext_ok
	File.write "#{get_automdir}/AMBIENTE_OK_AUTOMATION_EXT.CFG",'ok'
end
def imgclick_via_codigo_nativo?
	return false 
	#2017Nov10 - ESTRANHO! Parece que, pra click que abre imagem, nao dá mais erro AUTOMATION_EXT!
end


def ascii_only_str(non_ascii_string)
	replacements = { 
	#  'á' => "a",
	# @ 'ë' => 'e'
	}



	encoding_options = {
	  :replace => "*",             # Use a blank for those replacements
	  :invalid   => :replace,     # Replace invalid byte sequences
	  :universal_newline => true, # Always break lines with \n
	  # For any character that isn't defined in ASCII, run this
	  # code to find out how to replace it
	  :fallback => lambda { |char|
	    # If no replacement is specified, use an empty string
	    replacements.fetch(char, "*")
	  },
	}

	ascii = non_ascii_string.encode(Encoding.find('ASCII'), encoding_options)
	#puts ascii.inspect
	return ascii
end

def add_app_prefix_to_msg(msg)
	return msg if msg == nil or msg.start_with? "App="
	return "#{prefixo_msg_app}#{msg}"
end

def prefixo_msg_app
	#2017Nov15 - pefixando mensagens de erro com "App=[mob ou webdesktop]" para mais
	#facil localizacao de erro.
	#
	# ENTAO: isso ainda nao nos ajuda quanto ao Nome Do Cenario/Nome da Feature.
	#
	# PORÈM... poderíeamos, sim, CHUMBAR no nome do Cenário/Feature , já que
	#reprocessamento é sempre também da mesma app
	#
	return nil if not ($massa and $massa.is_a? Hash and $massa.keys.length > 0)  
	return nil if ($massa['QUALAPP']||'')==''
	return "App=#{($massa||{})['QUALAPP']}: "
end

def add_appname_prefix_to_exception(e)
	# MÈTODO INÒCUO!
	#
	#    EU queria SEMPRE conseguir setar, mesmo que RAISE direto chamado em vez de FALHAR,
	# o App=[mob/webdesktop] no texto da exceção;
	#
	#    Porém, ao que parece, quando chego em "After do |scenario|" já é tarde demais
	# pra manipular "scenario.exception", ou é outra coisa que eu deveria manipular.
	#
	#    RESUMINDO: terei que colocar "App=" na excecao ou em "falhar" ou em 
	# "remove_nonascii_exception", que podem nao ser chamadas pra péssimas exceções
	# originadas diretamente em RBs de "feature/steps" (em tudo que não estiver
	# protegido por remove_nonascii_exception/falhar) 
	#
	#MÈTODO INÒCUO!
	#
	#

	write_rsi_log :debug, "add_appname_prefix_to_exception,e=#{e.inspect}, P00" 
	emsg=nil

	begin
		write_rsi_log :debug, "add_appname_prefix_to_exception P01 - vai obter emsg" 
		emsg = e.message
		write_rsi_log :debug, "add_appname_prefix_to_exception P02 - emsg=#{emsg}"
	rescue Exception => xe
		write_rsi_log :debug, "add_appname_prefix_to_exception P03 - EXCECAO AO OBTER emsg,"
		return e
	end

	write_rsi_log :debug, "add_appname_prefix_to_exception P04 - serah q comeca com App= ?"
	if emsg.start_with? "App="
		write_rsi_log :debug, "add_appname_prefix_to_exception P05 - comeca com App=, OK"
		return e
	end

	write_rsi_log :debug, "add_appname_prefix_to_exception P06 - nao começa com App= , vai manipular"
	new_text=add_app_prefix_to_msg(new_text)
	write_rsi_log :debug, "add_appname_prefix_to_exception P07 - nao começa com App= , new_text=#{new_text}"
	begin
		write_rsi_log :debug, "add_appname_prefix_to_exception P08 - lançando excecao pra entar ter nova exception"
		raise e, new_text, e.backtrace #produz nova excecao com App=
	rescue Exception => xe
		write_rsi_log :debug, "add_appname_prefix_to_exception P09 - obtida a execao, retornando"
		return xe #retorna nova excecao com App-
	end
	falhar "add_appname_prefix_to_exception P10 - NUNCA DEVE CHEGAR AQUI"
end

def remove_nonascii_exception
	#2017Out17 - TODOS entry-points de page-object devem ser protegidos por este método
	begin
		yield
	rescue Exception => e
		write_rsi_log :trace, "remove_nonascii_exception, e=#{e}, e.class=#{e.class}"
		new_text=nil
		begin
			emsg=e.message
			new_text=add_app_prefix_to_msg(ascii_only_str(emsg))
		rescue Exception => xe
			write_rsi_log :trace, "remove_nonascii_exception - Excecao #{xe} ao obter e.message"
		end
		if new_text and new_text != e.message
			raise e, new_text, e.backtrace
		else
			raise e
		end
	end
end

def get_msgerr_desculpe_fazendo_ajustes
	"Desculpe, estamos fazendo alguns ajustes"
end

def get_msgerr_label_solicitacao_enviada_nao_presente_na_tela
	"Elemento que indica [solicitacao enviada corretamente] nao estah presente na tela"
end
def get_msgerr_cpf_ja_usado
	"CPF já usado antes na abertura de conta digital PF"
end

def get_msgerr_cpf_recuperado_ou_maisdados
	"Elemento que [pede mais dados OU indica cpf já em uso/recuperado] nao estah presente na tela"
end

def get_cpf_obterorisco
	'obterorisco' #2018Mar14 earlyam-UNDERSCORE,'_', prejudicava separacao de fields em zs_proc !!!!!!!!!!!    #2017Nov24
end

def escreve_xls_de_hash(xlsname,data)
	begin
		mkdir_noexist get_automtmpdir
	rescue SystemCallError => e
		#nada
	end
	f_m = nil
	nome_tmp="#{get_automtmpdir}/csv_tmp_#{obtem_guid}.txt"

	begin
		f_m = File.open(nome_tmp, "w+t")

		data.keys.each_index do |i|
			f_m.write data.keys[i]
			if i < (data.keys.length - 1)
				f_m.write ";"
			else
				f_m.write "\n"
			end
		end
		data.keys.each_index do |i|
			k=data.keys[i]
			f_m.write data[k].to_s # ASPAS simples - sugere formato
			if i < (data.keys.length - 1)
				f_m.write ";"
			else
				f_m.write "\n"
			end
		end
	rescue Exception => e
		f_m.close if f_m != nil
		raise e
	ensure
		f_m.close if f_m != nil
	end

	book = Spreadsheet::Workbook.new
	sheet1 = book.create_worksheet
	header_format = Spreadsheet::Format.new(
	  :weight => :bold,
	  :horizontal_align => :center,
	  #:bottom => true, #exemplo q vi bottom invalido
	  :locked => true
	)
	sheet1.row(0).default_format = header_format
	CSV.open(nome_tmp, 'r', :col_sep=>';') do |csv|
		csv.each_with_index do |row, i|
	    	#write_rsi_log :debug, "manipulando linha #{i}"
	    	sheet1.row(i).replace row
	  	end
	end
	FileUtils.rm nome_tmp

	book.write(xlsname)
	#book.io.close #2018Mar11 - pode resolver problemas intermitentes de nao permitir edição de XLSs criados pelo programa  #DAMN, depois de write, io fica nil. FIQUE ATENTO!
	return
end

def janelas_sempre_maximizadas?
	#2017Nov29 - deve ler arquivo de configuracao...
	
	sempre = true #2017Dez29 - valor para testes em massa deve ser true!!!!!!! 2017Dez29 20:44 - naoestah fazendo RESIZE/REPOSICIONANDO!

	return (sempre or get_paralelismo == 1)
end

def write_text_to_file(fname, str)
	File.open(fname,'w') { |f| f.write("#{str}") }
	return
end

def strzero(inum, nchars)
	fmtstr="%0#{nchars}d"
	return sprintf(fmtstr, inum)
end

def gera_screenshot(nomeTela=nil)
	if false
		10.times {write_rsi_log :debug, "gera_screenshot, desabilitados, nomeTela=#{nomeTela}"}
		return
	end

    sleep 4 if false #2018Out8 - sleep removido #rbattaglia 2018Fev06 - já tinha este sleep 4. Necessario? Sempre?
    executa_exclusivo do
    	
        #rbattaglia 2018Fev06 - CReiO que falhará para "janelas lado-a-lado". Alwaysmax=OK
    	scrshot_fullpath = "#{get_nome_de_screenshot}/#{Time.now.strftime('%y%m%d-%H%M%S')}_#{nomeTela}.browser.png"
    	begin
        	#2018Set09 - usando sempre screenshots nativos do windows para aparecer URL do browser
        	if false
        		page.save_screenshot scrshot_fullpath
        	else
        		traz_esta_janela_pra_topo
        		mkdir_noexist File.dirname(scrshot_fullpath); Win32::Screenshot::Take.of(:desktop).write!(scrshot_fullpath) 
        	end
    	rescue Exception => e
    		write_rsi_log :error, "Erro excecao=#{e} , gerando screenshot, filepath=scrshot_fullpath, e.backtrace=#{e.backtrace}"
    	end
    end
	return
end


def load_java_properties(properties_filename)
    properties = {}
    File.open(properties_filename, 'r') do |properties_file|
      properties_file.read.each_line do |line|
        line.strip!
        if (line[0] != ?# and line[0] != ?=)
          i = line.index('=')
          if (i)
            properties[line[0..i - 1].strip] = line[i + 1..-1].strip
          else
            properties[line] = ''
          end
        end
      end      
    end
    properties
end

def save_java_properties(properties_filename, hash_props)
#	write_rsi_log :debug, "save_java_properties P00, properties_filename=#{properties_filename}, hash_props=#{hash_props}"
	out_str=''
	hash_props.keys.each do |k|
		out_str=out_str+"#{k}=#{hash_props[k]}\n"
	end
	tmp_path = "#{get_automtmpdir}/temp.#{obtem_alphanum_guid}.properties" #2018Mar19 earlyam - estava gerando PERMISSION DENIED antes, por faltar desambiguador "obtem_alphanum_guid" no nome do arquivo temporario!
	File.open(tmp_path,'wt') { |f| f.puts out_str }
	FileUtils.mv tmp_path, properties_filename
	write_rsi_log :debug, "save_java_properties retornando, properties_filename=#{properties_filename}, hash_props=#{hash_props}"
end
def incrementa_global_scenario_count
	$global_scenario_count = (((File.read("#{get_automdir}/global_scenario_count.lck") rescue nil)||'0').split("\n").first.to_i+1); File.open("#{get_automdir}/global_scenario_count.lck",'w') {|h| h.write($global_scenario_count)}; $global_scenario_count
end

def run_command_retry_eagain(c, nof_tries=15)
	o=nil
	nof_tries.times do |try_num| 
		begin 
			o = out_system(c)
			break
		rescue Errno::EAGAIN => eagain
			write_rsi_log :debug, "Excecao #{eagain} em run_command_retry(c='#{c}''), tentativa #{try_num+1} de #{nof_tries}"
			if try_num+1 == nof_tries
				raise eagain
			end
		end
	end
	return o
end

def screen_is_unlocked
	#write_rsi_log :debug, "screen_is_unlocked, vai rodar e achar imagem de notepad.exe pra detectar se ´nao houve screen lock"
	retval = true
	begin

		notepad_pid = spawn "notepad.exe"
		#write_rsi_log :debug, "screen_is_unlocked, notepad_pid=#{notepad_pid}"
		sleep 5
		#write_rsi_log :debug, "screen_is_unlocked, vai rodar AHK img_notepad_new"
		exit_code = run_autohk_copia 'img_notepad_new'
		#write_rsi_log :debug, "screen_is_unlocked, rodou AHK img_notepad_new, exit_code=#{exit_code},"
		killret = Process.kill 9, notepad_pid
		retval = (exit_code == 0)
		write_rsi_log :debug, "screen_is_unlocked, matou com Process.kill notepad.exe, retornando, killret=#{killret}, retval=#{retval}"
	rescue Exception => e
		write_rsi_log "screen_is_unlocked() - Retornando #{retval} por excecao #{e} obtida durante screen_is_unlocked, full stack trace=#{e.backtrace}"
	end
	return retval
end

def keep_machine_awake
	# TODO 2018Fev20 - ESTA ROTINA DEVE SER CHAMADA EM LOOP ETERNO NO CONSOLE IRB DE MÀQUINA CLIENTE QUE ABRIU A VM! ASSIM, EVITA SCReENLOCK DO CLIENT QUE RESULTA EM SCREENLOCK DA VM!
	# TBM PODE E DEVE SER CHAMADA NO CÒDIGO DE autom QUE RODA NA VM! 
	run_autohk_copia 'keep_awake_client_and_vm'
end


def remove_aged_file(fpath, seconds)
	removeu = false
	existe = File.exist?(fpath)
	agora = Time.now
	mtime = File.mtime(fpath) if existe
	idade = (agora - mtime) if mtime
	if File.exist?(fpath) and (Time.now - File.mtime(fpath) > seconds)
		FileUtils.rm fpath
		removeu = true
	end
	write_rsi_log "remove_aged_files, removeu=#{removeu}, fpath=#{fpath}, seconds=#{seconds}, existe=#{existe}, idade=#{idade}, mtime=#{mtime}, agora=#{agora}"
	return removeu
end

def get_maxval_nice
	return 999999
end

def get_nice(s)
	return nil if not s
	retval = ((s[/nice.*\d+.*X/i]||'999999')[0..15][/\d+/]||'999999').to_i
	return retval
end

def get_last_guid(s)
	return nil if not s
	return nil if not is_str_alphanumeric?(s)

	return get_alphanumeric( (s.split('guid').last)||'' .strip )
end

def get_random_cpf(last_digit=9)
	return strzero(Random.new.rand(1..99999999999)/10+last_digit, 11)
end

def out_system(cmdline)
	return `#{cmdline}` 


	tmpfname = "#{get_automtmpdir}/out_system_#{obtem_alphanum_guid}.txt"
	cmd_completo = "#{cmdline} >#{tmpfname} 2>&1}"
	system cmd_completo
	retval = File.read(tmpfname) if File.exist? tmpfname
	FileUtils.rm tmpfname if File.exist? tmpfname
	return retval
end

def create_new_file(fname, content = nil)
	retval = nil
	File.open(fname,File::WRONLY|File::CREAT|File::EXCL) { |f|
		if content
			f.write content
		end
		if block_given?
			retval = yield(f)
		end
	}
	return retval
end

def kill_and_watch(signatures, max_tempo = 128)
#2018Set02 - max_tempo agora tem default 128 (antes, nao tinha nenhum). ATENCAO - max_tempo ainda é ignorado! fica pra sempre!
#2018Ago16 pm, - residuo de CTRL+C/cmd_stop em "stt*act=done*.7z" aconteceu algumas vezes (COMPLEXAS DE DEBUGAR), gerando prolema em condolidador de reports (zs\zs_proc.rb consolidador). SOLUÇÂO: colocar asinaturas no método "zs_proc.rb::zs_run_parallel_process_signatures" na ordem correta, e, também, matar e esperar (em método "kill_and_watch") um a um os processos(em vez de matar_todos+esperar_todos.
	t_ini = Time.now
	while true
		undead = first_undead(signatures) 
		if undead == nil
			break
		end

		while not is_dead?( [undead] )
			#2018Ago16 - insiste em matar processos(s) da assinatura até conseguir, só vai tentar outras assinatura quando esta estiver morta.
			t_now = Time.now
			elapsed = t_now - t_ini
			write_rsi_log :debug, "killandwatch - elapsed=#{elapsed}, max_tempo=#{max_tempo}, t_ini=#{t_ini}, t_now=#{t_now}, undead=#{undead}, signatures=#{signatures}" 
			
			if elapsed > max_tempo
				write_rsi_log :error, "NAO ABORTANDO POR ISSO, TENTANDO PROSSEGUIR MESMO ASSIM - kill_anw_watch excedeu tempo limite, elapsed=#{elapsed}, max_tempo=#{max_tempo}, t_ini=#{t_ini}, t_now=#{t_now}, undead=#{undead}, signatures=#{signatures}" 
			end
			write_rsi_log :debug, "killandwatch, P05.1 - ESPERANDO A MORTE de signatures, mandando matar o primeiro undead com zs_kill, undead=#{undead}, signatures=#{signatures}"
			just_kill [undead]
			write_rsi_log :debug, "killandwatch, P05.2 - ESPERANDO A MORTE de signattures, mandei matar  o primeiro undeadcom kill_run_parallel, undead=#{undead}, signatures=#{signatures}"
		end

	end
	return
end

def just_kill(assinaturas)
	raise 'just_kill, parametro assinaturas invalido' if not (assinaturas and assinaturas.is_a? Array)
	write_rsi_log "just_kill, assinaturas=#{assinaturas}"
	tempo_dormir=1 #posso refinar conforme CFG de cada máquina de zs
	vezes=1 #2018Fev26 - ERAM 3 VEZES JÀ AQUI! NAO PRECISA! zs_kill é chamada em LOOP! ISSO TIMEOUTAVA??? ESTRANHAMENTE?? Sem protecao contra falhar? Efeito colateral presumido de antes = "nao avancava em run_parallel ?? nao ia de waiting pra running?" 
	vezes.times do |m|
		vez = m + 1
		assinaturas.length.times do |k|
			a=assinaturas[k]
			if a.class == Array
				assinatura = a[0]
				tempo_sleep_depois_matar = a[1]
			else
				assinatura = a
				tempo_sleep_depois_matar = 0
			end

			where = clausula_wmic_where_de_pid_ou_palavras(assinatura)
			write_rsi_log :debug, "just_kill, (vez #{vez} de #{vezes}) - Vai chamar mata_todos_processos com where=#{where}"
			mata_todos_processos where
			sleep tempo_sleep_depois_matar

			#vai_dormir= (k==assinatura.length-1) ? 0: tempo_dormir
			vai_dormir= tempo_dormir
			write_rsi_log :debug, "just_kill, (vez #{vez} de #{vezes}) - Chamou     mata_todos_processos com where=#{where}, dormindo #{vai_dormir} segundos"
			sleep vai_dormir
		end
	end
	return
end

def is_dead?(signatures)
	raise "is_dead?, paramatro signatures invalido, deve ser Array, signatures=#{signatures}" if not (signatures and signatures.class == Array) #2018Set01 - aumentado rogor no parametro signatures
	return first_undead(signatures) == nil
end

def first_undead(signatures)
#2018Ago16 pm, criado.
	raise "first_undead, paramatro signatures invalido, deve ser Array, signatures=#{signatures}" if not (signatures and signatures.class == Array) #2018Set01 - aumentado rogor no parametro signatures
	write_rsi_log :debug, "first_undead, signatures=#{signatures}"

	rstart=Time.now
	
	retval = signatures.find {|s|
		if s.class == Array
			signature = s[0]
			write_rsi_log :debug, "first_undead - signature = #{signature} nao checavel, presumindo que morreu"
			alive = false
		else
			signature = s
			write_rsi_log :debug, "first_undead - signature = #{signature} normal, checavel, vai conferir no sistema operacional se morreu"
			where_clause = clausula_wmic_where_de_pid_ou_palavras(signature)
			alive = processo_naofilho_executando?(where_clause) #2018Set01 - capaz de interpretar multiplas palavras separadas por espaço para where clause
			if alive
				write_rsi_log :debug, "first_undead, ainda há processos rodando com assinatura #{signature}"
			end
		end
		alive
	} 
	rend=Time.now; rsecs=rend-rstart;write_rsi_log :debug, "first_undead - rsecs=#{rsecs}"
	return retval
end

def set_wmic_priority
	#
	#      TODO 2018Mar29 - EMBRIAO de monitorador e modificador de sistema
	# operacional, visando monitorar e alterar constantemente settings 
	# para aumento de desempenho da automação.

	cmd=''
	exes =['ruby','chrome','java','javaw','cmd', '7za', "lftruntime"]
	exes.length.times do |i| 
		exe = exes[i]
		cct = ''
		if i > 0
			cct = ' & '
		end
		cmd = cmd + cct + 'wmic process where name="' + exe + '.exe" call setpriority "high priority"'
	end
	write_rsi_log :debug, "WIN32/WMIC - aumentando a prioridade de exes=#{exes}, cmd=#{cmd}"
	system cmd
end

def exitcode_ok_de_run_parallel
	return 100
end

def str_short_random(s_orig, lmax, preserve_words=nil)
	#TODO 2018Mai5 - nao remover caracteres que estejam no meio da palavra 'Rnd'
	preserve_words = preserve_words || Array.new
	falhar "str_short_random, parametro preserve_words=#{preserve_words} invalido" if preserve_words.class != Array

	s_new = s_orig
	#puts "check, s_orig=#{s_orig}, len=#{s_orig.length}"
	while s_new.length > lmax
		preserve_w_pos = []  #posicao de cada palavra que nao pode ser adulterada
		preserve_words.each do |w|
			i = s_new.index w
			w.length.times do |k|
				preserve_w_pos << i + k #todas as posicoes na String ocupadas pelas palavras a preservar. Exempo: s=Rnd1000020000BLABLABLAMrk25 , preserve_words=['Rnd','Mrk'], preserve_w_pos ficará [0,1,2,22,23,24], de forma a impedir que qualquer um dos caracteres com essas posições sejam removidos para reduzir comprimento da string.
			end
		end
		#puts "preserve_w_pos=#{preserve_w_pos}"

		p1=''
		p2=''
		pos_remove = nil
		visited=[] #posicoes ja visitadas. Se ja visitou todas , falha/raise 
		begin 
			if visited.length == s_new.length
				falhar "str_short_random, nao foi possivel reduzir palavra, s_orig=#{s_orig}, lmax=#{lmax}, preserve_words=#{preserve_words}, s_new=#{s_new}"  		
			end
			pos_remove = Random.new.rand(0..s_new.length-1) 
			visited << pos_remove if not visited.include?(pos_remove)
		end until not preserve_w_pos.include?(pos_remove) #loop até que tenha escolhido caracter a remover que nao esteja dentro das palavras a preservar
	
		#puts "pos_remove=#{pos_remove}"
		p1 = s_new[0..pos_remove-1] if pos_remove > 0
		#puts "p1=#{p1}"
		p2 = s_new[pos_remove+1..-1] if pos_remove < s_new.length - 1
		#puts "p2=#{p2}"
		s_new = "#{p1}#{p2}"
		#puts "agora, s_new =#{s_new}, len=#{s_new.length}"
		falhar 'Erro interno de implementacao' if s_new.length > s_orig.length 
	end
	s_new
end

def ler_um_excel_de_7z(sevenz_fullpath)
	tmpd = "#{get_automtmpdir}/umexcel#{zs_new_global_id}"
	mkdir_noexist tmpd; delete_all_in_dir tmpd
	pwd = Dir.pwd
	Dir.chdir tmpd
	system "7za x #{sevenz_fullpath}"
	Dir.chdir pwd
	xlsfile = Dir.glob("#{tmpd}/**/*.xls").first
	h = ler_xls_com_id(xlsfile) if xlsfile 
	FileUtils.rm_rf tmpd
	return h
end