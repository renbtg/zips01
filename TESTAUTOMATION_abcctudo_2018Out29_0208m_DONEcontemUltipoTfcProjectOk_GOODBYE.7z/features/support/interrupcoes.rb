require 'timeout'
$INTERROMPIDO=false
def deve_interromper?(file_path, quais)
	#2018Set30 - extensao mudada de LCK para ITR, para na confundir com LOCK_EXCLUSIVO
	#2018Set30 - pode ser passado em ENV VAR 'TEST_INTERRUPCOES_PREFIXO' dirpath e feature
	retval = false
	if File.exist?(file_path)
		if quais==nil
			retval = true
		else
		 	bname = File.basename(file_path,'.ITR')
			uma=bname.split('.').last
		 	if quais.include? uma
				retval = true
			end
		end
	end
	return retval
end

def interrupcoes_file_names(tipo_de_interrupcao)
	#2018Set40, created
	#2018Set30 - pode ser passado em ENV VAR 'TEST_INTERRUPCOES_PREFIXO' dirpath e feature
	#2018Out6, 22:34pm - pode haver multiplos arquivos de interrupcao
	if ENV['TEST_INTERRUPCOES_PREFIXO']
		prefixos = ENV['TEST_INTERRUPCOES_PREFIXO'].split(',')
		file_names=prefixos.map{|prefixo| "#{prefixo}.#{tipo_de_interrupcao}.ITR"} 
		#ex: z:/zs/zs_a/feature_Rnd400a1100solteiroBlaBlaCredito_TERMINATE.ITR
	else
		file_names = ["#{get_automdir}/#{tipo_de_interrupcao}.ITR" ]#ex: c:/arAlgo/TERMINATE.ITR
	end
	if false #hyper debugging
		write_rsi_log :debug, "interrupcoes_file_name(tipo_de_interrupcao=#{tipo_de_interrupcao}), file_names=#{file_names}"
	end
	
	return file_names
end


def checa_interrupcoes(quais=nil) 
	#2018Abr20 - ATENCAO, apenas confiamos na capacidade de TERMINATE, as outras coisas , principalmente PAUSAR, estão DEPRECATED!!!!!


#2017Ago19, PAUSAR/RECOMECAR/TERMINAR
# SUSPENDER espera cucumber terminar, checado apenas após chamada ao cucumber: nao gera erro em teste

# Parametros:
    #quais --- Passar ARRAY de quais arquivos lock deve checar. Com ou sem .LCK ao fim.
    #        # parametro quais==nil, checa todos tipos de interrupcao 
    #
    #                         quais ...    Em cucumber, deve ser ['PAUSAR', 'TERMINATE'], sem 'SUSPEND',
    #                                   pois SUSPEND significa que queremos que cucumber termine 
    #                                   normalmente sua feature que já está executando, deixando apenas 
    #                                   para programas chamadores (run_parallel.rb e 
    #                                   consumidor_de_deatures.rb a tarefa de sair)    
    #                                    
    #                                      Ja os outros programas devem também checar SUSPEND. 
    #
    # block --- bloco a chamar para EXIT do programa. passar...
    #             {|msg| falhar msg} # se em cucumber 
    #             {|msg| $LOG.debug msg; exit 1} # se em outros programas
    #
    # CUIDADO! nao deve chamar rotinas de rsi_log.rb no block, pois rsi_log.rb talvez chame esta func! 

	if $INTERROMPIDO
		return #já interrompido acima no STACK, apenas retorna 
	end

	if quais and (not quais.is_a? Array)
		quais = [quais]
	end

	timeouts_recebidos = []
	while true
		begin
			deve = false
			begin
				deve_pausar    = interrupcoes_file_names('PAUSAR'   ).any?{|fname| deve_interromper? fname,quais}
				deve_terminar  = interrupcoes_file_names('TERMINAR' ).any?{|fname| deve_interromper? fname,quais}
				deve_suspender = interrupcoes_file_names('SUSPENDER').any?{|fname| deve_interromper? fname,quais}
			rescue StandardError => e
				write_rsi_log :warn, "checa_interrupcoes, Excecao em deve_interromper, excecao=#{e}"
			end
			
			deve = 
				(deve_pausar ||
				deve_terminar ||
				deve_suspender)

			break if not deve


			$INTERROMPIDO=true
			if deve_terminar #2017Set28 - deprecating, serah trocado por KILL em LNK
				yield "Processamento terminado , saindo, existe lock TERMINAR" # ABORTA
			end
			
			if deve_suspender  #2017Set28 - deprecating, serah trocado por KILL em LNK
				yield "Processamento suspenso , saindo, existe lock SUSPENDER" # ABORTA
			end

			write_rsi_log :info, "Processamento temporariamente pausado, existe lock PAUSAR" 
			sleep 1
		rescue Timeout::Error => e
			timeouts_recebidos << e
		end	
=begin
		@@@@@@@@@@@@@@@
		** ATENCAO - ao chegar aqui, um REWIND de todos timeouts deveria ocorrer.

		** Nao basta ignorar aqui excecoes de timeout...  

		** PORÈM, se eu deixar aqui o PAUSAR eterno, até que seja apagado PAUSAR.LCK,
		os efeitos colaterais nao seriam tao danosos... NAO MESMO?
			** HMMM, pode ficar complicado...
			** Ex: 
			begin
				Timeout 100 do
					while true do
						checa_interrupcoes
						if algo_no_filesystem
							break
						end 
					end
				end
			rescue TimeoutException => e
				puts "shit happened - timeout"
			end 

			** No código acima, checaria excecao TimeoutException pra 
			checa_interrupcoes, e seria ignorada: nao sairir NUNCA do loop eterno

			** SOLUCAO: dentro de checa_interrupcoes, anoto a 1a excecao que vier...
			e, na saída do método (E.G. PAUSAR.LCK apagado), eu fazo RAISE dessa 1a
			excecao!
		@@@@@@@@@@@
=end

	end 
	$INTERROMPIDO=false
	raise timeouts_recebidos.first if timeouts_recebidos.length > 0 
	#2018Out3 - esse código de TIMEOUT é bem antigo e potencialmente frágil. Anyway, praticamente não uso Timeout do Ruby em código...

	#2017Set28 -nao para a PAUSA por excecao (tineout). Em vez disso, espera 
	#indefinidamente até que usuário remova PAUSAR.LCK, e entao lança proteladamente
	#o possivel timeout recebido anteriormente!!
	#             ** HMM, isso vai deixar transparante pra chamadora que declarou TIMEOUT?  
end