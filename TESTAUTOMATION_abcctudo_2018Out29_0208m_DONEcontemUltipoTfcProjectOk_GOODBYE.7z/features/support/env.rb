require_relative "./rsi_utils.rb"

include Capybara::DSL

=begin
TODO 2017Ago10 
	done 1) cucumber.yml já salva HTML e JSON
	todo 2) veja q.rtf , ^SÒ FALTA PARALELISMO E REPORT FINAL!
		TODO 2.a) prioridade inicial - paralelismo )OBS: nao se preocupe, cucuber.yml já vai salvar JSONs isolados)
		TODO 2.b) gema report.blabla, pra ler JSONs e gerar um report só
		TODO 2.c) achar jeito de linkar SCREENSHOT HTML em vez de SCREENSHOT PNG nos reports (html e json)
		TODO 2.d) segregar GERACAO da EXECUCAO, pode requerer conceitos novos de "artefatos intermediários"
=end

write_rsi_log :debug, 'env.rb, antes de register_driver'
Capybara.register_driver :selenium do |app| #Eu chamei de :selenium pela gema (agora nao usado) capybara-screenshot
	client = Selenium::WebDriver::Remote::Http::Default.new
  	client.open_timeout = 120 #2017Ago13 - visit, mais timeout: passar client em httpc_lient pra Capybara::Selenium::Driver.new 
  	client.read_timeout = 120 #2017Ago13 - visit, mais timeout: passar client em httpc_lient pra Capybara::Selenium::Driver.new 
  	write_rsi_log :debug, 'DO block de env.rb, register_driver, chamado!'
    capabilities = Selenium::WebDriver::Remote::Capabilities.chrome(accept_ssl_certs: true)  #2018Julho28 - bypassa aceitacao de certificado SSL invalido
	retval = Capybara::Selenium::Driver.new(app, :browser => :chrome, :http_client => client, desired_capabilities: capabilities)
	write_rsi_log :debug, "passou pelo Capybara::Selenium::Driver.new"
	#Capybara::Selenium::Driver.new(app, :browser => :internet_explorer)
	retval
end
write_rsi_log :debug, 'env.rb, depois de register_driver'

	Capybara.default_driver = :selenium
	Capybara.javascript_driver = :selenium

Capybara.configure do |config|
	config.default_max_wait_time = 20 #PRA ATUALIZACOES AJAX

end


$env_tratando_terminar = false if not defined?($env_tratando_terminar)
def rotina_de_interrupcao_em_log
	if $env_tratando_terminar
		return
	end


	#2018Set30 - readicionado método "rotina_de_interrupcao_em_log" para rápida morte, focada na FEATURE/CENARIO
	if false #hyper debugging interrupcoes
		write_rsi_log :debug,  'env.rb - rotina_de_interrupcao_em_log P00'
	end
	checa_interrupcoes do |msg|
		$env_tratando_terminar = true
		if true
			#   2018Out2, "manutenção durante vôo"
			#
			#   Potencialmente, fazer Kenel.exit mantém janela de chrome da feature aberta.
			#
			#   SAD BUT TRUE: eu gostaria que ccumber morresse imediata e incondicionalmente, mas Kernel.exit(1) apresenta
			# desafios novos que agora terei que enfrentar.
			#
			#   Pode ser que problemas se avolumem, e que eu deva mudar abordagem: Checagem SOFT em transicao fases/passos, ou
			# checagens explicitas ao longo do codigo cucumber/pageObjects de "devo cancelar processamentpo da feature por interrupcao?".
			#            ** OPCAO menos desejada é essa de checagens explicitas. 
			#

			write_rsi_log :debug, msg

			write_rsi_log :debug, "env.rb, tratando TERMINAR, vai fechar janela de browser, possivel efeito colateral se sem janela???"
			begin
				fecha_janela_browser
			rescue StandardError => e
				 write_rsi_log :error, "Excecao #{e}, backtrace=#{e} ao fechar_janela_browser dentro de rotina_interrupcao_de_log."
			end
			write_rsi_log :debug, "env.rb, tratando TERMINAR, fechou janela de browser, possivel efeito colateral se sem janela???"
			## SERÀ que podem ficar Autohotkeys em background presos?

			Kernel.exit! 1
		else
			#2018Out9 - manutenção durante vôo - GOSTARIA de falhar elegantemente com 'falhar X raise' em vez de Kernel.exit 
			$interrupcoes_deve_falhar = msg
			NAO_IMPLEMENTADO_AINDA_MORTE_SUAVA_VIA_CHECAGEM_PERVASIVA_EM_TFCdotRB_E_EM_GeraScreenshot
		end
	end
end
