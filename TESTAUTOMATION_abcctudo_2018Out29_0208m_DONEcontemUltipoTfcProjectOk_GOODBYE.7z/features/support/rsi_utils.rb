require 'monetize'
require 'cucumber'
require 'selenium/webdriver'
require 'capybara/dsl'
require 'site_prism'
require_relative './basic_utils.rb'
require_relative '../../veracidade_new_ok.rb' #2018Abr21, nova checagem de veracidade, HSPrevent
require_relative '../../risco_cpfs.rb'


require 'rspec/expectations'
require_relative './rsi_log.rb'
require_relative './interrupcoes.rb'
require_relative './rsi_spreadsheet.rb'
require_relative './shared_utils.rb'
require_relative '../../rsi_profiler.rb'
require_relative '../../tfc.rb'
require_relative '../../rotinas_processo.rb'
require_relative '../../ipc_processo.rb'

require 'cucumber/core/gherkin/parser'
#require 'cucumber/gherkin/formatter/json_formatter'
require 'stringio'


require 'selenium-webdriver'

require 'io/console'

ERR_FRAGMENT_NENHUMA_AGENCIA = 'selecionar_agencia: Nao foi encontrada na lista nenhuma agencia'

NUM_STEP_TFC = 10  #2018Ago02 - corrigido erro bobo de setar NUM_STEP_TFC para 3 #2018Julho28, PAD adicionado. #TFC.. 0a7=webdesk/mob. 8=veracidade. 9=todos passos de pasta digital,m são considerados mesmo numero de step. 11=TFC.
NUM_ULTIMO_STEP_FINAL_AUTOMACAO = NUM_STEP_TFC #TODO 2018Julho28 - quando houver devolucao e fluxos alternativos, muita coisa pode ter q ser alterada em matéria de numeros de passos VERSUS processo colaborativo VERSUA step definitions 
MAX_TENTATIVAS_FEATURE = 6 #gera_exec LINUX=0 #zs_proc = 5 #5 na mesma fase, quando passar de fase com sucesso, zera
MAX_GLOBAL_TENTATIVAS_FEATURE = 12 #gera_exec LINUX=0 #zs_proc = 15 3 #15 no total, nao importa como.     EXEMPLO pra gera_exec sem zs_proc e sem TFC: Hackeamos NUM_ULTIMO_STEP_FINAL_AUTOMACAO=9, MAX_TENTATIVAS_FEATURE pra 1 e MAX_GLOBAL_TENTATIVAS_FEATURE pra 3.

def get_max_tentativas_feature
	return 0 if ENV['TEST_REPROC']=='0'
	return MAX_TENTATIVAS_FEATURE
end
def get_max_global_tentativas_feature
	return 0 if ENV['TEST_REPROC']=='0'
	return MAX_GLOBAL_TENTATIVAS_FEATURE
end

def get_step_maxval_notfailed
	return 999
end
def get_step_maxlen
	return get_step_maxval_notfailed.to_s.length
end

def step_strzero(step_num)
	stz_step = strzero(step_num.to_s.to_i, get_step_maxlen) if step_num
	return stz_step
end

module Capybara
	class << self
		def current_session
			#rbattaglia - SitePrism SEMPRE usa Capybara.page que é a mesma
			#coisa que Capybara.current_session
			#
			#   Portanto, pra obter confiavel nova sessao, tenho que fazer
			# MONKEY-PATCH de current_session do Capybara !!!!!!
			#
			####session_pool["#{current_driver}:#{session_name}:#{app.object_id}"] ||= Capybara::Session.new(current_driver, app)
			write_rsi_log :trace, 'RSI MONKEY-PATCH 0 Capybara::current_session'
			#begin
			#	raise 'veja stack de current_session'
			#rescue Exception => e
			#	write_rsi_log :debug, e.backtrace
			#end
			if not defined? $pagina_capybara 
				$pagina_capybara = Capybara::Session::new(:selenium)
			end
			return $pagina_capybara
		end
	end
end

Capybara::Selenium::Driver.class_eval do

  def browser
    unless @browser
      write_rsi_log :debug,  "RSI - monkey-patched Capybara::Selenium::Driver (gem version capybara-2.15.1), startingCapybara::Selenium::Driver"
      if firefox?
        options[:desired_capabilities] ||= {}
        options[:desired_capabilities].merge!({ unexpectedAlertBehaviour: "ignore" })
      end

      @processed_options = options.reject { |key,_val| Capybara::Selenium::Driver::SPECIAL_OPTIONS.include?(key) }
      @browser = Selenium::WebDriver.for(options[:browser], @processed_options)

      @w3c = ((defined?(Selenium::WebDriver::Remote::W3CCapabilities) && @browser.capabilities.is_a?(Selenium::WebDriver::Remote::W3CCapabilities)) ||
              (defined?(Selenium::WebDriver::Remote::W3C::Capabilities) && @browser.capabilities.is_a?(Selenium::WebDriver::Remote::W3C::Capabilities)))

      main = Process.pid
      if false
	      at_exit do
	        # Store the exit status of the test run since it goes away after calling the at_exit proc...
	      	if true
	      		write_rsi_log :debug, "RSI - monkey-patched o at_exit em (def Capybara::Selenium::Driver.browser), pra nao chamar quit e nao conflitar com processo!"
		        @exit_status = $!.status if $!.is_a?(SystemExit)
		        exit @exit_status if @exit_status # Force exit with stored status
	      	else
		        @exit_status = $!.status if $!.is_a?(SystemExit)
		        quit if Process.pid == main
		        exit @exit_status if @exit_status # Force exit with stored status
		    end
	      end
	    end
	 else
	 	xmsg = "RSI monkey-patch - NAO registrando hook at_exit em Capybara::Selenium::Driver.browser !!!!"
	 	write_rsi_log :debug, xmsg if false
	 end
    @browser
  end
end



Selenium::WebDriver::Driver.class_eval do
    def zquit

=begin
CASO necessite de monley-patch de quit, renomeie zquit para quit e USE!
=end

      STDOUT.puts "#{self.class}#quit: no-op"
    end
  end

Selenium::WebDriver::Chrome::Driver.class_eval do
    def zquit

=begin
CASO necessite de monley-patch de quit, renomeie zquit para quit e USE!
=end

      STDOUT.puts "#{self.class}#quit: no-op"
    end
  end

Selenium::WebDriver::Chrome::Service.class_eval do
=begin
CASO necessite de monley-patch de stop, renomeie zstop para stop e USE!
=end
      def zstop
        #STDOUT.puts "#{self.class}#stop: no-op"
      end
    end
		
#
#
# 2017Set19 - NAO USO MAIS gema caoybara-screenshot!
#
#


module Cucumber #TRAZIDO de automacao Mobile PJ, tentando evitar INCOMPATIBLE ENCODING sem screenshot
	module Formatter
		module Console
			def print_failing_scenarios(failures, custom_profiles, given_source)
		    	if false
				     10.times{write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: NAO IMPRIMINDo, afetarah apenas console????"}
		    		return
		    	end
		    	begin
		    	  begin
		    	  	#raise 'nada, pra ver stack de print_failing_scenarios'
		    	  rescue Exception => e	
				     write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: full stack=#{e.backtrace}"
		    	  end	

				  write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: executando codigo original copy-pasted"
		          @io.puts format_string("Failing Scenarios:", :failed)
		          write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios:P10"	
		          
		          failure=nil
		          source = nil
		          fst = nil
		          fst_utf8 = nil
		          failures.each do |fl|
		          	failure=fl
		          	write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios:P20"	

			          profiles_string = custom_profiles.empty? ? '' : (custom_profiles.map{|profile| "-p #{profile}" }).join(' ') + ' '
		          	write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios:P30"	
			          source = given_source ? format_string(" # " + failure.name, :comment) : ''
		          	write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios:P40"	
			          fst = format_string("cucumber #{profiles_string}" + failure.location, :failed) 
		          	
		          	write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios:P41"	
			          fst_utf8 = fst.encode('UTF-8')
		          	write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios:P42"	
			          @io.puts "#{fst_utf8}#{source}" #orig=@ios.puts fst + source
		          	write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios:P50"	
			       end
		          	write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios:P60"	
			       @io.puts
		          	write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios:P70"	

					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: AFTER ONE PRINT, failures=#{failures}" 
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: AFTER ONE PRINT, ,failure=#{failure}, "
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: AFTER ONE PRINT, given_source=#{given_source}, "
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: AFTER ONE PRINT, failure.name=#{failure.name},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: AFTER ONE PRINT, failure.name.encoding=#{failure.name.encoding},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: AFTER ONE PRINT, source=#{source},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: AFTER ONE PRINT, source.encoding=#{source.encoding},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: AFTER ONE PRINT, fst=#{fst},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: AFTER ONE PRINT, fst.encoding=#{fst.encoding},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: AFTER ONE PRINT, cenarios com falha,fst_utf8=#{fst_utf8},"

		        rescue Exception => e
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha, exception=#{e}"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha, failures=#{failures}" 
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha,failure=#{failure}, "
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha,given_source=#{given_source}, "
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha,failure.name=#{failure.name},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha,failure.name.encoding=#{failure.name.encoding},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha,source=#{source},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha,source.encoding=#{source.encoding},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha,fst=#{fst},"
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha,fst.encoding=#{fst.encoding},"

					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_failing_scenarios: erro ao imprimir cenarios com falha,fst_utf8=#{fst_utf8},"
		        end
		    end
		 end
	end
end

module Cucumber #TRAZIDO de automacao Mobile PJ, tentando evitar INCOMPATIBLE ENCODING sem screenshot
	module Formatter
		module Console
			def print_exception(e, status, indent) #rbattaglia - evita MUITOS dos erros de "UTF-8:invalid byte sequence", principalmente qdo device desconecta
	#
	# 2017Out17
	# TINHA TUDO PRA DAR CERTO!!
    # MAS NAO DEU! ENTAO, tenho q proteger exception com non-ascii em pageObject ou STEP!
	#

				write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_exception: P00, e=#{e}"
				#ok_apenas_ascii = false
				#begin
				#	e.message=ascii_only_str(e.message)
				#	ok_apenas_ascii = true
				#rescue Exception => xe
				#	write_rsi_log :warn, "Excecao #{xe} ao retirar non-ascii chars de e.message, e=#{e}"
				#end
				#if ok_apenas_ascii 
				#	write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_exception: P10, sucesso ao remover non-ascii charsm agora, e=#{e}"
				#end
				begin
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_exception: executando codigo original copy-pasted"

					message = "#{e.message} (#{e.class})".force_encoding("UTF-8")
					message = linebreaks(message, ENV['CUCUMBER_TRUNCATE_OUTPUT'].to_i)

					string = "#{message}\n#{e.backtrace.join("\n")}".indent(indent)
					@io.puts(format_string(string, status))
				rescue => out_exc
					write_rsi_log :trace, "RSI monkey patched Cucumber::Formatter:Console::print_exception: erro ao imprimir uma excecao, out_exc=#{out_exc}"
				end
			end
		end
	end
end

def formata_cpf(str)
	return "#{str[0..2]}.#{str[3..5]}.#{str[6..8]}-#{str[9..10]}"
end

def formata_data(str)
	return "#{str[0..1]}/#{str[2..3]}/#{str[4..7]}"
end

def formata_cep(str)
	return "#{str[0..4]}-#{str[5..7]}"
end

def escreve_texto(el, str, pausas=nil)
	scroll_to(el) #2017Out3
	if false
		#2018Mar03 - abordagem anterior derrubava conexao do Selenium!
		el.set str 
		return
	end

	if not pausas
		s_pausas=(ENV['TEST_PAUSE_SECONDS']||'0/0.2/0.5') 
		pausas=s_pausas.split('/').map{|s|s.to_f}
	end
	write_rsi_log :debug, "escreve_texto: pausas=#{pausas}, str=#{str}"
	pausas.each_index do |i|
		pausa = pausas[i]
		if i > 0
			el.native.clear
		end
		if pausa==0
			el.set str
		else
			str.each_char do |c|
				sleep pausa
				el.native.send_keys c
			end
		end
		sleep 1
		conteudo = el.value
		if (conteudo == str) or (conteudo == formata_cpf(str)) or (conteudo == formata_data(str)) or (conteudo == formata_cep(str))
			return #deu certo
		end
		m_conteudo = Monetize.parse(conteudo)
		m_str = Monetize.parse(str)
		if (m_conteudo and m_str) and (m_conteudo.amount == m_str.amount or m_conteudo.amount == m_str.amount/100)
			return
		end

		loglevel = :warn
		loglevel=:error if i == pausas.length
		write_rsi_log loglevel, "escreve_texto: tentei escrever '#{str}', mas conteudo ficou '#{conteudo}'"
	end
	falhar "Erro em escreve_texto, conteudo diferente do parametro" 
end

def click_em_botao_continuar(scrshot_name=nil)  #2018Ago11, permite nao ter screenshot
#
#
# 2018Mar25 - visibilidade antes de click CONTINUAR - faz scroll TOP do último elemento para o qual houve scroll, logo antes de clicar em CONTINUAR, evitando esconder evidencias screeshot. Isto substitui o screenshot imediatamente anterior a qualquer click de BOTAO CONTINUAR (id='ctaFullButton')
#
#
	botao_continuar = nil
	espera_condicao 60 do 
		#2018Ago10 03:27am, mais robusto, com espera de condicao e executa_com_retry_stale_element 
		executa_com_retry_stale_element do
			botao_continuar = find(:id,'ctaFullButton') #2018Ago10 - nao tenta acelerar, usa FIND mesmo como sempre, em vez de FIRST
		end 
	end


	if $last_scrolled_element
		begin
			write_rsi_log :debug, "click_em_botao_continuar, fazendo scroll prévia para $last_scrolled_element"
			scroll_to $last_scrolled_element, true, save_scrolled:false 
		rescue Exception => e
			write_rsi_log :error, "Tentativa de fazer scroll ALIGNTOP=TRUE em método click_em_botao_continuar falhou, excecao=#{e}, backtrace=#{e.backtrace}"
		end
		$last_scrolled_element = nil
	end
	
	if scrshot_name
		#2018Ago11, permite nao ter screenshot
		write_rsi_log :debug, "click_em_botao_continuar, fazendo screenshot"
		gera_screenshot scrshot_name if scrshot_name
	end
	executa_com_retry_stale_element do
		write_rsi_log :debug, "click_em_botao_continuar, reobtendo com novo find variavel botao_continuar"
		botao_continuar = find(:id,'ctaFullButton')
		write_rsi_log :debug, "click_em_botao_continuar, fazendo scroll pra botao_continuar"
		scroll_to botao_continuar, false, save_scrolled:false 
		#2018Set19 "durante execucao de regressivos" - faz novo FIND, e além disso protege com executa_com_retry_stale_element.
		#2018Ago10 03:27am, estranhamente , nao tinha scroll_to para o botao, aqui
	end
	write_rsi_log :debug, "click_em_botao_continuar, clicando em botao_continuar"
	botao_continuar.click
	write_rsi_log :debug, "click_em_botao_continuar, clicou em botao_continuar"

	return
end


def scroll_to(element, pAlignTop=false, options={:save_scrolled=>true}) #2017Nov17 00:48am, voltei pra implementacao original
	#2017Nov15 - alinha no TOPO da página. Aumenta chance de scroll default tornar elemento visivel e clicável!. Isso ajuda muito o webdesktop, que pode ser bastante minimizado verticalmente,
	# para < 30% do tamanho do desktop. Já o Mob é menos tolerante como minimizacao vertical: abaixo
	#de 55% ou 50%, já começa a ter erro "element not clickable at this point"! Percebtuais obtidos
	#no notenbook da RSI de Renato battaglia. CREIO que MOB funciona com 50% de minimização .
	#
	#   DETECTADO depois que alignTop é ruim pra MOB, apesar de bom pra WEBDESK. Alterado.. Entao: 
	# pra preservar comportamento original de "non-webdesktop", terá default FALSE sempre que
	# nao for webdesktop. 
	#
    $last_scrolled_element = nil #2018Julho31 - LIMPA forçosamente $last_scrolled_element na entrada do método

    return if not element #2017Out3 14:44pm BrTime


    
	qualapp = ($massa || {}) ['QUALAPP']
	
	alignTop = pAlignTop
	if pAlignTop == nil
		alignTop = (   qualapp == 'webdesktop'   )
	end

	save_scrolled = false
	if qualapp == 'webdesktop'
		options = options || {:save_scrolled => true}
		save_scrolled = true
		if options[:save_scrolled] != nil
			save_scrolled = options[:save_scrolled]
		end
		if save_scrolled
			$last_scrolled_element = element
		end
	end

    write_rsi_log :debug, "scroll_to, qualapp=#{qualapp}, pAlignTop=#{pAlignTop}, alignTop=#{alignTop}"
    script = <<-JS
      arguments[0].scrollIntoView(#{alignTop});
    JS
#2017Set9 - scrollIntoView(false)=avança o suficiente p/ elto todo ser visivel. Ou seja,
#Se true, a parte superior do elemento ficará alinhada com o topo da área visível do elemento-pai. Este é o valor default.
#Se false, a parte inferior do elemento ficará alinhada com o fundo da área visível do elemento-pai.	
#https://developer.mozilla.org/pt-BR/docs/Web/API/Element/scrollIntoView
	Capybara.current_session.driver.browser.execute_script(script, element.native)
end

Capybara::Node::Element.class_eval do
  def click_at(x, y)
    #wait_until do
      right = x - (native.size.width / 2)
      top = y - (native.size.height / 2)
      driver.browser.action.move_to(native).move_by(right.to_i, top.to_i).click.perform
    #end
  end
end

if false #if false=FIND original SitePrism. if true=FIRST< mais rápido, em Ago14, nao 100% testado
	SitePrism::Page.class_eval do
		def find_first(*find_args)
			if false
				find(*find_args) #original Site-Prism
			else
				write_rsi_log :trace, "SitePrism::Page::find_first, monkey-patched de find pra first, 2017Ago13"
				first(*find_args)
			end
		end
	end
end



def lista_de_arquivos_feature
	return Dir["features/auto/*.feature"]
end



def flock(file, mode, &block)
	success = file.flock(mode)
	if success
		begin
			block.call  file
		ensure
			file.flock(File::LOCK_UN)
		end
	end
	return success
end

def get_massa(key=nil)
	m = $massa || Hash.new
	return m[key] if key != nil
	return m
end
def set_massa(m)
	$massa = m
end

def autohk_get_currwindow_id
	run_autohk_copia 'get_currwindow_id' 
	window_id = File.read($autohk_guid_file) #.AHK deve escrever altura@largura para STDOUT
	FileUtils.rm $autohk_guid_file
	return window_id
end

def autohk_seta_rectangle_browser(window_title_or_handle, x, y, w, h)
	write_rsi_log :trace, "autohk_seta_rectangle_browser-start"
	run_autohk_copia 'seta_rectangle_browser', '"' + window_title_or_handle + '"' + " #{x} #{y} #{w} #{h}"   
	write_rsi_log :trace, "autohk_seta_rectangle_browser-end"
end
def autohk_seta_rectangle_este_browser(x ,y, w, h)
	#titulo_janela = get_nome_janela
	#autohk_seta_rectangle_browser titulo_janela+' - Google Chrome', x, y, w, h

	write_rsi_log :trace, "autohk_seta_rectangle_este_browser-start"

	handle_janela = get_handle_da_janela_do_tpn
	autohk_seta_rectangle_browser handle_janela, x, y, w, h
	write_rsi_log :trace, "autohk_seta_rectangle_este_browser-end"
end

def autohk_get_rectangle_browser(titulo_janela)
	run_autohk_copia 'get_rectangle_browser', '"' + titulo_janela + '"'   
	x,y,w,h = File.read($autohk_guid_file).split('@') #.AHK deve escrever altura@largura para STDOUT
	FileUtils.rm $autohk_guid_file
	return [x,y,w,h]
end
def autohk_get_rectangle_este_browser()
	#titulo_janela = get_nome_janela
	#return autohk_get_rectangle_browser(titulo_janela+' - Google Chrome')
	handle_janela = get_handle_da_janela_do_tpn
	return autohk_get_rectangle_browser(handle_janela)
end

def autohk_get_desktop_dimensions
	# este método é executado PROTEGIDO POR LOCK EXCLUSIVO, por isso os tratamentos de
	# excecao de move file/remove/read são tao simplistas e otimistas.

	desk_size_arq = "#{get_automdir}/autohk_get_desk_size.lck"

	if defined? $autohk_valores_desktop_dimensions and $autohk_valores_desktop_dimensions
		return $autohk_valores_desktop_dimensions
	end

	begin
		w,h = File.read(desk_size_arq).split('@')
		$autohk_valores_desktop_dimensions = [w.to_i,h.to_i]
		return $autohk_valores_desktop_dimensions
	rescue Exception => e
		#nada, nao conseguiu ler
	end

	run_autohk_copia 'get_desk_size'
	w,h=nil
	w,h = File.read($autohk_guid_file).split('@')
	
	begin; FileUtils.mv $autohk_guid_file, desk_size_arq; rescue Exception =>e; end
	begin; FileUtils.rm $autohk_guid_file; rescue Exception =>e; end
	$autohk_valores_desktop_dimensions = [w.to_i,h.to_i]

	return $autohk_valores_desktop_dimensions
end

def autohk_maximiza_browser(window_title_or_handle)
	run_autohk_copia 'maximiza_browser', '"' + window_title_or_handle + '"'
end
def autohk_maximiza_este_browser
	#titulo_janela = get_nome_janela
	#autohk_maximiza_browser titulo_janela+' - Google Chrome'
	handle_janela = get_handle_da_janela_do_tpn
	autohk_maximiza_browser handle_janela
end

def carrega_img(botao, arquivo_imagem='imagem_upload.jpg')
#2018Abr21 - novo parametro: arquivo_imagem

	#2017Set9 - se tentar uma vez e perceber que deu erro
	# "CANNOT LOAD AUTOMATION EXTENSION" (ocorre na VM... versao de chromedriver??),
	# entao, nesse caso, seta global $ambiente_erra_automation_ext
	#
	#   Em ambientes bem configurados, ganhamos alguns preciosos segundos com esta
	# abordagem, ao evitar repetidamente a frustrada tentativa de click em cada
	# fileupload de imagem. 
	#
	#
	# 

	#
	# 2011Nov10 - nao tem deteccao e reacao a problema de AUTOMATION EXTENSION aqui. 
	#
	#  Portanto, se quisermos qus use imgclick_via_codigo_nativo?==true, temos que de fato
	#alterar a torina!!!


	if (imgclick_via_codigo_nativo?) or (botao.is_a? String) #DEPRECATED, era para click nativo sem Selenium/com AutoHotKey
		write_rsi_log :debug, "carrega_img STRING chamada"
		#2017Set8 - elemento nao reage na VM, "cannot require_relative automation bla"
		el = nil
		if not botao.is_a? String
			el = botao
			botao = botao.path
		else
			el = first(:xpath,botao)
		end

		#funciona em VM. SCROLL manual, acha botao, entao AUTOHOTKEY img_find+click
		ret_ahk_click = -1
		executa_exclusivo(
			maximizar_janela_antes:true , 
			#2017Jan19 - trazer_janela_para_topo_antes:true, 
			restore_janela_depois:true
			) do
		
			scroll_to(el) #garante que imagem extá visível a olho humano na tela
			ret_ahk_click = clica_em_icone_foto #autohotkey, localizar img+mousemove+click
			if ret_ahk_click == 0
				sleep 3
				digita_nome_imagem_upload arquivo_imagem
			else
				falhar "Erro ao chamar clica_em_icone_foto, ret_ahk_click = #{ret_ahk_click}"
			end
		end
	else
		write_rsi_log :debug, "carrega_img ELEMENT chamada"
			
		executa_exclusivo(
			#maximizar_janela_antes:true , 
			#trazer_janela_para_topo_antes:true, 
			#restore_janela_depois:true
			) do
			if botao.is_a? Proc
				#2018Julho31 - recebe Proc/Lambda que faz aparecer dialog
				botao.call
			else
				scroll_to(botao) #2017Set28 19:11, subitamente, tornouse necessario!
				botao.click # SIM... tocar no botao ja deve ser feito EXCLUSIVO, pq ele causa "tela que pode se sobrepor"
			end
			sleep 3
			digita_nome_imagem_upload arquivo_imagem
		end

	end
end

def xpath_botal_salvar_imagem
	xp = nil
	if get_massa('QUALAPP')=='mob'
		xp = xpath_elemento_botao_acao 'Salvar' #fix attempt - 2017Ago14, after 80
	else
		xp = "//p[contains(text(),'Enviar imagem') or contains(text(),'Salvar')]"
	end
end

def carrega_img_e_salva(qual_imagem, arquivo_imagem='imagem_upload.jpg')
#2018Abr21 - novo parametro: arquivo_imagem	  
	 if qual_imagem.class == Fixnum
	 	num_imagem = qual_imagem
	 else
	 	#jah recebeu elemento Capybara!
	 	num_imagem = 1
	 end
	 #2017Set28-PASSAR ELEMENTO DENTRO DE BLOCK! Obtido internamente!
	 #----------------------------------------------------------------
	 # COM ISSO, telas extremamente reduzidas nao dau mais erro, pois
	 # tentamos fazer find do capybara APENAS quando a tela já está
	 #maximizada !!!!!!!!!!!!!!!


#
#
######
# FILEUPLOAD generico. Até 2016Set9, somente fazemos FILEUPLOAD de imagem.
#######
#
	#gera_screenshot

	write_rsi_log :debug, "carrega_img_e_salva - P00"

	botao = nil
	if qual_imagem.is_a? Fixnum
		botoes = find_all(:xpath, get_xpath_imgupload, visible:false) 
		#2017Jan22, webdesk, achava poucos botoes, entao, adicionei visible:false
		botao = botoes[qual_imagem-1]
		if not botao
			falhar "processo de clicar elemento web em imgupload: Elemento de posicao #{num_imagem} nao encontrado, quantidade de botoes na tela: #{botoes.length}"
		end
	else
		botao = qual_imagem
	end
	carrega_img botao, arquivo_imagem 

	write_rsi_log :debug, "Dormindo alguns segundos, antes de tocar em salvar, depois de file upload, TODO - deveria ser WAIT inteligente!"
	sleep 3 # Fiz 7 segundos antes, OVERKILL? Tentando tempo menor
	write_rsi_log :debug, "Dormiu antes de clicar em salvar"
	#executa_com_retry_stale_element {wait_for_botao_salvar_click? 20} #podemos definir tempo maximo aqui
	xp = xpath_botal_salvar_imagem
	##############
	##
	## Alternativa a wait:secs ... (que em 1os testes se comportou estranho com find...) 
	##        Capybara.using_wait_time(segundos) do
	##			  find 'bla'; write_rsi_log :debug, "muda Capybara.default_wait_time, executa e restaura"
	##         end
	##
	#####

	btn = first(:xpath, xp, wait: 35 * 3)  
	write_rsi_log :debug, "Buscou por xpath o elemento de botao salvar"
	if btn == nil
		tempo_sleep = 20
		write_rsi_log :debug, "Nao achou  o elemento de botao salvar, vai dormir #{tempo_sleep} e tentar de novo"
		#2017Ago17, retentativa e novo wait, untested, Ago17-09:17am. OBS: 
		
		sleep tempo_sleep # 2017Ago17, retentativa, SLEEP alto... como otimizar???
		write_rsi_log :debug, "Nao achou  o elemento de botao salvar, dormiu #{tempo_sleep}, vai tentar de novo agora"
		btn = first(:xpath, xp, wait: 35 * 3) #  2017Ago17, aumentado WAIT de 35 p 60, untested, Ago17-09:17am
		if btn == nil
			write_rsi_log :debug, "Nao achou  zNOVAMENTE o elemento de botao salvar, adeus, vai falhar"
			falhar "Elemento de botao salvar nao estah presente na tela"
		end
	end
	write_rsi_log :debug, "Exatamante antes de click em elemento de botao salvar"
	scroll_to btn, true, save_scrolled:false  #2018Julho31, nao salvar $last_scrolled_element #2017Set28 19:11, subitamente, tornouse necessario!
	gera_screenshot "CarregaImagem#{num_imagem.to_s}"
	
	btn.click
	ainda_btn_salvar=nil #2017Set28 - para telas reduzidas, checagem de botal Salvar sem efeito
	vezes_checar_salvar = 3
	vezes_checar_salvar.times do |k|
		ainda_btn_salvar=first(:xpath, xp, wait:2)
		write_rsi_log :debug, "k=#{k}, ainda_btn_salvar==nil?? (#{ainda_btn_salvar==nil})"
		if ainda_btn_salvar == nil
			break
		end  		
  		sleep 2
  		ainda_btn_salvar=first(:xpath, xp, wait:2)
  		if ainda_btn_salvar
  			#2018Julho31, agora, só faz scroll se ainda_btn_salvar nao for nil"
  			scroll_to(ainda_btn_salvar,false, save_scrolled:false) #2018Julho31, nao salvar $last_scrolled_element
  			ainda_btn_salvar.click
  		end
  	end

	write_rsi_log :debug, "Exatamante depois do click em elemento de botao salvar"
end

def string_is_integer(str)
	return /\A[-+]?\d+\z/ === str
end

def get_xpath_imgupload
	if get_massa('QUALAPP')=='mob'
		# 2017Out2 - lista de elementos de imagem é dinâmica, precisa reobter a cada 
		#tenttiva de click, para máxima robustez
		return "//*[@class='img-change-photo' or @class='image-placeholder-container']"
	else
		return "//*[contains(@class,'upload-btn')]/img"
		#2017Dez29 - trocado 'LABEL' por '*'
	end
end

def xpath_elemento_botao_acao(texto)
	return "//button[contains(.,'#{texto}')]"
end

def xpath_qualquer_titulo_de_step #WEBDESKTOP
	return "//conversation-title/h1[contains(@class,'conversation')]/text-typing/span"
end

def xpath_elemento_radio_botao(texto)
	if false and string_is_integer(texto) ## ATENCAO - nao da p pegar por posicao, VENCIMENTO tbm eh inteiro! TEM Q TER TEXTO EXATO NA MASSA 
		#AINDA nao sabe trazer sequencia dentro de section especifica
		return "(//*[@class='button-label'])[#{texto.to_i}]"
	else
		return "//*[@class='button-label']/label[normalize-space(./text())='#{texto}']"
	end
end

def mob_xpath_simnao_toggle(texto)
	return "//div[contains(@class,'container-toggle')]//label[contains(@class,'sn-label-descrition-toggle-left') and text()='#{texto}']/ancestor::div[contains(@class,'container-toggle')]//label[contains(@class,'sntoggle-input')]"
end

def webdesktop_xpath_radiobutton_wrapper(texto_radio, texto_botao)
   return "//input-radio-group-wrapper"+
   "//*[contains(text(),'#{texto_radio}')]"+
   "/ancestor::input-radio-group-wrapper/*" + 
   "//p[contains(@class,'label-text') and " +
   "contains(text(),'#{texto_botao}')]"
end
def webdesktop_xpath_radiobutton_tooltip(texto_radio, texto_botao)
   return "//input-radio-group-with-tooltip"+
   "//*[contains(text(),'#{texto_radio}')]"+
   "/ancestor::input-radio-group-with-tooltip/*" + 
   "//p[contains(@class,'label-text') and " +
   "contains(text(),'#{texto_botao}')]"
end

def executa_com_retry_stale_element
	begin
		yield
	rescue Selenium::WebDriver::Error::StaleElementReferenceError => e
		write_rsi_log :trace, 'StaleElementReferenceError executa_com_retry_stale_element, refazendo...'
		yield
	rescue Exception => e
		write_rsi_log :error, "Outra excecao, classe=#{e.class}, message=#{e.message} em executa_com_retry_stale_element, fazendo RAISE"
		raise e
	end
end

def fecha_janela_err_1_chrome
	run_autohk_copia 'fecha_jan_err1_chrome'
end


def clica_em_icone_foto
	run_autohk_copia 'imgclick_foto',  '35 35' #acha imagem e clica... 2017Out20-35 right/down
end

def get_ahk_nomejanela_fileupload
	return 'Open' if ((get_automlanguage)||'')=='en'
	return 'Abrir'
end
def digita_nome_imagem_upload(arquivo_imagem='imagem_upload.jpg')
	run_autohk_copia "digita_path_imagem", "#{get_ahk_nomejanela_fileupload} #{arquivo_imagem}" 
end

def get_nome_janela(pn=nil)
	pn ||= get_process_num
	titulo_janela = "AUT.C.DIG.PF #{pn}"
	return titulo_janela
end
def traz_janela_pra_topo(window_title_or_handle=nil, inexato=false)
	#ATENCAO - programa AUTOHOTKEY (.AHK) é responsável por diferenciar entre
	# HANDLE e TITLE, através dos primeiros 2 caracteres: se forem "0x", é um handle!
	#
	# Esta abordagem parece ser bem pouco portável para Linux. Provavelmente, necessitará
	# de refactoring quando for portado de Windows para Linux.
	#
	# MESMA ABORDAGEM está sendo adotada pra todas outras rotinas que recebiam nome
	# da janela
	sInexato='0'
	if inexato
		sInexato='1'
	end

	return run_autohk_copia 'traz_janela_para_topo', '"' + window_title_or_handle +  '" ' + sInexato    
end

def traz_esta_janela_pra_topo
	#titulo_janela = get_nome_janela
	#return traz_janela_pra_topo titulo_janela+' - Google Chrome'
	handle_janela = get_handle_da_janela_do_tpn
	return traz_janela_pra_topo handle_janela
end


def get_valor_int_em_controle_range(e)
	return e.text.gsub('+','').gsub(' ','').gsub('.','').to_i
end
def acha_valor_em_range(meu_valor, e_range, valor_no_prim_pixel=0)
	scroll_to(e_range) #2017Set28 19:11, subitamente, tornouse necessario!
	e_v=find '.range-value' #ago13, find -> first, FAST

	#meu_valor: integer
	#i_range: Capybara Element, já devidando encontrado com "find"/"first"
	#
	#define valor meu_valor em elm_range bem mais rápido que clicando repetidas vezes em "botao +"
	# ini_)value - PARAMETRO DEPRECATED

	e_range.click_at  0, 0;  return if (get_valor_int_em_controle_range e_v) == meu_valor

	dead_pixels = 12 #pixels "mortos", à direita e à esquerda, que nao contam pra calculo de range
	native_w=e_range.native.size.width
	w=native_w-dead_pixels
	write_rsi_log :trace, "dead_pixels=#{dead_pixels}, native_w=#{native_w}, w=#{w}"
	vmax=get_valor_int_em_controle_range(find '.range-max') #ago13, find -> first, FAST
	write_rsi_log :trace, "vmax=#{vmax}"
	e_mais=find '.range-btn-control.increment' #ago13, find -> first, FAST
	e_menos=find '.range-btn-control.decrement' #ago13, find -> first, FAST
	v_por_pixel=(vmax-valor_no_prim_pixel)/ w
	write_rsi_log :trace, "v_por_pixel = #{v_por_pixel}"
	first_click_x = (meu_valor - valor_no_prim_pixel) / v_por_pixel
	write_rsi_log :trace, "first_click_x =#{first_click_x} = meu_valor #{meu_valor} / v_por_pixel #{v_por_pixel}"
	
	if first_click_x == w
		first_click_x = first_click_x -1
	end

	e_range.click_at  first_click_x+dead_pixels, 0; return if (get_valor_int_em_controle_range e_v) == meu_valor

	curr_v = get_valor_int_em_controle_range e_v
	write_rsi_log :trace, "curr_v após first_click = #{curr_v}"

	if curr_v == meu_valor
		return
	end

	#checa se precisa de mais um click posicional, pra deixar MUITO perto do valor desejado
	prev_pixel = 0
	cur_pixel = first_click_x
	prev_v = 0
	
	iters=0
	max_iters = 10

	while (iters=iters+1; write_rsi_log :trace, "1st loop, iters=#{iters} de max_iters #{max_iters}"; iters) < max_iters do
		curr_v = curr_v=get_valor_int_em_controle_range e_v

		valor_por_pixel = 0; valor_por_pixel = 0; andar_pixels = 0

		dif_valor= meu_valor - curr_v
		quanto_andei=curr_v - prev_v
		dif_pixels = cur_pixel - prev_pixel
		valor_por_pixel=quanto_andei / dif_pixels if dif_pixels != 0
		andar_pixels  = dif_valor / valor_por_pixel if valor_por_pixel != 0
		
		write_rsi_log :trace, "1st loop, iters #{iters}, curr_v=#{curr_v}, dif_valor=#{dif_valor}, quanto_andei=#{quanto_andei}, dif_pixels=#{dif_pixels}, valor_por_pixel=#{valor_por_pixel}, andar_pixels=#{andar_pixels}"

		if andar_pixels == 0
			write_rsi_log :trace, "1st loop, andar_pixels ficou ZERO, break"
			break
		end

		click_pos = cur_pixel + andar_pixels
		write_rsi_log :trace, "1st loop, click_pos=#{click_pos}, #{andar_pixels} de diferenca de #{cur_pixel}"
		e_range.click_at  click_pos+dead_pixels, 0; ; return if (get_valor_int_em_controle_range e_v) == meu_valor

		prev_pixel = cur_pixel
		cur_pixel = click_pos
		prev_v = curr_v

	end

	max_clicks = 50 #deve abortar processo com erro se precisarmos de mais que 20 cliques
	este_click = 1
	prev_v = -9999
	while ((curr_v = get_valor_int_em_controle_range(e_v)) != meu_valor) and este_click < max_clicks
		write_rsi_log :trace, "2nd loop, iter #{este_click} de max #{max_clicks} - loop mais_menos, curr_v=#{curr_v}, meu_valor=#{meu_valor}"


		if curr_v == prev_v
			falhar 'Erro em range - valor nao mudou depois de clikcar em BOTAO + ou BOTAO -'
		end
		if curr_v < meu_valor
			write_rsi_log :trace, "2nd loop, dentro de loop, vai clicae e_mais"
			e_mais.click; ; return if (get_valor_int_em_controle_range e_v) == meu_valor  
		else
			write_rsi_log :trace, "2nd loop, dentro de loop, vai clicae e_menos"
			e_menos.click; ; return if (get_valor_int_em_controle_range e_v) == meu_valor
		end

		este_click = este_click + 1
		prev_v = curr_v
	end

	if curr_v != meu_valor
		falhar 'Erro em range - nao localizado valor #{meu_valor}'
	end
end

def set_dados_massa(cen)  
	cen=cen.encode('utf-8')
	Thread.current[:nome_cenario_corrente]=cen
	caminho_xls = "massas_feature/#{cen}/massa.xls"
	write_rsi_log :debug, "caminho_xls de massa=#{caminho_xls}"
	set_massa(ler_xls_com_id(caminho_xls))
	write_rsi_log :debug, "get_massa() = #{get_massa()}"

	return
end

def get_report_run_dir(autdir=nil)
	autdir ||= get_automdir

	if ENV['TEST_ID']==nil
		runTid=""
	else
		runTid='_'+ENV['TEST_ID']
	end

	if ENV['TEST_RUN_NUM']==nil
		runNum=""
	else
		runNum="/TRN#{ENV['TEST_RUN_NUM']}"
	end
	
	return "#{autdir}/reports#{runNum}"
end





def get_nome_de_screenshot
	if ENV['TEST_ID']==nil
		runTid=""
	else
		runTid='_'+ENV['TEST_ID']
	end

	if ENV['TEST_RUN_NUM']==nil
		runNum=""
		runFname=""
	else
		runNum="/TRN#{ENV['TEST_RUN_NUM']}"
		runFname='_TRN'+ENV['TEST_RUN_NUM']
	end
	
	"reports#{runNum}/scrshot#{runFname}#{runTid}_#{get_alphanumcenario(Thread.current[:nome_cenario_corrente])}" 
end

def veracidade_deve_fechar_janela?
	#TOFDO 2017Nov30 - RUN_PARALLEL.RB precisa, creio eu, checar se vamos fechar janela de veravidade, se vai ter "fila de espera por slot de janela browser" etc.!
	#ATUALMENTE, 2017Nov30, decidimos que nao vai ter fila de espera nem vamos fechar
	#janela durante a veracidade.
	#
	#
	# NO MÀXIMO, vamos colocar um, HTML "on the fly" no browser contando quantas vezes
	# ja checou veraidade, pra que usuário assistindo à tela de automação entenda o porque
	# estamos com a janela parada!


	return false
end

def prepend_text_to_html(fname, str)
	new_contents = ''
	contents = IO.binread(fname)
	new_contents = str << contents
	File.open(fname,'w') do |f|
		f.write new_contents
	end

	return
end

def espera_status_veracidade(cpf=get_massa()['CPF'], segundos_espera=450, segundos_pausa=30)
	#2018Jun20 - aumentado segundos_espera de 350 segundos para 450 segundos 
	#2017Dez04 - segundos_espera foi de 300 pra 350, JUST IN CASE ocorra erro de SSL exatamente nas últimas tentativas. OBS: também estou passando reto, sem erro em STEP CUCUMBER DE VERACIDADE, just in case o mesmo erro de SSL esconda a resposta 200. 

	if veracidade_deve_fechar_janela?
		fecha_janela_browser
	end


	retval = [999, 'ainda nao executado']
	t_ini = Time.now
	write_rsi_log :info, "espera_status_veracidade() : Esperando veracidade: status 200 ou 'ja sendo analisada' por até #{segundos_espera} segundos"
	nof_checks_veracidade = 0

	html_fname="#{get_automtmpdir}/esperando_veracidade_#{obtem_guid}.html"
	mkdir_noexist File.dirname(html_fname)
	write_text_to_file(html_fname, '')

	while true
		#2018Mar10 - revamped para nao usar Timeout::Timeout (má prática de Ruby). E, também, para tirar screenshots

		nof_checks_veracidade = nof_checks_veracidade + 1
		status, msg_excecao = [nil, nil]
		t_agora = Time.now
		elapsed = t_agora - t_ini

		write_rsi_log :debug, "espera_status_veracidade, segundos_espera=#{segundos_espera}, elapsed=#{elapsed}, t_agora=#{t_agora}, t_ini=#{t_ini}"

		if elapsed > segundos_espera
			if not veracidade_deve_fechar_janela?
				prepend_text_to_html html_fname, "<p>ERRO TIMEOUT - EXPIROU O TEMPO LIMITE E O STATUS DA VERACIDADE NAO FOI ALTERADO PARA 200!</p>"
				visit "file:///#{html_fname}" 
				gera_screenshot "VeracidadeTimeout#{nof_checks_veracidade}"
			end
			write_rsi_log :error, "espera_status_veracidade() : TimeoutDeVeracidade"
			break
		end

		executa_exclusivo(nil, 'LOCK_STATUS_VERACIDADE') do
			t_agora = Time.now
			elapsed = t_agora - t_ini
			write_rsi_log :debug, "espera_status_veracidade, LOCKOU LOCK_STATUS_VERACIDADE, segundos_espera=#{segundos_espera}, elapsed=#{elapsed}, t_agora=#{t_agora}, t_ini=#{t_ini}, vai rodar checar_status_veracidade_new(#{cpf})"
			(status, msg_excecao) = checar_status_veracidade_new cpf #2018Abr21, chama nova chgem de veracidade (HS Prevent)
			retval=[status, msg_excecao]
			write_rsi_log :debug, "espera_status_veracidade, LOCKOU LOCK_STATUS_VERACIDADE, segundos_espera=#{segundos_espera}, elapsed=#{elapsed}, t_agora=#{t_agora}, t_ini=#{t_ini}, rodou checar_status_veracidade(#{cpf})"
		end
		

		msg_esperando = "espera_status_veracidade() : retval=#{retval}, tempo decorrido=#{(t_agora.to_f-t_ini.to_f).to_i} segundos de #{segundos_espera}"
		write_rsi_log :info, msg_esperando

		if (status == 500) and ((msg_excecao||'').include? 'No entity found')
			if not veracidade_deve_fechar_janela?
				prepend_text_to_html html_fname, "#{msg_esperando}\n"
				prepend_text_to_html html_fname, "<p>VERACIDADE COM STATUS 500, no entity found, FALHA ABORTIVA DE VERACIDADE!</p>"
				visit "file:///#{html_fname}" 
				gera_screenshot "VeracidadeNotFound#{nof_checks_veracidade}"
			end
			break
		end

		if (status == 200) or ((msg_excecao||'').include? 'lready being analy')
			if not veracidade_deve_fechar_janela?
				prepend_text_to_html html_fname, "#{msg_esperando}\n"
				prepend_text_to_html html_fname, "<p>VERACIDADE COM STATUS 200 OK, OU already being analysing (sic) ! EXECUTANDO PROXIMO PASSO!</p>"
				visit "file:///#{html_fname}" 
				gera_screenshot "VeracidadeOk#{nof_checks_veracidade}"
			end
			break
		end

		if not veracidade_deve_fechar_janela?
			prepend_text_to_html html_fname, "#{msg_esperando}\n"
			prepend_text_to_html html_fname, "<p>AGUARDANDO STATUS DA VERACIDADE PARA STATUS 200! (tempo decorrido=#{(t_agora.to_f-t_ini.to_f).to_i} segundos de #{segundos_espera})</p>"
			write_rsi_log :debug, "Vai visitar arquivo html_fname=[#{html_fname}]"
			visit "file:///#{html_fname}" 
			gera_screenshot "VeracidadeWait#{nof_checks_veracidade}"
		end
		sleep segundos_pausa
	end

	write_rsi_log :info, "espera_status_veracidade() OK : retval=#{retval}, tempo total decorrido tempo decorrido=#{(Time.now.to_f-t_ini.to_f).to_i} segundos de #{segundos_espera} "
	$time_veracidade_ok = Time.now

	if veracidade_deve_fechar_janela?
		reabre_janela_browser
	end

	return retval
end

def fecha_janela_browser
  	$massa||={}

	if $not_single_maq_zsproc_debug
		if ($massa['STEP_INICIAL']||0).to_i == NUM_STEP_TFC and ($massa['STEP_FINAL']||NUM_STEP_TFC).to_i == NUM_STEP_TFC
			write_rsi_log :debug, "NAO chamando run_fecha_janela_browser nem checando maximizacao pois $massa['STEP_INICIAL']=#{$massa['STEP_INICIAL']} e $massa['STEP_FINAL']=#{$massa['STEP_FINAL']} "
		else
			run_fecha_janela_browser
		end
	end
end


def run_fecha_janela_browser(deve_salvar_rectangle=false) #parametro pra manipulacao em CONSOLE!

	write_rsi_log :debug, "run_fecha_janela_browser: fora de LOCK, P00"

	if last_lock_exclusivo_falhou
		write_rsi_log :debug, "run_fecha_janela_browser: P00.1, last_lock_exclusivo_falhou = true,retornando. Sem chamar Capybara.page.driver.quit? Melhor nao: decidi chamar incondicionalmente com begin/rescue"
		begin
			Capybara.page.driver.quit #TALVEZ, um executa_exclusivo() 
		rescue Exception => e
			write_rsi_log "run_fecha_janela_browser, Capybara.page.driver.quit lancou excecao que serah ignorada, e=#{e}"
		end
		return
	end

	begin

		executa_exclusivo(
			trazer_janela_para_topo_antes:true #2018Jan19 - LENTIDAO? REVAMP ME!
			# PRA que maximizar no fechamento? Já rolou scresnshot anntes... NO NEED!
			) {

			begin
				if deve_salvar_rectangle
					salva_rectangle_deste_browser
				end 
				# HMMM, posso ter acabado de salvar em AFTER HOOK CUCUMBER
				#
				#  QUANDO será que posso chegar aqui sem after hook? Apenas em erro
				# grave, situacao em que rectangle salvo será o menor de meus problemas...
				#
			rescue Exception => e
				write_rsi_log :debug, "Uma excecao que ignorarei de salva_rectangle_deste_browser em run_fecha_janela_browser, excecao #{e}"
			end
			write_rsi_log :debug, "run_fecha_janela_browser: dentro de lock, P00, vai Capybara.page.driver.quit"
			begin
				Capybara.page.driver.quit #TALVEZ, um executa_exclusivo() tradicional, PRA TOPO=true
			rescue Exception => e
				write_rsi_log :debug, "Uma excecao que ignorarei de Capybara.page.driver em run_fecha_janela_browser, excecao #{e}"
			end
			write_rsi_log :debug, "run_fecha_janela_browser: dentro de lock, P00, fez Capybara.page.driver.quit (com ou sem excecao)"

		}

	rescue Exception => e
		write_rsi_log :debug, "run_fecha_janela_browser: NEM DEVERIA CAIR AQUI - ignorando excecao de Capybara.driver.quit, excecao=#{e}"
	end
	
	begin
		desocupar_slot_de_janela_do_tpn
	rescue Exception => e
		write_rsi_log :warn, "run_fecha_janela_browser - NO FIM- Ignorando excecao de desocupar_slot_de_janela_do_tpn, excecao=#{e}"
	end
	remove_fila_lock('LOCK_BROWSER_WINDOW','fecha_janela_browser')
end

def log_chrome_port
	write_rsi_log :trace, "Porta chrome de Capybara.page.driver.BLA=#{get_porta_chromedriver}"
end
def get_porta_chromedriver
	ht=Capybara.page.driver.options[:http_client]
	ht.inspect.split('@server_url=').last.split(',').first.split(':').last.to_i
end

def reabre_janela_browser(path_botao_err_chrome='.')
	begin
		log_chrome_port
		core_abre_janela_browser(true, path_botao_err_chrome)
		log_chrome_port
	rescue Exception => e
		write_rsi_log :debug, "reabre_janela_browser: excecao #{e} em core_abre_janela_browser(true), retentando..."
		begin
			log_chrome_port
			core_abre_janela_browser(true, path_botao_err_chrome)
			log_chrome_port
		rescue Exception => e
			write_rsi_log :debug, "reabre_janela_browser: AGAIN excecao #{e} em core_abre_janela_browser(true), lancando excecao"
			falhar e
		end
	end
end

def abre_janela_browser(path_botao_err_chrome='.')
  	$massa||={}
  	if $not_single_maq_zsproc_debug
  		if ($massa['STEP_INICIAL']||0).to_i == NUM_STEP_TFC and ($massa['STEP_FINAL']||NUM_STEP_TFC).to_i == NUM_STEP_TFC
  			write_rsi_log :debug, "NAO chamando run_abre_janela_browser nem checando maximizacao pois $massa['STEP_INICIAL']=#{$massa['STEP_INICIAL']} e $massa['STEP_FINAL']=#{$massa['STEP_FINAL']} "
  		else
  			write_rsi_log :debug, "chamando run_abre_janela_browser e checando maximizacao pois $massa['STEP_INICIAL']=#{$massa['STEP_INICIAL']} e $massa['STEP_FINAL']=#{$massa['STEP_FINAL']} "
  			run_abre_janela_browser path_botao_err_chrome #nao passava adiante o parametro path_botao_err_chrome. Caught by ruby-lint Alre
			if janelas_sempre_maximizadas? #HASK 2017Nov28 - + 2017Nov29
				maximiza_este_browser
			end
		end
	end
end

def run_abre_janela_browser(path_botao_err_chrome='.')
	if last_lock_exclusivo_falhou
		write_rsi_log :error, "run_abre_janela_browser, last_lock_exclusivo_falhou=true, retornando sem chamar core_abre_janela_browser"
		return
	end
	core_abre_janela_browser(false,path_botao_err_chrome)
end

def core_abre_janela_browser(reabertura=false, nonNil_param_if_chrome='.')
#2017Set13, revamp, abertura de janela browser
	write_rsi_log :debug, "core_abre_janela_browser  - reabertura=#{reabertura}: FORA DE LOCKEXCL - P00 init"
	obtem_lock('LOCK_BROWSER_WINDOW', (reabertura ? 1 : 2 ))
	write_rsi_log :debug, "core_abre_janela_browser  - reabertura=#{reabertura}: FORA DE LOCKEXCL - P01 after obtem_lock - reabertura=#{reabertura}"

	caminho_arquivo_botao_err_chrome = "#{get_automdir}/BOTAOOK.LCK" if nonNil_param_if_chrome
	executa_exclusivo() do
		incrementa_global_scenario_count

		#2017Ago13 - truque: abre janela rápido... COM LOCK DE SINCORONIZACAO
		# assim, nao APARECE pagina na frente de algo do autoit, como DIALOG FILE UPLOAD 

		write_rsi_log :debug, "core_abre_janela_browser - reabertura=#{reabertura}: DENTRO DE LOCKEXCL - P02 vai escrever BOTAOOK.LCK"
				
		File.open(caminho_arquivo_botao_err_chrome, "w") {} if nonNil_param_if_chrome	
		write_rsi_log :debug, "core_abre_janela_browser - reabertura=#{reabertura}: DENTRO DE LOCKEXCL - P03 escreveu BOTAOOK.LCK, vai visitar c:/" if nonNil_param_if_chrome



		browser_window_handle = nil
		begin
			#log_chrome_port
			Capybara.page.driver.quit
			#log_chrome_port
		rescue Exception => e
			#log_chrome_port
			write_rsi_log :debug, "Alguma excecao ignoravel no Capybara.page.driver.quit forçado que coloquei antes de todos visit c:, excecao=#{e}"
		end
		begin
			#log_chrome_port
			$pagina_capybara = Capybara::Session::new(:selenium)
			visit "file:///#{get_automdir}/autom.html"
			traz_janela_pra_topo 'file:///C:/ - Google Chrome' if false
			sleep 10 if true #gambiarra: sleep em vez de trazer pra topo!
			browser_window_handle = autohk_get_currwindow_id #2017Out3 - grande avanço: window handle, em vez de titulo de janela 
			#log_chrome_port
		rescue Exception => e
			#retrying after some sleep...
			sleep 3
			begin
				Capybara.page.driver.quit #2017Set17 23:50, high hopes
			rescue Exception => e
				write_rsi_log :debug, "AGAIN Alguma excecao ignoravel no Capybara.page.driver.quit forçado que coloquei antes de todos visit c:, excecao=#{e}"
			end
			begin
				write_rsi_log :debug, "core_abre_janela_browser - reabertura=#{reabertura}: retentando visit"
			#	log_chrome_port
				$pagina_capybara = Capybara::Session::new(:selenium)
				visit "file:///#{get_automdir}/autom.html"
				browser_window_handle = autohk_get_currwindow_id #2017Out3 - grande avanço: window handle, em vez de titulo de janela 
				write_rsi_log :debug, "core_abre_janela_browser - reabertura=#{reabertura}: retentou visit"
			#	log_chrome_port
			rescue Exception => e
			#	log_chrome_port
				falhar "excecao=#{e},excecao manipulada VINDA DE VISIT DE core_abre_janela_browser - nao vou mandar corpo original pq pode ter acento e gerar CP850"
			end
		end

		write_rsi_log :debug, "core_abre_janela_browser - reabertura=#{reabertura}: DENTRO DE LOCKEXCL - P04 visitou File://algo"
		linha_errchrome=File.read(caminho_arquivo_botao_err_chrome).strip.split('\n').first if nonNil_param_if_chrome
		if nonNil_param_if_chrome and linha_errchrome and linha_errchrome != '1'
			#$ambiente_erra_automation_ext = true
			  #2017Out2 - se nao havia erro e fechou, AMBIENTE OK, nem vai checar mais em checador_erro_chrome.rb
			do_detect_automation_ext_ok
		end

		FileUtils.rm caminho_arquivo_botao_err_chrome if File.exist? caminho_arquivo_botao_err_chrome and nonNil_param_if_chrome #2017Set23 - remoção de BOTAOK.LCK movida pra core_abre_janela_browser, em vez de ficar em checador_err_chrome.rb !	

		seta_titulo_janela_browser
		desocupar_slot_de_janela_do_tpn
		write_rsi_log :debug, "vai chamar ocupar_slot_de_janela_do_tpn"
		numero_desta_janela = ocupar_slot_de_janela_do_tpn(browser_window_handle)
		write_rsi_log :debug, "chamou ocupar_slot_de_janela_do_tpn, numero_desta_janela=#{numero_desta_janela}"

		write_rsi_log :debug, "vai chamar seta_rectangle_janela_numero(#{numero_desta_janela})"
		seta_rectangle_janela_numero numero_desta_janela
		write_rsi_log :debug, "chamou seta_rectangle_janela_numero(#{numero_desta_janela})"
	end
	write_rsi_log :debug, "core_abre_janela_browser - reabertura=#{reabertura}: FORA DE LOCKEXCL - retornando"
	#log_chrome_port

end

def seta_titulo_janela_browser
	write_rsi_log :debug, "2017Nov29 - seta_titulo_janela_browser agora nada mais faz! Evita um executa_exclusivo à toa!"
end
def str_to_xpath_contains(str, ponto_ou_text_class_etc='.', and_ou_or='and')
	badencode_webdesk = true
	if badencode_webdesk
		str = ascii_only_str(str).gsub('*',' ') #2017Dez04, GAMBIARRA para bad encoding em deployment de webdesktop
	end
	return strspace_to_xpath_fragment(str, 'contains', ponto_ou_text_class_etc, and_ou_or)
end

def strspace_to_xpath_fragment(str, funcao='contains', ponto_ou_text_class_etc='.', and_ou_or='and')
 	retval = ''

	a = str.split(' ')

	a.length.times do |i|
		if i > 0
			retval = retval + " #{and_ou_or.strip} "
		end
		retval = retval +  "#{funcao}(#{ponto_ou_text_class_etc},'#{a[i]}')"
	end
	retval =  "(#{retval})"
	return retval
end



def xpath_contains_fazendo_ajustes #webdesktop
	return str_to_xpath_contains('fazendo alguns ajustes')
end

def xpath_contains_contratacao_produtos
	return str_to_xpath_contains('confirme a contratação dos produtos que você escolheu')
end

def nbsp
	return "\u00a0" #2017Nov7
end



def obter_cpf_pra_massa(cpf=nil, veracidade=nil, tipo_credito=nil)
	write_rsi_log :debug, "obter_cpf_pra_massa, cpf=#{cpf}, get_cpf_obterorisco=#{get_cpf_obterorisco}, comparacao=#{cpf == get_cpf_obterorisco}"
	#2018Ago01 - nao existe mais reserva de cpf, quueima direto

	cpf = cpf || $massa['CPF'] #EXEMPLO: passe 'obterorisco' pra testes em console
	veracidade = veracidade || $massa['SINAL DE VERACIDADE']
	tipo_credito = tipo_credito || $massa['TIPO_CREDITO']

	if (cpf||'').strip != get_cpf_obterorisco #se cpf passado (ou da massa) nao tiver a assinatura indicando que queremos pegar de risco, apenas retorna o próprio.


		return false
	end


	retval = nil
	executa_exclusivo(nil, get_lockfile_obter_cpf_risco) do #2018Jan3, LOCK diferente para CPF LOCK_OBTER_CPF_RISCO
		retval = risco_obter_cpf(veracidade, tipo_credito)
		if $massa and retval
			$massa['CPF'] = retval
			regrava_arquivo_massa
		end
	end
	if false and (not retval) #2018Ago10 - deixa retornar nil !
		falhar "ERRO! retval=nil ao chamar risco_obter_cpf(veracidade=#{veracidade}, tipo_credito=#{tipo_credito}) " 
	end

	return (retval != nil) 
end

def regrava_arquivo_massa(fname=nil)
	begin
		core_regrava_arquivo_massa fname
	rescue Exception => e
		write_rsi_log :error, "regrava_arquivo_massa(fname=$#{fname}), Nao foi possivel regravar arquivo de massa, excecao =#{e}"
		if not e.is_a?(TypeError)
			raise e
		end
	end
end

def core_regrava_arquivo_massa(fname=nil)
	if fname
		escreve_xls_de_hash(fname,$massa)
		return
	end
	path_xls="features/auto/r/#{get_alphanumcenario(Thread.current[:nome_cenario_corrente])}*.xls"
	write_rsi_log :debug, "regrava_arquivo_massa: path_xls=#{path_xls}"
	nome_arq_xls=Dir[path_xls].first
	write_rsi_log :debug, "regrava_arquivo_massa: nome_arq_xls=#{nome_arq_xls}, $massa=#{$massa}"
	FileUtils.rm nome_arq_xls
	escreve_xls_de_hash(nome_arq_xls,$massa)
end



def set_massa_cen(cen=nil)
	#Thread.current[:nome_cenario_corrente] = cen

	write_rsi_log "set_massa, P00, cen=#{cen}"
	if cen != nil
		#2018Set6, debug mais racional, capaz de mostrar e até regravar a massa se houver auto/r correspondente.
		Thread.current[:nome_cenario_corrente] = cen.split("V ").last
		write_rsi_log "set_massa, P00.01, cen=#{cen}, Thread.current[:nome_cenario_corrente]=#{Thread.current[:nome_cenario_corrente]}"
	end
	cen = cen || "#{get_alphanumcenario(Thread.current[:nome_cenario_corrente])}"
	write_rsi_log "set_massa, P01, cen=#{cen}"
	dirs_xls = Dir["massas_feature/#{cen}*"]
	write_rsi_log "set_massa, P02, dirs_xls=#{dirs_xls}"
	um_dir = dirs_xls.first
	caminho_xls = "#{um_dir}/massa.xls"
	write_rsi_log :debug, "caminho_xls de massa=#{caminho_xls}"
	set_massa(ler_xls_com_id(caminho_xls))
	write_rsi_log :debug, "get_massa() ==#{get_massa() }"

	return
end

def processa_validar_veracidade()
	(status, msg_excecao) = espera_status_veracidade #LOOP checar_status_veracidade por 5 minutos
	
	if status != 200 
		if true
			falhar "Status de veracidade invalido, msg_excecao=#{msg_excecao}" #2018Mar19 - early am - nao eh um erro de negócios, e sim um erro técnico! Merece retentativa... #falhar_definitivo "Status de veracidade invalido"
		else
			write_rsi_log :warn, "Vou tentar avançar até pasta digital mesmo com erro em veracidade, pois eventual erro de SSL de HttParty pode ocultar bom retorno 200."
		end
	end
end

def get_pular_este_step

	#
	# TODO - refinar esta lógica para situações complexas!!
	#
	#

	if ($massa['STEP_INICIAL']||'0').to_i  > $numero_step_atual
		return true
	elsif ($massa['STEP_FINAL']||NUM_STEP_FINAL).to_i  < $numero_step_atual
		return true
	end

	return false

end





def set_num_step(num_step)
	$numero_step_atual = num_step

	write_rsi_log "$numero_step_atual=#{$numero_step_atual}"
	return true if false #2018Mar11 - renato revamping ###bobagem, sendo revamped por Diogo, 2018Mar8

	if get_pular_este_step
		return false
	end
	puts "chegou no passo" #IMPORANTE! MANTENHA ESTE puts! Ajuda a checar no "c.html" do consolidado qual passo foi de fato executado !!!
#
#
# TODO 2018Mar11 EOD - está robustamente testado em gera_e_executa, falta agora testar e ajustar para "zs_proc.rb proc" !!!!!!!! Está avançando fases bem, checando erros bem e tudo !
#
#



	if $not_single_maq_zsproc_debug
		return true
	end

	if false
		single_maq_zsproc_setnumstep
	end

	if true
		#randomizador de erro para SEM PROCESSO COLABORATIVO
		#falha a cada 15!
		fail_a_cada = 2
		rnd = Random.new.rand(1..fail_a_cada)
 		if rnd == 1 and $numero_step_atual >2 #nunca falha em steps <3, ASSIM, consigo ver CPF evoluindo quando necessario
 			falhar "Falhando em set_num_step , uma em cada #{fail_a_cada}"
		end
	end

	return true
end

def single_maq_zsproc_setnumstep
	sleep 10 #dormir alguns segundos fixos
	
	write_rsi_log :debug, "PZ01, set_num_step, $not_single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}"
	dir_rede_zsproc = 'c:/zznetwork'
	write_rsi_log :debug, "PZ02, set_num_step, $not_single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}, dir_rede_zsproc=#{dir_rede_zsproc}"
	fname_stepfailed = "#{dir_rede_zsproc}/debug_not_single_maq_zsproc_debug_failstep.properties"
	write_rsi_log :debug, "PZ03, set_num_step, $not_single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}, dir_rede_zsproc=#{dir_rede_zsproc}, fname_stepfailed=#{fname_stepfailed}"
	must_fail = false
	write_rsi_log :debug, "PZ04, set_num_step, $not_single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}, dir_rede_zsproc=#{dir_rede_zsproc}, fname_stepfailed=#{fname_stepfailed}, must_fail=#{must_fail}"
	executa_exclusivo(nil, "#{dir_rede_zsproc}/set_num_step.LCK") do
		# a cada 4 minutos, 1 falha.
		write_rsi_log :debug, "PZ05, set_num_step, $not_single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}, dir_rede_zsproc=#{dir_rede_zsproc}, fname_stepfailed=#{fname_stepfailed}, must_fail=#{must_fail}"
		if not (File.exist? fname_stepfailed)
			write_rsi_log :debug, "PZ06, set_num_step, $not_single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}, dir_rede_zsproc=#{dir_rede_zsproc}, fname_stepfailed=#{fname_stepfailed}, must_fail=#{must_fail}, nao existe arquivo fname_stepfailed=#{fname_stepfailed}"
			File.open(fname_stepfailed,'w') {|f| f}
		end
		mtime = File.mtime(fname_stepfailed)
		difftime = Time.now - mtime 
		write_rsi_log :debug, "PZ07, set_num_step, $not_single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}, dir_rede_zsproc=#{dir_rede_zsproc}, fname_stepfailed=#{fname_stepfailed}, must_fail=#{must_fail}, mtime=#{mtime}, Time.now=#{Time.now}"
		if (difftime) > (5 * 60) #falha a cada 5 minutos
			must_fail = true
			write_rsi_log :debug, "PZ08, set_num_step, $not_single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}, dir_rede_zsproc=#{dir_rede_zsproc}, fname_stepfailed=#{fname_stepfailed}, must_fail=#{must_fail}, mtime=#{mtime}, difftime=#{difftime}"
			FileUtils.rm fname_stepfailed
			write_rsi_log :debug, "PZ09, set_num_step, ápós remover arquivo, exists=#{File.exist? fname_stepfailed}"
			File.open(fname_stepfailed,'w') {|f| f} #apaga e recria
			write_rsi_log :debug, "PZ09.1, set_num_step, $not_single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}, dir_rede_zsproc=#{dir_rede_zsproc}, fname_stepfailed=#{fname_stepfailed}, must_fail=#{must_fail}, arquivo recriado, Time.now=#{Time.now}"
		end
	end 
	
	if must_fail
		falhar "PZ10, set_num_step, DEBUG - FALHA DE STEP RANDOMICA SIMULADA, pois $not_single_maq_zsproc_debug eh igual a #{$not_single_maq_zsproc_debug}, e arquivo #{fname_stepfailed} exist? eh #{File.exist? fname_stepfailed}"
	end
end	




def traduz_pacote_massa_para_tela
#2018Mar09, early am
	retval = $massa['PACOTE'] || ''
	if retval == 'Superdigital'
		retval = 'Conta Super'
	end
	return retval
end

def reinsere_clone_reproc_feature(ri_orig_arq_feature, ri_json_steps, ri_hash_massa, ri_dest_feat_dir, ri_dest_massa_dir, ri_max_tentativas, ri_max_global_tentativas, opcoes={:apenas_debug => false})

#2018ASet17 - adicionados aqui e em chamadoras parametros ri_max_tentativas e ri_max_global_tentativas, para libertar a reinsercao das limitacoes de sempre usar valores de rsi_utils (ex: em zs_proc.rb, podemos configurar feature-a-feature)

#2018Ago17 pm, revamped para nova opcao :forcar_refluxo, usada emmconjunto com :forcar_reinsercao == true! Nesse casp, forcar_reinsercao:true e forcar_refluxo:true, forçosamente fazer feature voltar pra "STEP_INICIAL=0 com "cpf=get_cpf_obterorisco" !!!
	opcoes[:apenas_debug     ] = false if opcoes[:apenas_debug     ] == nil

	opcoes[:forcar_reinsercao] = false if opcoes[:forcar_reinsercao] == nil

	opcoes[:forcar_refluxo   ] = false if opcoes[:forcar_refluxo   ] == nil
	#
	#
	# :forcar_reinsercao é casada com método chamador zs_proc.rb:: zs_reinsere_desistencias_para_reprocessamento - ao receber :forcar_reinsercao => true (default = false), nós bypassamos as checagens iniciais de DEVO REINSERIR? e também re-setamos TENTATIVAS para 1, no massa.xls !!
	#
	#


	if opcoes[:forcar_refluxo] and (not opcoes[:forcar_reinsercao])
		falhar "reinsere_clone_reproc_feature, opcoes invalidas, opcoes=#{opcoes}"
	end

	reinseriu = false

	write_rsi_log :debug, "reinsere_clone_reproc_feature , ri_orig_arq_feature=#{ri_orig_arq_feature}, ri_hash_massa=#{ri_hash_massa}, ri_dest_feat_dir=#{ri_dest_feat_dir}, ri_dest_massa_dir=#{ri_dest_massa_dir}, opcoes=#{opcoes}"

	if (not massa_failed(ri_hash_massa['FAILED'])) and ( (ri_hash_massa['STEP_FINAL']||NUM_ULTIMO_STEP_FINAL_AUTOMACAO).to_i==NUM_ULTIMO_STEP_FINAL_AUTOMACAO )
		if not opcoes[:forcar_refluxo]
			#2018Out6 11:30am - permitir reinsercao de NOT FAILED(999), mesmo com :forcar_reinsercao == true,, e SI=010(NUM_ULTIMO_STEP_FINAL_AUTOMACAO) causava SEVEROS efeitos colaterais, detectados em chamadas z 'zs_proc.rb continuar_features feat01,feat02' !!!!!!!!!!!!!!!!! Isso causava criacao de stt*done*7z com si=011, além de renomear stt*7z de 'ls=1' para 'ls=0'. Devido à grande quantidade de rotinas que chamam rotina intermediária que por fim chama esta rotina com :forcar_reinsercao == true, tornou-se mais prática arrumar aqui, fazendo checagem incondicional dessa situação!!!!! 

			write_rsi_log :debug, "reinsere_clone_reproc_feature , forcar_refluxo=#{opcoes[:forcar_refluxo]}, Nao precisa reinserir pois concluiu step final com exito, forcar_reinsercao=#{opcoes[:forcar_reinsercao]}"
			reinseriu = false
			return reinseriu
		else 
			#2018Out6 13:46pm - porém, no caso de forcar_refluxo=true, aí devo permitir reinsercao,  
			write_rsi_log :debug, "reinsere_clone_reproc_feature , forcar_refluxo=#{opcoes[:forcar_refluxo]}, precisa reinserir mesmo sem falhar e com si=NUM_ULTIMO_STEP_FINAL_AUTOMACAO, forcar_reinsercao=#{opcoes[:forcar_reinsercao]}"
		end

	elsif (not opcoes[:forcar_reinsercao])  
		if massa_failed(ri_hash_massa['FAILED']) and ((ri_hash_massa['FAIL_DEFINITIVO']||0).to_i == 1)
			status_veracidade_invalido = 'Status de veracidade invalido'
			
			if (ri_json_steps.any? {|step| (step['result']['error_message']||'').include? status_veracidade_invalido}) ############################ LÒGICA LEGADA, INÒCUA OU INCORRETA? 2018Mai01 - MANTENDO, POR ENQUANTO ESTÀ INOFENSIVA
				write_rsi_log :debug, "reinsere_clone_reproc_feature , nao bloqueando  reinsercao de ERRO DEFINITO legado: '#{status_veracidade_invalido}' (agora, nao eh mais considerado erro definitivo). Automação nao sabe recomeçar do step 8 (veracidade), portanto, se for reinserir, vai recomeçar do step 0. TODO 2019Mar19 - melhore isso!! De preferencia, colocando esta lógica daqui, de forma configurável a-la-JSON, numa máquina de estados previsível e facilmente compreensivel."
			elsif (ri_json_steps.any? {|step| (step['result']['error_message']||'').include? ERR_FRAGMENT_NENHUMA_AGENCIA}) ########################### LÒGICA LEGADA, INÒCUA OU INCORRETA? 2018Mai01 - MANTENDO, POR ENQUANTO ESTÀ INOFENSIVA
				write_rsi_log :debug, "reinsere_clone_reproc_feature , nao bloqueando  reinsercao de ERRO DEFINITO legado: '#{ERR_FRAGMENT_NENHUMA_AGENCIA}' (agora, nao eh mais considerado erro definitivo). Automação nao sabe recomeçar do step 4 (veracidade), portanto, se for reinserir, vai recomeçar do step 0. TODO 2019Mar19 - melhore isso!! De preferencia, colocando esta lógica daqui, de forma configurável a-la-JSON, numa máquina de estados previsível e facilmente compreensivel."
			else
				write_rsi_log :debug, "reinsere_clone_reproc_feature , Nao precisa reinserir poisri_hash_massa['FAIL_DEFINITIVO']=#{ri_hash_massa['FAIL_DEFINITIVO']}"
				reinseriu = false
				return reinseriu 
			end
		elsif massa_failed(ri_hash_massa['FAILED']) and ((ri_hash_massa['TENTATIVA']||1).to_i >= ri_max_tentativas or (ri_hash_massa['GLOBAL_TENTATIVA']||1).to_i >= ri_max_global_tentativas) 
			#2018Out28 - correcao de bug. Comparacao com max_tentativas. Agora, ">="... antes, ">"
			write_rsi_log :debug, "reinsere_clone_reproc_feature , nao deve reinserir pos excedeu numero de tentativas, ri_hash_massa['FAILED']=#{ri_hash_massa['FAILED']}, ri_hash_massa['TENTATIVA']=#{ri_hash_massa['TENTATIVAS']}, ri_hash_massa['GLOBAL_TENTATIVA']=#{ri_hash_massa['GLOBAL_TENTATIVA']}"
			reinseriu = false
			return reinseriu 
		end
	end


	orig_full_feat_name = parse_gherkin_feature_name(ri_orig_arq_feature)
	write_rsi_log :debug, "reinsere_clone_reproc_feature, orig_full_feat_name=#{orig_full_feat_name}"
	orig_feat_name = get_raw_feature_name_from_feature_file(ri_orig_arq_feature)
	write_rsi_log :debug, "reinsere_clone_reproc_feature, orig_feat_name=#{orig_feat_name}"
	orig_feat_guid = get_last_guid(orig_feat_name)
	write_rsi_log :debug, "reinsere_clone_reproc_feature, orig_feat_guid=#{orig_feat_guid}"
	new_feat_guid = obtem_alphanum_guid(8)
	write_rsi_log :debug, "reinsere_clone_reproc_feature, new_feat_guid=#{new_feat_guid}"
	
	orig_nice = get_nice(orig_feat_name)
	write_rsi_log :debug, "reinsere_clone_reproc_feature, orig_nice=#{orig_nice}"

	base_orig_nice = orig_nice / 1000 * 1000
	write_rsi_log :debug, "reinsere_clone_reproc_feature, base_orig_nice=#{base_orig_nice}"
	new_nice = base_orig_nice + (massa_failed(ri_hash_massa['FAILED']) ? 100 : 200) #nice aumentado pra que reprocessamento de erro nao concorra com feature ainda nao processada. Reprocessamento de erro ganha 100 em nice, enquanto que avanço de fase ganha 200 (REPROCESSAMENTO È MAIS PRIORITARIO Q AVANÇO DE FASE)
	#
	#
	#   RESULTADO PRÀTICO REAL (testado) DA ESTRATÈGIA DE NICING "+100=reproc, +200=fase" 
    # ====================================================================================
	#        O reprocessamento de erros (M100) tem prioridade
	# antes do avanço de fase (N200), sem preconceito de qual  
	# fase está sendo avançada. Uma feature avançando de webdesktop para pastadigital
	# tem a mesma prioridade que uma feature avançando de pastadigital para TFC, e ambas
	# sao menos prioritarias que qualquer feature tendo reprocessamento de erro. 


	new_feat_name = orig_feat_name.gsub(orig_feat_guid, new_feat_guid).gsub("Nice#{orig_nice}","Nice#{new_nice}")
	write_rsi_log :debug, "reinsere_clone_reproc_feature, new_feat_name=#{new_feat_name}"


	new_feat_fullpath = "#{ri_dest_feat_dir}/#{new_feat_name}.feature"
	write_rsi_log :debug, "reinsere_clone_reproc_feature, new_feat_fullpath=#{new_feat_fullpath}"
	new_full_feature_name = orig_full_feat_name.gsub(orig_feat_guid, new_feat_guid)
	write_rsi_log :debug, "reinsere_clone_reproc_feature, new_full_feature_name=#{new_full_feature_name}"
	new_hash_massa = ri_hash_massa.clone

	#2018Set19 , faltava deletar keys ERROR_*, ... estava carregando ERROR_* para próximo 7z
	new_hash_massa.delete 'ERROR_AJUSTES'  
	new_hash_massa.delete 'ERROR_BASE'
	new_hash_massa.delete 'ERROR_CODE'
	new_hash_massa.delete 'ERROR_MESSAGE'
	new_hash_massa.delete 'FAILED'
	new_hash_massa.delete 'FAIL_DEFINITIVO' #2018Mar22 - 10:02am, antes, preservava FAIL_DEFINITIVO anterior, o que fazia com que a nova execucao, se falhasse por qualquer motivo, fosse considerada erro definitivo indevidamente!
	if opcoes[:forcar_reinsercao] or opcoes[:forcar_refluxo]
		#2018Set17 - ambos FORCAR_REFLUXO(exclusivo p/ reinserir desistencias) quanto FORCAR_REINSERCAO causam reinicio dos contadores TENTATIVAS e GLOBAL_TENTATIVAS. Se executor quiser, pode editar valor de max_tentativas e max_global_tentativas no CVS feature_list.*.csv (infelizmente, ainda 2 CSVs , um DETALHADO e um RESUMIDO: em breve, corrigirei pra ser apenas um CVS com colunas diferencias pra report resumido e detalhado)
		new_hash_massa['TENTATIVA']='1'
		new_hash_massa['GLOBAL_TENTATIVA']='1' 
	
	elsif not massa_failed(ri_hash_massa['FAILED'])
		new_hash_massa['TENTATIVA']='1'
		#2018Mai01 - nao re-setamos GOBALTENTATIVA aqui. Este é o caso de avanço de fase. @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ISTO deve resolver o "loop de eterno refluxo de TFC -> WEBDESK -> PASTA -<> TFC -> (...)", quando nao encontra em estado pendente de aprovacao no TFC, aí dáva verto em webdesl+pasta, aí chegava em TFC com TE=1, e nunca estourava tentativas. Agora, existe limte GLOBAL de tentativas. 
	else
		new_hash_massa['TENTATIVA']=(ri_hash_massa['TENTATIVA'].to_i + 1).to_s 
		new_hash_massa['GLOBAL_TENTATIVA']=(ri_hash_massa['GLOBAL_TENTATIVA'].to_i + 1).to_s 
	end


	if opcoes[:forcar_refluxo]
		#2018Ago17 pm, permite que chamadora gere refluxo mesmo sem haver erro detectado!
		new_hash_massa['STEP_INICIAL']= (opcoes[:refluxo_step_inicial]||'0').to_s
		new_hash_massa['STEP_FINAL']=   (opcoes[:refluxo_step_final  ]||'8').to_s

	elsif ri_hash_massa['STEP_INICIAL'] and not massa_failed(ri_hash_massa['FAILED'])
		new_hash_massa['STEP_INICIAL'] = (ri_hash_massa['STEP_FINAL'].to_i+1).to_s
		new_hash_massa['STEP_FINAL'] = new_hash_massa['STEP_INICIAL']
		# SIMPLES, sem maiores checagens de avanço de step/fases: correntemente, 2018Mar11, avançamos de 1 em 1 depois dos 8 steps da 1a fase.
	
	elsif false and (massa_failed(ri_hash_massa['FAILED'])) and ((ri_hash_massa['TENTATIVA']||1).to_i <= ri_max_tentativas) and  (ri_json_steps.any? {|step| (step['result']['error_message']||'').include? 'LimiteContratado de tela TFC BRBW091 diferente'})
		
		write_rsi_log :debug, "2018Mar21 - Erro TFC de LimiteContratado diferente nao era por conflito de executa_exclusivo, mas sim por nao ter salvo na massa o valor do limite!"
	elsif 	(massa_failed(ri_hash_massa['FAILED'])) and (ri_json_steps.any? {|step| (step['result']['error_message']||'').include? 'TFC_STATUS_NOT_PENDENTE_APROV_DIGITAL'})
		#2018Abr02, 04:24am - nenhuma mudança... nao chegava aqui antes em ZS_PROC pois, para zs_proc.rb, método tfc_processa_faz_automacao_do_cenario não adicionava 'TFC_STATUS_NOT_PENDENTE_APROV_DIGITAL' à mensagem de erro quando devia! 
		if false
			write_rsi_log "reinsere_clone_reproc_feature, TFC_STATUS_NOT_PENDENTE_APROV_DIGITAL, deve voltar pro STEP_INICIAL/si = 0 !!!"
				new_hash_massa['STEP_INICIAL']='0'
				new_hash_massa['STEP_FINAL']='8'
		else
			write_rsi_log :debug, "rbattaglia 2018Set07  - reinsere_clone_reproc_feature, TFC_STATUS_NOT_PENDENTE_APROV_DIGITAL, nao deve mais causar refluxo automatico pra STEP_INICIAL/si = 0 !!! Isso gerava toda uma lentidao de reprocessamento às vezes desnecessário, que será melhor tratado por comandos administraticos de zs_proc.rb como FORCA_REFLUXO etc.!"
		end
	elsif ($gambiarra_rodando_2018Julho19 == true) and (massa_failed(ri_hash_massa['FAILED'])) and (($massa['STEP_INICIAL']||0) == NUM_STEP_TFC)
		#2018Julho19 - afeta REFLUXO PRA STEP 0 de CPFs detectados manualmente como nao chegando ao TFC: assim que der qquer erro de TFC, vai reinserir parecido com REFLUXO TRADICIONAL POR STATUS NAO PENDENTE!
		cpfs_sem_proposta_nucleo = ['88288406173', '39148253162', '30579226190', '49209837193', '71186764112', '77906635183']
		write_rsi_log "reinsere_clone_reproc_feature, $gambiarra_rodando_2018Julho19 igual a true ,TALVEZ (a deidir) deva voltar pra STEP-INICIAL/SI=0 , execucao de 2018Julho19, pra CPFS que parecem nao ter atingido nucleo, parecido com o q faz quando erro e TFC_STATUS_NOT_PENDENTE_APROV_DIGITAL. $massa['CPF']=#{$massa['CPF']}, cpfs_sem_proposta_nucleo = #{cpfs_sem_proposta_nucleo}"
		if cpfs_sem_proposta_nucleo.include? $massa['CPF']
			write_rsi_log "reinsere_clone_reproc_feature, $gambiarra_rodando_2018Julho19 igual a true ,DECIDI- VAI FAZER SIM -  deve voltar pra STEP-INICIAL/SI=0 , execucao de 2018Julho19, pra CPFS que parecem nao ter atingido nucleo, parecido com o q faz quando erro e TFC_STATUS_NOT_PENDENTE_APROV_DIGITAL. $massa['CPF']=#{$massa['CPF']}, cpfs_sem_proposta_nucleo = #{cpfs_sem_proposta_nucleo}"
			new_hash_massa['STEP_INICIAL']='0'
			new_hash_massa['STEP_FINAL']='8'
		end
	end

	if new_hash_massa['STEP_INICIAL'].to_i == 0
		new_hash_massa['CPF'] = get_cpf_obterorisco #2018Mar20 - corrigido o reset de cpf pra 'obterorisco', fevo fazer isso sempre que for começar do step 0, SIMPLES ASSIM, incodicionalmente!! # # # # # # # # # # # 2017Mar12 23:55, nao estava reobtendo cpf de risco/queimando mnova massa para as retentativas de passos 0-a-8 (WEBDESKTOP+VERACIDADE) !!
	end 

	write_rsi_log :debug, "reinsere_clone_reproc_feature, new_hash_massa=#{new_hash_massa}"

	
	if not opcoes[:apenas_debug]
		cria_arquivo_feature(ri_hash_massa['QUALAPP'], new_feat_fullpath, new_full_feature_name)
		fpath_new_massa = "#{ri_dest_massa_dir}/V #{new_feat_name}/massa.xls"
		mkdir_noexist File.dirname(fpath_new_massa)
		escreve_xls_de_hash  fpath_new_massa, new_hash_massa
	end

	reinseriu = true
	return reinseriu 
end

def cria_arquivo_feature(qualapp, full_path_feature, full_feature_name)
	full_feature_name = full_feature_name.gsub('Validar ','') #glitch - de alguma forma, chegou aqui com full_feature_name conbtendo/começando_com 'Validar ', algumas vezes

	t_mob = 'template_abccdigpf.feature'
	t_wds = 'template_webdesktop.feature'
	if qualapp == "mob"
		nomearq_template_ft = Dir[t_mob].first || Dir.glob("*/#{t_mob}").first
	else
		nomearq_template_ft = Dir[t_wds].first || Dir.glob("*/#{t_wds}").first
	end
	template_txt = File.read(nomearq_template_ft)
		#write_rsi_log :debug, "template_txt=#{template_txt}, encoding=#{template_txt.encoding}"
		template_txt.force_encoding('UTF-8')
		#write_rsi_log :debug, "AFTER ENCODING template_txt=#{template_txt}, encoding=#{template_txt.encoding}"
		new_txt = template_txt.gsub('@@NOME_CENARIO@@', "Validar #{full_feature_name}")
	File.open(full_path_feature, "w") {|file| file.puts new_txt }
	return
end

def parse_gherkin_feature_name(feature_file)

	parser = Gherkin::Parser.new #(formatter)
	parsed=parser.parse(IO.read(feature_file).encode('UTF-8'))
  	nome_da_feature = parsed[:feature][:name]
  	return nome_da_feature
end


def massa_failed(step_num)
	i_step_num = (step_num.to_s.to_i) if step_num

	# USA "na dúvida, considero que falhou!! Robustez para reprocessamento, mas se mecanismo de reprocessamento for desativado, vai considerar que todos steps falharam. C'est la vie.
	falhou = true
	if not i_step_num
		falhou = false #2018Mar29, 02:31am - step indefinido/nil = NAO FALHOU!
	end
	if i_step_num == get_step_maxval_notfailed
		falhou = false
	end 

	return falhou
end

def run_parallel_deve_fazer_boot_de_tfc?
	retval = false
	if $not_single_maq_zsproc_debug and (not (ENV['TEST_BOOTTFC_IN_RUNPARALLEL']=='0')) and Dir.glob("massas_feature/**/*.xls").map{|xls| m=ler_xls_com_id(xls); write_rsi_log :debug, "m['STEP_FINAL']=#{m['STEP_FINAL']}"; (m['STEP_FINAL']||NUM_STEP_TFC).to_i}.max == NUM_STEP_TFC 
	 	#2018Mar13, adicionada checagem de max step final lendo todos massa.xls. Somente faz tfc_do_server_boot se alguma feature for avançar até o tfc
		retval = true
	end
	return retval
end

def run_parallel_tem_apenas_tfc_para_processar?
	retval = false
	if $not_single_maq_zsproc_debug and  not Dir.glob("massas_feature/**/*.xls").any? {|xls| m=ler_xls_com_id(xls); write_rsi_log :debug, "m['STEP_INICIAL']=#{m['STEP_INICIAL']}, m['STEP_FINAL']=#{m['STEP_FINAL']}"; (m['STEP_INICIAL']||0).to_i != NUM_STEP_TFC or (m['STEP_FINAL']||NUM_STEP_TFC).to_i != NUM_STEP_TFC} 
	 	#2018Mar13, adicionada checagem de max step final lendo todos massa.xls. Somente faz tfc_do_server_boot se alguma feature for avançar até o tfc
		retval = true
	end
	return retval
end

def run_parallel_tem_algum_tfc_para_processar?
	retval = false
	if $not_single_maq_zsproc_debug and  Dir.glob("massas_feature/**/*.xls").any? {|xls| m=ler_xls_com_id(xls); write_rsi_log :debug, "m['STEP_INICIAL']=#{m['STEP_INICIAL']}, m['STEP_FINAL']=#{m['STEP_FINAL']}"; (m['STEP_INICIAL']||0).to_i == NUM_STEP_TFC and (m['STEP_FINAL']||NUM_STEP_TFC).to_i == NUM_STEP_TFC} 
	 	#2018Mar13, adicionada checagem de max step final lendo todos massa.xls. Somente faz tfc_do_server_boot se alguma feature for avançar até o tfc
		retval = true
	end
	return retval
end

def parse_cucumber_json_steps(json_file)
	retval = nil #badname retval cauhgt by ruby-lint! ALREADY PAYING OFF!
	json = nil
	begin
		if File.file? (json_file||'/') # " || '/ " eh residuo de codigo em  rotinas_processo, estou mantendo por segurança. Parece que foi tentativa de evitar excecao por NIL
			json = JSON.parse ( (File.open json_file).read) 
		end
	rescue Exception => e
		write_rsi_log :warn, "Erro/exception #{e.message} fazendo parse de json '#{json_file}'"
	end
	if not json
		write_rsi_log :warn, "Arquivo cucumber json #{json_file} - nao foi possivel ler ou fazer parse"
	else
		retval = (((json[0]||{})['elements']||{})[0]||{})['steps'] #:steps = ARRAY(7).. cada elto tem s['result']	
	end
	retval ||= []
	return retval
end

def regexp_for_nice_frag_of_feature_file
	#nice_frag = fn[/nice.*\d+.*X/i]
	#2018Jun29 -   @(.+?)X@ em vez de @.*)@ ... ou, vai comer nomeinteiro até ultimo X  
	/nice(.+?)\d(.+?)X/i
end

def get_feature_sem_nice(feature)
	fn = get_raw_feature_name_from_feature_file(feature.to_s)
	nice_frag = fn[regexp_for_nice_frag_of_feature_file]

	retval = fn.gsub(nice_frag,'')

	return retval
end

def get_feature_sem_guid_nem_nice(feature)
	fn = get_raw_feature_name_from_feature_file(feature.to_s)
	
	nice_frag = fn[regexp_for_nice_frag_of_feature_file]
	
	retval = fn.split('guid').first.split(nice_frag).last
	#write_rsi_log "get_feature_sem_guid_nem_nice, feature=#{feature}, fn=#{fn}, nice_frag=#{nice_frag}, retval=#{retval}"

	return retval
end

def time_from_str(str, adj_tz=" -2")
	DateTime.parse("#{str}#{adj_tz}").to_time
end

def tfcCpf2018Mai5and6_manual(massa_cpf)
	retval = false

	tnow = Time.now
	dtini_2019Mai5_and_6 = time_from_str '20180505000000', -3
	dtfim_2018Mai5_and_6 = time_from_str '20180506235959', -3
	cpfs_manuais_2018Mai5and6 = [
		'11177140128',
		'14359336136',
		'17178297166',
		'20437611108',
		'27192354155',
		'32342502192',
		'33136872100',
		'35814237155',
		'41306843103',
		'43234542104',
		'47831212140',
		'50526809108',
		'52735536106',
		'53346613100',
		'54452026150',
		'55766167156',
		'58579456150',
		'58609825183',
		'62306085102',
		'63857199105',
		'63977597175',
		'66432302170',
		'69571292176',
		'71547855193',
		'73148485130',
		'73470599173',
		'73732310124',
		'74222065196',
		'75352165108',
		'75548712187', 
		'76767586102', 
		'77630731108' 
	]
	if tnow >= dtini_2019Mai5_and_6 and tnow <= dtfim_2018Mai5_and_6 and cpfs_manuais_2018Mai5and6.include?(massa_cpf)
		msg= "ATENCAO - 2018Mai5_and_6 - TFC executado manualmente, tnow=#{tnow}, massa_cpf=#{massa_cpf}, cpfs_manuais_2018Mai5and6=#{cpfs_manuais_2018Mai5and6}, dtini_2019Mai5_and_6=#{dtini_2019Mai5_and_6}, dtfim_2018Mai5_and_6=#{dtfim_2018Mai5_and_6}"
		write_rsi_log :debug, msg
		puts msg #pra aparecer em console de cucumber
		retval = true
	else
		write_rsi_log :debug, "TFC executado normalmente, tnow=#{tnow}, massa_cpf=#{massa_cpf}, cpfs_manuais_2018Mai5and6=#{cpfs_manuais_2018Mai5and6}, dtini_2019Mai5_and_6=#{dtini_2019Mai5_and_6}, dtfim_2018Mai5_and_6=#{dtfim_2018Mai5_and_6}"
		retval = false
	end
	return retval
end


def tfcCpf2018Mai9and10_manual(massa_cpf)
	retval = false

	tnow = Time.now
	dtini_2019Mai9_and_10 = time_from_str '20180509000000', -3
	dtfim_2018Mai9_and_10 = time_from_str '20180510235959', -3
	cpfs_manuais_2018Mai9and10 = [
		['58699034164', 'erro - nao chegou ao BW'],
		['67784173156', 'erro - nao chegou ao BW'],
		['26082108132', 'erro - nao chegou ao BW e daria erro por ser SELECT']
	]
	if tnow >= dtini_2019Mai9_and_10 and tnow <= dtfim_2018Mai9_and_10 and cpfs_manuais_2018Mai9and10.any? {|chk| puts "chk=#{chk}"; chk[0] == massa_cpf}
		achado = cpfs_manuais_2018Mai9and10.select{|chk| chk[0] == massa_cpf}.first
		msg= "ATENCAO - 2018Mai9_and_10 - TFC executado manualmente com '#{achado[1]}', tnow=#{tnow}, massa_cpf=#{massa_cpf}, cpfs_manuais_2018Mai9and10=#{cpfs_manuais_2018Mai9and10}, dtini_2019Mai9_and10=#{dtini_2019Mai9_and_10}, dtfim_2018Mai9_and_10=#{dtfim_2018Mai9_and_10}"
		if achado[1].start_with? 'erro'
			falhar_definitivo msg
		else
			write_rsi_log :debug, msg
			puts msg #pra aparecer em console de cucumber
		end

		retval = true
	else
		write_rsi_log :debug, "TFC executado normalmente, tnow=#{tnow}, massa_cpf=#{massa_cpf}, cpfs_manuais_2018Mai9and10=#{cpfs_manuais_2018Mai9and10}, dtini_2019Mai9_and_10=#{dtini_2019Mai9_and_10}, dtfim_2018Mai9_and_10=#{dtfim_2018Mai9_and_10}"
		retval = false
	end
	return retval
end

def espera_condicao (segundos_espera, segundos_sleep = 1)
	if not block_given?
		raise "esperar_condicao : nao foi passado bloco de codigo esperado"
	end

	inicio = Time.now
	if yield
		return
	end

	while true
		agora = Time.now

		diff = agora - inicio

		if diff > segundos_espera
			break
		end

		if yield
			break
		end

		sleep segundos_sleep
	end
end
