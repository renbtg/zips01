require 'win32/screenshot'
require "base64"
#INSTALLATION_STATE = {


def wrap_before_do(scenario)
	###Capybara.page.driver.browser.manage.window.maximize - DESNECESSARIo maximizar aqui
	$numero_step_atual = 0
	begin
		write_rsi_log :debug, "Before do de cenario com nome #{scenario.name}"
		Thread.current[:nome_cenario_corrente] = scenario.name
		begin
			set_massa_cen 
		rescue Exception => e
			#2018Abr03 - QUE FAÇO DA VIDA se falhar na leitura da massa???
			falhar e
		end
		
		#2018Set28 - grava timestamp de inicio e fim de execucao em xls de massa
		$massa['TS_INI']=ts_now

		$numero_step_atul = ($massa['STEP_INICIAL']||'0').to_i #2018aBR03
		write_rsi_log :debug, "wrap_before_do, $massa=#{$massa}"

		if $massa['TERMINATE_FILE_PREFIX']
			#2018Out6, 22:40 - zs_proc.rb pode passadr TERMINATE_FILE na massa, pra checagem de interrucap de um ID
			ENV['TEST_INTERRUPCOES_PREFIXO'] = ENV['TEST_INTERRUPCOES_PREFIXO'] + ',' if ENV['TEST_INTERRUPCOES_PREFIXO']
			ENV['TEST_INTERRUPCOES_PREFIXO'] = (ENV['TEST_INTERRUPCOES_PREFIXO']||'') + $massa['TERMINATE_FILE_PREFIX']
		end
		write_rsi_log :debug, "wrap_before_do, ENV['TEST_INTERRUPCOES_PREFIXO']=#{ENV['TEST_INTERRUPCOES_PREFIXO']}"

		regrava_arquivo_massa
		
		abre_janela_browser

	rescue Exception => e
   		$falhou_em_before_hook = true #Pode ser usado pra controles posteriores
  		falhar e
  	end

end

def wrap_after_do(scenario)
	write_rsi_log :debug, "wrap_after_do(scenario) - P0000 - vai chamar BLOCK EXCLUSIVO"

	
	primeira_excecao = nil

	begin
		if true #2018Mar23 - WTF! executa_exclusivo aqui impedia todo processamento do nucleo de AFTER, em runAfterDo, se o failure do step for NAO CONSEGUIU LOCK DE GUI! CORRIGIDO! Movendo lock de GUI, talvez com logicas adicionais, pro instante exato dos screenshots de browser e de desktop.
	  		begin
	  			runAfterDo(scenario)
	  		rescue Exception => e
	  			primeira_excecao = e
	  			write_rsi_log :error, "wrap_after_do(scenario) - Alguma excecao em [runAfterDo], excecao=#{e}"
	  		end
	  		begin
	  			fecha_janela_browser
	  		rescue Exception => e
	  			primeira_excecao = e
	  			write_rsi_log :error, "wrap_after_do(scenario) Alguma excecao em [fecha_janela_browser], excecao=#{e}"
	  		end
		end
	rescue Exception => e
	  	primeira_excecao = e
	  	write_rsi_log :error, "wrap_after_do(scenario) Alguma excecao em [executa_exclusivo], excecao=#{e}"
	end

	begin
  		del_exes_ahk_processo #2017Set20, CLEANUP de executaveis auto-hotkey
  	rescue Exception => e
 	  	primeira_excecao = e # ISSO MESMO! Até falha em deletar exes de Autohotkey é FAIL
 		write_rsi_log :warn, "wrap_after_do(scenario) Alguma excecao em fecha_janela_browser, excecao=#{e}"
  	end

	if primeira_excecao
		#fail primeira_excecao ------ 
		# ------- ATENCAO - nao quero ERRO CUCUMBER apenas por erro em AFTER !!
	end
end


def runAfterDo(scenario)
	write_rsi_log :debug, "P00 runAfterDo" 
	
	if not scenario.failed?
		$massa['FAILED']=get_step_maxval_notfailed.to_s
	else
		$massa['FAILED'] = $numero_step_atual.to_s
		#2018Mar27 03:26am - HMMM, devo , sim, setar e regravar aqui massa['FAILED'], pq posso muito bem te RAISEs e FAILs sem passar pelo tradicional FALHAR!
	end
	#2018Set28 - grava timestamp de inicio e fim de execucao em xls de massa
	$massa['TS_FIM']=ts_now
	regrava_arquivo_massa
	
	if not $not_single_maq_zsproc_debug 
		return #retorna, pois de agora em diante, só restam screenshots finais que nao sao feitos neste caso
	end

	if last_lock_exclusivo_falhou
		write_rsi_log :debug, "runAfterDo, NAO fazendo screenshots finais pois last_lock_exclusivo_falhou=true"
		return #retorna, pois de agora em diante, só restam screenshots finais que nao sao feitos neste caso
	end

	if false
		5.times {write_rsi_log "DEBUG, runAfterDo, SCREENSHOTS DESABILITADOS"}
	else
		executa_exclusivo(trazer_janela_para_topo_antes: true) do
			screenshots_after_do
		end
	end

	#
	# 2017Set18 am - NAO coloca SCREENSHOT HTML, que parece ser tecnologia do
	# Capybara::screenshots... SE necessario, depois, eu estudo como manter
	#coerencia entre MULTIPLAS OBTENCOES DE visit+driver.quit e FINAL_SESSION!
	#


	write_rsi_log :debug, '#TODO 2018Fev18- screenshot de desktoptfc -PLEASE DO IT! A estratégia CORRETA é pegar o último último scrrenshot com assinatura/máscara de TFC e renomear e copiar pro nome definido em rotinas_processo.rb :: :desktoptfc_screenshot !!! E aí tenho que mudar html_from_json.rb pra lidar com isso (creio eu).'


	dormir_depois = 5
	if dormir_depois and dormir_depois > 0
		write_rsi_log :debug, "runAfterDo(scenario) - dormindo #{dormir_depois} segundos depois dos screenshots. Movido de ANTES pra DEPOIS em 2017Nov17 am"
		sleep dormir_depois 
		write_rsi_log :debug, "runAfterDo(scenario) - dormiu #{dormir_depois} segundos depois dos screenshots. Movido de ANTES pra DEPOIS em 2017Nov17 am"
	end
	return
end

def core_sceenshots_after_do_desktop(desktop_png)
	begin
		Win32::Screenshot::Take.of(:desktop).write!(desktop_png)
		image = open(desktop_png, 'rb') {|io|io.read}
		encoded_img = Base64.encode64(image)
		embed(encoded_img, 'image/png;base64', "Screenshot")
	rescue Exception => e
		write_rsi_log :error, "screenshots_after_do - Excecao #{e} no screnshot do desktop"
	end
	return
end


def screenshots_after_do
	

	browser_png = "#{get_nome_de_screenshot}/scrshot_final_report.browser.png"
	desktop_png=browser_png.split(".browser.png")[0]+".desktop.png"

	if ($massa['STEP_INICIAL']||0).to_i==NUM_STEP_TFC and ($massa['STEP_FINAL']||NUM_ULTIMO_STEP_FINAL_AUTOMACAO).to_i==NUM_STEP_TFC
		  write_rsi_log :debug, "NAO chamando screnshot final de browser para TFC EXCLUSIVO, pois $massa['STEP_INICIAL']=#{$massa['STEP_INICIAL']} e $massa['STEP_FINAL']=#{$massa['STEP_FINAL']} "
		if false
			#2018Out17 - tira screenshot final mesmo quando executando TFC
			return
		end
	end



	#2018Set28 - checagem [desabilitada] de FAZENDO AJUSTES removida daqui, já estava ok há semanas 100% dentro de método 'falhar'



	if false
		#2018Set29 - screenshots sempre de desktop, já faz algumas semanas.... pois screenshots de browser nao mostram URL. Portanto, nao será tirado nem embutido em report o screenshot do browser 

		#2018Set29 - código de tirar screenshot do browser removido
	end

	begin
		#2018Set29 - já no topo. OBS: ainda nao consegui tirar screenshots da janela de carregar arquivo "image upload" quando esse falha, preciso pesquisar forma de evidenciar isso.
		core_sceenshots_after_do_desktop desktop_png 
	rescue  Exception => e
		write_rsi_log :error, "screenshots_after_do - Excecao #{e} ao tirar screnshot do desktop"
	end
end
