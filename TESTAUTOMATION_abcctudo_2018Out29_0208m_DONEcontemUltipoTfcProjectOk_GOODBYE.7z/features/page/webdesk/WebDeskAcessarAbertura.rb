require 'faker'

class WebdesktopAcessarAbertura < SitePrism::Page

element :botao_continuar,	:id,	'ctaFullButton' #IGUAL EM TODOS OS PASSOS
#------------------------------------------------------------------------------------------------------------------------


	def processa()
		remove_nonascii_exception {run_processa}
	end
	def run_processa()
		acessarLink
	end

	def acessarLink()
		liberaAberturaUrl='https://mobhk.servcoord.santanderbr.pre.corp:8443/'
		#url = "https://mob-front-desk-contacorrente-pre.appls.cmp#{NORTE_SUL.downcase}.paas.gsnetcloud.corp/#/"
		url = 'https://abrasuacontadesk.paas.santanderbr.pre.corp/'
		#url = "https://www.wikipedia.org"
		#visit liberaAberturaUrl
		visit url
		
		seta_titulo_janela_browser
		gera_screenshot "AcessarAbertura"

	end

end