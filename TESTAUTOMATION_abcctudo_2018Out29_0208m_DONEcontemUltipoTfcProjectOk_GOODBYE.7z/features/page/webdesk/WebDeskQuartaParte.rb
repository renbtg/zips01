#
#	** DONE 1) maximizar perdo da hora de confirmar agencia. 
#		** SERAH q eh melhor mazimizar antes de escolher
#	** DOING 2 - continuar FAZENDO os lances de clicar/checar cred/debito
#	** TODO 3 - WAIT em vez de sleep, c/ "todas transicoes de pagina protegidas de FAZENDO_ALGUNS_AJUSTES"
#
# AINDA ZICADO transicao pra ela de bonus, quando tem. Quando nao tem, de boa, dá certo.
class QuartaParte < SitePrism::Page

XPATH_CONTAINS_LIMITE_CONTA=str_to_xpath_contains("limite da conta")

XPATH_CONTAINS_LIMITE_VALOR=str_to_xpath_contains("eu limite aprovado") # 2018Mar5 - sem o 'S' maiúsculo, serve tando para limite a aprovar como já aprovado
#XPATH_CONTAINS_CARTAO_CRED=str_to_xpath_contains("dá direito a um cartão de crédito")
XPATH_CONTAINS_CARTAO_CRED=str_to_xpath_contains("também um cartão de crédito") #2017Nov24, app mudou. Ou tem variações. Antes="Sua conta tamb´pem d´pa direito a um cartão de crédito", agora="Você também pode ter um cartão de crédito"
XPATH_CONTAINS_FATURA=str_to_xpath_contains("Escolha a data de vencimento da sua fatura")
XPATH_CONTAINS_ESCOLHAAGENCIA=str_to_xpath_contains("Escolha a sua agência")
XPATH_CONTAINS_TITLE_BONUS=str_to_xpath_contains('pode ser revertido em bônus')


element :desculpe_estamos_fazendo_ajustes, :xpath, "//span[text()[#{xpath_contains_fazendo_ajustes}]]"
#
#
#   TODO 2017Nov14 02:10am - ATENCAO - momentos de checagem de desculpe_estamos_fazendo_ajustes 
# podem gerar mensagens de erro enganosas. Ex: logo depois de escolher agencia, há checagem em
# espera_pagina_limite. PORÈM, pode ser que naturalmente, naquele cenário, não exiata página de 
# limites (deveria ir direto pra CARTAOCREDITO). Nesse caso, um erro server-side na rotina de oboterd
# dados do cartao vai aparecer na mensagem como 
# esper_pagina_limite: espera_pagina_limite: #{get_msgerr_desculpe_fazendo_ajustes} "."
#
#                 COMO POSSO MELHORAS A SITUACAO ACIMA???


element :botao_continuar,		:id,	'ctaFullButton' #IGUAL EM TODOS OS PASSOS

element :botao_agencia  ,	:xpath,	"(//img[contains(@src,'icon-santander-tag')])[1]", visible:false #2018Abr21 - DOM ALTERADO
#2018Abr21 - ALTERAÇÂO NO DOM - DEPRECATED #element :botao_agencia  ,	:xpath,	"(//*[@id='Santander-Tag'])[1]", visible:false #2018Mar25 - visible:false para telas nao-maximizadas #Nao-Select: icon-santander-tag desposicionado, tive que usar o ID do svg/g dentro do icon-select-tag !!

#2018Abr21, AGENCIA SELECT NAO MUDOU! ##element :botao_agencia_select, :xpath, "(//img[contains(@src,'icon-select-tag')])[1]", visible:false #2018Mar25 - visible:false para telas nao-maximizadas #SELECT-icon-select-tag já OK
element :botao_agencia_select, :xpath, "(//icon-select-tag)[1]", visible:false #2018Mar25 - visible:false para telas nao-maximizadas #SELECT-icon-select-tag já OK

XPATH_CONTAINS_CONFIRMAAGENCIA="contains(.,'Confirmar Agência')     or          contains(., 'enho acesso')"#2017Nov17 - existe PAB cuja mensagem é algo como "ok, tenho acesso" em vez de 'Confirmar agência"!!!

XPATH_CONTAINS_TROCAROFERTA="contains(.,'Trocar oferta para')"
element :botao_confir_ag,		:xpath,	"//span[text()[#{XPATH_CONTAINS_CONFIRMAAGENCIA}]]"
element :trocaroferta_or_confirmagencia, :xpath, "//span[text()[#{XPATH_CONTAINS_TROCAROFERTA} or #{XPATH_CONTAINS_CONFIRMAAGENCIA}]]"
element :botao_trocar_oferta,:xpath,	"//span[text()[#{XPATH_CONTAINS_TROCAROFERTA}]]"
element :limitevalor,	:xpath,	"//h2[text()[#{XPATH_CONTAINS_LIMITE_VALOR}]]" #2018Fev10 , pra obter valor, pra comparar com TFC
element :limiteconta,	:xpath,	"//span[text()[#{XPATH_CONTAINS_LIMITE_CONTA}]]"
element :limiteconta_ou_cartaocred_contratacao_ou_errosconhecidos, :xpath, "//*[text()[#{XPATH_CONTAINS_LIMITE_CONTA} or #{XPATH_CONTAINS_CARTAO_CRED} or #{xpath_contains_contratacao_produtos} or #{xpath_contains_fazendo_ajustes}]]"
element :escolheagencia_ou_bonus_ou_cartaocred_contratacao_ou_errosconhecidos, :xpath, "//*[text()[#{XPATH_CONTAINS_ESCOLHAAGENCIA} or #{XPATH_CONTAINS_TITLE_BONUS} or #{XPATH_CONTAINS_CARTAO_CRED} or #{xpath_contains_contratacao_produtos} or #{xpath_contains_fazendo_ajustes}]]" #2018Jun19 - colocado BONUS... estava dava pau quando ia direto pra bonus
element :botao_sim_limite,				:xpath, "//*[text()[contains(.,'sempre bom')]]"
element :botao_nao_limite,				:xpath, "//*[text()[contains(.,'obrigado')]]"

element :label_cartao_cred,		:xpath,	"//span[text()[#{XPATH_CONTAINS_CARTAO_CRED}]]"
#element :botao_quero_esse,		:xpath, "//*[text()[contains(.,'Quero esse')]]" 
element :botao_naoquero_cartao,		:xpath, "//*[text()[contains(.,'Não tenho interesse no momento')]]" #2018_AGO_03 - Alterado de botão para link e novo texto

element :cartao_credito,			:xpath, "//span[contains(text(),'Saiba Mais')]" #somente quando é credito

##### DAMN, mudança de ultima hora na app na noite de 2017Nov13: 
element :origBeforeNov13Night_cartao_sujeito_a_analise,	:xpath, "//*[contains(@class,'benefits') and contains(.,'Sujeito a análise')]" #credito adormecido
element :cartao_sujeito_a_analise,	:xpath, "(//*[contains(.,'análise de crédito')])[1]" #É um H3 que usa BR seperando parágrafos, e nao o NBSP hiper dinâmico

element :cartao_nome_large_browser ,	:xpath, "//div[contains(@class,'card-item-image')]//span"
element :cartao_nome_small_browser ,	:xpath, "//span[contains(@class,'card-item-right-card')]"
#rbattaglia 2017Nov12 - dois elementos de nome de cartao sao necessarios, pois tratamento de 
#RESPONSIVE UI modifica estrutura do HTML/DOM sem ID/CLASS/WHATEVER que iteitifique, em ambas
#estruturas, o elemento onde temos o NOME DO CARTAO 

element :cartaocred_ou_contratacao_ou_bonus_ou_errosconhecidos, :xpath, "//*[text()[#{XPATH_CONTAINS_CARTAO_CRED} or #{XPATH_CONTAINS_TITLE_BONUS} or #{xpath_contains_contratacao_produtos} or #{xpath_contains_fazendo_ajustes}]]"

element :label_fatura,			:xpath,	"//span[text()[#{XPATH_CONTAINS_FATURA}]]"
element :labelfatura_ou_errosconhecidos, :xpath, "//span[text()[#{XPATH_CONTAINS_FATURA} or xpath_contains_fazendo_ajustes]]"

#2018AGO06 rboker - alteração do tipo de objeto
#element :campo_vencimento,		:xpath, "//select[@formcontrolname='selectCreditCardMaturityDate']", visible:false

element :campo_vencimento,		:id, 'creditCardMaturityDate', visible:false

element :contratacao,		:xpath,	"//span[text()[#{xpath_contains_contratacao_produtos}]]"

element :label_escolhaagencia, :xpath, "//*[text()[#{XPATH_CONTAINS_ESCOLHAAGENCIA}] and not(ancestor::tooltip)]"
element :chegou_escolhaagencia_ou_errosconhecidos, :xpath, "//*[text()[#{XPATH_CONTAINS_ESCOLHAAGENCIA} or #{xpath_contains_fazendo_ajustes}]  and not(ancestor::tooltip)]"

element :title_bonus,:xpath, "//*[text()[#{XPATH_CONTAINS_TITLE_BONUS}]]"
element :checkbox_bonus, :xpath,"//step-mobile-bonus-component//*//div[@class='checkbox']"
element :campo_operadora, :id, 'carrier' #2018Ago22 - added
element :qualquer_titulo_de_step,:xpath, xpath_qualquer_titulo_de_step #DESISTI de usar
element :contratacao, :xpath, "//*[text()[#{xpath_contains_contratacao_produtos}]]"
element :bonuscelular_ou_contratacao_ou_errosconhecidos, :xpath,"//*[text()[#{XPATH_CONTAINS_TITLE_BONUS} or #{xpath_contains_contratacao_produtos} or #{xpath_contains_fazendo_ajustes}]]"

element :contratacao_ou_errosconhecidos , :xpath,"//*[text()[#{xpath_contains_contratacao_produtos} or #{xpath_contains_fazendo_ajustes}]]"

element :botao_cartao_saiba_mais, '.card-item-know-more'
element :div_cartao_saiba_mais, '.know-more-container'
element :icon_close, 'icon-close'

#------------------------------------------------------------------------------------------------------
	
	def espera_pagina_carregada()
		write_rsi_log "espera_pagina_carregada: P00'"
		write_rsi_log "P'"
		executa_com_retry_stale_element {wait_for_escolheagencia_ou_bonus_ou_cartaocred_contratacao_ou_errosconhecidos 75}
		
		

		write_rsi_log "P'"

		if has_label_escolhaagencia? or has_title_bonus? or has_label_cartao_cred? or has_contratacao?
			write_rsi_log "P'"
			return
		end

		write_rsi_log "P'"
		if has_desculpe_estamos_fazendo_ajustes?
			falhar "espera_pagina_carregada: #{get_msgerr_desculpe_fazendo_ajustes}"
		end
		falhar "espera_pagina_carregada: Elemento escolheagencia_ou_bonus_ou_cartaocred_contratacao nao estah presente na tela, nem tampouco erros conhecidos"
	end
	
	def espera_pagina_limite()
		write_rsi_log "espera_pagina_limite: P00'"
		#
		#
		# RBATTAGLIA, 2017Nov13 - SIM, às vezes, a tela de limite nao aparece, como em alguns
		# cenários de "baixissima renda (0 a 400) e Nao Trabalho"!!!
		#
		#  RBATTAGLIA - e... até para TIPOCRED=CRÈDITO (com cartao de crédito) tem vezes que
		# não é dado limite na conta (nem aparece tela de limites, nesse caso!)
		#

		write_rsi_log "P'"
		executa_com_retry_stale_element {wait_for_limiteconta_ou_cartaocred_contratacao_ou_errosconhecidos 75}
		write_rsi_log "P'"

		if has_limiteconta? or has_label_cartao_cred? or has_contratacao?
			write_rsi_log "P'"
			return
		end

		write_rsi_log "P'"
		if has_desculpe_estamos_fazendo_ajustes?
			falhar "espera_pagina_limite: #{get_msgerr_desculpe_fazendo_ajustes}"
		end
		falhar "espera_pagina_limite: nao encontrado elemento limiteconta, nem elemento label_cartao_cred, nem elemento contratacao, na tela"
	end
	
	def espera_pagina_cartao()
		write_rsi_log "espera_pagina_cartao: P00'"
		
		executa_com_retry_stale_element {wait_for_cartaocred_ou_contratacao_ou_bonus_ou_errosconhecidos 75}
		#2017Dez04 - creio ter arrumado bug de DEBITO em passo 4, nao sabia lidar casos em que DEBITO oferecesse diretamente BONUS DE CELULAR logo depois de escolher LIMITE.

		write_rsi_log "P'"

		if has_label_cartao_cred? or has_title_bonus? or has_contratacao?
			write_rsi_log "P'"
			return
		end

		write_rsi_log "P'"
		if has_desculpe_estamos_fazendo_ajustes?
			falhar "espera_pagina_cartao: #{get_msgerr_desculpe_fazendo_ajustes}"
		end

		falhar "espera_pagina_cartao:  Nao encontrado elemento label_cartao_cred, nem elemento contratacao, na tela"
	end

	def get_msgerr_tipocartao_incompativel(texto_cartao_de)
		return "Tipo de cartao na tela #{texto_cartao_de} incompativel com TIPO_CREDITO #{get_massa()['TIPO_CREDITO']} da massa de dados"
	end

	def validar_tipo_credito
		write_rsi_log "validar_tipo_credito: P00'"
		espera_pagina_cartao

		if has_contratacao? or has_title_bonus?
			texto_cartao_de="Débito"
			write_rsi_log :debug, "Tipo do cartao na tela #{texto_cartao_de}"
			write_rsi_log :debug, "TIPO_CREDITO #{$massa['TIPO_CREDITO']} da massa de dados"
			
			if get_massa() ['TIPO_CREDITO'] != texto_cartao_de 
				#2018Jan04 - nao ofereceu cartao, isso só é OK quando TIPO_CREDITO=Débito!
				falhar_definitivo(get_msgerr_tipocartao_incompativel(texto_cartao_de)) #2018Fev08 - removido mau uso de proc/lambda 
			end

			return #ok - não contem tela - já passa para o proximo passo
		
		elsif has_label_cartao_cred?	
			
			if has_cartao_credito?
				texto_cartao_de="Múltiplo"
				write_rsi_log :debug, "Tipo do cartao na tela #{texto_cartao_de}"
				write_rsi_log :debug, "TIPO_CREDITO #{$massa['TIPO_CREDITO']} da massa de dados"
			
				if get_massa() ['TIPO_CREDITO'] == texto_cartao_de 
					selecionar_cartao
					escolhe_data_vencimento_fatura
				else
					if get_massa() ['TIPO_CREDITO'] == 'Débito' and (get_massa() ['FORCAR_CARTAO_DEBITO']||'')[0]=='S'
						#2018Jan04 - ignora mismatch de tipo de credito, quando massa pede Débito, e escolhe nao querer cartao
						scroll_to botao_naoquero_cartao

						gera_screenshot "Parte4TpCredito"

						botao_naoquero_cartao.click
					else
						falhar_definitivo(get_msgerr_tipocartao_incompativel(texto_cartao_de)) #2018Fev08 - removido mau uso de proc/lambda 
					end
				end
			elsif has_cartao_sujeito_a_analise?
				texto_cartao_de="Crédito Adormecido"
				write_rsi_log :debug, "Tipo do cartao na tela #{texto_cartao_de}"
				write_rsi_log :debug, "TIPO_CREDITO #{$massa['TIPO_CREDITO']} da massa de dados"
				
				if get_massa() ['TIPO_CREDITO'] == texto_cartao_de 
					selecionar_cartao
				else
					if get_massa() ['TIPO_CREDITO'] == 'Débito'  and (get_massa() ['FORCAR_CARTAO_DEBITO']||'')[0]=='S'
						#2018Jan04 - ignora mismatch de tipo de credito, quando massa pede Débito, e escolhe nao querer cartao
						scroll_to botao_naoquero_cartao
						gera_screenshot "Parte4TpCredito"
						botao_naoquero_cartao.click
					else
						falhar_definitivo(get_msgerr_tipocartao_incompativel(texto_cartao_de)) #2018Fev08 - removido mau uso de proc/lambda 
					end
				end
			else
				falhar "validar_tipo_credito: nao encontrados elementos que diferenciam se cartão oferecido é Múltiplo ou Crédito Adormecido"
			end
		else
			falhar "validar_tipo_credito:  Nao encontrados elementos que identificam tipo do cartão oferecido, nem tampouco próximas telas esperadas em caso de Débito"
		end
	end

	def escolhe_data_vencimento_fatura
		espera_pagina_fatura

		scroll_to campo_vencimento
		write_rsi_log "P'"
		executa_exclusivo(trazer_janela_para_topo_antes: true) do #2018Set18 and 2018Set19 - evita que perda/retomada de foco afetem + sleep depois de click
			campo_vencimento.click
			sleep 3
			(campo_vencimento.find :xpath,"//*[text()[contains(.,'Dia 02')]]").click
		end
		write_rsi_log "P'"
		click_em_botao_continuar "Parte4DtVencimento"
	end

	def espera_pagina_fatura
		# SOMENTE chama aqui se TIPO_CREDITO=Múltiplo.
		# Entao, apenas espero LABEL_FATURA ou ERROS_CONHECIDOS/DESCULPE_FAZENDO_AJUSTES
		write_rsi_log "espera_pagina_fatura: P00'"
		executa_com_retry_stale_element {wait_for_labelfatura_ou_errosconhecidos 75}
		if has_label_fatura? 
			return
		end
		if has_desculpe_estamos_fazendo_ajustes?
			falhar "espera_pagina_fatura: #{get_msgerr_desculpe_fazendo_ajustes}"
		end
		falhar "espera_pagina_fatura: Elemento label_fatura nao estah presente na tela"
	end		

	def selecionar_cartao
		write_rsi_log "selecionar_cartao: P00'"
		validar_cartao_oferecido
		validar_texto_cartao #2018Set19, validar_texto_cartao
		click_em_botao_continuar "Parte4SelecionaCartao"
	end
	
	
	def validar_cartao_oferecido
		write_rsi_log "validar_cartao_oferecido: P00'"
		if has_cartao_nome_large_browser?
			write_rsi_log "P'"
			texto_cartao_nome=cartao_nome_large_browser.text
		elsif has_cartao_nome_small_browser?
			write_rsi_log "P'"
			texto_cartao_nome=cartao_nome_small_browser.text
		else
			falhar "Nao encontrado elemento de nome do cartao na tela"
		end
		write_rsi_log :debug, "validar_cartao_oferecido , texto_cartao_nome=#{texto_cartao_nome}, nome na massa=#{get_massa()['CARTAO']}"

		if texto_cartao_nome == get_massa()["CARTAO"] 
			#ok
		else
			msgerr = "Nome do cartao na tela #{texto_cartao_nome} incompativel com CARTAO #{get_massa()["CARTAO"]} da massa de dados"
			write_rsi_log :error, msgerr
			falhar_definitivo msgerr
		end
	end

	def validar_texto_cartao
		#created 2018Set19
		write_rsi_log :debug, "validar_texto_cartao - INI, $massa['TEXTO_CARTAO_CHECAR']=#{$massa['TEXTO_CARTAO_CHECAR']}"
		if (not $massa['TEXTO_CARTAO_CHECAR']) or ($massa['TEXTO_CARTAO_CHECAR'].strip == '')
			#2018Set19 - comment: para fluxo alternativo de FORCAR_CARTAO_DEBITO, massa deve manipular TEXTO_CARTAO_CHECAR para '', se desejado
			write_rsi_log :debug, "validar_texto_cartao, massa de TEXTO_CARTAO_CHECAR em branco, nao precisa validar"
			#faz nada
		else
			write_rsi_log :debug, "validar_texto_cartao, massa de TEXTO_CARTAO_CHECAR tem conteudo, precisa validar"
			if not has_botao_cartao_saiba_mais?
				falhar_definitivo "Botao Saiba Mais do cartao nao foi encontrado na tela" 
			end
			scroll_to botao_cartao_saiba_mais
			botao_cartao_saiba_mais.click
			texto_saiba_mais = nil
			executa_com_retry_stale_element {wait_for_div_cartao_saiba_mais 45}
			if not has_div_cartao_saiba_mais?
				falhar_definitivo "Elemento div_cartao_saiba_mais nao encontrado após clicar em elemento botao_cartao_saiba_mais"
			end
			write_rsi_log :debug, "validar_texto_cartao, clicou no botao e encontrou div_cartao_saiba_mais"
			texto_saiba_mais = div_cartao_saiba_mais.text
			write_rsi_log :debug, "validar_texto_cartao, clicou no botao e encontrou div_cartao_saiba_mais, texto_saiba_mais=#{texto_saiba_mais}"
			if not texto_saiba_mais.include? $massa['TEXTO_CARTAO_CHECAR']
				falhar_definitivo "Texto descritivo em Saiba Mais nao contem o texto desejado [#{$massa['TEXTO_CARTAO_CHECAR']}] - texto completo de Saiba Mais=[#{texto_saiba_mais}]"
			end
			write_rsi_log :debug, "validar_texto_cartao, clicou no botao e encontrou div_cartao_saiba_mais, OK, texto bateu"
			gera_screenshot 'Parte4SaibaMais'
			icon_close.click		
		end

		write_rsi_log :debug, "validar_texto_cartao - FIM"
		return
	end
		
	def fazer_click_ag(bt_ag)
		vezes_click=10
		sleep_click=0.5

		vezes_click.times{|c| #MAD TRY! VÀRIOS CLICKS NA SEQUENCIA! Como ficará em maq lenta?
			if has_trocaroferta_or_confirmagencia?
				break
			end
			sleep sleep_click
			write_rsi_log "bt_ag.click #{c+1} de #{vezes_click}, sleep_click=#{sleep_click}"
			scroll_to bt_ag
			bt_ag.click
		} 
	end

	def selecionar_agencia
		write_rsi_log "selecionar_agencia: P00'"

		bt_ag = nil
		proc_has_ag = nil
		descr_ag=nil

		if $massa['PACOTE'].downcase.include? 'select'
			descr_ag = 'SELECT'
			proc_wait_ag = lambda {wait_for_botao_agencia_select 15}
			proc_has_ag = lambda {has_botao_agencia_select?}
			proc_bt_ag = lambda {botao_agencia_select}
		else 
			descr_ag = 'comum'
			proc_wait_ag = lambda {wait_for_botao_agencia 15}
			proc_has_ag = lambda {has_botao_agencia?}
			proc_bt_ag = lambda {botao_agencia}
		end

		proc_wait_ag.call
		if not proc_has_ag.call 
			
			falhar "#{ERR_FRAGMENT_NENHUMA_AGENCIA} #{descr_ag} para pacote #{$massa['PACOTE']}' da massa de dados, CEP=#{$massa['CEP']}"
			#2018Mar22 - 08:59am - estava inserindo como falha definitiva, mas pode ser que backend/whatever de agencias estivesse com falha intermitente!
		end
		
		write_rsi_log "P'"

		scroll_to(proc_bt_ag.call)
		write_rsi_log "P'"
		write_rsi_log :debug, "selecionar_agencia: vai fazer primeiro click, bt_ag=#{bt_ag}"
		fazer_click_ag(proc_bt_ag.call)

		write_rsi_log :debug, "selecionar_agencia: fez primeiro click, esperando dialog"
		wait_for_trocaroferta_or_confirmagencia 15
		write_rsi_log :debug, "selecionar_agencia: esperou dialog pela 1a vez"
		if not has_trocaroferta_or_confirmagencia?
			write_rsi_log :debug, "selecionar_agencia: nao encontrado 1o dialog, vai fazer segundo clic, bt_ag=#{bt_ag}"
			fazer_click_ag(proc_bt_ag.call)

			write_rsi_log :debug, "selecionar_agencia: nao fez segundo click"
		end

		write_rsi_log "P'"
		write_rsi_log :debug, "selecionar_agencia: esperando dialog pela 2a vez, mais tempo, tendo ou nao clicado 2 vezes"
		wait_for_trocaroferta_or_confirmagencia 30 
		write_rsi_log :debug, "selecionar_agencia: esperou dialog pela 2a vez,"

		if has_botao_trocar_oferta?
			falhar_definitivo "selecionar_agencia: Botao de confirmacao de agencia sugeriu troca de pacote. Isso indica que nao foi escolhida corretamente agencia Select/Nao-Select"
		end
		write_rsi_log :debug, "selecionar_agencia: vai fazer scroll e click botao_confir_ag"
		scroll_to(botao_confir_ag)

		botao_confir_ag.click
		write_rsi_log :debug, "selecionar_agencia: fez scroll e click botao_confir_ag"
	end

	def selecionar_agencia_maximizado
		if not has_label_escolhaagencia? #nao tem agencia na tela
			if $massa['ESCOLHER_AGENIA'] == 'S'
				falhar_definitivo "Tela de escolher agencia indevidamente ausente para ESCOLHER_AGENCIA=#{$massa['ESCOLHER_AGENCIA']} e CEP=#{$massa['CEP']}"
			end
			return
		else #SIM, TEM agencia na tela
			if $massa['ESCOLHER_AGENIA'] == 'N'
				falhar_definitivo "Tela de escolher agencia indevidamente presente para ESCOLHER_AGENCIA=#{$massa['ESCOLHER_AGENCIA']} e CEP=#{$massa['CEP']}"
			end
		end

		write_rsi_log "selecionar_agencia_maximizado: P00'"
		if janelas_sempre_maximizadas? #2017Nov29
			selecionar_agencia #NEM precisa de executa_exclusivo! SPEED UP!
		else
			executa_exclusivo(
				maximizar_janela_antes:true , 
				#2018Jan19 - trazer_janela_para_topo_antes:true, 
				restore_janela_depois:true)	do
				#ARRISCADO!E SE REORGANIZANDO OUTRAS JUNTO? #x,y,largura,altura = get_rectangle_este_browser
				#ARRISCADO!E SE REORGANIZANDO OUTRAS JUNTO? #maximiza_este_browser true
				selecionar_agencia

				#ARRISCADO!E SE REORGANIZANDO OUTRAS JUNTO? #seta_rectangle_este_browser x,y,largura,altura
			end
		end

		
		
		#gera_screenshot "Parte4SelecionaAgencia"
		click_em_botao_continuar "Parte4SelecionaAgencia"
	end

	def DEPRECATED_aceitar_ou_rejeitar_limite
	end


	def confirmar_contratacao
		write_rsi_log :debug, "confirmar_contratacao - P00"
		
		executa_com_retry_stale_element {wait_for_contratacao_ou_errosconhecidos 75}
		write_rsi_log :debug, "confirmar_contratacao - P01"

		if has_contratacao? 
			write_rsi_log :debug, "confirmar_contratacao - P02"

			

			#gera_screenshot "Parte4Confirmar"

			#click_em_botao_continuar "Parte4Confirmar"
			#write_rsi_log :debug, "confirmar_contratacao - P03"
			#2018AGO06 Código fundido ao passo 5 - Código de confirmação de contratação e termos
			return
		end

		if has_desculpe_estamos_fazendo_ajustes?
			falhar "confirmar_contratacao: #{get_msgerr_desculpe_fazendo_ajustes}"
		end

		falhar "confirmar_contratacao:Elemento contracacao nao estah presente na tela"
		
	end

	def rejeitar_bonus_celular
		write_rsi_log :debug, "rejeitar_bonus_celular - P00"
		executa_com_retry_stale_element {wait_for_bonuscelular_ou_contratacao_ou_errosconhecidos 75}
		write_rsi_log :debug, "rejeitar_bonus_celular - P01"

		if has_contratacao? or has_desculpe_estamos_fazendo_ajustes? 
			write_rsi_log :debug, "rejeitar_bonus_celular - P02"
			return
		end
		
		write_rsi_log :debug, "rejeitar_bonus_celular - P03, ao chegar aqui, certamente estamos na tela de rejeitar bonus de celular"

		if $massa['PACOTE'].downcase.include?('select') or $massa['PACOTE'].downcase.include?('van gogh') or $massa['PACOTE'].downcase.include?('essenciais')
			
			#2018Mar04 - definicao de QA William Goulart durante reuniao , aproximadamente dia 2018Fev27
			falhar_definitivo "rejeitar_bonus_celular: pacote da massa #{$massa['PACOTE']} apresentou incorretamente a tela de bonus de celular, que nao deve ser apresentada pra pacotes [*Van Gogh*, *Select*, Servicos Essenciais]"
		end 
		
		# ao chegar aqui, sabemos que tem title de bônus de celular
		wait_for_checkbox_bonus 30 #2018Set19 - espera pelo campo do checkbox, q pode demorar a aparecer!
		write_rsi_log :debug, "rejeitar_bonus_celular - P04"
		if not has_checkbox_bonus?
			falhar_definitivo "rejeitar_bonus_celular: nao achado elemento checkbox_bonus mesmo havendo texto de bônus de celular"
		end
		write_rsi_log :debug, "rejeitar_bonus_celular - P05"

	
		if has_campo_operadora? #2018Ago22 - checkbox de bonus mudou default de SIM para NAO. Mas checkbox nao retorna diferença entre ligado e desligado. Entao, pra saber como "rejeitar" bonus, apenas checo se pagina tem id=carrier (operadora). Se tiver, preciso clicar (cjeckbox deve erstar selecionado). Se nao iver, nao preciso. 
			write_rsi_log "checkbox_bonus.path=#{checkbox_bonus.path}"
			scroll_to checkbox_bonus
			write_rsi_log :debug, "rejeitar_bonus_celular - P05.5"
			checkbox_bonus.click #desmarca, por default, vem marcado
			write_rsi_log :debug, "rejeitar_bonus_celular - P06"
		end
		
		

		#gera_screenshot "Parte4BonusCelular"

		click_em_botao_continuar "Parte4BonusCelular"
	end

	def processa()
		remove_nonascii_exception {run_processa()}
	end

	def run_processa()
		write_rsi_log :info, "Iniciando - Quarta Parte"
		
		espera_pagina_carregada
		gera_screenshot "Parte4paginaCarregada" #2018Set19

		selecionar_agencia_maximizado

		##DEPRECATED_aceitar_ou_rejeitar_limite #2018Jun19, removidao finalmente, codigo morto de limite, q foi pra outro lugar nao mapeado (e nao há mais valor de limite em nenhum lugar da app)
		
		validar_tipo_credito
		
		rejeitar_bonus_celular

		confirmar_contratacao	
	end
	
end


