require 'faker'

class PrimeiraParte < SitePrism::Page


#Digita CPF
element :campo_cpf, 		:xpath, "//input[@formcontrolname='cpf']"

#Sobre Você
element :campo_apelido,		:xpath, "//input[@formcontrolname='nickname']"
element :campo_email,		:xpath, "//input[@formcontrolname='email']"
element :campo_cep,			:xpath, "//input[@formcontrolname='cep']"
element :campo_ocupacao,	:xpath, "//select[@formcontrolname='selectOccupation']"
element :campo_celular,		:xpath, "//input[@formcontrolname='cellPhone']"
element :botao_universitario_sim,	:xpath, webdesktop_xpath_radiobutton_wrapper("Você é universitário?", "Sim")
element :botao_universitario_nao,	:xpath, webdesktop_xpath_radiobutton_wrapper("Você é universitário?", "Não")
element :nao_possuo_renda,	:xpath, "//span[text()='Não possuo renda']"
element :campo_renda,		:xpath, "//input[@formcontrolname='income']"

#Seus Dados

XPATH_CONTAINS_CONTEUMPOUCO=str_to_xpath_contains("Conte um pouco")
XPATH_CONTAINS_DADOS_RECUPERAMOS=str_to_xpath_contains("recuperamos seus dados")
XPATH_CONTAINS_CPF_INVALIDO=str_to_xpath_contains("número CPF inválido")
XPATH_CONTAINS_CPF_OBRIGATORIO=str_to_xpath_contains("campo obrigatório")
XPATH_FORMCONTROLNAME_CODIGO="(@formcontrolname='token')"

element :label_conteumpouco,	:xpath,	"//span[text()[#{XPATH_CONTAINS_CONTEUMPOUCO}]]"
element :label_conteumpouco_ou_dadosrecuperamos , :xpath, "//span[text()[#{XPATH_CONTAINS_DADOS_RECUPERAMOS} or #{XPATH_CONTAINS_CONTEUMPOUCO}]]"
element :cpfobrigatorio_ou_cpfinvalido_ou_label_conteumpouco_ou_dadosrecuperamos, :xpath, "//*[text()[#{XPATH_CONTAINS_DADOS_RECUPERAMOS} or #{XPATH_CONTAINS_CONTEUMPOUCO} or #{XPATH_CONTAINS_CPF_OBRIGATORIO} or #{XPATH_CONTAINS_CPF_INVALIDO}]]" #2018Ago10 - cpf invalido
element :cpfinvalido, :xpath, "//*[text()[#{XPATH_CONTAINS_CPF_INVALIDO}]]" #2018Ago10 - cpf invalido
element :cpfobrigatorio, :xpath, "//*[text()[#{XPATH_CONTAINS_CPF_OBRIGATORIO}]]" #2018Ago10 - cpf invalido
element :label_dados_recuperamos , :xpath, "//span[text()[#{XPATH_CONTAINS_DADOS_RECUPERAMOS}]]"

#Codigo Token
element :campo_codigo,		:xpath, "//input[#{XPATH_FORMCONTROLNAME_CODIGO}]" 
element :campo_codigo_ou_ajustes, :xpath, "//*[#{XPATH_FORMCONTROLNAME_CODIGO} or #{xpath_contains_fazendo_ajustes}]" #2018Set6, acelera detecao de erros depois de confirmar dados basicos
element :ajustes, :xpath, "//span[#{xpath_contains_fazendo_ajustes}]"

#Campo Email Tela Confirmação
element :campo_email_confirmacao, :xpath, "//domain-list//input[@class='ng-untouched ng-pristine ng-valid']"

#------------------------------------------------------------------------------------------------------------------------
	
	def processa()
		remove_nonascii_exception {run_processa}
	end
	def run_processa()
		
		gera_screenshot "Parte1"
		click_em_botao_continuar "Parte1"

		digitarCpf

		sobreVoce
	end

	def digitarCpf()
		executa_com_retry_stale_element {wait_for_campo_cpf 75} #2018Set5, antes, tentava digitar direto. Agora, espera e confere.
		if not has_campo_cpf?
			falhar "Campo de digitacao do CPF nao encontrado"
		end

		write_rsi_log :info, "Iniciando run_digitarCpf - Passo Digitar CPF"
		scroll_to campo_cpf

		max_tentativas_cpf = 30 #2018Out8 - 
		cpfs_tentados = []
		tentativas_cpf = 1
		orig_massa_cpf = $massa['CPF']
		while true
			#2018Ago10 - LOOP para tentar algumas vezes obter cpf valido da massa, workaround a geracao incorreta (comum em cpfs com inicio ZERO/'0') em cpf_utils.rb
			obter_cpf_pra_massa() #2018Ago01 - nao existe mais reserva de cpf, queima direto
			if $massa['CPF'] == nil
				falhar_definitivo "CPF - nao consegui obter cpf de arquivo #{get_xls_cpfs_risco} ."
			end

			cpfs_tentados << $massa['CPF']
			escreve_texto campo_cpf, $massa['CPF']		
			click_em_botao_continuar "Parte1CPF#{tentativas_cpf}"

			ret_espera = esperar_tela_depois_de_digitacao_do_cpf #0=OK, -2=nao preenchido, -1=inválido 
			if ret_espera == 0 #retorna NEGATIVO se cpf inválido/obrigatorio
				break
			elsif ret_espera == -3
				write_rsi_log :error, "CPF ja usado antes, talve retry, cpf original da massa=#{orig_massa_cpf}, cpf utilizado=#{$massa['CPF']}"
			elsif ret_espera == -1
				write_rsi_log :error, "CPF invalido, talvez retry, cpf original da massa=#{orig_massa_cpf}, cpf utilizado=#{$massa['CPF']}"
			elsif ret_espera == -2
				falhar "CPF nao preenchido, cpf original da massa=#{orig_massa_cpf}, cpf utilizado=#{$massa['CPF']}"
			elsif orig_massa_cpf != get_cpf_obterorisco
				falhar "CPF invalido, cpf utilizado=#{$massa['CPF']}"
			elsif tentativas_cpf == max_tentativas_cpf
				falhar_definitivo "CPF invalido, mesmo depois de #{max_tentativas_cpf} tentativas, cpfs utilizados=#{cpfs_tentados}"
			end
			tentativas_cpf = tentativas_cpf + 1
			$massa['CPF'] = get_cpf_obterorisco

			if ret_espera == -3 #ja utilizado, precisa visitar cpf
				visit 'https://abrasuacontadesk.paas.santanderbr.pre.corp/#/cpf'
			end
		end

		write_rsi_log :debug, "digitarCpf concluída ok, $massa['CPF']=#{$massa['CPF']}, tentativas_cpf=#{tentativas_cpf}, cpfs_tentados=#{cpfs_tentados}, max_tentativas_cpf=#{max_tentativas_cpf}"
		return
	end

	def debugUmCpfExiste(lc)
		visit 'https://abrasuacontadesk.paas.santanderbr.pre.corp/#/cpf'
		$massa['CPF']=lc['CPF']
		digitarCpf() #deixa queimar a massa, deve haver backup prévio
	end


	def debugarCpfsExistem
		cpfsJaExistentes = [] #hash array as linhas de cpfs_risco
		cpfsNaoExistentes = [] #hash array das linhas de cpfs_risco
		todosCpfsDaMassa = ler_xls_com_id(get_xls_cpfs_risco, nil, nil, -1)
		todosCpfsNaoUtilizados = todosCpfsDaMassa.select{|lc| lc['PROCESSADO'].to_i == 0}
		write_rsi_log :debug, "debugarCpfsExistem, todosCpfsNaoUtilizados=#{todosCpfsNaoUtilizados}"
		todosCpfsNaoUtilizados.each do |lc|
			exc = nil
			begin
				debugUmCpfExiste lc
			rescue Exception => e
				exc = e
			end
			if exc
				write_rsi_log :debug, "debugarCpfsExistem, ER CPF LC=#{lc}, e=#{e}"
			else	
				write_rsi_log :debug, "debugarCpfsExistem, OK CPF LC=#{lc}"
			end
		end
		return
	end

	def sobreVoce
		write_rsi_log :info, "Iniciando run_sobreVoce - Passo Sobre Voce"

		nome_completo = Faker::Name.name
		scroll_to campo_apelido
		escreve_texto campo_apelido, nome_completo

		scroll_to campo_email
		escreve_texto campo_email, get_massa() ['EMAIL']
	
		scroll_to campo_cep
		escreve_texto campo_cep, get_massa() ['CEP']
		
		scroll_to(campo_celular)
		escreve_texto campo_celular, get_massa() ['CELULAR']

		#2018Jun14, restaurada simplificacao de ocupacao na massa, TrabalhoU+niv_S+N #2018Mai21 - removido da app o input OCUPACOES, temos apenas agora 'UNIVERSITARION S/N'
		#2018Jun28 - voltou a haver massa UNIVERSITARIOn, 'Sou universitario' x 'Fora de universidade', e nao ha mais OCUPACAO #2018Jun21 - arrumado DOWNCASE de universitario #2018Jun14 - assim como TRABALHO, massa UNIVERSITARIO pode sobrepor-se a definicao de OCUPACAO
		if not $massa['UNIVERSITARIO'].downcase.include? 'fora' 
			scroll_to(botao_universitario_sim)
			botao_universitario_sim.click
		else
			scroll_to(botao_universitario_nao)
			botao_universitario_nao.click
		end
		
		gera_screenshot "Parte1SobreVoce"

		if (get_massa()['RENDA'] || '0').to_i > 0 #2017Dez28, para Robo Kaio
			scroll_to campo_renda
			escreve_texto campo_renda, ((get_massa() ['RENDA']).to_i*100).to_s #VEZES 100 PARA DUAS CASAS DECIMAIS.
		else
			#2017Dez28, para Robo Kaio
			scroll_to(nao_possuo_renda)
			nao_possuo_renda.click
		end

		
		click_em_botao_continuar "Parte1SobreVoce"
		#2018Mai21 - removido campo/tela email 
		write_rsi_log :info, "Passo Confirme seus dados CA"
		executa_com_retry_stale_element {wait_for_campo_codigo_ou_ajustes 3*20} #2018Abr23 - evitando erro em demora antes de elemento
		if has_ajustes?
			falhar "Erro depois de continuar Parte1SobreVoce, #{get_msgerr_desculpe_fazendo_ajustes}"
		end
		if not has_campo_codigo?
			falhar "Elemento campo_codigo nao encontrado"
		end

		scroll_to campo_codigo
		escreve_texto campo_codigo, get_massa() ['TOKEN']

		

		#2018Ago01, nao existe mais reserva de cpf, queima direto
		gera_screenshot "Parte1Token"
		click_em_botao_continuar "Parte1Token"
	end
	
	
	def esperar_tela_depois_de_digitacao_do_cpf
		write_rsi_log :debug, "esperar_tela_depois_de_digitacao_do_cpf"
		executa_com_retry_stale_element {wait_for_cpfobrigatorio_ou_cpfinvalido_ou_label_conteumpouco_ou_dadosrecuperamos 3*20}
		if has_cpfobrigatorio?
			#2018Agp11 - checagem de cpf invalido
			return -2
		end
		if has_cpfinvalido?
			#2018Agp11 - checagem de cpf invalido
			return -1
		end

		if has_label_dados_recuperamos?
			write_rsi_log :debug, "Regra 2: CPF já usado - isso eh um erro, enquanto não tivermos testes de lidar com retomada de abertura!"
			#2018Ago01 - nao existe mais reserva de cpf, queima direto
			#2018Out8 - CPF ja utilizado deixar de falhar: agora, desprezamos esse CPF e vamos para o próximo!
			return -3
		end

		if not has_label_conteumpouco_ou_dadosrecuperamos?
			fail "esperar_tela_depois_de_digitacao_do_cpf: #{get_msgerr_cpf_recuperado_ou_maisdados}"
		end

		if has_label_conteumpouco?
			write_rsi_log :info, "Regra 1: CPF novo"
		end

		return 0
	end

end