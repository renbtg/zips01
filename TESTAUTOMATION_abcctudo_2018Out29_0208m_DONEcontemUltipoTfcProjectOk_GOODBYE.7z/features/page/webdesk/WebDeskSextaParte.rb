class SextaParte < SitePrism::Page
#------------------------------------------------------------------------------------------------------------------------------
NUM_FOTO_DOC_F = 1
NUM_FOTO_DOC_V = 2

element :botao_continuar,	:id,	'ctaFullButton'

NUM_BOTAO_OU_UNIV_1_F = 3
NUM_BOTAO_OU_UNIV_1_V = 4

NUM_BOTAO_OU_UNIV_2_F = 5
NUM_BOTAO_OU_UNIV_2_V = 6

XPATH_CONTAINS_IMPOSSIVEL_DAR_CONTINUIDADE = str_to_xpath_contains('dar continuidade ao seu pedido de abertura')
#XPATH_CONTAINS_ENVIARDOCS=str_to_xpath_contains('Agora você pode enviar seus documentos por aqui mesmo')
XPATH_CONTAINS_ENVIARDOCS=str_to_xpath_contains('enviar documentos')

element :impossivel_dar_continuidade, :xpath, "//*[text()[#{XPATH_CONTAINS_IMPOSSIVEL_DAR_CONTINUIDADE}]]"
element :label_enviardocs     , :xpath, "//span[text()[#{XPATH_CONTAINS_ENVIARDOCS}]]"
element :desculpe_estamos_fazendo_ajustes, :xpath, "//span[text()[#{xpath_contains_fazendo_ajustes}]]"
element :chegou_enviardocs_ou_erros_conhecidos, :xpath, "//*[text()[#{XPATH_CONTAINS_ENVIARDOCS} or #{XPATH_CONTAINS_IMPOSSIVEL_DAR_CONTINUIDADE} or #{xpath_contains_fazendo_ajustes}]]"


element :elto_finalizar_enviar    , :xpath,  "//*[text()[ contains(.,'Finalizar e enviar')]]" #2017Set28 - UNTESTED!

#------------------------------------------------------------------------------------------------------------------------------

	def espera_pagina_carregada()
		executa_com_retry_stale_element {wait_for_chegou_enviardocs_ou_erros_conhecidos 3*30} #podemos definir tempo maximo aqui
		if has_desculpe_estamos_fazendo_ajustes?
			falhar "espera_pagina_carregada: #{get_msgerr_desculpe_fazendo_ajustes}"
		end

		if get_massa()['SINAL DE VERACIDADE'] == 'verde' 
			if has_label_enviardocs?
				return
			end

			if has_impossivel_dar_continuidade? 
				falhar_definitivo "espera_pagina_carregada: sinal de veracidade verde, mas nao foi possivel dar continuidade a abertura de conta"
			end
			
			falhar "espera_pagina_carregada: Elemento label_enviardocs nao estah presente na tela, nem tampouco erros conhecidos"
		else #vermelho
			if has_impossivel_dar_continuidade? 
				return #OK
			end
			
			falhar_definitivo "espera_pagina_carregada: sinal de veracidade vermelho, mas nao encontrou mensagem de que nao foi possivel dar continuidade a abertura de conta"
		end	
	end

	def processa()
		remove_nonascii_exception {run_processa()}
	end

	def run_processa()
		write_rsi_log :info, "Iniciando processa - Parte 6"
		
		espera_pagina_carregada
		gera_screenshot "Parte6CarregarImagens-paginaCarregada" #2018Set19 - mesmo se VERACIDADE vermelho, gera screenshot
		
		if get_massa()['SINAL DE VERACIDADE'] == 'vermelho'
			return #2017Set01 - PARA AQUI, no caso de sinal de veracidade vermelho.
		end

		carrega_img_e_salva NUM_FOTO_DOC_F #2018Abr22 - 'rg1_imagem_frente.jpg', E... renomear copiar imagem_upload_new.jpg sobre imagen_upload.jpg, se Cortana INDEVIDAMENTE ATIVO. USAR IMAGENS Q WILL MANDOU EM EMAIL!
		gera_screenshot "Parte6CarregarImagens"
		carrega_img_e_salva NUM_FOTO_DOC_V #2018Abr22 - 'rg1_imagem_verso.jpg', E... renomear copiar imagem_upload_new.jpg sobre imagen_upload.jpg, se Cortana INDEVIDAMENTE ATIVO. USAR IMAGENS Q WILL MANDOU EM EMAIL!

		
		if find_all(:xpath, get_xpath_imgupload, visible:false).length >= NUM_BOTAO_OU_UNIV_1_F
			#2017Jan22, webdesk, achava poucos botoes, entao, adicionei visible:false
			gera_screenshot "Parte6CarregarImagens"
			carrega_img_e_salva NUM_BOTAO_OU_UNIV_1_F
			gera_screenshot "Parte6CarregarImagens"
			carrega_img_e_salva NUM_BOTAO_OU_UNIV_1_V
		end
		
		if find_all(:xpath, get_xpath_imgupload, visible:false).length >= NUM_BOTAO_OU_UNIV_2_F
			#2017Jan22, webdesk, achava poucos botoes, entao, adicionei visible:false
			gera_screenshot "Parte6CarregarImagens"
			carrega_img_e_salva NUM_BOTAO_OU_UNIV_2_F
			gera_screenshot "Parte6CarregarImagens"
			carrega_img_e_salva NUM_BOTAO_OU_UNIV_2_V
		end

		write_rsi_log :debug, "SextaParte - depois de Finalizar e enviar"
		
		#gera_screenshot "Parte6Confirmar"
		click_em_botao_continuar "Parte6Confirmar"

		write_rsi_log :debug, "SextaParte - depois de Finalizar e enviar"
	end

end
