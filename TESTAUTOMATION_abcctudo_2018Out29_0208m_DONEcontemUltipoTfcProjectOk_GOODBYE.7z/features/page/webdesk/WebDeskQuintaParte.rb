class QuintaParte < SitePrism::Page
#------------------------------------------------------------------------------------------------------------------------------
element :check_politica,    :xpath, "(//div[contains(@class,'checkbox')])[1]"
element :check_condicoes,   :xpath, "(//div[contains(@class,'checkbox')])[2]"
element :check_autorizo,    :xpath, "(//div[contains(@class,'checkbox')])[3]"
element :check_ciencia,     :xpath, "(//div[contains(@class,'checkbox')])[4]"

XPATH_CONTAINS_CONTRATACAO=str_to_xpath_contains("confirme contratação")
element :label_contratacao,	:xpath,	"//span[text()[#{XPATH_CONTAINS_CONTRATACAO}]]"


element :cheguei_no_contratacao_ou_erros_conhecidos, :xpath, "//*[text()[#{XPATH_CONTAINS_CONTRATACAO} or #{xpath_contains_fazendo_ajustes}]]"
element :desculpe_estamos_fazendo_ajustes, :xpath, "//span[text()[#{xpath_contains_fazendo_ajustes}]]"


element :elt_li_e_concordo    , :xpath,  "//*[text()[ contains(.,'Li e concordo')]]" #Li, maiusculas=checkbox

element :servicos, :xpath, "//div/*/label[.='Serviços']/ancestor::div[1]" #2018Set19 - para conferir texto do cartao

#------------------------------------------------------------------------------------------------------------------------------

	def espera_pagina_carregada
		executa_com_retry_stale_element {wait_for_cheguei_no_contratacao_ou_erros_conhecidos 3*45}
		if has_label_contratacao?
			return #ok, adiós
		end

		if has_desculpe_estamos_fazendo_ajustes?
			falhar "#{get_msgerr_desculpe_fazendo_ajustes}"
		end

		falhar "Elemento label_contratacao nao estah presente na tela"
	end

	def processa()
		remove_nonascii_exception {run_processa()}
	end

	def concordar_com_item(item)
		
		scroll_to(item)
		item.click

		wait_for_elt_li_e_concordo
		scroll_to(elt_li_e_concordo)

		gera_screenshot "ConcordaItem"

		elt_li_e_concordo.click
	end

	def valida_texto_cartao
		#created 2018Set19
		write_rsi_log :debug, "valida_texto_cartao - INI, $massa['TEXTO_CARTAO_CHECAR']=#{$massa['TEXTO_CARTAO_CHECAR']}"
		if (not $massa['TEXTO_CARTAO_CHECAR']) or ($massa['TEXTO_CARTAO_CHECAR'].strip == '')
			#2018Set19 - comment: para fluxo alternativo de FORCAR_CARTAO_DEBITO, massa deve manipular TEXTO_CARTAO_CHECAR para '', se desejado
			write_rsi_log :debug, "valida_texto_cartao, massa de TEXTO_CARTAO_CHECAR em branco, nao precisa validar"
			#faz nada
		else
			write_rsi_log :debug, "valida_texto_cartao, massa de TEXTO_CARTAO_CHECAR tem conteudo, precisa validar"
			scroll_to servicos
			texto_servicos = servicos.text
			write_rsi_log :debug, "valida_texto_cartao, texto_servicos=#{texto_servicos}"
			if not texto_servicos.include? $massa['TEXTO_CARTAO_CHECAR']
				falhar_definitivo "Texto de Servicos nao contem o texto desejado [#{$massa['TEXTO_CARTAO_CHECAR']}] - texto completo de Servicos=[#{texto_servicos}]"
			end
			write_rsi_log :debug, "valida_texto_cartao, OK, texto bateu com servicos"
			gera_screenshot 'Parte5textoServicos'
		end

		write_rsi_log :debug, "valida_texto_cartao - FIM"
		return
	end

	def run_processa()
		write_rsi_log :info, "Iniciando processa Parte 5"
		espera_pagina_carregada
		gera_screenshot "Parte5Resumo - carregou pagina"

		valida_texto_cartao #2018Set19, validacao de texto de cartao

		concordar_com_item check_politica
		gera_screenshot "Parte5Resumo - concordou politica"
		concordar_com_item check_condicoes
		gera_screenshot "Parte5Resumo - concordou condicoes"
		concordar_com_item check_autorizo
		gera_screenshot "Parte5Resumo - concordou autorizo"
		scroll_to(check_ciencia); check_ciencia.click #declarar "ter ciencia" nao abre janela de "li e concordo"
		gera_screenshot "Parte5Resumo - clicou ciencia"
		
		#gera_screenshot "Parte5Confirmar"
		click_em_botao_continuar "Parte5Confirmar"
	end
	
end
