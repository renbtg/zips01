require 'faker'

class TerceiraParte < SitePrism::Page


element :confirm_dados_pessoais, :xpath, "//div[contains(@class,'row')]//div[contains(.,'Dados pessoais')]"


#Sobre você
element :label_titulo,		:css,	"label",:text => "Boa escolha! Agora vamos completar os seus dados" 
element :campo_nome,		:xpath, "//input[@formcontrolname='fullname']"
element :campo_data,       	:xpath, "//input[@formcontrolname='birthdate']"

#element :campo_uf,         	:xpath, "(//states-list)[1]//*//select", visible:false #antes de 2018Julho12 
element :campo_uf , :id, "state", visible:false #2018AGO03 - rboker = mudança de xpath para id por mudança na interface. Elemento mudou de select para input, mas recebeu um ID # 2018Julho12# 2018Julho12 

#element :campo_cidade,     	:xpath,  "//cities-list//*//input"  #antes de 2018Julho12
element :campo_cidade , :xpath, "//input[@formcontrolname='city']" # 2018Julho12 - varios campos de varios page object tiveram  modificacoes pequenas, como tirar INPUT do nome do controle, entre outras

element :campo_nome_mae,   	:xpath, "//input[@formcontrolname='mother']"


element :botao_masculino,  	:xpath, webdesktop_xpath_radiobutton_wrapper('Gênero', 'Masculino')

element :campo_estado_civil, :id, 'maritalStatus', visible:false



element :campo_nome_conjuge,:xpath, "//input[@formcontrolname='marital']"



element :botao_patrimonio_sim, :xpath, webdesktop_xpath_radiobutton_wrapper('Você tem patrimônio', 'Sim')
element :botao_patrimonio_nao, :xpath, webdesktop_xpath_radiobutton_wrapper('Você tem patrimônio', 'Não')

element :campo_patrimonio, 	:xpath, "//input[@formcontrolname='patrimonyValue']"

#Documento
element :botao_rg,  	:xpath, webdesktop_xpath_radiobutton_wrapper('Tipo de documento', 'RG') #2017Nov17 01:08am, Identidade (I inicial maiusculo), agora. Antes, minusculo.
element :campo_num_doc,   	:xpath, "//input[@formcontrolname='rgNumber']"
element :campo_rg_emissor, 	:xpath, "//input[@formcontrolname='rgIssuingBody']"
element :campo_data_emis,  	:xpath, "//input[@formcontrolname='rgIssuingDate']"
element :campo_rg_uf , :id, 'rgIssuingState', visible:false


#Complementos
element :botao_cidadania, 	:xpath, webdesktop_xpath_radiobutton_tooltip('Você possui outra cidadania?','Não')
element :botao_dom_fiscal, 	:xpath, webdesktop_xpath_radiobutton_tooltip('Você possui outro domicílio fiscal?','Não')

element :campo_profissao , :id, 'profession', visible:false
element :campo_empresa,  	:xpath, "//input[@formcontrolname='companyName']"
element :naotrabalho, :xpath, "//span[text()='Não estou trabalhando no momento']"
element :campo_escolaridade , :id, 'schooling', visible:false


element :campo_inst_ensino,:xpath, "//input[@formcontrolname='institution']"
#campo_inst_ensino
element :campo_curso , :id, 'course', visible:false #2018Ago29 - course nã havia sido adaptado para SP4, feito
element :campo_inicio,       	:xpath, "//input[@formcontrolname='courseStartDate']"
element :campo_termino,       	:xpath, "//input[@formcontrolname='courseEndDate']"

XPATH_CONTAINS_SUPERDIGITAL = str_to_xpath_contains('Bem-vindo à Superdigital')
XPATH_CONTAINS_VAMOSCOMPLETAR = str_to_xpath_contains('vamos completar os seus dados')
XPATH_CONTAINS_PREENCHA_ENDERECO = str_to_xpath_contains('preencha o endereço de onde você mora')
#OBS: superdigital, TAG=P. VamosCompletar: TAG=SPAN... por isso, o "//*" generico.
element :label_vamoscompletar_ou_superdigital , :xpath  ,  "//*[text()[#{XPATH_CONTAINS_VAMOSCOMPLETAR} or #{XPATH_CONTAINS_SUPERDIGITAL}]]"
element :label_vamoscompletar                 , :xpath  ,  "//span[text()[#{XPATH_CONTAINS_VAMOSCOMPLETAR}]]"
element :label_superdigital                   , :xpath  ,  "//p[text()[#{XPATH_CONTAINS_SUPERDIGITAL}]]"

element :cheguei_no_vamoscompletar_superdigital_ou_erros_conhecidos, :xpath, "//*[text()[#{XPATH_CONTAINS_VAMOSCOMPLETAR} or #{XPATH_CONTAINS_SUPERDIGITAL} or #{xpath_contains_fazendo_ajustes}]]"
element :desculpe_estamos_fazendo_ajustes, :xpath, "//span[text()[#{xpath_contains_fazendo_ajustes}]]"

element :chegou_preenchaendereco_ou_erros_conhecidos, :xpath, "//*[text()[#{XPATH_CONTAINS_PREENCHA_ENDERECO} or #{xpath_contains_fazendo_ajustes}]]"
element :label_preenchaendereco, :xpath, "//*[text()[#{XPATH_CONTAINS_PREENCHA_ENDERECO}]]"

element :campo_propria,    :xpath, webdesktop_xpath_radiobutton_wrapper('Onde você mora?', 'Residência Própria')
element :campo_sem_num,    :xpath, "//span[contains(text(),'sem número')]"

#XPATH_CONTAINS_FOTOSSUAS = str_to_xpath_contains('foto sua segurando') #2018Abr04 - 
XPATH_CONTAINS_FOTOSSUAS = str_to_xpath_contains('foto documento') #2018Out26 
element :chegou_fotossuas_ou_erros_conhecidos, :xpath, "//*[text()[#{XPATH_CONTAINS_FOTOSSUAS} or #{xpath_contains_fazendo_ajustes}]]"
element :label_fotossuas , :xpath  ,  "//span[text()[#{XPATH_CONTAINS_FOTOSSUAS}]]"

element :alguma_imagem, ".upload-btn", visible:false #2018Julho31 - mudado para '.upload-bbtn' css  #2018Mar25 - added visible:false, para telas nao-maximizadas
element :label_como_enviar_foto, :xpath, "//*[contains(text(),'Como enviar sua foto')]"
element :botao_continuar, 'cta-full-button'


XPATH_CONTAINS_CONFIRMAR_ESCOLHAS = str_to_xpath_contains('confirme suas informações e o produto que escolheu')
element :label_confirmar_escolhas, :xpath, "//span[text()[#{XPATH_CONTAINS_CONFIRMAR_ESCOLHAS}]]"


element :campo_endereco, :xpath, "//input[@formcontrolname='address']"
element :campo_bairro, :xpath, "//input[@formcontrolname='neighborhood']"


#------------------------------------------------------------------------------------------------------
	
	def espera_pagina_carregada()
		executa_com_retry_stale_element {wait_for_cheguei_no_vamoscompletar_superdigital_ou_erros_conhecidos 3*45} #podemos definir tempo maximo aqui
		if has_label_vamoscompletar_ou_superdigital?
			return #ok, adiós
		end

		if has_desculpe_estamos_fazendo_ajustes?
			falhar "espera_pagina_carregada - #{get_msgerr_desculpe_fazendo_ajustes}"
		end

		falhar "espera_pagina_carregada - Elemento label_vamoscompletar_ou_superdigital nao estah presente na tela"
	end

	def espera_pagina_endereco()
		executa_com_retry_stale_element {wait_for_chegou_preenchaendereco_ou_erros_conhecidos 3*45} #podemos definir tempo maximo aqui
		if has_label_preenchaendereco?
			return #ok, adiós
		end

		if has_desculpe_estamos_fazendo_ajustes?
			falhar "espera_pagina_endereco - #{get_msgerr_desculpe_fazendo_ajustes}"
		end

		falhar "espera_pagina_endereco - Elemento label_preenchaendereco nao estah presente na tela"
	end

	def espera_pagina_selfies()
		executa_com_retry_stale_element {wait_for_chegou_fotossuas_ou_erros_conhecidos 3*45} #podemos definir tempo maximo aqui
		if has_label_fotossuas?
			executa_com_retry_stale_element {wait_for_alguma_imagem 3*15}
			if has_alguma_imagem?
				###########################################################sleep 5 #ESTRANHO: mesmo depois de ter elemento de imagem, ainda tem que ainda esperar!
				return
			else
				falhar "espera_pagina_selfies: nao encontradas imagens depois de pagina de selfies ativa"
			end
		end


		if has_desculpe_estamos_fazendo_ajustes?
			falhar "espera_pagina_selfies - #{get_msgerr_desculpe_fazendo_ajustes}"
		end

		falhar "espera_pagina_selfies - Elemento label_fotossuas nao estah presente na tela"
	end

	def espera_pagina_confirmar_escolhas
		executa_com_retry_stale_element {wait_for_confirm_dados_pessoais 3*15} # ?? rbtg 2017Nov10 - DEVERIA ser ESPERA_PAG??
		
		if has_confirm_dados_pessoais?
			return
		end
		falhar "espera_pagina_confirmar_escolhas: Elementp confirm_dados_pessoais nao encontrado na tela"
	end

	def preencher_instituicao_ensino

		instituicao_ensino = (get_massa() ['INSTITUICAO_ENSINO'] || '').strip # vira blank string se fora da massa
		tem_campo_instituicao_ensino = has_campo_inst_ensino?
		write_rsi_log :debug, "instituicao_ensino na massa: #{instituicao_ensino}, tem_campo_instituicao_ensino=#{tem_campo_instituicao_ensino}"
		
		if tem_campo_instituicao_ensino and instituicao_ensino == '' 
			falhar_definitivo "Erro - existe instituicao_ensino na tela, mas nao exise na massa de dados"
		elsif instituicao_ensino != '' and not tem_campo_instituicao_ensino
			# TODO talvez - proteger MAIS contra incorerencia de massa. TALVEZ, a protecao contra incoerencia de massa faça mais mal que bem, levando a falha e exigindo geracao complexa de massa!
			#falhar "Erro - existe instituicao_ensino na massa de dados, mas nao exise na tela"
		end
		
		if tem_campo_instituicao_ensino
			# TODO talvez - proteger contra incorerencia de massa. TALVEZ, a protecao contra incoerencia de massa faça mais mal que bem!
			scroll_to campo_inst_ensino
			escreve_texto campo_inst_ensino, instituicao_ensino
			scroll_to(campo_curso)
			executa_exclusivo(trazer_janela_para_topo_antes: true) do #2018Set18 and 2018Set19 - evita que perda/retomada de foco afetem + sleep depois de click
				campo_curso.click
				sleep 3
				(campo_curso.find :xpath,"(//*[text()[contains(.,'ADMINISTRACAO')]])[1]").click #2018Ago29 - mudou (em Sp4, perto de 2018Ago03) de SELECT pra INPUT coom LIs dinamicas
			end
			
			scroll_to campo_inicio
			escreve_texto campo_inicio, get_massa() ['INICIO']
			scroll_to campo_termino
			escreve_texto campo_termino, get_massa() ['TERMINO']
		end

	end

	def preencher_campo_empresa
		empresa = (get_massa() ['EMPRESA'] || '').strip # vira blank string se fora da massa
		tem_campo_empresa = (has_campo_empresa? and campo_empresa.disabled? == false)
		write_rsi_log :debug, "empresa na massa: #{empresa}, tem_campo_empresa=#{tem_campo_empresa}"
		
		if tem_campo_empresa and empresa == '' 
			falhar_definitivo "Erro - existe empresa na tela, mas nao exise na massa de dados"
		elsif empresa != '' and not tem_campo_empresa
			write_rsi_log :debug, "Nao falhando em empresa != '' and not tem_campo_empresa, pois APENAS NaoTrabalho bloqueia preencher empresa"
			# TODO talvez - proteger MAIS contra incorerencia de massa. TALVEZ, a protecao contra incoerencia de massa faça mais mal que bem, levando a falha e exigindo geracao complexa de massa!
			#falhar "Erro - existe empresa na massa de dados, mas nao exise na tela"
		end
		
		if tem_campo_empresa
			scroll_to campo_empresa
			escreve_texto campo_empresa, empresa
		end
	end

	def processa()
		remove_nonascii_exception {run_processa()}
	end

	def run_processa()
		if has_label_superdigital?
			if $superdigital_outrosistema
				write_rsi_log :debug, "OK, direcionado pra Cadastro/sistema Super Digital"
				return
			else
				write_rsi_log :debug, "2018Mar9 - Superdigital não é mais aberta por outro sistema. Continuar com abertura." 
			end
		end

		write_rsi_log :info, "Iniciando - Terceira Parte"
		espera_pagina_carregada
		gera_screenshot "Parte3paginaCarregada" #2018Set19

		scroll_to campo_nome
		escreve_texto campo_nome, get_massa() ['NOME']
		scroll_to campo_data
		escreve_texto campo_data, get_massa() ['DATA_NASCIMENTO']
		
		obj = self
		scroll_to(obj.campo_uf);executa_exclusivo(trazer_janela_para_topo_antes: true) {obj.campo_uf.click; sleep 3; (obj.campo_uf.find :xpath,"//*[text()[contains(.,'São Paulo')]]").click}

		sleep 5 #dá um tempinho pra preencher lista de cidades???????? 2017Nov13 20:12
		scroll_to campo_cidade
		escreve_texto campo_cidade, 'SAO PAULO'
		

		scroll_to campo_nome_mae
		escreve_texto campo_nome_mae, get_massa() ['NOME_DA_MÃE']
		
		gera_screenshot "Parte3CompletaDados"

		scroll_to(botao_masculino)
		botao_masculino.click
		
		estado_civil = get_massa() ['ESTADO_CIVIL']
		if estado_civil == '1' #2018Jun27, antigo... de 2017/Agosto, deprecared
			estado_civil = 'Solteiro (a)' #2018Jun27, antigo... de 2017/Agosto, deprecared
		elsif estado_civil == '2' #2018Jun27, antigo... de 2017/Agosto, deprecared
			estado_civil = 'Casado (a)'  #2018Jun27, antigo... de 2017/Agosto, deprecared
		elsif estado_civil == '3'
			estado_civil = 'Viúvo (a)' 
		elsif estado_civil == '3'
			estado_civil = 'União estável'
		elsif estado_civil == '4'
			estado_civil = 'Divorciado (a)' 
		elsif estado_civil == '5'
			estado_civil = 'Separado (a)'
		end
		
		scroll_to(campo_estado_civil)
		#2018AGO03 rboker - alteração do tipo de objeto
		#(campo_estado_civil.find :xpath, "option[text()[contains(.,'#{estado_civil}')]]").click
		executa_exclusivo(trazer_janela_para_topo_antes: true) do #2018Set18 and 2018Set19 - evita que perda/retomada de foco afetem + sleep depois de click
			campo_estado_civil.click
			sleep 3
			(campo_estado_civil.find :xpath,"//*[text()[contains(.,'#{estado_civil}')]]").click #rbattaglia,2018Ago22 - orrigido 'Casado (a)' fixo (errado) para estado)civil da massa
		end
		if estado_civil.downcase.include? 'casado'
			scroll_to campo_nome_conjuge
			escreve_texto campo_nome_conjuge, get_massa() ['NOME_CONJUNGE']
		end

		valor_patrimonio=($massa['VALOR_PATRIMONIO']||'800000').to_i
		#2017Dez29 - para Robô Kaio - obter VALOR_PATRIMONIO de massa
		if valor_patrimonio == 0
			scroll_to(botao_patrimonio_nao)
			botao_patrimonio_nao.click
		else
			scroll_to(botao_patrimonio_sim)
			botao_patrimonio_sim.click
			scroll_to campo_patrimonio
			escreve_texto campo_patrimonio, (valor_patrimonio*100).to_s # vezes 100 por cause de zeros , centavos
		end

		gera_screenshot "Parte3CompletaDados"

		scroll_to(botao_rg)
		botao_rg.click
		scroll_to campo_num_doc
		escreve_texto campo_num_doc, get_massa() ['RG']
		scroll_to campo_rg_emissor
		escreve_texto campo_rg_emissor, get_massa() ['ORGÃO_EMISSOR']
		scroll_to campo_data_emis
		escreve_texto campo_data_emis, get_massa() ['DATA_DE_EMISSÃO']
		scroll_to campo_rg_uf
		executa_exclusivo(trazer_janela_para_topo_antes: true) do #2018Set18 and 2018Set19 - evita que perda/retomada de foco afetem + sleep depois de click
			campo_rg_uf.click #2018Ago03 - mudou de SELECT pra INPUT coom LIs dinamicas
			sleep 3
			(campo_rg_uf.find :xpath,"//*[text()[contains(.,'São Paulo')]]").click
		end		
		scroll_to botao_cidadania
		botao_cidadania.click
		scroll_to botao_dom_fiscal 
		botao_dom_fiscal.click
		
		gera_screenshot "Parte3CompletaDados"

		scroll_to(campo_profissao)
		str_profissao=$massa['PROFISSAO'] || 'Administrador'
		executa_exclusivo(trazer_janela_para_topo_antes: true) do #2018Set18 and 2018Set19 - evita que perda/retomada de foco afetem + sleep depois de click
			campo_profissao.click
			sleep 3
			(campo_profissao.find :xpath,"//*[text()[contains(.,'#{str_profissao}')]]").click
		end
		
		10.times {
			write_rsi_log "TODO - 2018Jun12 - será que simplificacao, TrabalhoSN e UnivSN ignorando aposentado? E... anyway, se for, deve atualizar GERADOR_MASSA pra nao deixar apenas o 'N' no nomefeature/arq, mas sim umdos 4... TrabalhoUniv, NaoTrabalhoUniv, TrabalhoNaoUniv, NaoTrabalhoNaoUniv !!! SIMPLIFICACAO, parece ser o que Kaio quer. E profissao pode ser sempre ADMINISTRADOR. NOVAS CHAVES DE $massa=PROFISSAO(varchar) E TRABALHO(S/N)"

#				@@@@@
#				TODO NOW 2018Jun12 - passar logo daqui, acho q já fiz o básico, e ir para P4, onde #à#s vezes aparece agencia(dependendo do CEP) e às vezes nao!
#
#				ALÈM DISSO, devo, depois de AG_INTERMITENTE ok, deve atacar o GeradorMassa pras 4 #opcoes de SimNaoTrabalhoUniv !!!

		}
		if not $massa['TRABALHO'].downcase.include? 'eu trabalho' #2018Jun28 - massa TRABALHO agora sempre existe, e nao ha mais OCUPACAO #2018Jun14 - assim como UNIVERSITARIO, massa TRABALHO pode sobrepor-se a definicao de OCUPACAO
			# DO NOTHING, default na tela já é SIM, TRABALHO
		else
			scroll_to(naotrabalho)
			naotrabalho.click
		end

		preencher_campo_empresa

		obj = self		
		scroll_to(obj.campo_escolaridade); executa_exclusivo(trazer_janela_para_topo_antes: true) {obj.campo_escolaridade.click; sleep 3; (obj.campo_escolaridade.find :xpath,"//*[text()[contains(.,'ENSINO MEDIO/TECNICO COMPLETO')]]").click}
		preencher_instituicao_ensino

		
		#gera_screenshot "Parte3CompletaDados"
		click_em_botao_continuar "Parte3CompletaDados"
	
		espera_pagina_endereco
		scroll_to(campo_propria) #2017Set28 19:11, subitamente, tornouse necessario!
		campo_propria.click

		scroll_to(campo_endereco)
		if campo_endereco.value.strip == ''
			escreve_texto campo_endereco, 'Avenida dos Estados'
		end
		scroll_to(campo_bairro)
		if campo_bairro.value.strip == ''
			escreve_texto campo_bairro, 'Jardim Brasil'
		end
		

		scroll_to(campo_sem_num) #2017Set28 19:11, subitamente, tornouse necessario!
		gera_screenshot "Parte3Endereco"
		campo_sem_num.click

		#gera_screenshot "Parte3Endereco"
		click_em_botao_continuar "Parte3Endereco"

		espera_pagina_selfies

		gera_screenshot "Parte3Selfie"
		load_img_selfie

		
		#gera_screenshot "Parte3Selfie"
		click_em_botao_continuar "Parte3Selfie"
		
		espera_pagina_confirmar_escolhas

		
		#gera_screenshot "Parte3Confirma"
		click_em_botao_continuar "Parte3Confirma"
	end

	def load_img_selfie
		#2018Julho31 - dialog de orientacao com botao continuar entre click em "Anexar" e windows-img-dialog

		write_rsi_log "load_img_selfie, P00"
		alguma_imagem.click
		write_rsi_log "load_img_selfie, P01"
		executa_com_retry_stale_element {write_rsi_log "load_img_selfie P02.1";wait_for_label_como_enviar_foto 60 }
		write_rsi_log "load_img_selfie, P03"
		if not has_label_como_enviar_foto?
			write_rsi_log "load_img_selfie, P04"
			falhar "Dialog de Como enviar selfie nao foi encontrado"
		end
		write_rsi_log "load_img_selfie, P05"
		gera_screenshot "Dialog como enviar selfie"

		write_rsi_log "load_img_selfie, P06"
		carrega_img_e_salva botao_continuar
		write_rsi_log "load_img_selfie, P07"
	
###		$last_scrollet_element = nil #2018Julho31 evita GLITCH de exception STALE ELEMENT inofensiva por mudar de tela sem click_em_botao_continuar, PODEMOS VOLTAR A IMPLEMENTACAO ORIGINAL DE método scroll_to de rsi_utils.rb (de antes de 2018Julho31)  
	end


end
