class RecomendadosSection < SitePrism::Section
    element :titulo , "div.title p", visible:false
    element :botao  , "div.button img" , visible:false
end

class PadronizadosSection < SitePrism::Section

element :titulo , :xpath, "(html-string-text)[1]", visible:false 
# DICA: "> bla = primeiro", como xpath "(//BLA")[1] !!
element :botao  , :xpath, "*/button", visible:false
#2018Abr21 - DOM CHANGE # 	element :titulo , 'div.standard-offer-item-title'
#2018Ar21 - DOM CHANGE  # 	element :botao  , 'div.standard-offer-item-choose button'
end


class SegundaParte < SitePrism::Page
#------------------------------------------------------------------------------------------------------------------------------

	# rbattaglia 2017Nov7 - Sério problema com "&nbsp;" que nao é traduido em XPATH.
	# Unica solucao ACEITA em StackOverflow seria colocar via NUMERICKEYPAD ALT+0160, e 
	# eu nem tenho numeric keypad
	#
	# ALÈM DISSO, a renderizacao "&nbsp;" versus "espaço normal" muda de acordo com o
	# tamanho da jale,a , por vezes sendo &nbsp; e por vezes "epsaço normal".
	#
	# POR ENQUANTO, contornando com contains(algo) and contais(maisalgo) etc.



	XPATH_CONTAINS_MELHORES_OPCOES=str_to_xpath_contains('veja melhores opções')

	element :label_passo_2, :xpath, "//span[text()[#{XPATH_CONTAINS_MELHORES_OPCOES}]]"
	element :cheguei_no_passo_2_ou_erros_conhecidos, :xpath, "//span[text()[#{XPATH_CONTAINS_MELHORES_OPCOES} or #{xpath_contains_fazendo_ajustes}]]"
	element :desculpe_estamos_fazendo_ajustes, :xpath, "//span[text()[#{xpath_contains_fazendo_ajustes}]]"

	sections :padronizados, PadronizadosSection, :css, '.offer'
	#2018Abr21 - DOM CHANGE - sections :padronizados, PadronizadosSection, :css, 'div.standard-offer-item' #2018Mar04 02:56am - removida sufixo ".row" de standard-offer-item, quebrando script. Script adaptado. 	
	
	sections :recomendados, RecomendadosSection, :css, 'div.featured-offer'

#------------------------------------------------------------------------------------------------------------------------------

	def espera_pagina_carregada()
		executa_com_retry_stale_element {wait_for_cheguei_no_passo_2_ou_erros_conhecidos 3*45} #podemos definir tempo maximo aqui
		
		if has_label_passo_2?
			return #ok, adiós
		end

		if has_desculpe_estamos_fazendo_ajustes?
			falhar "#{get_msgerr_desculpe_fazendo_ajustes}"
		end

		falhar "Elemento label_passo_2 nao estah presente na tela"
	end

	def processa()
		remove_nonascii_exception {run_processa()}
	end

	def tabajara_visita_e_preenche_na_mao_primparte
		visit 'https://mobhk.servcoord.santanderbr.pre.corp:8443/SantanderAbertCoord/v1/abertura/step/0'
		visit 'https://mob-front-desk-contacorrente-pre.appls.cmpn.paas.gsnetcloud.corp'
		seta_titulo_janela_browser
		50.times {write_rsi_log :debug, "DIGITE PASSO 1 MANUALMENTE!!"}
	end

	def run_processa()
		write_rsi_log :info, "Iniciando processa - Passo 2"

		tabajara_visita_e_preenche_na_mao_primparte if false

		espera_pagina_carregada

		

		gera_screenshot "Parte2Inicio"
		
		fazer_escolha_de_pacotes()

	end

	def fazer_escolha_de_pacotes
		pacote_massa = traduz_pacote_massa_para_tela
		write_rsi_log :debug, "$massa['PACOTE']=#{$massa['PACOTE']}, pacote_massa=#{pacote_massa}"

		pacotes_recomendados_na_tela=[]
		pacotes_padronizados_na_tela=[]

		ok_recomendados = escolhe_pacote(pacote_massa, recomendados, pacotes_recomendados_na_tela)
		
		if not ok_recomendados
				# HMM, em VM pode demorar um pouco pra carregar pacotes.
				# POR simplicidade, sleep de 5 segundos e entao RETRY.
				# TODO - fazer WAIT INTELIGENTE , até que a SECTION tenha length>0
			if pacotes_recomendados_na_tela.length == 0
				write_rsi_log "pacotes_recomendados_na_tela, depois de checar recomendados, tem length 0, vai dormir e reler"
				sleep 5
				ok_recomendados = escolhe_pacote(pacote_massa, recomendados, pacotes_recomendados_na_tela)
			end
		end

		ok_padronizados = false
		if not ok_recomendados #somente checa padronizados se recomendados not ok
			ok_padronizados = escolhe_pacote(pacote_massa, padronizados, pacotes_padronizados_na_tela)
			if not ok_padronizados
				if pacotes_padronizados_na_tela.length == 0
					write_rsi_log "pacotes_padronizados_na_tela, depois de checar padronizados, tem length 0, vai dormir e reler"
					sleep 5
					ok_padronizados = escolhe_pacote(pacote_massa, padronizados, pacotes_padronizados_na_tela)
				end
			end
		end

		if not (ok_recomendados or ok_padronizados)
			pacotes_na_tela = []
			pacotes_na_tela << pacotes_recomendados_na_tela
			pacotes_na_tela << pacotes_padronizados_na_tela
			write_rsi_log :debug, "(Pacote de ofertas da massa de dados).encoding=#{pacote_massa.encoding}"
#
#
#
			falhar_definitivo "Pacote de ofertas da massa de dados #{pacote_massa} nao encontrado na tela, que mostrou opcoes #{pacotes_na_tela}"
		end

		return
	end

	def escolhe_pacote(pacote_massa, secao, pacotes_na_tela)
		retval = false
		secao.length.times do |num_pack|
			write_rsi_log :debug, "secao.class=#{secao.class}, num_pack=#{num_pack}"	
			scroll_to secao[num_pack].titulo
			pack = secao[num_pack].titulo.text
			pacotes_na_tela << pack
			write_rsi_log :debug, "pack=#{pack}, pacote_massa=#{pacote_massa}" 
			write_rsi_log :debug, "pacotes_na_tela=#{pacotes_na_tela}"

			if pack == pacote_massa
				$elto = secao[num_pack].botao
				puts $elto
				write_rsi_log "pack #{pack} encontrado OJ na tela, vai clicar em quero, elto=#{secao[num_pack].botao}"
				scroll_to secao[num_pack].botao
				gera_screenshot "Parte2EscolhePacote"
				secao[num_pack].botao.click
				retval = true
				break
			end
		end

		return retval
	end

end
