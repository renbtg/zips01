
class WebdesktopEnvioDaSolicitacao < SitePrism::Page
#------------------------------------------------------------------------------------------------------------------------------

	FALHAR_DEFINITIVO_AJUSTES_ENVIOSOLIC = false
	
	XPATH_CONTAINS_EM_ANALISE=str_to_xpath_contains("abertura da sua conta está em análise")
	element :label_em_analise, :xpath, "//span[text()[#{XPATH_CONTAINS_EM_ANALISE}]]"
	element :label_em_analise_ou_erros_conhecidos, :xpath, "//span[text()[#{XPATH_CONTAINS_EM_ANALISE} or #{xpath_contains_fazendo_ajustes}]]"
	element :desculpe_estamos_fazendo_ajustes, :xpath, "//span[text()[#{xpath_contains_fazendo_ajustes}]]"

#------------------------------------------------------------------------------------------------------------------------------


	def espera_pagina_carregada()
		write_rsi_log :debug, "WekdesktopEnvioDeSolicitacao-espera_pagina_carregada-P000" 
		executa_com_retry_stale_element {wait_for_label_em_analise_ou_erros_conhecidos 180}
		#2017Nov20 - aumentando para 3 minutos/180 segundos a tolerancia, era 2 minutos/120 segundos. 
		if has_label_em_analise?
			return #ok, adiós
		end

		if has_desculpe_estamos_fazendo_ajustes?
			msgfalha = "espera_pagina_carregada: #{get_msgerr_desculpe_fazendo_ajustes}"
			if FALHAR_DEFINITIVO_AJUSTES_ENVIOSOLIC
				msgfalha = "#{msgfalha}, falhando definitivo, FALHAR_DEFINITIVO_AJUSTES_ENVIOSOLIC=#{FALHAR_DEFINITIVO_AJUSTES_ENVIOSOLIC}"
				falhar_definitivo msgfalha
			else
				falhar msgfalha
			end
		end
	end

	def processa
		remove_nonascii_exception {run_processa()}
	end

	def run_processa
		write_rsi_log :info, "Iniciando processa - Envio Solicitação" 
		
		begin
			espera_pagina_carregada
			gera_screenshot "SolicitacaoEnviada"
		rescue Exception => e
			write_rsi_log :debug, "Excecao em WekdesktopEnvioDeSolicitacao::run_processa, e=#{e}, e.class=#{e.class}"
			falhar e
		end
		write_rsi_log :debug, 'Solicitação enviada com Sucesso!!'
	
	end
	
end
