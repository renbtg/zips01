require_relative '../support/rsi_log.rb'
class DocumentoSection < SitePrism::Section
  #2018Mar25 - vários visible:false adicionados, para lidar com telas nao-maximizadas
  element :um_doc_btn_plus   , "span.icon.plus", visible:false
  element :um_doc_btn_minus  , "span.icon.minus", visible:false
  element :um_doc_span_titulo, "span.title.ng-binding", visible:false
  element :um_doc_span_folderverde, "span.foldercol.verde", visible:false
  element :um_doc_span_folderbranca, "span.foldercol.branca", visible:false
  #element :um_doc_btn_minuss   , "span.icon.minus" #nao sei ESPERAR POR minus DESAPARECER. E... desnecessario
end
class StatusSection < SitePrism::Section
  element :um_status   , "a", visible:false
end

class AcessarPastaDigital < SitePrism::Page

sections :todos_docs  , DocumentoSection, :xpath, "//div[@id='headingOne']//*//div[@class='pull-left paddingLeft_0']", visible:false
#sections :todos_docs  , DocumentoSection, :css, "div.headingOne a div.pull-left.paddingLeft_0"
XPATH_TODOS_STATUS="//div[@class='lista-links-tabela ng-scope']/ul/li"
sections :todos_status, StatusSection   , :xpath, XPATH_TODOS_STATUS, visible:false


element :select_cpf		, :css, '.select-m', visible:false
element :campo_cpf		, :xpath, "(//input[@type='text'])[1]", visible:false
element :botao_buscar   , :css, '.btn-blue.btn-buscar.ng-scope', visible:false

element :cpf_pesquisado 		, :css, '.ng-binding.ng-scope' , visible:false

element :btn_conta_corrente		 , :xpath, "//a[text()[contains(.,'CONTA CORRENTE DIGITAL PF')]]", visible:false
#element :btn_alterar_status 	 , :xpath, "//i[@title='Alterar status']", visible:false
element :btn_alterar_status 	 , :xpath, "//div[@class='panel-default accordionGroup ng-isolate-scope panel panel-open']//i[@title='Alterar status']", visible:false
element :btn_aprovado			 , :xpath, "#{XPATH_TODOS_STATUS}//*/a[text()[normalize-space()='Aprovado']]", visible:false #100% inequivoco
element :btn_devolvido			 , :xpath, "#{XPATH_TODOS_STATUS}//*/a[text()[normalize-space()='Devolvido']]", visible:false  #100% inequivoco
element :btn_rejeitado			 , :xpath, "#{XPATH_TODOS_STATUS}//*/a[text()[normalize-space()='Rejeitado']]", visible:false  #100% inequivoco
element :btn_pendente_de_analise , :xpath, "#{XPATH_TODOS_STATUS}//*/a[text()[normalize-space()='Pendente Análise']]", visible:false  #100% inequivoco

element :btn_acao_status		, :xpath, "//button[text()[normalize-space()='Aprovar' or normalize-space()='Devolver' or normalize-space()='Rejeitar']]", visible:false

#element :cartao_nome_1 , :xpath, "//*[contains(@class,'sn-container-cred-card-tpl1')]/label[contains(@data,'item.fields.label_1')]"


element :span_titulo_conta_digital , :xpath , "//div[contains(@class,'pull-left')]/span[text()[normalize-space()='Conta Digital']]", visible:false
#element :prod_conta_digital_btn_plus,  :xpath , "//div[contains(@class,'pull-left')]/span[@class='icon plus']"

element :select_motivo, 'select', visible:false
element :option_motivo, :xpath, '//select/option[2]', visible:false



	def aumentar_jan_pasta
		dw,dh = autohk_get_desktop_dimensions
		x,y,w,h=get_rectangle_este_browser
		write_rsi_log :debug, "aumentar_jan_pasta, [dw,dh,x,y,w,h]=#{[dw,dh,x,y,w,h]}"
		$arqslot_bkp_pasta = "#{get_arq_rectangle_do_slot}.BKPPASTA"
		write_rsi_log "aumentar_jan_pasta , $arqslot_bkp_pasta=#{$arqslot_bkp_pasta}"
		FileUtils.rm $arqslot_bkp_pasta if File.exist? $arqslot_bkp_pasta
		File.write($arqslot_bkp_pasta,"#{x}@#{y}@#{w}@#{h}")
		seta_rectangle_este_browser 50,50,dw-50,dh-50 
	end

	def restaurar_jan_pasta
		if File.exist? ($arqslot_bkp_pasta)
			x,y,w,h = File.read($arqslot_bkp_pasta).split("@")
			seta_rectangle_este_browser x,y,w,h 
			FileUtils.rm $arqslot_bkp_pasta
		end
	end

	def roda_pedaco_pastadigital()
		begin
			remove_nonascii_exception {yield}
		rescue Exception => e
			begin
				executa_exclusivo do
					restaurar_jan_pasta
				end if not janelas_sempre_maximizadas?
			rescue Exception =>xe
				write_rsi_log "Excecao #{xe} tentando restaurar tamanho de janela de pasta digital"
			end
			falhar e
		end

	end


	def acessarPasta()
		executa_exclusivo do
			 aumentar_jan_pasta
		end if not janelas_sempre_maximizadas? 

		roda_pedaco_pastadigital {run_acessarPasta()}
	end

	def run_acessarPasta(url=nil)
		if url == nil
			url = 'https://gddangular.santanderbr.pre.corp/PASDIG_PORTALCORP/#/search'
		end
		
		visit url
		seta_titulo_janela_browser
	end


	def iniciarBusca
		roda_pedaco_pastadigital {run_iniciarBusca()}
	end

	def run_iniciarBusca()
		write_rsi_log :debug, "run_iniciarBusca, P00"
		scroll_to(select_cpf) #2017Set28 19:11, subitamente, tornouse necessario!
		write_rsi_log :debug, "run_iniciarBusca, P01"
		select_cpf.find("option[value='object:6']").click
		write_rsi_log :debug, "run_iniciarBusca, P02"
		escreve_texto campo_cpf, get_massa() ['CPF'] #43955043100
		write_rsi_log :debug, "run_iniciarBusca, P03"
		scroll_to(botao_buscar) #2017Set28 19:11, subitamente, tornouse necessario!
		write_rsi_log :debug, "run_iniciarBusca, P04"
		#gera_screenshot "PDigital_BuscaCPF"
		botao_buscar.click
		write_rsi_log :debug, "run_iniciarBusca, P05"
	end
	
	def nada
		fail 'nada'
	end


	def analiseDocumentacoes
		roda_pedaco_pastadigital {run_analiseDocumentacoes()}
		executa_exclusivo do
			restaurar_jan_pasta
		end if not janelas_sempre_maximizadas?
	end

	MINUTOS_PASTA_DIGITAL = 7
	def run_analiseDocumentacoes()
		first_iter = true
		while true do
			begin
				if first_iter
					first_iter = false 
					# na 1a tentativa, já fez busca. Apenas analisa
				else
					#a partir da 2a tentativa, tem que reacessar pasta e reiniciar busca
					run_acessarPasta 
					run_iniciarBusca
				end
				core_analiseDocumentacoes
			rescue Exception => e
				write_rsi_log :debug, "run_analiseDocumentacoes() - excecao,  e = #{e}, e.backtrace = #{e.backtrace}"
				msg = nil
				msg = e.message rescue nil #ignora solenemente excecao se nao houver MESSAGE
				msg = msg || ''
				if not (msg.include? 'Primeiro botao' and has_btn_pendente_de_analise?) 
					#Nao conseguir achar primeiro botao de mudar status indica que Veracidade ainda nao sensibilizou a pasta digital. Ou seja, processo background de liberar documentos pra edicao, que ocorre minutos depois de Veracidade, ainda nao foi executado com sucesso.

					#Se excecao nao for no "Na primeira checagem de botoes de status, vi opção que permite ir pra pendente de análise", entao, nao sei qual foi o erro, e deve dar erro imediatamente. Apenas faz raise.

					# SE , bizarramente, houver opcoes de Aprovado,Devolvido/Rejeitado E TABMBEM pendente de analise, nao dará erro, pois terei conseguido achar [Aprovado/Devolvido/Rejeitado]  
					write_rsi_log :debug, "msg=#{msg}, has_btn_pendente_de_analise?=#{has_btn_pendente_de_analise?}"
					falhar e
				end

				agora=Time.now
				if (agora.to_f - $time_veracidade_ok.to_f)/60.0 >= MINUTOS_PASTA_DIGITAL
					falhar e
				end
				write_rsi_log :warn, "Primeiro botao de alterar status nao encontrato - presumindo que isto é por causa de VERACIDADE AINDA NAO SENSIBILIZOU PASTA DIGITAL, tentando de novo pois difftempo de agora(#{agora})-$time_veracidade_ok(#{$time_veracidade_ok}) eh menor que #{MINUTOS_PASTA_DIGITAL} minutos"
				
				next
			end
			break #se nao teve excecao, perfeito, saio do loop
		end

		return
	
	end


	def core_analiseDocumentacoes()
#	Comprovante de Endereço
#	Comprovante de Renda
#	Comprovante Universitário
#	RG
#	Selfie
#
		write_rsi_log :debug, "run_analiseDocumentacoes, P00"

		if not wait_for_cpf_pesquisado 20*5
			falhar 'elemento do CPF pesquisado nao encontrado!'
		end
		write_rsi_log :debug, "run_analiseDocumentacoes, P01"
		scroll_to(cpf_pesquisado) #2017Set28 19:11, subitamente, tornouse necessario!
		gera_screenshot "PDigital_Result_busca"
		cpf_pesquisado.click
		write_rsi_log :debug, "run_analiseDocumentacoes, P02"
		
		page.driver.switch_to_frame find("iframe")

		write_rsi_log :debug, "run_analiseDocumentacoes, P03"
		wait_for_span_titulo_conta_digital 20 *5
		write_rsi_log :debug, "run_analiseDocumentacoes, P04"
		if not has_span_titulo_conta_digital?
			falhar 'span de titulo de produto Conta Digital nao encontrado'
		end
		write_rsi_log :debug, "run_analiseDocumentacoes, P05"
		

		#AQUI, já fizemos espera pelo tíotulo Conta Digital, que sempre aparece DPOIS do botao 
		# de CONTA CORRENTE DIGITAL PF
		wait_for_btn_conta_corrente 10*2 #2018Out29 - contornando BUG de Pasta Digital que mostra texto de botao em ingles antes de mostrar em portugues 
		if not has_btn_conta_corrente?
			falhar 'Botao CONTA CORRENTE DIGITAL PF nao encontrado'
		end

		write_rsi_log :debug, "run_analiseDocumentacoes, P06"
		scroll_to(btn_conta_corrente) #2017Set28 19:11, subitamente, tornouse necessario!
		gera_screenshot "PDigital_Dossie"
		btn_conta_corrente.click

		write_rsi_log :debug, "run_analiseDocumentacoes, P07"
		if not wait_for_todos_docs 10*5
			falhar 'Lista de documentos nao encontrada'
		end
		write_rsi_log :debug, "run_analiseDocumentacoes, P08"

		ja_escolheu_o_nao_aprovado = false

		ainda_nao_achou_botao_status = true

		todos_docs.length.times do |k|
			write_rsi_log :debug, "run_analiseDocumentacoes, P10"
			write_rsi_log :debug, "loop de todos_docs, k=#{k}, todos_docs.length=#{todos_docs.length}"
			

			scroll_to(todos_docs[k].um_doc_span_titulo) #JA TINHA - 2017Set28 19:11, subitamente, tornouse necessario!
			scr_tipodoc = todos_docs[k].um_doc_span_titulo.text
			write_rsi_log :debug, "loop de todos_docs, scr_tipodoc=#{scr_tipodoc}"
			gera_screenshot "PDigital_Documentos"

			if ($massa['STEP_INICIAL']||0).to_i >= $numero_step_atual and todos_docs[k].has_um_doc_span_folderverde?
				write_rsi_log :debug, "$massa['STEP_INICIAL']=#{$massa['STEP_INICIAL']}, scr_tipodoc=#{scr_tipodoc},  has_um_doc_span_folderverde?=true. Ok, pode pular este documento e ir checar o próximo, se houver mais algum."
				next
			end

			todos_docs[k].um_doc_btn_plus.click
			write_rsi_log :debug, "run_analiseDocumentacoes, P11"

			wait_for_btn_alterar_status 10*5
			if not todos_docs[k].has_um_doc_span_titulo?
				falhar "Botao de alterar  status nao encontrado"
			end
			write_rsi_log :debug, "run_analiseDocumentacoes, P12"
			scroll_to(btn_alterar_status)
			gera_screenshot "PDigital_AbrirItemDoc"
			btn_alterar_status.click
			write_rsi_log :debug, "run_analiseDocumentacoes, P13"
			gera_screenshot "PDigital_ClicaAlteraStatus"


			wait_for_todos_status 10*5
			if not wait_for_todos_status 10*5
				falhar 'Menu de escolher novo status nao encontrado'
			end
			write_rsi_log :debug, "run_analiseDocumentacoes, P14"

			p_btn_st, p_wait_st = define_blocks_status('aprovado') #por default, aprovo
	
			if (not ja_escolheu_o_nao_aprovado) and (deve_alterar_status(scr_tipodoc))
	
				#
				# APENAS UM dos ducumentos eh REJEITADO ou DEVOLVIDO, o resto eh APROVADO
				#
				write_rsi_log :debug, "run_analiseDocumentacoes, P15"
				p_btn_st, p_wait_st = define_blocks_status()
				ja_escolheu_o_nao_aprovado = true
				write_rsi_log :debug, "run_analiseDocumentacoes, P16"
			end
			if (not p_wait_st.call) #or true #or true = debug hack
				falhar "#{ainda_nao_achou_botao_status ? 'Primeiro botao' : 'Botao'}/opcao de novo status #{$massa['PASTADIGITAL_STATUS_DOCUMENTO']} nao encontrado"
			end
			write_rsi_log :debug, "run_analiseDocumentacoes, P17"
			ainda_nao_achou_botao_status = false
			scroll_to(p_btn_st.call)
			gera_screenshot "PDigital_StatusItem"
			p_btn_st.call.click

			write_rsi_log :debug, "run_analiseDocumentacoes, P18"
			
			if not wait_for_select_motivo 10*5
				falhar 'Dialog de escolher motivo do novo status nao encontrado'
			end
			write_rsi_log :debug, "run_analiseDocumentacoes, P19"
			if not wait_for_option_motivo 30*5 #lendo lista de banco? às vezes, muito lento...
				falhar 'select.option de motivo do novo status nao encontrado'
			end
			write_rsi_log :debug, "run_analiseDocumentacoes, P20"
			option_motivo.select_option

			write_rsi_log :debug, "run_analiseDocumentacoes, P21"
			if not wait_for_btn_acao_status 5*5
				falhar 'Botao de confirmar alteracao de status nao encontrado'
			end
			write_rsi_log :debug, "run_analiseDocumentacoes, P22"
			gera_screenshot "PDigital_OpcaoMotivo"
			btn_acao_status.click
			write_rsi_log :debug, "run_analiseDocumentacoes, P23"
			
			 5	
			#por causa de possível demora fechamento de DIALOG DE CONFIRMAR MUDANÇA STATUS
			#    ***   OBS: nao foi suficiente...saiu da rotina ainda com DIALOG fechando! Portanto,
			#    *** devo colocar mais algum wait, ou acao de CLICK de alguma forma ao fim.   
			if not todos_docs[k].wait_for_um_doc_span_titulo 30*5
				falhar "Titulo de tipo de documento nao encontrado"
			end
			write_rsi_log :debug, "run_analiseDocumentacoes, P24"

			executa_com_retry_stale_element{
				write_rsi_log :debug, "run_analiseDocumentacoes, P25"
				scroll_to(todos_docs[k].um_doc_btn_minus)
				gera_screenshot "PDigital_ItemDoc"
				todos_docs[k].um_doc_btn_minus.click #GARANTE que o lento fechamento do dialog de confirmação de mudança de status tenha ocordrido

				### TODO 2017Set24 04:00am, AINDA IMPERFEITO: quando dá pau na tela,
				# "FUNCIONALIDADE INDISPONIVEL", existe súbito e imprevisivel fechamento
				# da tela-base onde todos_docs está definido... o que gera falha na 
				# automacao com exception nativa do Ruby 
				# (Ex: undefined method `um_doc_btn_minus' for nil:NilClass (NoMethodError))
				#         ____    IDEALMENTE, essa excecao deveria ser RESCUED, e mensagem mais
				#         _____ amigável deveria ser mostrada
			}   
			write_rsi_log :debug, "run_analiseDocumentacoes, P26"

			write_rsi_log :debug, "Status executado #{k}"
			write_rsi_log :debug, "run_analiseDocumentacoes, P27"
		end
		write_rsi_log :debug, "run_analiseDocumentacoes, P28"
			
	end
	

	def deve_alterar_status(scr_tipodoc) 
		write_rsi_log :debug, "deve_alterar_status, P00"
		if not ['rejeitado','devolvido'].include? (($massa['PASTADIGITAL_STATUS_DOCUMENTO']||'').downcase)
			write_rsi_log :debug, "deve_alterar_status, P01"
			return false
		end
		write_rsi_log :debug, "deve_alterar_status, P02"
		return true if scr_tipodoc.downcase == ($massa['PASTADIGITAL_TIPO_DOCUMENTO']||'').downcase
		write_rsi_log :debug, "deve_alterar_status, P03"
		
		#
		# $massa nao sabe distinguir, ainda, quando tem Comprovante Universitario e/ou de Renda
		#
		# Portanto, esses 2 tipos de documento
		#

		a_outros = ['Comprovante Universitário'.downcase, 'Comprovante de Renda'.downcase]
		write_rsi_log :debug, "deve_alterar_status, P04"
		if (($massa['PASTADIGITAL_TIPO_DOCUMENTO']||'').downcase=='outro') and (a_outros.include?(scr_tipodoc.downcase))
			write_rsi_log :debug, "deve_alterar_status, P05"
			return true
		end
		write_rsi_log :debug, "deve_alterar_status, P06"
		return false
	end

	def define_blocks_status(st=$massa['PASTADIGITAL_STATUS_DOCUMENTO'])
		#
			## Quero checar minuciosamente se cada um dos botoes desejados estah presente.
			##    Para tanto, uso os metodos granulares do siteprism (has_bla_?, wait_for_bla),
			## armazenando cada um deles em PROC/LAMBDAs p_btn_st, p_wait_st e p_has_st.
			##
			## Tendo apenas definido quais os métodos corretos, entao, chamo-os quando necessario
			##
			#

		if st.downcase=='aprovado'
			b=Proc.new {btn_aprovado}
			w=Proc.new {wait_for_btn_aprovado 10*5}
		elsif st.downcase=='devolvido'
			b=Proc.new {btn_devolvido}
			w=Proc.new {wait_for_btn_devolvido 10*5}
		elsif st.downcase=='rejeitado'
			b=Proc.new {btn_rejeitado}
			w=Proc.new {wait_for_btn_rejeitado 10*5}
		elsif st.downcase=='pendente de análise'
			b=Proc.new {btn_pendente_de_analise}
			w=Proc.new {wait_for_btn_pendente_de_analise 10*5}
		else
			falhar 'Erro ao definir blocks de codigo para checagem de status'
		end
		return [b,w]
	end




end

