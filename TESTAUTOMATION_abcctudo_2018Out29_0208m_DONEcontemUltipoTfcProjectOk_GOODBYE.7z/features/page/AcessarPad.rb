require_relative '../support/rsi_utils.rb'

class AcessarPad < SitePrism::Page


element :monte_seu_perfil, "div",:text => "Passo 1 - Monte seu perfil"
element :option_nao_fraude , 'option', :text => 'NÃO Fraude' #.encode('utf-8') em console
element :option_segundo_motivo, :xpath, "//select[@id='submotive']/option[2]"
element :descricao, :id, 'description'
element :btn_aprovar, 'button', :text => 'APROVAR'
element :mesa_antifraude, 'div.title', :text => 'Mesa Antifraude'
element :primeiro_cpf_na_pagina, :xpath, "((//tbody/tr)[1]/td)[2]"
element :table_body, 'tbody'

element :search_cpf_input, :id, 'cpfInput'
element :iniciar_atendimento, '.title', :text => 'Iniciar Atendimentos'
element :status_proposta, '.status-description' 
element :btn_buscar, 'button', :text => 'BUSCAR'

#element :proposta_analisada_sucesso, 'div', :text => 'Essa proposta foi analisada com sucesso.'
element :botao_entendi, 'button', :text => 'ENTENDI'
element :proposta_analisada_com_sucesso, 'md-dialog-content', :text => 'Essa proposta foi analisada com sucesso.'
element :mesa_cpf_input, :xpath  ,  "//input[@name='cpf']"
element :mesa_filtrar_button,  'button', :text => 'FILTRAR'

TXT_AGUARDANDO_NUCLEO = 'aguardando núcleo'
TXT_PRONTO_PARA_BW = 'pronto para bw'

	def processa()
		remove_nonascii_exception { profile_block lambda { run_processa } } 
	end
	def run_processa()
		deve_exigir_statuses_post_pad = false #massa sensibilizada. 

		texto_status_proposta = abre_status_proposta #2018Set03 - revamp status 
		if deve_exigir_statuses_post_pad #2018Set6 - coloque 'if false' para evitar siscos e ter abordagem algo lenta, mas segura, a PAD, como vinha sendo feito em semanas anteriores. Ou... if 'true' para a nova aceleracao de exigir massa sensibilizada
			if [TXT_AGUARDANDO_NUCLEO, TXT_PRONTO_PARA_BW].include? texto_status_proposta.downcase #2018Set03 - revamp status + apenas tolerar statuses post-PAD, a.k.a ["prontp para bw',TXT_AGUARDANDO_NUCLEO]
				if texto_status_proposta.downcase != TXT_PRONTO_PARA_BW
					return
				end

				vezes_tentar_aguardando_nucleo = 5
				sleep_segundos_aguardando_nucleo = 60
				vez = 0
				while vez < vezes_tentar_aguardando_nucleo
					vez = vez + 1
					write_rsi_log :debug, "AcessarPad::run_processa, ainda [pronto para bw], vai retentar vez #{vez} de #{vezes_tentar_aguardando_nucleo}. Vai dormir #{sleep_segundos_aguardando_nucleo} segundos, tolerantemente"
					sleep sleep_segundos_aguardando_nucleo
					write_rsi_log :debug, "AcessarPad::run_processa, ainda [pronto para bw], vai retentar vez #{vez} de #{vezes_tentar_aguardando_nucleo}. Dormiu #{sleep_segundos_aguardando_nucleo} segundos"
					texto_status_proposta = abre_status_proposta
					if texto_status_proposta.downcase == TXT_AGUARDANDO_NUCLEO
						return
					elsif texto_status_proposta.downcase != TXT_PRONTO_PARA_BW
						break
					end
				end #end while
			end
			falhar_definitivo "2018Set03 - Proposta em status #{texto_status_proposta} nao estah devidamente aguardando nucleo, e este teste de 2018Set6 quer apenas considerar OK o PAD com massa sensibilizada"
		end

		if texto_status_proposta.downcase.include? 'aprovad' #2018Set03 - revamp status  
			return
		end
		visitar_antifraude
		profile_block lambda { fazer_aprovacao }
	end

	def abre_status_proposta(cpf=$massa['CPF'])
		urlLanding = 'https://mobhk.boconf.santanderbr.pre.corp/#!/search-proposal'
		visit urlLanding
		escreve_texto search_cpf_input, cpf
		gera_screenshot 'PAD - vai buscar cpf, pra checar status'
		btn_buscar.click
		executa_com_retry_stale_element {wait_for_monte_seu_perfil 90}
		if not has_monte_seu_perfil?
			falhar "ERRO PAD: Tela de analise do CPF, com status da proposta, nao apareceu"
		end
		gera_screenshot 'PAD - status da proposta'
		texto_status_proposta = status_proposta.text
		write_rsi_log "PAD - status da proposta, texto_status_proposta=#{texto_status_proposta}"
		
		return texto_status_proposta
	end

	def visitar_antifraude
		urlAntifraude = 'https://mobhk.boconf.santanderbr.pre.corp/#!/mesa-antifraude'
		visit urlAntifraude
		gera_screenshot "PAD - visitou"
	end

	def fazer_aprovacao
		executa_com_retry_stale_element {wait_for_mesa_cpf_input 45}
		if not has_mesa_cpf_input?
			falhar "PAD - campo de digitacao de CPF (mesa_cpf_input) da mesa antifraude nao apareceu"
		end
		escreve_texto mesa_cpf_input, $massa['CPF']
		mesa_filtrar_button.click

		executa_com_retry_stale_element {wait_for_table_body 75}
		if not has_table_body?
			falhar "PAD - tabela da mesa antifraude nao apareceu"
		end
		gera_screenshot "PAD - tabela presente"

		pagina_atual = 1
		achou_cpf = false
		while true
			#2018Out24 - LOOP DE PÀGINAS agora é exagero (mas inofensivo): já teremos pré-filtrado por CPF

			write_rsi_log :debug, "Loop fazer_aprovacao, P10"
			pagina_seguinte = pagina_atual + 1
			el_cpf_da_massa = get_elemento_cpf 
			if el_cpf_da_massa
				write_rsi_log :debug, "Loop fazer_aprovacao, P20"
		    	scroll_to el_cpf_da_massa
		    	gera_screenshot 'PAD - cpf encontrado em mesa antifraude'
		    	achou_cpf = true
			    break
             end
             elto_prox_pag = pagina_numero(pagina_atual +1)
             if not elto_prox_pag
				write_rsi_log :debug, "Loop fazer_aprovacao, P30"
             	break
             end
             prim_cpf_pag_anterior = primeiro_cpf_na_pagina
             
             scroll_to elto_prox_pag
             gera_screenshot "PAD - avancando pagina"
             elto_prox_pag.click #scroll antes de click

             espera_pagina(pagina_atual + 1, prim_cpf_pag_anterior)
             gera_screenshot "PAD - avancou pagina"
             
             pagina_atual = pagina_atual + 1
		end
		if not achou_cpf
			if false
				falhar "ERRO PAD - cpf #{$massa['CPF']} nao encontrado na mesa antifraude do PAD, mesmo tendo sido localizado na pesquisa"
			else
				#2018Ago10 - TOLERA nao encontrar o CPF no PAD, q pode ser por comportamento estranho do PAD, que é uma aplicação bem instável !!!!!!!!!!!!!!!
				msgPadTolerante = "PAD tolerante - cpf nao encontrado na mesa antifraude, presumindo algum comportamento estranho do PAD ... NAO FALHANDO AQUI, vai tentar achar CPF no TFC mesmo assim" 
				write_rsi_log :debug, msgPadTolerante
				puts msgPadTolerante #
				return
			end
		end
		begin
			raise "Aqui, chama aprova_cpf com parametro el_cpf_da_massa"
			aprova_cpf el_cpf_da_massa

		rescue Exception => e
			falhar "PAD - erro ao aprovar cpf, excecao=#{e}"
		end
		return
	end

	def espera_pagina(num_pg, primeiro_cpf_pag_anterior)
		#PELO JEITO, nao tem absolutamente nada no HTML que indica que proxima pagina ja carregou!s Quem sabe dê certo, se eu checar se primeiro CPF for diferente da pagina anterior...

		espera_condicao 60 do
			primeiro_cpf_pag_anterior != primeiro_cpf_na_pagina
		end

		### TODO 2018Julho28 - talvez precise de um SLEEP fixo aqui, depois de detectar mudança de página, pra ter carregado.
		### TODO 2018Julho28 - se vier a existir jeito de detectar que um certo Numero de Pagina (num_pg) estiver ativo, podemos parar de usar a estratégia de "primeiro cpf mudou"
	end

	def pagina_numero
		retval = first "li a"
	end

	def get_elemento_cpf(cpf=$massa['CPF'])
		retval = nil
		profile_block lambda { retval = first 'td', :text => cpf }
		return retval
	end

	def pagina_numero(num_pg)
		first 'div.pagination li a', :text => num_pg.to_s
	end



	def aprova_cpf(cpf=$massa['CPF'])
		profile_block lambda {
		write_rsi_log "PAD - aprova_cpf, P00"
		el_cpf = nil
		if cpf.is_a? String
			write_rsi_log "PAD - aprova_cpf, P10"
			el_cpf = get_elemento_cpf(cpf).click
		else
			write_rsi_log "PAD - aprova_cpf, P20"
			el_cpf = cpf
		end
		write_rsi_log "PAD - aprova_cpf, P30 - vai clicar no CPF"
		el_cpf.click
		executa_com_retry_stale_element {wait_for_monte_seu_perfil 90}
		if not has_monte_seu_perfil?
			falhar "ERRO PAD: Tela para analise do CPF nao apareceu"
		end
		option_nao_fraude.click
		option_segundo_motivo.click
		escreve_texto descricao, 'automacao'
		gera_screenshot "PAD - vai aprovar"
		btn_aprovar.click
		} #fim profile_block
		

		executa_com_retry_stale_element { wait_for_proposta_analisada_com_sucesso 60}
		#2018Out24 - espera por PROPOSTA ANALISADA COM SUCESSO em vez de ENTENDI
		if not has_proposta_analisada_com_sucesso?
			falhar "ERRO PAD: Nao encontrado texto dizendo que 'proposta foi aprovada com sucesso' depois de clicar em APROVAR"
		end
		gera_screenshot "PAD - aprovou"

		return
	end

end
