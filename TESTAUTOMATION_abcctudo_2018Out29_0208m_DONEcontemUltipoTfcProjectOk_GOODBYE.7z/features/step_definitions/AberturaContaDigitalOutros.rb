Quando(/^valido a Veracidade$/) do
	next if not set_num_step 8
	
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug

	next if false #DEBUG - pra pular o passo 
	if $superdigital_outrosistema and get_massa() ['PACOTE'] == 'Superdigital'
		next
	end
	
	processa_validar_veracidade
end

Quando(/^aprovo no PAD$/) do
	next if not set_num_step 9
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo
	if $superdigital_outrosistema and get_massa() ['PACOTE'] == 'Superdigital' #TODO 2017Set19 - gerar .feature sem steps "mortos"!
		next
	end
	#puts 'pasta'
	
	deve_aprovar_no_pad = false #2018Set19 - está bem estável, sem precisar passar no PAD.
	if deve_aprovar_no_pad
		pad = AcessarPad.new
		pad.processa
	end
end

Quando(/^acesso Pasta Digital$/) do
	next if not set_num_step 9
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo
	if $superdigital_outrosistema and get_massa() ['PACOTE'] == 'Superdigital' #TODO 2017Set19 - gerar .feature sem steps "mortos"!
		next
	end
	#puts 'pasta'
	

	debug_pular_pasta_digital = false #2018Set7, rbattaglia - testes de Set6 invalidos, este debug estava ativado e nao fez Pasta Digital!
	if not debug_pular_pasta_digital
		pastaDigital = AcessarPastaDigital.new
		pastaDigital.acessarPasta
	end
end

Quando(/^busco pelo CPF$/) do
	next if not set_num_step 9
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo
	if $superdigital_outrosistema and get_massa() ['PACOTE'] == 'Superdigital' #TODO 2017Set19 - gerar .feature sem steps "mortos"!
		next
	end
	#puts 'inicio busca'	
	debug_pular_pasta_digital = false #2018Set7, rbattaglia - testes de Set6 invalidos, este debug estava ativado e nao fez Pasta Digital!
	if not debug_pular_pasta_digital
		pastaDigital = AcessarPastaDigital.new
		pastaDigital.iniciarBusca
	end
end

Então (/^realizo a analise da documentacao na Pasta Digital$/) do
	next if not set_num_step 9
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo
	if $superdigital_outrosistema and get_massa() ['PACOTE'] == 'Superdigital' #TODO 2017Set19 - gerar .feature sem steps "mortos"!
		next
	end
	
	debug_pular_pasta_digital = false #2018Set7, rbattaglia - testes de Set6 invalidos, este debug estava ativado e nao fez Pasta Digital!
	if not debug_pular_pasta_digital
		pastaDigital = AcessarPastaDigital.new
		pastaDigital.analiseDocumentacoes
	end

	falta_pad_em_features = true
	if falta_pad_em_features #2018Ago10 - enquanto nao tem step do PAD nos features..
		deve_aprovar_no_pad = false  #2018Set19 - está bem estável, sem precisar passar no PAD.
		if deve_aprovar_no_pad
			pad = AcessarPad.new
			pad.processa
		end
	end

end



Quando(/^aprovo no TFC$/) do
	next if not set_num_step NUM_STEP_TFC
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo

	if false
		next if tfcCpf2018Mai5and6_manual($massa['CPF'])
	end
	if false
		next if tfcCpf2018Mai9and10_manual($massa['CPF']) #falhar/raise se CPF de SELECT com erro esperado
	end

	tfc_faz_automacao_do_cenario 
end

