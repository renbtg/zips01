Dado(/^que o usuario acesse o link e inicie a abertura de conta digital Web Desktop$/) do
	next if not set_num_step 0
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo

	WebdesktopAcessarAbertura.new.processa
end

Quando(/^preencho a primeira parte$/) do
	next if not set_num_step 1

	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false, MAS, AO MENOS, chama reserva_cpf_pra_massa, preservando comportamento importante pra reproc/faseamento'; reserva_cpf_pra_massa; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo
	PrimeiraParte.new.processa
end

E(/^preencho a segunda parte$/) do
	next if not set_num_step 2
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo

	SegundaParte.new.processa
end

Quando(/^preencho a terceira parte$/) do
	next if not set_num_step 3
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo
	TerceiraParte.new.processa
end

Quando(/^preencho a quarta parte$/) do
	next if not set_num_step 4
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo
	if get_massa() ['PACOTE'] == 'Superdigital' #TODO 2017Set19 - gerar .feature sem steps "mortos"!
		next
	end
	QuartaParte.new.processa
end

Quando(/^preencho a quinta parte$/) do
	next if not set_num_step 5
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo
	if get_massa() ['PACOTE'] == 'Superdigital' #TODO 2017Set19 - gerar .feature sem steps "mortos"!
		next
	end
	QuintaParte.new.processa
end

Quando(/^preencho a sexta parte$/) do
	next if not set_num_step 6
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo
	if get_massa() ['PACOTE'] == 'Superdigital' #TODO 2017Set19 - gerar .feature sem steps "mortos"!
		next
	end
	SextaParte.new.processa
end

Então (/^realizo a solicitacao de abertura de conta digital Web Desktop$/) do
	next if not set_num_step 7
	(puts 'chegou no passo, fazendo nada pois $not_single_maq_zsproc_debugEH false'; next) if not $not_single_maq_zsproc_debug
	next if false #DEBUG - pra pular o passo
	if get_massa() ['PACOTE'] == 'Superdigital'
		next
	end
#puts 'passo fim'
	contaDigitalEnvio = WebdesktopEnvioDaSolicitacao.new
	contaDigitalEnvio.processa
end