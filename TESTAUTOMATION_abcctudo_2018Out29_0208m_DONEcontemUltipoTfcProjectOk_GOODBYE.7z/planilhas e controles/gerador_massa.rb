require_relative '../rotinas_processo.rb'
require_relative '../rotinas_processo.rb'
require_relative '../features/support/rsi_utils.rb'
require_relative '../risco_cpfs.rb'
require_relative '../ipc_processo.rb'
require_relative '../cpf_utils.rb'

require 'spreadsheet'
require 'csv'
require 'capybara/dsl';
include Capybara::DSL;
require 'fileutils'
require 'faker'


HACKS_DEBUG_MASSA_ENABLED = false


SOMENTE_GERAR_COM_CPFS_RISCO_ENCONTRADO =  false #2017Out18, deve ser true em execucoes normais ..... OBS TODO 2018Jan22 - código ainda nao é capaz de retardar decisao , do tipo "busque cpf rm cpfs_risco.xls... e, caso nao encontre, seja toelrante e gere cpf de http://geradordecpf.org... ISSO VAI REQUERER ter mais uma janela de browser aberta, de http://geradordecpf.org" 

PERCENTUAIS_QUALAPP={
	:mob=>0, # REAL=??
	:webdesktop=>100, # REAL=??
}
PERCENTUAIS_VERACIDADE={
	:verde=>100 ,
	:amarelo=>0, #2018Out5 - AMARELO requerido por Sheila, apenas pra obter cpfs_risco.xls, AUTOMACAO RUBY NAO CONHECE AMARELO!
	:vermelho=>0  #REAL VERMELHO=10... OBS: =^ 2017Nov16, deve tentar 10% vermelho MESMO se faltar cpfs na massa, temo ter peddo flexibilizacao de pouquissimos cpfs com 9o digito='9'!!!
}

PERCENTUAIS_PASTADIGITAL={
#########	begin
###
#
#     PERCENTUAL_PASTADIGITAL: Sao relaticos a VERACIDADE VERDE.
#            Sendo assim, se VERACIDADE_VERDE for 90%, e PERCENTUAL_PASTADIGITAL_OK for 70%,
#        63% (90% x 60%) DOS REGISTROS TERAO STATUS OK EM PASTADIGITAL.
#######
	:ok=>100, # REAL=70
	:devolvido=>0, # REAL=25
	:rejeitado=>0  # REAL=5
}

PERCENTUAIS_TRABALHO = { #2018Jun27
	:sim=>80, # REAL=70
	:nao=>20
}

PERCENTUAIS_ESTADO_CIVIL = { #2018Jun27
	:casado=>70, # REAL=70
	:solteiro=>30,
	:divorciado=>0,
	:uniao_estavel=>0,
	:viuvo=>0,
	:separado=>0
}


PASTADIGITAL_DOCUMENTOS=
[
	'RG', 'Selfie', 'Comprovante de Residência', 'outro'
	# 2017Set23 - OUTRO - como nao foi analisado e implementado em PageObject a logica de
	# checar se deve ou nao ter Comprovante de Renda e/ou Comprovante Universiaário,
	# $massa[PASTADIGITAL_TIPO_DOCUMENTO] para esses 2 será "outro", e PageObject
	# devolverá/rejeitará o primeiro desse tipo que encontrar.
	#
	# ATENCAO - isso pode gerar pequeno problema, onde pedidos de abertura que tiverem
	# ambos sempre pegarão o primeiro deles. Se a ordem for fixa, deixaremos de testar
	# o segunto tipo. Tolerável
]

def rotina_de_interrupcao_em_log
	checa_interrupcoes do |msg|
		write_rsi_log :debug, msg
		Kernel.exit! 1
	end
end


def obter_tipo_cred(oferta)
	if $superdigital_outrosistema and oferta == 'Superdigital'
		return [STR_NAO_TESTAVEL]
	end

	if (HACKS_DEBUG_MASSA_ENABLED and true)
		write_rsi_log :debug, "DEBUG HACK! retornando apenas Crédito Adormecido, pra oferta <>> Superdigital "
		#return ['Crédito Adormecido']
	# TODO 2017Ago02 - HMMM, como causar CRÈDITO ADORMECIDO na APP? 
	# ENTAO: por enquanto, deixe estar... mas... vamos gerar SemCartão no nomep do cartao
	# quanto topo_cred for 'Débito'
		
		return [
		'Débito',
		'Múltiplo'
		]
	end

	return [	
	# TODO 2017Ago02 - HMMM, como causar CRÈDITO ADORMECIDO na APP? 
	# ENTAO: por enquanto, deixe estar... mas... vamos gerar SemCartão no nomep do cartao
	# quanto topo_cred for 'Débito'
		
		'Débito',
		'Múltiplo',
		'Crédito Adormecido'
	]
end


def obter_cartao_cred_ou_deb(tipo_cred, i_renda, oferta)
	#2018Mai22 - MVP, modificacoes em renda , pacotes, cartoes

	#write_rsi_log :debug, "tipo_cred=#{tipo_cred}, i_renda=#{i_renda}, oferta=#{oferta}"
	if oferta == 'Superdigital'
		return STR_NAO_TESTAVEL
	end

	if tipo_cred == 'Débito'
		return "CARTÃO DÉBITO"
	end


	regras=[  
			[ [0,1,2,3],  "inclui",'Conta Universitária',"SANTANDER PLAY"    ],
			[ [0,1,2,3],  "inclui",'Santander Van Gogh' ,"SANTANDER 1, 2, 3" ],
			[ [0,1,2,3],  "inclui",nil                  ,"SANTANDER FREE" ]
	]

	da_renda = regras.select{|_r| rs = _r[0]; rd=rs.is_a?(Array) ? rs : [rs]; rd.include? i_renda} 
	#write_rsi_log :debug, "da_renda=#{da_renda}"

	da_renda.each do |dr|
		(ir_jah_filtrado, op, pc, cc) = dr
		#write_rsi_log :debug, "ir=#{ir}, op=#{op}, pc=#{pc}, cc=#{cc}"

		pc = pc.is_a?(Array) ? pc : [pc]
		#write_rsi_log :debug, "pc=#{pc}"

		if (op == "exclui") and (pc[0] == nil or not pc.include?(oferta))
			return cc
		elsif (op == "inclui") and (pc[0] == nil || pc.include?(oferta))
			return cc
		end

	end

	write_rsi_log :error, "Cartão Inválido No Gerador para tipo_cred=#{tipo_cred}, i_renda=#{i_renda}, oferta=#{oferta}"
	return 'Cartão Inválido No Gerador'
end

def obter_texto_cartao_checar(tipo_credito, cartao)
	#2018Set19am created
	#2018Set19pm, modificada pra receber param tipo_credito e somente definir texto non-blank pra Múltiplo 
	retval = ''
	if tipo_credito and cartao and tipo_credito == 'Múltiplo' and cartao == 'SANTANDER FREE'
		usar_novo_texto_de_santander_free_2018Set19 = true
		if usar_novo_texto_de_santander_free_2018Set19
			retval = "Esfera: Programa de descontos em mais de 300 estabelecimentos, como cinemas, lojas, restaurantes e hotéis"
		else
			retval = "Bônus Esfera: 1 bônus a cada R$ 5,00 em compras no crédito"
		end
	end
	return retval
end

def adiciona_cpfs_de_risco_indefinido (qt_cpfs_pra_risco, id_tipo_cred, arq_cpfs_xls)
	arq_cpfs_xls=arq_cpfs_xls || get_xls_cpfs_risco
	if File.exist? arq_cpfs_xls
		FileUtils.cp arq_cpfs_xls, arq_cpfs_xls.split('.xls')[0]+'.anterior.xls'
	end

	id_tipo_cred = (id_tipo_cred || '0').to_i

	orig_data = []
	if File.exist? arq_cpfs_xls 
		orig_data = ler_xls_com_id(arq_cpfs_xls, nil, nil, -1)
	end

	new_data = orig_data

	opt_cred=['Múltiplo','Débito','Crédito Adormecido']
	qt_cpfs_pra_risco.times do |k|
		sinal_veracidade = "verde"
		
		#2017Out9 - Julia pegou bug de ainda haver chamada residual a get_percentual_veracidade_vermelho, removida daqui
		if deve_gerar_percentual(:veracidade, :vermelho, qt_cpfs_pra_risco, k+1)
			sinal_veracidade = "vermelho"
		elsif deve_gerar_percentual(:veracidade, :amarelo, qt_cpfs_pra_risco, k+1)
			sinal_veracidade = "amarelo" #2018Out5 - AMARELO requerido por Sheila, apenas pra obter cpfs_risco.xls, AUTOMACAO RUBY NAO CONHECE AMARELO!
		end	
		cpf = site_obter_cpf(sinal_veracidade, "adiciona_cpfs_de_risco_indefinido") #true=veracidade verde

		if id_tipo_cred==1
			tipo_credito='Múltiplo'
		elsif id_tipo_cred==2
			tipo_credito='Crédito Adormecido'
		elsif id_tipo_cred==3
			tipo_credito='Débito'
		else 
			tipo_credito=opt_cred[ k % 3]
		end

		new_data << { #usar hash aqui é desperdicio de memoria e de chance de erro
			'CPF'=> cpf,
			'TIPO_CREDITO' => tipo_credito,
			'PROCESSADO' => '0',
			'STATUS' => 'indefinido',
			'DATA_ENVIADO'=> 'sei la',
			'DATA_DEFINIDO' => 'tbm n sei',
			'DATA_PROCESSADO' => 'nem ideia',
		}
		k=k+1
		reescreve_xls_risco(arq_cpfs_xls, rsk_cpf_cols, new_data) #2017Dez11 - corrigido bug escondido, já que fazia algumas semanas que não gerávamos cpfs. FALTAVA passar parâmetro rsk_cpf_cols !!
		# SIM, reescreve a cada registro, MAIS SEGURO: pode interromper processo longo
	end
end

def push_cpf(cpf, sinal_veracidade) #2017Set1 - push_cpf e pop_cpf e $cpf_cache: acelera obtencao
	if not condicao_veracidade(sinal_veracidade,cpf)
		return
	end
	$cpf_cache=[] if $cpf_cache == nil
	$cpf_cache << cpf
end


def pop_cpf(sinal_veracidade)
	$cpf_cache=[] if $cpf_cache == nil

	retval = nil
	k = $cpf_cache.find_index { |cpf| condicao_veracidade(sinal_veracidade,cpf) }
	
	if k
		retval = $cpf_cache[k]
		$cpf_cache.delete_at k 
	end
	
	return retval
end

def obter_cpf(sinal_veracidade = 'verde', contexto='contexto indefinido', tipo_credito = nil)
	if (sinal_veracidade == nil) or (not File.exist? get_xls_cpfs_risco)
		write_rsi_log "Vai chamar site_obter_cpf, pois sinal_veracidade=#{sinal_veracidade} ou arquivo #{get_xls_cpfs_risco} nao existe. DARÀ ERRO PROVÀVEL NO PASSO 4."
		return site_obter_cpf(sinal_veracidade, contexto)
	else
		write_rsi_log "2017Dezxx - deixa valor #{get_cpf_obterorisco }, e obtencao de cpf real é feita durante fluxo de digitacao/confirmacao"
		return get_cpf_obterorisco 
	end
end


def site_obter_cpf(sinal_veracidade = 'verde', contexto='contexto indefinido') #nil = NAO APLICAVEL: 'não testável'
	if SOMENTE_GERAR_COM_CPFS_RISCO_ENCONTRADO
		if (not ($superdigital_outrosistema and contexto.include? 'Superdigital') and (not contexto.include? 'adiciona_cpfs_de_risco_indefinido') )
			raise "RISCO DE QUEIMAR MASSA DE CPFS ERRONEAMENTE - site_obter_cpf chamado com SOMENTE_GERAR_COM_CPFS_RISCO_ENCONTRADO=#{SOMENTE_GERAR_COM_CPFS_RISCO_ENCONTRADO} e contexto=#{contexto}!!!"
		end
	end
	cpf = pop_cpf(sinal_veracidade)
	if cpf
		return cpf
	end

	if true
		cpf = 'a' * 11 #nem mesmo sao numéricos, os digitos: boa forma segura de começar sempre com cpf indesejado
	else
		if sinal_veracidade == nil
			cpf=get_random_cpf(9) #começca com cpf indesejado
		elsif sinal_veracidade == 'verde'
			cpf=get_random_cpf(1) #começca com cpf indesejado
		else
			cpf=get_random_cpf(1) # #começca com cpf indesejado
		end
	end

	if HACKS_DEBUG_MASSA_ENABLED and false #faLSE = DESABILITA ESTE HACK 
		 # DEBUG HACK pra acelerar, debug hack! NAO DEVE FAZER RETURN AQUI em codigo real
		write_rsi_log :debug, "DEBUG HACK pra acelerar, debug hack! NAO DEVE FAZER RETURN AQUI em codigo real"
		return cpf
	end

 	while not condicao_veracidade(sinal_veracidade,cpf)
		write_rsi_log :debug, "NO LOOP em (def site_obter_cpf), obtendo CPF do site, sinal_veracidade=#{sinal_veracidade}"
		cpf = obter_cpf_do_site
		
		#push_cpf cpf, sinal_veracidade

		if HACKS_DEBUG_MASSA_ENABLED and false #faLSE = DESABILITA ESTE HACK  #TODO OBS: em 2017Ago8, obter cpf da pagina de gerador pareceu lento... checar
			write_rsi_log :debug, "cpf a ser utilizado=#{cpf}, 2017Ago7 e Ago31 - (HACK ??) - nao ligamos ainda pra veracidade, RETORNANDO IMEDIATAMENTE, "
			return cpf
		else

			#write_rsi_log :debug, "2017Ago31/Set01 - com veracidade, ligaremos pro fluxo todo. 1=VERDE, 9=VERMELHO"
		end
	end
	#cpf = pop_cpf(sinal_veracidade)
	write_rsi_log :debug, "cpf a ser utilizado=#{cpf}"
	return cpf
end

def obter_cpf_do_site
	cpf='1234567890x'
	while (not CPF_CORTANA_ULTIMOS_DIGITOS_VALIDOS.include?(cpf[10])) do
		begin
			cpf = gerar_cpf(0,1) 
			#gerar_cpf(1) = *)gerar cpf válido; *)nao fixa digito.
			#rbattaglia 2018Out5 - nao chama mais gerar_cpf fixando digito de veracidade! Desde 2018Julho27, a mudança feita estava engessada, servindo apenas para veraciade verde (8o digito='1')
			 #rboker, 2018Julho27, nao usa mais site gerador de cpf 
		end while cpf[0]=='0' #2018Ago02 - nao considerando cpfs que começam com '0' pois muitos são inválido
=begin
		raise 'Codigo morto abaixo, nao busca mais cpf do site mas sim de rotinas de cpf_utils.rb'

		(find :id, 'btn-gerar-cpf').click  #ago13, find -> first, FAST 
		cpf=(find :id, 'numero').value  #ago13, find -> first, FAST
=end
		write_rsi_log :debug, "obter_cpf_do_site , obtido cpf #{cpf}, vai bater ult. digito com CPF_CORTANA_ULTIMOS_DIGITOS_VALIDOS=#{CPF_CORTANA_ULTIMOS_DIGITOS_VALIDOS}"
	end
	write_rsi_log :debug, "obter_cpf_do_site , retornado cpf #{cpf}"
	return cpf
end

def get_a_renda
	if (HACKS_DEBUG_MASSA_ENABLED and true)  #faLSE = DESABILITA ESTE HACK 
		write_rsi_log :debug, "DEBUG HACK - retornando menos ou alternativas faixas de renda a_renda"
		a_renda = [
		    [0, 499, 0],
		    nil, #[500, 1199, 1]
		    nil, #[1200, 3999, 1]
		    nil, #[4000, nil, 3]
		]
	else
		a_renda = [
	 		[0, 499, 0],
			[500, 1199, 1],
			[1200, 3999, 2], #2018Mai22, cada faixa de renda realmente com apenas um elemento.
			[4000, nil, 3]
		]
	end
end

def get_a_universitarios
	#2018Jun26 - voltando de OCUPACOES pra UNIVERSITARIO S/N
	#2018Jun14 - retornando Ocupacoes , simplificado: Trabalho+Univ,SN... #2018Mai22 - trocando TABELA DE OCUPACOES por UNIVERSITARIO?(S/N)
	if HACKS_DEBUG_MASSA_ENABLED and false #faLSE = DESABILITA ESTE HACK 
		write_rsi_log :debug, "debug_hack, manipulando retorno de get_a_universitario"

		a_universitarios = [
			nil,
			nil
		]
	else
		a_universitarios = [
			#Em 2018Jun27 e 2018Jun28 antes de 15:11 tava invertido, Fora x Sou. Arrumei. 
			'Fora de universidade',
			'Sou universitario'
		]

	end
	return a_universitarios
end



def get_a_ofertas_padrao
	if (HACKS_DEBUG_MASSA_ENABLED and false) #faLSE = DESABILITA ESTE HACK 
	
		write_rsi_log :debug, "debug hack - retornando get_a_ofertas_padrao modificado"
		a_ofertas_padrao = [
			nil,#'Pacote Padronizado 1',
			nil,#'Pacote Padronizado 2',
			nil,#'Pacote Padronizado 3',
			nil, #'Pacote Padronizado 4',
			nil #'Serviços Essenciais'
		]
	else
		a_ofertas_padrao = [
			'Pacote Padronizado 1',
			'Pacote Padronizado 2',
			'Pacote Padronizado 3',
			'Pacote Padronizado 4'
		]
	end
end

def get_a_pacote_ofertas_de_universitario(indice_pacote_ofer, i_universitario)
	a_pacote_ofertas = get_a_pacote_ofertas_todos_universitarios

	a_ofertas_padrao = get_a_ofertas_padrao

	a_ofer = a_pacote_ofertas[indice_pacote_ofer][i_universitario] 

	a_ofer = a_ofer + a_ofertas_padrao

	a_ofer = a_ofer.uniq #2018Mai22, novo carrossel tem 'Padronizado 3' tanto em pacotes  


	if HACKS_DEBUG_MASSA_ENABLED and false #faLSE = DESABILITA ESTE HACK 

		write_rsi_log :debug, "debug_hack - manipulando retorno em get_a_pacote_ofertas_de_universitarioSN"

		write_rsi_log :debug, "debug_hack - get_a_pacote_ofertas_de_universitarioSN - retornando apenas 2 pacotes, + 1 padrao"
		retval = a_ofer[0..2]
	else
		retval =  a_ofer
	end


	return retval
end

def get_a_pacote_ofertas_todos_universitarios
	a_pacote_ofertas = [
		 #0 a 499

			[
			 	["Serviços Essenciais", "Superdigital"],  #UNIV=NAO
			 	["Serviços Essenciais", "Conta Universitária"] #UNIV=SIM #2018Ago07 - sai SuperDigital, entra Conta Universitária. 
			], # [0]

		 #500 a 1199
			[
				["Pacote Padronizado 3", "Serviços Essenciais"],  #UNIV=NAO
				["Conta Universitária" , "Serviços Essenciais"] #UNIV=SIM
			], # [1]

		#1200 a 3999
			[
				["Pacote Padronizado 3", "Serviços Essenciais"],  #UNIV=NAO
				["Conta Universitária" , "Serviços Essenciais"] #UNIV=SIM
			], #[2]

		 #4000 e >
			[
				["Santander Van Gogh"  , "Serviços Essenciais"] , #UNIV=NAO
				["Conta Universitária" , "Serviços Essenciais"] #UNIV=SIM
			] # [3]

	]

	if HACKS_DEBUG_MASSA_ENABLED and false #faLSE = DESABILITA ESTE HACK 
		write_rsi_log "debug_hack - manipulando retorno de get_a_pacote_ofertas_todos_universitarios"

		return a_pacote_ofertas[faca_algo_aqui]
	else
		return a_pacote_ofertas
	end

end

def converte_cartao_old_para_new(o)
	#para podeer ler planilha original da P.O , e gerar massa e features/opcoes com novo texto
	tab={
		'Cartão Débito' => 'CARTÃO DÉBITO',
		'Cartão Free' => 'SANTANDER FREE',
		'Cartão Play' => 'SANTANDER PLAY',
		'Cartão 123' => 'SANTANDER 1, 2, 3',
		'Cartão Elite' => 'SANTANDER ELITE PLATINUM',
		'Cartão Platinum' => 'SANTANDER ELITE PLATINUM',
		'Cartão Unique' => 'SANTANDER SELECT UNIQUE BLACK' #2017Ago18am - mapa incompleto! requer IF adiante
		#elementos ausentes nao necessitam de conversao. Em 2017Ago16, restringe-se a "nao testável"
	}
	s = o['Cartão']
	novo = tab[s]

    #write_rsi_log_debug "converte_cartao_old_para_new, s=#{s}, o[[Pacote de ofertas']=#{o['Pacote de ofertas']}, o=#{o}"
	if s=='Cartão Unique' and (not o['Pacote de ofertas'].downcase.include? 'select') 
		# ENTAO... Cartao Unique chama-se SANTANDER UNIQUE BLACK, pra todos pacotes exceto *SELECT*   
		novo = 'SANTANDER UNIQUE BLACK'
	end

	return novo || s

end






PERCENTUAIS = {
	#    OBS: as quantidades sao arredondadas todas pra baixo...
	#    A sobra de inexatidao gerada vai toda pra 1a percentagem, que tende a ter quantidade
	# de registros distorcida pra cima

	:veracidade   => PERCENTUAIS_VERACIDADE,
	:pastadigital => PERCENTUAIS_PASTADIGITAL,
	:qualapp      => PERCENTUAIS_QUALAPP,
	:trabalho     => PERCENTUAIS_TRABALHO,
	:estado_civil => PERCENTUAIS_ESTADO_CIVIL
}

def deve_gerar_percentual(distribuicao, qual, total, num_reg_atual)
	write_rsi_log :debug, "INI deve_gerar_percentual(distribuicao, qual, total, num_reg_atual), distribuicao=#{distribuicao}, qual=#{qual}, total=#{total}, num_reg_atual=#{num_reg_atual}"

	if not defined? $pct_distrib
		$pct_distrib = Hash.new
	end

	if $pct_distrib[distribuicao] == nil

		qtds_cada_chave=Hash.new
		
		rev_keys = PERCENTUAIS[distribuicao].keys.reverse
		#puts "rev_keys=#{rev_keys}, rev_keys.length=#{rev_keys.length}"
		tot_calc = 0

		(rev_keys.length-1).times  {|k| 
			#recerse pra pear 1o as menos significantes
			#
			key = rev_keys[k]
			#puts "k=#{k}, key=#{key}"
			if PERCENTUAIS[distribuicao][key] == 0 #garante que 0% e 100% sejam precisos
				qtds_cada_chave[key] = 0
			elsif PERCENTUAIS[distribuicao][key] == 100 #garante que 0% e 100% sejam precisos
				qtds_cada_chave[key] = total
			else
				qtds_cada_chave[key] = (PERCENTUAIS[distribuicao][key]/100.0*total).to_i
			end
			tot_calc = tot_calc + qtds_cada_chave[key]
		}
		qtds_cada_chave[rev_keys[rev_keys.length-1]] = total - tot_calc #resíduo, sobra
		
		#puts qtds_cada_chave	

		$pct_distrib[distribuicao] = Array.new
		qtds_cada_chave.keys.each {|key|
			qt=qtds_cada_chave[key]
			qt.times { |k|
				$pct_distrib[distribuicao] << key
			}
		}
		
		#######################
		##
		########### EMBARALHA a distribuicao, evita viés sequencial
		##      (TODO 2017Set23 - poderia ser melhor, evitando grande quantidade de regs com )   
		#       mesmo valor, seguidos, um após o outro! ESTUDE distribuicao!!!!   
		#
		#

		$pct_distrib[distribuicao].shuffle! 
		###
		##
		##############

		#puts "$pct_distrib[#{distribuicao}] = #{$pct_distrib[distribuicao]}"
	end

	retval = false
	na_posicao = $pct_distrib[distribuicao][num_reg_atual-1]
	#puts na_posicao
	if na_posicao == qual
		retval =  true
	end 

	write_rsi_log :debug, "retval = #{retval} pra qual=#{qual} e num_reg_atual=#{num_reg_atual} porque $pct_distrib[#{distribuicao}][#{num_reg_atual-1}] = #{na_posicao}"
	return retval
end

#t=75; t.times{|k| deve_gerar_percentual :pastadigital, :ok, t, k+1} 
#t=75; t.times{|k| deve_gerar_percentual :pastadigital, :devolvido, t, k+1} 
#t=75; t.times{|k| deve_gerar_percentual :pastadigital, :rejeitado, t, k+1} 


#t=99; t.times{|k| deve_gerar_percentual :veracidade, :verde, t, k+1} 
#t=99; t.times{|k| deve_gerar_percentual :veracidade, :vermelho, t, k+1} 

def get_dirname_massa(h, feature_name)
	dirname_massa = "#{h[:dirname_massa]}/V #{feature_name}"
	return dirname_massa
end

def get_fname_massa(h, feature_name)
	dirname_massa = get_dirname_massa(h, feature_name)
	nome_arq_xls = "#{dirname_massa}/massa.xls".encode('cp850')
	return nome_arq_xls
end	

def get_fname_feat(h, feature_name)
	dirname_feat = h[:dirname_feature]
	nome_arq_feature = "#{dirname_feat}/#{feature_name}.feature"
end

def gera_dados(h,v)
	write_rsi_log :debug, "gera_dados DEBUG 2018Mai22, P0000"
	$all_reduced_feature_names = [] if not $all_reduced_feature_names

	qualapp = "webdesktop"
	if deve_gerar_percentual(:qualapp, :mob, h[:total_de_registros], h[:count_geracao])
		qualapp = "mob"
	end

	#2018Jun27 - montagem de feature_name etc. MOVIDO DAQUI PARA FIM DO MÈTODO, para que possamos utilizar campos nao-default da massa de dados na composicao do nome da feature


	### INICIO, INICIALIZACAO DE CAMPOS DISTRIBUIDOS PERCENTUALMENTE 
	estado_civil = nil
	trabalho = nil
	pastadigital_status_documento = nil
	pastadigital_tipo_documento   = nil
	sinal_veracidade = nil
	### FIM, INICIALIZACAO DE CAMPOS DISTRIBUIDOS PERCENTUALMENTE 

	#2018Jun27 - removido código de reprocessamento tradicional manual! Envolvia massa_ult_trn e h[:reprocessamento] == 1

	#INICIO DE CODIGO DE OBTER E USAR CAMPOS DISTRIBUIDOS PERCENTUALMENTE
		
	#INICIO DE PERCENTUAL PASTA DIGITAL E VERACIDADE
	sinal_veracidade = "verde"
	pastadigital_status_documento = ''
	pastadigital_tipo_documento   = ''
	
	if deve_gerar_percentual(:veracidade, :vermelho, h[:total_de_registros], h[:count_geracao])
		sinal_veracidade = "vermelho"
	end	
	if sinal_veracidade == "verde"
		h[:count_geracao_verde] = h[:count_geracao_verde] + 1
		#
		#
		# LÒGICA FRÀGIL! Depende de pct_rejeitado ser <= pct_devolvido <= pct_ok 
		#
		if deve_gerar_percentual(:pastadigital, :rejeitado, h[:tot_regs_verde_calc], h[:count_geracao_verde])
			pastadigital_status_documento='rejeitado'
		elsif deve_gerar_percentual(:pastadigital, :devolvido, h[:tot_regs_verde_calc], h[:count_geracao_verde])
			pastadigital_status_documento='devolvido'
		end
		if pastadigital_status_documento and pastadigital_status_documento.length>0
			rd = Random.new.rand(0..PASTADIGITAL_DOCUMENTOS.length-1)
			pastadigital_tipo_documento = PASTADIGITAL_DOCUMENTOS[rd]
			write_rsi_log :debug, "pastadigital_tipo_documento=#{pastadigital_tipo_documento}"
		end
	end 
	#FIM DE PERCENTUAL PASTA DIGITAL E VERACIDADE

	#INICIO DE PERCENTUAL TRABALHO
	trabalho = "Eu trabalho"
	if deve_gerar_percentual(:trabalho, :nao, h[:total_de_registros], h[:count_geracao])
		trabalho = "Nao trabalhando"
	end
	#FIM DE PERCENTUAL TRABALHO

	#INICIO DE PERCENTUAL ESTADO CIVIL
	estado_civil = "Solteiro"
	if deve_gerar_percentual(:estado_civil, :casado, h[:total_de_registros], h[:count_geracao])
		estado_civil = "Casado"
	elsif deve_gerar_percentual(:estado_civil, :divorciado, h[:total_de_registros], h[:count_geracao])
		estado_civil = "Divorciado"
	elsif deve_gerar_percentual(:estado_civil, :uniao_estavel, h[:total_de_registros], h[:count_geracao])
		estado_civil = "União estável"
	elsif deve_gerar_percentual(:estado_civil, :viuvo, h[:total_de_registros], h[:count_geracao])
		estado_civil = "Viúvo"
	elsif deve_gerar_percentual(:estado_civil, :separado, h[:total_de_registros], h[:count_geracao])
		estado_civil = "Separado"
	end

	#FIM DE PERCENTUAL TRABALHO

	#FIM DE CODIGO DE OBTER E USAR CAMPOS DISTRIBUIDOS PERCENTUALMENTE



	if h[:gerar_massa]
		massa_qualapp = qualapp





		massa_nice = v[:nice]

		massa_incluir_cartao='1'
		if v[:tipo_cred] == 'Débito'
			#cartao = 'SemCartão #MESMO sem CartaoCredito usamos NOME DO CARTAO!
			massa_incluir_cartao='0' #2017Set01, ISTO FAZ DIFERENÇA???
		end

		massa_renda = (v[:renda_ini] ||0)
		if v[:renda_fim] > v[:renda_ini]
			massa_renda = massa_renda + 100 #2017Dez28 - cenarios alternativos, para Robô Kaio
		end
		

		if not v[:oferta].downcase.include? 'select'
			massa_cep = '04534001'
		else
			massa_cep = '04534001' #a mesma   #antes de 2018Abr21, era '05726140'
		end
		massa_pacote = v[:oferta]					
		
		massa_cartao = v[:cartao]
		massa_tipo_credito = v[:tipo_cred]

		massa_texto_cartao_checar = obter_texto_cartao_checar(massa_tipo_credito, massa_cartao)
		
		write_rsi_log "chamando obter_cpf com parametros #{sinal_veracidade} e #{massa_tipo_credito}"
		massa_cpf = obter_cpf(sinal_veracidade, "gera_dados", massa_tipo_credito) #2017Set3 - passando sinal_veracidade, tipo_credito
		if massa_cpf == nil
			#2017Out18
			massa_cpf='00000000000' #menos arriscado que nao gerar: nao deturpa possivel contagem
		end

		massa_universitario = v[:universitario]
		massa_nome='Darcy Oliveira da Silva'
		massa_genero='Feminino'
		#massa_email='p000rdatovo@prservicos.com.br'
		nome_fake = Faker::Name.name
		nome_fake = get_alphanumeric(nome_fake).downcase
		num_random=Random.new.rand(1..100)
		massa_email="#{nome_fake}#{num_random}@hotmail.com" #2017Set28 - evitando recente e súbito EMAIL INVÀLIDO da aplicacao
		if File.exist? '../email_funciona.txt'
			massa_email = File.read('../email_funciona.txt').split("\n").first.strip
			#2017Set29 - email aceito instável. Portanto, tanto massa quanto PAGEOBJ leram txt 
		end
		massa_celular='(61) 99651-7833'
		massa_token='99999'
		massa_data_nascimento='11011998'
		massa_rg='171590557'
		massa_orgao_emissor='SSP/SP'
		massa_data_emissao='10012010'
		massa_nome_da_mae='Maria da Silva'

		massa_nome_conjuge='Marcia Fernandez' #incondicional, mesmo se solteiro
		massa_empresa = 'Teste'  #mesmo se "nao trabalho" etc., incondicional
		massa_profissao='Administrador' #mesmo se "nao trabalho" etc., incondicional
		massa_instituicao_ensino='USP - UNIVERSIDADE DE SÃO PAULO' #incondicional, mesmo se nao estudo, nao fiz faculdade etc.
		massa_curso='ADMINISTRACAO' #indondicional, mesmo se nao estudo/nao fiz faculdade
		massa_inicio_curso = '02022017'  #indondicional, mesmo se nao estudo/nao fiz faculdade
		massa_termino_curso = '02122023'  #indondicional, mesmo se nao estudo/nao fiz faculdade
		massa_dia_vencimento_ccred='02' #incondicional, mesmo que sem cartao de credito
		massa_comprovante_residencia='luz'

		massa_estado_civil = estado_civil
		massa_trabalho = trabalho



		massa=Hash.new
		massa['QUALAPP'] = massa_qualapp
		massa['NICE'] = massa_nice

		#bEGIN - 2018Mar11 - reprocessamento/reinsercao/faseamento
		if true #2018Jan27 - sempre reprocessamento NEW_STYLE inaugurado por z_proc, mesmo que rodando fora de zs_proc. 
			massa['STEP_INICIAL']='0' if ( (not massa['STEP_INICIAL']) and ENV['TEST_FASES_STEPSFINAIS'])
			massa['STEP_FINAL']=ENV['TEST_FASES_STEPSFINAIS'].split('/').first if ( (not massa['STEP_FINAL']) and ENV['TEST_FASES_STEPSFINAIS'])
			massa['TENTATIVA']='1'
			massa['GLOBAL_TENTATIVA']='1' #2018Mai01 - limitando total de tentativas global, de todas fases
			#END - 2018Mar11 - reprocessamento/reinsercao/faseamento
			if false
				500.times {
					write_rsi_log "SETEI massa['STEP_INICIAL] e massa['STEP_FINAL'] para 10, para um teste isolado de TFC"
					massa['STEP_INICIAL']='10'
					massa['STEP_FINAL']='10'
				}
			end

		else
			falhar "FALTA ENV VAR TEST_FASES_STEPSFINAIS" 
			massa['STEP_INICIAL']='0'
			massa['STEP_FINAL']='10'
		end



		massa['RENDA'] = massa_renda
		massa['NOME'] = massa_nome
		#2018Mai01 - escolha de sobrescrever ou nao e tota logica de campos_adicionais movidas para depois de massa default  ##2017Mar07 - por enquanto, apenas CPF possivelmente sobrescrito dos campos preexistentes!
		massa['CPF'] = massa_cpf 
		massa['CEP'] = massa_cep
		massa['UNIVERSITARIO'] = massa_universitario
		massa['TRABALHO'] = massa_trabalho #added 2018Jun28 21:49, bugfix, faltava esta linha
		massa['EMAIL'] = massa_email
		massa['CELULAR'] = massa_celular
		massa['TOKEN'] = massa_token
		massa['PACOTE'] = massa_pacote
		massa['INCLUIR_CARTAO'] = massa_incluir_cartao
		massa['CARTAO'] = massa_cartao
		massa['TIPO_CREDITO'] = massa_tipo_credito
		massa['DATA_NASCIMENTO'] = massa_data_nascimento
		massa['RG'] = massa_rg
		massa['ORGÃO_EMISSOR'] = massa_orgao_emissor
		massa['DATA_DE_EMISSÃO'] = massa_data_emissao
		massa['NOME_DA_MÃE'] = massa_nome_da_mae
		massa['ESTADO_CIVIL'] = massa_estado_civil
		massa['NOME_CONJUNGE'] = massa_nome_conjuge
		massa['PROFISSAO'] = massa_profissao
		massa['EMPRESA'] = massa_empresa
		massa['INSTITUICAO_ENSINO'] = massa_instituicao_ensino
		massa['CURSO'] = massa_curso
		massa['INICIO'] = massa_inicio_curso
		massa['TERMINO'] = massa_termino_curso
		massa['DIA_VENCIMENTO'] = massa_dia_vencimento_ccred if v[:tipo_cred] == 'Múltiplo'
		massa['COMPROVANTE DE RESIDENCIA'] = massa_comprovante_residencia
		massa['SINAL DE VERACIDADE'] = sinal_veracidade
		massa['PASTADIGITAL_TIPO_DOCUMENTO'] = pastadigital_tipo_documento
		massa['PASTADIGITAL_STATUS_DOCUMENTO'] = pastadigital_status_documento
		massa['TEXTO_CARTAO_CHECAR'] = massa_texto_cartao_checar #2018Set19 - adicionada checagem de texto que deve estar presente em SaibaMais e em Confirmacao de cartao. Até 2018Set19 01:17am, apenas SANTANDER FREE é checado... se a massa estiver vazia nesse campo, nada é checado
		# @@@@CAMPOS ADICIONAIS INICIO
		#2018Mai01 - CPF precisa ser feito por lógiva de gerador, enquanto outros campos podem ser sobrescritos. SOLUCAO: mover novamente campos_adicionais para depois de logica basica, mas nao sobrescrever CPF

		campos_adicionais = v.keys.select{|cpo| cpo.is_a? String}
		campos_adicionais.each do |cpo|
			if v[cpo] == 'DEFAULT#'
				#faz nada, nao sobrescreve. Usar '@DEFAULT' para indicar que queremos usar valores calculados automaticamente, ou nil se nao houve cálculo
			elsif v[cpo] == 'NIL#'
				#FORÇA Ruby-nil, removendo chame do hash massa
				massa.delete cpo
			elsif cpo == 'CPF'
				#nao sobrescrever valor calculado do CPF, usar sempre calculado
			else
				massa[cpo] = v[cpo] 	
			end
		end
		#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ CAMPOS ADICIONAIS FIM
		
	end #end if gerar_massa




	write_rsi_log :debug, "gera_dados INICIO DE PARTE COM FEATURE_NAME, OPCOES ETC."
	max_base_featurename_len = 40 #2018Mai04 - reduzido de 70 para 55 caracteres, preventivamente evitando erro de filenametoolong em zs_proc.rb  #2018Marxx - aumenta rolerancia, quero nome completo, ou quase, ao menos dos cenarios tradicionais
	write_rsi_log :debug, "gera_dados DEBUG 2018Mai22, P0002"
	the_guid = obtem_alphanum_guid(8)
	if v[:nome_da_feature] != nil
		core_featname = v[:nome_da_feature]
	else
		core_featname = "Renda(#{v[:renda_ini]} a #{v[:renda_fim]}), #{v[:universitario]}, #{v[:oferta]}, #{v[:cartao]}, #{v[:tipo_cred]}"
	end
	### INICIO de campos da feature, customizado
	if v[:campos_da_feature] != nil #2018Jun27 - customizacao de campos
	
#################### TODO 2018Jun29 - aplicar info tipo campos/nome da feature, se prefixado por marcador devido, a todas linhas em branco. Isso deve ser logo após a leitura de config_cenario.xls !!!!!!!!!!!!!!!!!!!!!!!!!

		if v[:campos_da_feature].start_with? 'X#' 
			if v[:nome_da_feature] == nil
				core_featname = '' #campos default nao vao pra nome da feature se campos_da_feature começar com X. Mas no caso de haver Nome da Feature customizado, esse é preservado.
			end
			v[:campos_da_feature] = v[:campos_da_feature][2..-1] #tira o X# já processado
		end
		cps_feat = v[:campos_da_feature].split('#')
		cps_feat.each_index do |i_cp_feat|
			if i_cp_feat == 0
				core_featname = core_featname + ', ' 
			end

			cp_feat = cps_feat[i_cp_feat]
			(cp, descr) = cp_feat.split(',').map{|e|e.strip}
			if descr != nil
				core_featname = core_featname + "#{descr}="
			end
			core_featname = core_featname + "#{massa[cp]}"
			if i_cp_feat < cps_feat.length - 1
				core_featname = core_featname + ', ' 
			end
		end #FIM LOOP, adicionar cada 1 dos Campos da Feature
	end	
	### TERMINO de campos da feature, customizado
	if v[:sufixo_da_feature] != nil
		#2018Jun26 - permite um sufixo definido no config_cenarios.xls ao nome da feature, por exemplo, ' baixa renda', 'sem trabalho fixo', 'longe de agencia' etc.
		core_featname = core_featname + ', ' + v[:sufixo_da_feature]
	end
	write_rsi_log :debug, "gera_dados DEBUG 2018Mai22, P0003"


	#core_featname_short = core_featname.gsub('.','').gsub(/[aeiou]/i, '')[0..max_base_featurename_len-1]
	#######2018Abr01- diminuicao de tabalho para max_base_featurename_len revamped. Pega alphanum, e entao, enquanto aida for maior, vai retirando caracteres aleatorios até caber em max_base_featurename_len caracteres
	core_featname_short = get_alphanumeric(core_featname).gsub('Renda','Rnd') #2018Mai11 - removido truncagem pra gsub tirando vogais, preservando troca de "Renda" por "Rnd" da qual scripts de checagem depende
	core_featname_short = core_featname_short.gsub('X','') # 2018Ago17 pm, SAFETY: nao pode ter caracter 'X' no nome da feature neste ponto, pois X é um marcador de "fim de Nice'" 
	write_rsi_log :debug, "gera_dados DEBUG 2018Mai22, P0004"

	
	preserve_words = [] #2018Jun27 - ['Rnd'] , preservacao retirada. Dá erro com cenarios de nomes customizados sem os campos default. Pense em alternativa! #2018Mai05 - usado por bash scripts e grep etc. em ferramentas de sustentacao, como um marcador fácil de início de nome de feature. Entao, nao queremos remover/adulterar 'Rnd' da string.
	
	while true
		write_rsi_log "gera_dados DEBUG 2018Mai22, P0005.000, loop ini, core_featname_short.length=#{core_featname_short.length}, core_featname_short=#{core_featname_short}"
		if core_featname_short.length <= max_base_featurename_len and (not $all_reduced_feature_names.include? core_featname_short)
			break
		end

		#2018Mai22 - revamp do loop de reducao + unique

		if core_featname_short.length > max_base_featurename_len
			new_core_featname_short = str_short_random(core_featname_short, max_base_featurename_len, preserve_words)
		else
			#duplicate! Já está no tamanho certo mas existe na lista q deve ter uniques!
			new_core_featname_short = core_featname_short + 'Z' 
			#'+ Z' apenas para desambiguar. Pode acontecer várias vezes, até que eventualmente precise de reducao de tamanho. Caso extremo, mas atendido.
		end

		write_rsi_log :debug, "gera_dados DEBUG 2018Mai22, P0005 - EM LOOP, max_base_featurename_len=#{max_base_featurename_len}, preserve_words=#{preserve_words}, core_featname_short=#{core_featname_short}, new_core_featname_short=#{new_core_featname_short}, $all_reduced_feature_names.length=#{$all_reduced_feature_names.length}"
		core_featname_short = new_core_featname_short
	end
	$all_reduced_feature_names << core_featname_short #2018Mai05 - evita duplicidade no nucleo do nome da feature

	write_rsi_log :debug, "gera_dados DEBUG 2018Mai22, P0005"
	full_feature_name = "App=#{qualapp},#{core_featname}, guid #{the_guid}" 
	feature_name = get_alphanumeric("Nice #{v[:nice]} X, #{core_featname_short}, guid #{the_guid}")
	write_rsi_log :debug, "gera_dados - feature_name, P100, the_guid=@#{the_guid}@, core_featname=@#{core_featname}@, core_featname_short=@#{core_featname_short}@, feature_name=@#{feature_name}@ full_feature_name=@#{full_feature_name}@"
	write_rsi_log :debug, "gera_dados INICIANDO FINALIZANDO COM FEATURE_NAME, OPCOES ETC."


	if h[:gerar_massa]

		dirname_massa = get_dirname_massa(h, feature_name)
		write_rsi_log :debug, "gerador_massa.rb, Dir.pwd=#{Dir.pwd}, criando via mkdir_noexist o dirname=#{dirname_massa}"
		Dir["#{dirname_massa}*"].each{|d| FileUtils.rm_rf d}
		mkdir_noexist  dirname_massa
		# 2017Nov24 - protege reprocessamento - deleta diretorios dirname* (dir ant de massa em execucao) 
		nome_arq_xls = get_fname_massa(h, feature_name)

		escreve_xls_de_hash(nome_arq_xls,massa)
	end

	if h[:gerar_opcoes] #deve ser setada pra FALSE quando arquivo_opcoes passado para programa
		#
		#
		# linha_cenario: EXCLUSIVAMENTE PRA GERACAO DE OPCOES, NAO PREFIXADA POR qualapp
		#
		#
		linha_cenario = "#{v[:nice]},(#{v[:renda_ini]} a #{v[:renda_fim]}),#{v[:universitario]},#{v[:oferta]},#{v[:cartao]},#{v[:tipo_cred]}"
		linha_cenario_ptvirg = "#{v[:nice]};(#{v[:renda_ini]} a #{v[:renda_fim]});#{v[:universitario]};#{v[:oferta]};#{v[:cartao]};#{v[:tipo_cred]}"
		h[:f_o].write linha_cenario_ptvirg + "\n" 
	end
	write_rsi_log :debug, "gera_dados FINALIZANDO PARTE COM FEATURE_NAME, OPCOES ETC."

	if h[:gerar_features]
		full_path_feature = get_fname_feat(h, feature_name)
		cria_arquivo_feature(qualapp, full_path_feature, full_feature_name)
	end #end if gerar_feature
end

def get_lista_completa_opcoes(h)
	retval = nil
	if h[:arquivo_opcoes_input]
		write_rsi_log :debug, "get_lista_completa_opcoes(h) - vai retornar get_lista_opcoes_arquivo(h)"
		#2018Nov15 "QUALSPP EM FEATURE E CENARIO": 
		retval = get_lista_opcoes_arquivo(h)
	else
		write_rsi_log :debug, "get_lista_completa_opcoes(h) - vai retornar get_lista_opcoes_algoritmo(h)"
		#2018Nov15 "QUALSPP EM FEATURE E CENARIO": 
		retval = get_lista_opcoes_algoritmo(h)
	end
	#raise "see me, retval = #{retval}"
	return retval
end

def get_lista_opcoes_algoritmo(h)
	#2018Nov15 "QUALSPP EM FEATURE E CENARIO": Nao terá QUALAPP, aqui
	i=0

	retval = []
	v=Hash.new

	a_renda = get_a_renda
	a_renda.each_index do |i_renda|
		write_rsi_log :debug, "a_renda[#{i_renda} = #{a_renda[i_renda]}"
		if a_renda[i_renda] == nil
			write_rsi_log :debug, "DEBUG HACK - vetor de rendas = indice #{i_renda} NIL, significa que nao serah processado"
			next
		end
		v[:nice]='0'

		(v[:renda_ini],v[:renda_fim], indice_pacote_ofer) = a_renda [i_renda]
		v[:renda_fim] = v[:renda_fim] || 1000000 #1 milhao por mês, HIVALUES
		#write_rsi_log :debug, "ATENCAO - renda_ini=#{renda_ini}, renda_fim=#{renda_fim}, indice_pacote_ofer=#{indice_pacote_ofer}"
		a_universitarios = get_a_universitarios
		a_universitarios.length.times do |i_universitario|
			if a_universitarios[i_universitario] == nil
				write_rsi_log :debug, "DEBUG HACK - vetor de universitarios = indice #{i_universitario} NIL, significa que nao serah processado"
				next
			end
			
			v[:universitario] = a_universitarios[i_universitario] 
			a_ofer = get_a_pacote_ofertas_de_universitario(indice_pacote_ofer, i_universitario)
			for v[:oferta] in a_ofer do
				if v[:oferta] == nil
					write_rsi_log :debug, "DEBUG HACK - uma das ofertas hacked pra nil, nao serah processada"
					next
				end

				for v[:tipo_cred] in obter_tipo_cred(v[:oferta])  do 		

					v[:cartao] = obter_cartao_cred_ou_deb(v[:tipo_cred], i_renda, v[:oferta])

					i = i + 1
					retval << v.clone
					#write_rsi_log :debug, "@@@@@@@@@@@@@@@@ v=#{v}, retval.length=#{retval.length}"


					#quando for ler do arquivo, adicionar tb em h[:nome_campo]
					#OBS: lendo de arquivo, RENDA sera string composta, TEREI Q FAZER PARSE
				end
			end
		end
	end		
	#write_rsi_log :debug, "retval=#{retval}"
	return retval
end


def get_campos_default_arquivo
	retval = [
		'Nice',
		'Faixa de renda',
		'Universitário',
		'Pacote de ofertas',
		'Cartão',
		'Tipo de crédito',
		'Nome da Feature', #added 2017Dez28
		'Campos da Feature', #added 2018Jun27
		'Sufixo da Feature' #added 2018Jun27
	]
end


def get_lista_opcoes_arquivo(h)
	#2018Nov15 "QUALSPP EM FEATURE E CENARIO": 


	opcoes_lidas_xls = ler_xls_com_id(h[:arquivo_opcoes_input], nil, nil, -1)
	write_rsi_log "get_lista_opcoes_arquivo, P01, opcoes_lidas_xls==nil=#{opcoes_lidas_xls==nil}"
	write_rsi_log "get_lista_opcoes_arquivo, P01, opcoes_lidas_xls.length=#{opcoes_lidas_xls.length}"
	opcoes_lidas_xls.select! {|o| ((o['UTILIZAR_MASSA']||'S').upcase)[0] != 'N'}
	write_rsi_log "get_lista_opcoes_arquivo, P02, opcoes_lidas_xls.length=#{opcoes_lidas_xls.length}"

	retval = []

	campos_adicionais = []
	if opcoes_lidas_xls.length > 0
		o=opcoes_lidas_xls.first
		campos_adicionais=o.keys.select {|nomecpo|
			not get_campos_default_arquivo.include?(nomecpo)   
		}
	end

	for o in opcoes_lidas_xls do
		v=Hash.new
		
		#LEIME LEIAME LEIAME LEIAME LEIAME 2018Jun14 COMMENT - v[:campos_default_blah] - muitos desses campos só servem para a montagem do nome da feature! AINDA QUERO TER FEATURE_NAME MAl-E-MAL COMPREENSIVEL, EM NOME DE ARQUIVO??? CORRO RISCO DE NON-UNIQUENESS ??? TODO - PENSE NUM REFACTORING DISSO!
		#2018Jun14 COMMENT - v[:campos_default_blah] - muitos desses campos só servem para a montagem do nome da feature! AINDA QUERO TER FEATURE_NAME MAl-E-MAL COMPREENSIVEL, EM NOME DE ARQUIVO??? CORRO RISCO DE NON-UNIQUENESS ??? TODO - PENSE NUM REFACTORING DISSO!
		#2018Jun14 COMMENT - v[:campos_default_blah] - muitos desses campos só servem para a montagem do nome da feature! AINDA QUERO TER FEATURE_NAME MAl-E-MAL COMPREENSIVEL, EM NOME DE ARQUIVO??? CORRO RISCO DE NON-UNIQUENESS ??? TODO - PENSE NUM REFACTORING DISSO!
		#2018Jun14 COMMENT - v[:campos_default_blah] - muitos desses campos só servem para a montagem do nome da feature! AINDA QUERO TER FEATURE_NAME MAl-E-MAL COMPREENSIVEL, EM NOME DE ARQUIVO??? CORRO RISCO DE NON-UNIQUENESS ??? TODO - PENSE NUM REFACTORING DISSO!
		#2018Jun14 COMMENT - v[:campos_default_blah] - muitos desses campos só servem para a montagem do nome da feature! AINDA QUERO TER FEATURE_NAME MAl-E-MAL COMPREENSIVEL, EM NOME DE ARQUIVO??? CORRO RISCO DE NON-UNIQUENESS ??? TODO - PENSE NUM REFACTORING DISSO!
		#2018Jun14 COMMENT - v[:campos_default_blah] - muitos desses campos só servem para a montagem do nome da feature! AINDA QUERO TER FEATURE_NAME MAl-E-MAL COMPREENSIVEL, EM NOME DE ARQUIVO??? CORRO RISCO DE NON-UNIQUENESS ??? TODO - PENSE NUM REFACTORING DISSO!


		#2018Jun18 - :app parece nunca usado #v[:app] = o['App'] #2018Jun18, nao estou mais seguro de :app etc.   
		#write_rsi_log "#2018Nov15 [QUALSPP EM FEATURE E CENARIO] - 
		v[:nice] = o['Nice']

		faixa_crua = o['Faixa de renda'].gsub('(','').sub(')','')
		if not faixa_crua.include?('a')
			#2017Dez30 - para Robô Kaio - valor exato, e não
			v[:renda_ini] = v[:renda_fim] = faixa_crua.to_i
		else
			(v[:renda_ini], v[:renda_fim]) = faixa_crua.split(' a ').map{|e| e.to_i} 
		end
		v[:renda_fim] = v[:renda_fim] || 1000000 #1 milhao por mês, HIVALUES


		###v[:renda_fim]=nil if v[:renda_fim]==0 #REMOVIDO 2017Dez28, para Robo Kaio

		v[:universitario] = o['Universitário']
		v[:oferta]=o['Pacote de ofertas']
		
		v[:cartao] = converte_cartao_old_para_new(o)
		v[:tipo_cred]=o['Tipo de crédito']

		v[:nome_da_feature]=o['Nome da Feature']
		v[:sufixo_da_feature]=o['Sufixo da Feature']
		v[:campos_da_feature]=o['Campos da Feature']

		campos_adicionais.each{|nomecpo|
			v[nomecpo] = o[nomecpo] #2017Dez28, para Robô Kaio
		}

		retval << v
	end 

	write_rsi_log "get_lista_opcoes_arquivo(h), retval=#{retval}"
	return retval
end

def get_header_opcoes
	#2018Nov15 [QUALSPP EM FEATURE E CENARIO] - get_header_opcoes somente para GERACAO DE ARQ DE OPCOES! Nao precisa de Ap=p / :app 

	return ['Nice', 'Faixa de renda','Universitário','Pacote de ofertas','Cartão','Tipo de crédito']
end


if ARGV.length == 0
	write_rsi_log "gerador_massa.rb, ARGV.length igual a zero, saindo"
	exit
end

write_rsi_log "ARGV=#{ARGV}"

qt_escolher = (ARGV[0].to_i if ARGV.length >= 1) # nao passado/0="gere todas possibilidades"
write_rsi_log "qt_escolher=#{qt_escolher}"
qt_escolher = nil if qt_escolher == 0 #passar parametro cmdline: 0 = TODOS !!
write_rsi_log "qt_escolher=#{qt_escolher}"
######## 
#######
#
### 2017Set3
####  se qt_escolher NEGATIVA, significa "apenas gerar XLS de CPFs", ou PROG EXTERNO p isso
#                ___ GERACAO: nao gera UM NOVO, mas faz APPEND NO XLS JA EXISTENTE!
#
#    Quantidade de cpfs PARA RISCO a gerar, entao, será qt_escolher VEZES menos um!
#
#   Pra ADICIONAR CPFS, podemos passar qquer nome de arquivo ARGV[2]
#   MAS... pra geracao de massa em si, é hardcoded cpfs_risco.xls !
# 
#######
#######

if $not_single_maq_zsproc_debug
	if false
		raise 'inicializa_gerador_cpf_org - nem existe mais'
	else
		write_rsi_log :debug, "rboker 2018Jul27 - rotinas proprias de gerar cpf cpf_utils.rb criado, nao usa mais site gerador de cpf"
	end
end

write_rsi_log "qt_escolher=#{qt_escolher}"
if qt_escolher and qt_escolher < 0
	adiciona_cpfs_de_risco_indefinido (-1 * qt_escolher), ARGV[1], ARGV[2]
	#quantidade
	#1=Crédito, 2=Crédito Adormecido, 3=Débito, ELSE=sortido
	#2=arquivo de cpfs de risco, XLS (default=cpfs_risco.xls)
	exit
end


h=Hash.new
write_rsi_log "ARGV[1]#{ARGV[1]}"
h[:arquivo_opcoes_input] = ARGV[1] #Se nao passado, gera das ARRAYS/logica interna. Se passo, baseia-se em arq.
write_rsi_log "h[:arquivo_opcoes_input]=#{h[:arquivo_opcoes_input]}"
h[:arquivo_opcoes_input] = nil if h[:arquivo_opcoes_input] and h[:arquivo_opcoes_input].gsub('"','').gsub(' ','')=='' #string "" também é considerada "sem arquivo de input"
write_rsi_log "h[:arquivo_opcoes_input]=#{h[:arquivo_opcoes_input]}"
if h[:arquivo_opcoes_input] and File.basename(h[:arquivo_opcoes_input]) == 'opcoes.xls'
	raise 'Nome de input proibido - opcoes.xls, mesmo nome que nome padrao de output de opcoes!!!' 
end
h[:arquivo_opcoes_input]=File.basename(h[:arquivo_opcoes_input]) if h[:arquivo_opcoes_input] #SEMPRE do diretorio corrente, ou seja, Planilhas e Controles
write_rsi_log "h[:arquivo_opcoes_input]=#{h[:arquivo_opcoes_input]}"

h[:gerar_opcoes] = true
if false
	h[:gerar_opcoes] = false if h[:arquivo_opcoes_input]
	#raise BESTEIRA! Posso ter XLS de input restringindo, e ainda assim querer gerar aleatorio
end
h[:gerar_massa] = true
h[:gerar_features] = true
#write_rsi_log :debug, "                       ´pressione qualquer tecla\n\n"
#gets

STR_NAO_TESTAVEL = 'não testável'



if false
	write_rsi_log :debug, "\n\n\n\n\n\n" + 
	"     Hmmm, serah que gostariamos, em vez de DIVIDIR entre verde e vermelho, MULTIPLICAR cenarios? E tem mais: \n" + 
	"ainda teremos mais componentes do Cenario, como [resposta de conta digital], [aprovacao no TFC] etc. \n\n" + 
	"     Se tivermos mais 3 componentes, cada um com 3 valores possiveis, sao NOVE VEZES mais combinacoes, \n" + 
	"elevando o numero de cenarios distintos dos atuais 2000 (4000 se vermelho/verde MULT) pra 18000 (32000 MULT). \n\n" +
	"     Claro, podemos usar aleatoriedade simples (FILTRO FINAL) prater numero menor de cenários, mas , assim, talvez\n"+
	"deixemos de testar algo absolutamente necessario.\n" + 
	"     Para evitar essa situacao, podemos ter NOVA ITERACAO INTERMEDIARIA NA GERACAO, definindo SCORE DE PRIORIDADE \n" + 
	"para cada cenario. MAS EU NAO FAÇO IDÈIA AGORA DE COMO definir esse score, nem de como usá-lo na filtragem final."
	write_rsi_log :debug, "\n\n\n\n              pressione qualquer tecla para continuar"
	#gets
end




if h[:gerar_massa]
	h[:dirname_massa] = '../massas_feature'
	mkdir_noexist h[:dirname_massa]
end

if h[:gerar_features]
	h[:dirname_feature] = "../features/auto"
	mkdir_noexist  h[:dirname_feature]
end


if h[:gerar_opcoes]
	nomearq_opcoes_txt = "opcoes.txt"
	h[:f_o] = File.open(nomearq_opcoes_txt, "w+t")
	h[:f_o].write get_header_opcoes.join(';')+"\n"
end

if false; 3.times {write_rsi_log :debug, "AINDA NAO TEMOS FONTE PRA MASSA DE Crétido Adormecido!! "} ; sleep 10; end
escolhidos = [] #para nao gerar todas opcoes, obterndoqt_escolher
total = 0

lista_completa_opcoes = get_lista_completa_opcoes(h)

total = lista_completa_opcoes.length

if qt_escolher
	write_rsi_log :debug, "qt_escolher not nil, entao, vai sortear alguns"
	while escolhidos.length < qt_escolher do
		write_rsi_log :debug, "dentro de while escolhidos.length(#{escolhidos.length}) < qt_escolher(#{escolhidos.length})"

		#gera qt_escolher cenarios aleatorios
		rd = Random.new.rand(1..total)
		write_rsi_log :debug, "rd=#{rd}"
		if not escolhidos.include? rd
			write_rsi_log :debug, "Adicionando rd=#{rd} a escolhidos, pq escolhidos nao continha rd"
			escolhidos << rd 
		end
	end
	escolhidos.sort!
	write_rsi_log :debug, "escolhidos #{qt_escolher} de #{total} cenarios, gerando array escolhidos = #{escolhidos}"

end 
h[:total_de_registros] = qt_escolher || total #2017Set23
h[:tot_regs_verde_calc] = (h[:total_de_registros] * (PERCENTUAIS_VERACIDADE[:verde]/100.0)).to_i #2017Set23
write_rsi_log :debug, "h[:total_de_registros] = #{h[:total_de_registros]}, h[:tot_regs_verde_calc]=#{h[:tot_regs_verde_calc]}" 

	
id = 0
h[:count_geracao] = 0
h[:count_geracao_verde] = 0

for v in lista_completa_opcoes do
		id = id + 1 

		if qt_escolher and (not escolhidos.include? id)
			write_rsi_log :debug, "vai ignorar (nao gera dados) , pra id=#{id} porque nao estah dentro dos #{qt_escolher} escolhidos de total #{total}"
			next #ignora cenario se queremos apenas alguns cenarios e nao estiver na lista
		end

		h[:count_geracao] = h[:count_geracao] + 1

		write_rsi_log :debug, "gerando_dados, lista_completa_opcoes.length=#{lista_completa_opcoes.length}, v=#{v}"
		gera_dados(h,v)
end

##
#
#
# 2017Nov23, nao reescreve mais arquivo XLSCPFS_RISCO aqui!
#
#


if h[:gerar_opcoes]
	h[:f_o].close

	book = Spreadsheet::Workbook.new
	sheet1 = book.create_worksheet
	header_format = Spreadsheet::Format.new(:weight => :bold, :horizontal_align => :center, :locked => true	)
	sheet1.row(0).default_format = header_format
	#system 'type opcoes.txt'
	#write_rsi_log :debug, "vai manipular csv"
	CSV.open(nomearq_opcoes_txt, 'r', :col_sep=>';') { |csv|csv.each_with_index { |row, i|sheet1.row(i).replace row}}
	
	nome_arq_xls = "opcoes.xls"
	#write_rsi_log :debug, "tentando chamar"
	book.write(nome_arq_xls)
	#write_rsi_log :debug, "OPCOES escrito, arquivo #{nome_arq_xls}"
end

