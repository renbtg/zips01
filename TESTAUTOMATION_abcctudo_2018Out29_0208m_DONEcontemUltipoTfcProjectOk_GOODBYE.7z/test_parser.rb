require 'cucumber/core/gherkin/parser'
#require 'cucumber/gherkin/formatter/json_formatter'
require 'stringio'
require 'multi_json'

# This example reads a couple of features and outputs them as JSON.

io = StringIO.new
#formatter = Gherkin::Formatter::JSONFormatter.new(io)
parser = Gherkin::Parser.new #(formatter)

sources = [Dir['features/auto/*.feature'].first]
sources.each do |s|
  puts "feat_file=#{s}" 
  feat_content=IO.read(s).encode('UTF-8')
  puts "feat_content=#{feat_content}"
  parsed=parser.parse(IO.read(s).encode('UTF-8'))
  #puts "parsed=#{parsed}, parsed.class=#{parsed.class}"
  nome=parsed[:feature][:name]
  puts "nome da feature=#{nome}"
end

#formatter.done
#puts MultiJson.dump(MultiJson.require_relative(io.string), :pretty => true)