require 'httparty'
require 'openssl'
require_relative 'features/support/rsi_log.rb'

OpenSSL::SSL::VERIFY_PEER = OpenSSL::SSL::VERIFY_NONE
write_rsi_log :debug, "abcd"
