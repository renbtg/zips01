def metodo_1
	puts "agora existe metodo 1"
end




while true
	begin
		metodo_1
	rescue StandardError => e
		puts "e=#{e}"
	end
	sleep 5
	load 'x.rb'
end
