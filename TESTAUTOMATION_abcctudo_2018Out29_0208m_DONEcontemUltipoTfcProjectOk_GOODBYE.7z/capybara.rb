# encoding: UTF-8
# TODOS requires têm que vir aqui antes, antes de IRB.start, para que o "main object" inclua as functions "globais" 
require 'irb'
require 'capybara/dsl';
include Capybara::DSL;
require 'rspec/expectations'
include RSpec::Expectations # Nao consigo fazer "expect do RSpec" funcionar no IRB

require_relative "features/support/rsi_utils.rb"



puts 'Antes de register_driver'

if true
	Capybara.register_driver :selenium do |app|
	  100.times {puts "capybara.rb, dentro de bloco register_driver"}
	  client = Selenium::WebDriver::Remote::Http::Default.new
  	client.timeout = 120 #2017Ago13 - visit, mais timeout: passar client em httpc_lient pra Capybara::Selenium::Driver.new 

      capabilities = Selenium::WebDriver::Remote::Capabilities.chrome(accept_ssl_certs: true) #2018Julho28 - bypassa aceitacao de certificado SSL invalido
	  retval = Capybara::Selenium::Driver.new(app, :browser => :chrome, :http_client =>client, desired_capabilities: capabilities)
	  puts "register_driver, retval.class=#{retval.class}"
	  retval
	end

	Capybara.default_driver = ARGV[0].to_sym
	Capybara.javascript_driver = ARGV[0].to_sym

	Capybara.configure do |config|
		10.times {puts "capybara.rb, bloco em Capybara.configure"}
		#Capybara.current_driver = :selenium
		config.default_max_wait_time = 20 #PRA ATUALIZACOES AJAX
	end

end
	def visitar(url='https://mobhk.portal.santanderbr.pre.corp')
		visit url
	end

ARGV.clear
IRB.start # leave the console idle
