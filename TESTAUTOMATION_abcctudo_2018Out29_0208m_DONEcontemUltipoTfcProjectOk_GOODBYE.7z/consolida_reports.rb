# encoding: UTF-8
require 'fileutils'
require "./rotinas_processo.rb"
require "./features/support/rsi_log.rb"
require "./html_from_json.rb"



#echo off



def consolida_core(argv)

	if true
		write_rsi_log :debug, "GAMBIARRA - nao removendo reports/c"
	else
		FileUtils.rm_rf 'reports/c'
	end

	FileUtils.rm Dir['reports/*.json'] 
	FileUtils.rm Dir['reports/*.png'] 

	param_feat_dir = argv[0]
	param_feat_dir.gsub('\\','/').chomp('/') #troca barra invertida por barra normal, e tira a ultima barra

	argv_repots_dir = argv[1]
	argv_repots_dir.gsub('\\','/').chomp('/') #troca barra invertida por barra normal, e tira a ultima barra



	
	dest_report_dir = "#{argv_repots_dir}/c"
	mkdir_noexist dest_report_dir
	if true
		write_rsi_log "GAMBIARRa - nao deletando #{dest_report_dir}"
	else
		delete_all_in_dir dest_report_dir
	end

	ruby_file_definindo_qual_trn_reportar = argv[2]
	require ruby_file_definindo_qual_trn_reportar if ruby_file_definindo_qual_trn_reportar #isso mesmo, passar um arquivo ".rb" q tem a definicao do método, metodo qual_trn_reportar




	cleanup_de_features_interrompidas(param_feat_dir) #ISSO, tbm faz clneanup em consolidacao de reports 

	a_feature_names = lista_de_features_finalizadas_ausentes_da_fila(param_feat_dir)

	write_rsi_log :debug, "consolida_reports.rb : a_feature_names=#{a_feature_names}"
	write_rsi_log :debug, "consolida_reports.rb : a_feature_names.length=#{a_feature_names.length}"
	write_rsi_log :debug, "consolida_reports.rb : a_feature_names.uniq.length=#{a_feature_names.uniq.length}"

	a_feature_names.each do |feature_name|
		dest_report_feat = "#{argv_repots_dir}/c/#{feature_name.gsub(",", "").gsub(" ", "").gsub(";", "")}"
		if File.directory? dest_report_feat
			write_rsi_log "next, pois JA EXISTE diretorio #{dest_report_feat}"
			next
		elsif false
			write_rsi_log :debug, "GAMBIARRA - nao processando, apenas constatando q nao existe diretorio #{dest_report_feat}"
			next
		else
			#NORMAL, processando
		end

		
		trn_reportar = nil
		#maxtrn_desta_feature = max_trn_da_feature(param_feat_dir, feature_name)
		all_outputs =  get_test_outputs_da_feature(param_feat_dir, feature_name) #, maxtrn_desta_feature)
			# qual_trn_reportar blabla
			#
			# DEFINE DE FORMA REFINADA trn_reportar
			#
			#
		if not all_outputs
			write_rsi_log :debug, "all_outputs nil para feature_name=#{feature_name}, mesmo feature tendo vindo de metodo lista_de_features_finalizadas_ausentes_da_fila !"
			next
		end
		trn_reportar = qual_trn_reportar(feature_name,all_outputs) #simplorio LAST=get_max_trn_da_feature(param_feat_dir, feature_name) 
		write_rsi_log :debug, "trn_reportar=#{trn_reportar}"	

		trn_outputs = all_outputs.select{|o|o[:trn]==trn_reportar}[0][:outputs]



		######################
		#
		# LEGAL! Sao 257 reports... e tbm tem 275 unique features.
		# na rerun da Julia de Ago25 (LAsT TOUCH), que gerei report
		# consolidado em Ago27-DOMINGO
		# find features/ -name *.feature* |sed "s/TRN\..*//g"  |sed "s/.*\///g" |sed "s/\.TRN.*//g" |sort -u |wc -l
		# deu 275... legal!
		#############


		write_rsi_log :debug, "consolida_reports.rb : trn_reportar=#{trn_reportar}"
		write_rsi_log :debug, "consolida_reports.rb : trn_outputs.class=#{trn_outputs.class}, trn_outputs=#{trn_outputs}"
		write_rsi_log :debug, "consolida_reports.rb : trn_outputs[:json_report]=#{trn_outputs[:json_report]}"
		write_rsi_log :debug, "consolida_reports.rb : trn_outputs[:featname_log]=#{trn_outputs[:featname_log]}"

	#QUE MERDA! Nao imprime json_report , APESAR tr trn_outputs ter chave!

		jr=trn_outputs[:json_report]
		hr=trn_outputs[:html_report]
		tfcscrshots=trn_outputs[:tfc_screenshot]
		pngscrshots=trn_outputs[:png_screenshot]
		deskscrshot=trn_outputs[:desktop_screenshot]
		desktfcscrshot=trn_outputs[:desktoptfc_screenshot]
		htmlscrshot=trn_outputs[:html_screenshot]
		arq_massa=trn_outputs[:arquivo_massa]
		featname_log=trn_outputs[:featname_log]
		featnametfc_log=trn_outputs[:featnametfc_log]

		write_rsi_log :debug, "consolida_reports.rb jr=#{jr}"
		write_rsi_log :debug, "consolida_reports.rb pngsc=#{pngscrshots}"

		#dest_report_dir = "#{argv_repots_dir}/c/Report_#{feature_name}"
		#mkdir_noexist dest_report_dir; delete_all_in_dir dest_report_dir


		mkdir_noexist dest_report_feat
		dest_dir_scr = "#{dest_report_feat}/scrshot"
		mkdir_noexist dest_dir_scr

		######## COPIA APENAS O JSON, por enquanto

		if File.exist? jr #2017Nov17 - somente copia se existir
			FileUtils.cp jr, "#{dest_report_feat}/report_json.json"
		end

		if File.exist? hr
			write_rsi_log :debug, "consolida_reports.rb copiando arquivo #{hr} para #{dest_report_dir}"
			FileUtils.cp hr, "#{dest_report_feat}/report_html.html"
		else
			write_rsi_log :debug, "consolida_reports.rb ARQUIVO NAO ENCONTRADO - #{hr}"
		end

		deskscrshot    = [deskscrshot]    if deskscrshot.class    == String
		desktfcscrshot = [desktfcscrshot] if desktfcscrshot.class == String
		tfcscrshots    = [tfcscrshots]    if tfcscrshots.class    == String
		pngscrshots    = [pngscrshots]    if pngscrshots.class    == String
		(deskscrshot+desktfcscrshot+tfcscrshots+pngscrshots).each do |scrshot|
			if File.exist? scrshot
				
				write_rsi_log :debug, "consolida_reports.rb copiando arquivo #{scrshot} para #{dest_dir_scr}"
				FileUtils.cp scrshot, dest_dir_scr

			else
				write_rsi_log :debug, "consolida_reports.rb ARQUIVO NAO ENCONTRADO - #{scrshot}"
			end
		end

		if File.exist? htmlscrshot
			write_rsi_log :debug, "consolida_reports.rb copiando arquivo #{htmlscrshot} para #{dest_report_feat}"
			FileUtils.cp htmlscrshot, dest_report_feat
		else
			write_rsi_log :debug, "consolida_reports.rb ARQUIVO NAO ENCONTRADO - #{htmlscrshot}"
		end
		if File.exist? arq_massa
			write_rsi_log :debug, "consolida_reports.rb copiando arquivo #{arq_massa} para #{dest_report_feat}"
			FileUtils.cp arq_massa, "#{dest_report_feat}/massa.xls"
		else
			write_rsi_log :debug, "consolida_reports.rb ARQUIVO NAO ENCONTRADO - #{arq_massa}"
		end
		if File.exist? featname_log
			write_rsi_log :debug, "consolida_reports.rb copiando arquivo #{featname_log} para #{dest_report_feat}"
			FileUtils.cp featname_log, "#{dest_report_feat}/log.log"
		else
			write_rsi_log :debug, "consolida_reports.rb ARQUIVO NAO ENCONTRADO - #{featname_log}"
		end
		if File.exist? featnametfc_log
			write_rsi_log :debug, "consolida_reports.rb copiando arquivo #{featnametfc_log} para #{dest_report_feat}"
			FileUtils.cp featnametfc_log, "#{dest_report_feat}/tfc.log"
		else
			write_rsi_log :debug, "consolida_reports.rb ARQUIVO NAO ENCONTRADO - #{arq_massa}"
		end

	end

	write_rsi_log :debug, "consolida_reports.rb : processamento concluido"
end

def main_consolidar_reports(argv=nil)
	 write_rsi_log "main_consolidar_reports() argv=#{argv}"
	 argv ||= [] #2018Ago16 pm, adcionado 
	 argv[0] ||= 'features/auto' 
	 argv[1] ||= 'reports'
	 argv[2] ||= './reproc_qualquerum_exceto_apenaspasso2.rb' #2018Ago16pm, pra ficar iual consolidar_reports.bat !!
	consolida_core argv
	htmljson_parm = [(argv[3] || 'reports')+'/c']
	write_rsi_log "chamando html_from_json_main com parametros #{htmljson_parm}"
	if false
		write_rsi_log "GAMBIARRA - nao chamando html_from_json_main"
	else
		html_from_json_main htmljson_parm
	end
end


if ARGV.length > 0 and ARGV[0]=='run_consolida_reports'
	main_consolidar_reports(ARGV.drop(1))
end