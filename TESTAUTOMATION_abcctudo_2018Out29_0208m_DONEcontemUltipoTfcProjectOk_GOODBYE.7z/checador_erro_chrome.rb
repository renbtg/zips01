require_relative './features/support/rsi_utils.rb' 


def rotina_de_interrupcao_em_log
	#2018Abr20 - adicionado método "rotina_de_interrupcao_em_log" para rápida morte
	checa_interrupcoes do |msg|
		write_rsi_log :debug, msg
	end
end

def fechar_erro_thread_space()
	#2017Out16, aconcetece principalmente em VM da Julia

	if traz_janela_pra_topo("Microsoft Visual C++",true) == 0
		write_rsi_log :trace, 'checador_err_chrome.rb,para visual C++ thread blues,vai chamar fecha_janela_err_1_chrome '
		fecha_janela_err_1_chrome
		write_rsi_log :trace, 'checador_err_chrome.rb,para visual C++ thread blues,chamou fecha_janela_err_1_chrome '
	else
		#write_rsi_log :error, "checador_err_chrome.rb, (SEM JANELA DE Thread Visual C++ blues), fecha_erro_chrome, FOI IMPOSSIVEL TRAZER JANELA DO ERRO PRA FRENTE/foreground"
	end

end	

def fechar_erro_chrome()
	#
	#
	# ATENCAO! Nao chamar executa_exslusivo, direta ou indireamentem e, rotinas
	# de checador_err_chrome.rb ! Pois rsi_utils.rb::core_abre_janela_browser é que tem o LOCK!
	#
	#, P00'
	if detected_automation_ext_ok?
		#, P01'
		return #ja detectado em core_abre_janela_browser que conseguiu abrir sem dialog de ERRO AUTOMATION 
	end
	#, P02'

	arq_botao="#{get_automdir}/BOTAOOK.LCK"
	if File.exist? arq_botao
		#, P03'
		begin
			#, P04'
			fechar_erro_thread_space #tambem sem fecha janela de erro Thread Space aqui
		rescue Exception => e
			write_rsi_log :error, "checador_erro_chrome.rb Excecao #{e} ao chamar fechar_erro_thread_space"
			return
		end

		write_rsi_log :trace, 'checador_erro_chrome.rb, achou BOTAOOK.LCK, deve fechar'
		#File.delete "BOTAOOK.LCK" #2017Set23 - remoção de BOTAOK.LCK movida pra core_abre_janela_browser, em vez de ficar em checador_err_chrome.rb !	

		trouxe_error_loading_extension_topo=false
		begin
			trouxe_error_loading_extension_topo = (traz_janela_pra_topo("Error Loading Extension") == 0)
		rescue Exception => e
			write_rsi_log :error, "checador_erro_chrome.rb Excecao #{e} ao chamar obter variavel trouxe_error_loading_extension_topo"
			return
		end

		if trouxe_error_loading_extension_topo
			write_rsi_log :trace, 'checador_err_chrome.rb,vai chamar fecha_janela_err_1_chrome '
			fecha_janela_err_1_chrome
			write_rsi_log :trace, 'checador_err_chrome.rb,chamou fecha_janela_err_1_chrome '
			begin
				do_detect_automation_ext_erro
			rescue Exception => e
				write_rsi_log :error, "checador_erro_chrome.rb Excecao #{e} ao chamar  do_detect_automation_ext_erro"
				return
			end
			begin
				File.write(arq_botao, '1') #2017Out2 - avisa que efetivamente havia erro e fechou
			rescue Exception => e
				write_rsi_log :error, "checador_erro_chrome.rb Excecao #{e} ao escrever '1' em arq_botao, #{arq_botao}"
				return
			end

		else
			write_rsi_log :error, "checador_err_chrome.rb, (SEM ERRO DE AUTOMATION), fecha_erro_chrome, FOI IMPOSSIVEL TRAZER JANELA DO ERRO PRA FRENTE/foreground"
		end
	end	

end	

write_rsi_log :info, "checado_erro_chrome.rb STARTING"

i=0
while true do
	#, checado_erro_chrome.rb DENTRO LOOP P00"
	i=i+1

	sleep 0.5

	if i%100 == 0 #a cada 100 iteracoes, 50 segundos, "se errar, eh menos ruim que deixar travado"
		#, checado_erro_chrome.rb DENTRO LOOP P01"
		i=0
		begin
			#, checado_erro_chrome.rb DENTRO LOOP P02"
			fechar_erro_thread_space
			#, checado_erro_chrome.rb DENTRO LOOP P03"
		rescue Exception => e
			#, checado_erro_chrome.rb DENTRO LOOP P04"
			write_rsi_log :error, "checador_erro_chrome.rb Excecao #{e} ao chamar  fechar_erro_thread_space"
			next		
		end
	end
	begin
		#, checado_erro_chrome.rb DENTRO LOOP P05"
		fechar_erro_chrome
		#, checado_erro_chrome.rb DENTRO LOOP P06"
	rescue Exception => e
		write_rsi_log :error, "checador_erro_chrome.rb Excecao #{e} ao chamar  fechar_erro_chrome"
		next		
	end
end