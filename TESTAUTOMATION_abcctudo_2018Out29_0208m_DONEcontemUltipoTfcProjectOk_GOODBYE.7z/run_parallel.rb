# encoding: UTF-8
require 'FileUtils'
require './features/support/rsi_utils.rb'
require './tfc.rb'
require './rotinas_processo.rb'
require './ipc_processo.rb'
require './risco_cpfs.rb'


def rotina_de_interrupcao_em_log
	checa_interrupcoes do |msg|
		write_rsi_log :debug,  msg
		Kernel.exit! 1
	end
end

def cleanup_final_run_parallel
	ignora_excecoes{core_cleanup_final_run_parallel}
end	

def core_cleanup_final_run_parallel
	if not run_parallel_tem_apenas_tfc_para_processar?
		#2018Set7 - usa novo jeito de matar processos
		kill_and_watch ['checador_erro_chrome.rb'] 
	end
	tfc_do_server_kill

	ignora_excecoes {del_exes_ahk_geral}  #2017Set20, CLEANUP de executaveis auto-hotkey #TODO 2018Fev10

end

def main_run_parallel
	write_rsi_log "run_parallel.rb, PX001, ENV.inspect=#{ENV.inspect}"
	param_feat_dir = nil; paralelismo=nil;test_run_num=nil
	write_rsi_log "run_parallel.rb, PX002, $argv=#{$argv}"
	 
	param_feat_dir = $argv[0]
	param_feat_dir.gsub('\\','/').chomp('/') #troca barra invertida por barra normal, e tira a ultima barra
	paralelismo=4; paralelismo = $argv[1].to_i if $argv.length >= 2
	write_rsi_log "run_parallel.rb, PX003"
	test_run_num = get_max_trn(param_feat_dir) + 1
	write_rsi_log "run_parallel.rb, PX004"
	ENV['TEST_RUN_NUM']="#{test_run_num}"
	write_rsi_log "run_parallel.rb, PX005"

	##################
	##########
	# 2017Set26 - IMPORTANTE! Nao chamar write_rsi_log ANTES de setar ENV['TEST_RUN_NUM'],
	# ou isso vai gerar um Log adicional que não está mapeado em 
	# método "get_test_outputs_da_feature_da_trn()" !!!"
	#
	#########
	write_rsi_log :debug, "run_parallel.rb - paralelismo=#{paralelismo}"
	write_rsi_log :debug, "run_parallel.rb - depois de definir envvar TEST_RUN_NUM - SETANDO ENV['TEST_RUN_NUM']=@#{test_run_num}@"
	write_rsi_log :debug, "$argv=#{$argv}"

	write_rsi_log "run_parallel.rb, PX006"





	path_dir_features_subprocessos = "#{param_feat_dir}/TRN#{ENV['TEST_RUN_NUM']}"
	write_rsi_log :debug, "run_parallel.rb - path_dir_features_subprocessos=#{path_dir_features_subprocessos} (deve tambem ser usada por consumidor_de_feature.rb) - - criando, se nao existir, dir base sob o qual 1,2,3...TOT dirs de subprocesso trabalham... "
	if File.exist? path_dir_features_subprocessos
		msgerr="run_parallel.rb - pasta path_dir_features_subprocessos, #{path_dir_features_subprocessos}, ja existe! Serah mau calculo de LAST/MAX TRN???"
		write_rsi_log :error, msgerr
		falhar msgerr
	end
	mkdir_noexist  path_dir_features_subprocessos
	write_rsi_log :debug, "NAO DELETANDO nada desta subpasta: se quiser EXECUCAO MATANDO TUDO, outro batch/ruby eh que deve apagar diretorios antes"




	write_rsi_log :debug, "vai fazer cleanup pra possivel restart: cleanup_de_features_interrompidas #{param_feat_dir}"
	cleanup_de_features_interrompidas(param_feat_dir) 

	remove_todos_fila_lock #2017Set13, lock revamp

	
	#2018Ago01 - removido conceito de reserva , prejudicial, nao usar mais conceito de reserva de cpf: queimar imediatamente



	write_rsi_log :debug, "XXXXXXXXXXXXX run_parallel.rb, AINDA NAO SER fazer restart escolhendo quais features reexecutar. Agora, tenho continuacao/restart simplorio "

	pids_spawn=[]



	#-- CHECADOR DE CHROME!
	#pra CHECK ERR CHROME, (caso nao usemos spawn), precisa sim de janela separada SEMPRE!
	10.times {write_rsi_log :debug, "logo antes da decisao de tfc_do_server_boot, #single_maq_zsproc_debug=#{$not_single_maq_zsproc_debug}, run_parallel_tem_algum_tfc_para_processar?=#{run_parallel_tem_algum_tfc_para_processar?}"}
	if $not_single_maq_zsproc_debug
		if run_parallel_tem_algum_tfc_para_processar?
			begin
				#2018Mar30 12:26pm - evita lentidao em subida de TFC, causada por concorrencia com diversos Ruby (inerente à execucao paralela). 

				#COM ISSO, posso retomar estratégia de fazer paralelismo TFC em zs_proc=1. Por ter feito tfc_do_server_boot aqui, poderíamos obter um efeito colateral indesejado: todos WAITING de ZS_PROC ficariam tentando se processar, gerando falha (se deixarmos prosseguir apesar de exception em tfc_do_server_boot). 

				#OU, se nao deixarmos prosseguir, run_parallel.rb vai morrer em gerar "#{DIR_EXECUCAO_ZRDIR}/features/auto/*.f.feature", o que daria péssimo resultado de "descasamento entre chosen/waiting/running/done".

				# Para evitar ambos efeitos colaterais, somos obrigados a modificar zs_proc.rb para que esse detecte aborção antecipada de run_parallel.rb, e gere RUNNING.STT + DONE.&Z "com erro", permitindo assim reinsercao e reprocessamento das features. 

				if true
					#2018Set7 - se "if false", nao faz boot de tfc aqui. Pensando em permitir que cada cenario de TFC faça boot caso necessite. Incerto quando a habilitar/desabilitar isso, portanto, este "if false/if true" permite pensar a respeito.
					tfc_do_server_boot 
				end
			rescue Exception => e
				write_rsi_log :error, "run_parallel.rb, nao teve sucesso em executar tfc_do_server_boot. PORÈM, vai deixar prosseguir. Isso é especialmente relevante para que consumidor_de_features+cucumber relatem ao zs_proc de falha no statup, e serão devidamente reprocessadas no devido tempo, caso ainda não tenham esgotado limite de reprocessamentos. Excecao=#{e}" 
				#return 55			

			end
		end

		if not run_parallel_tem_apenas_tfc_para_processar?
			#prefixo_cmd='start cmd /c "'
			prefixo_cmd='' #2018Abr01 - removido "cmd /c" que iniciava "comando". 
			sufixo_cmd='"'
			cmdcore = "ruby checador_erro_chrome.rb"
			#nao to conseguindo passar env_vars pro SPAWN...
			spawn cmdcore
			write_rsi_log :debug, "run_parallel.rb (checador_erro_chrome.rb iniciado), SPAWNED , cmdcore=#{cmdcore} "
		end
	end


	########
	###
	########
	if get_test_reabertura_rapida #2017Set29 - deve ser TRUE para máquinas e rede de alto desempenho 
		quantos_cucumber = paralelismo * 2 #estava 3... 2017Out19... estranhamente, abriu 12 cucumber p parallel 4 SEM FLAG!
	else
		quantos_cucumber = paralelismo
	end
	quantas_features_na_fila = lista_de_arquivos_feature_na_fila(param_feat_dir).length
	if quantos_cucumber >  quantas_features_na_fila 
		quantos_cucumber = quantas_features_na_fila #2017Set29, evita muitos processos em execucao pequena
	end

	####
	#
	#2017Set13 - 3x mais CUCUMBER que paralelismo de CHROME
	#               ISTO aumenta throughput, evita lag de VERACIDADE PARADO SEM CHROME!
	#
	####
	quantos_cucumber.times do |i| 
		#deste_processo = cada_processo[i]
		test_process_num = i + 1
		#write_rsi_log :debug, "todos.length=#{todos.length}, e elto #{i} tem tamanho #{cada_processo[i].length}"


		prefixo_cmd=''
		sufixo_cmd=''

		if paralelismo > 1
			#prefixo_cmd='start cmd /c "'
			#2018Abr01 - removido "cmd /c" que iniciava "comando". 
			prefixo_cmd = ''
			sufixo_cmd='"'
		end


		cmdcore = "ruby consumidor_de_features.rb #{param_feat_dir} #{test_process_num} "


		#nao to conseguindo passar env_vars pro SPAWN...
		#2018Set30 - passando TEST_ZS_PROC e TEST_ZS_NETWORKDIR pra que consumidor_de_features passe adiante pro cucumber
		#2018Out9 - recebendo e passando adiante TEST_LOG_FILE,a que deve deve logar adicionalmente tudo de write_rsi_log. Usa aqui, e passa adiante para filho(s)  
		#2018Out28 - tfc centro adicionado
		comando =  "set TEST_TFC_CENTRO=#{ENV['TEST_TFC_CENTRO']}&&set TEST_LOG_FILE=#{ENV['TEST_LOG_FILE']}&&set TEST_ZS_PROC=#{ENV['TEST_ZS_PROC']}&&set TEST_ZS_NETWORKDIR=#{ENV['TEST_ZS_NETWORKDIR']}&&set TEST_PARALELISMO=#{paralelismo}&& set TEST_PROCESS_COUNT=#{quantos_cucumber}&& set TEST_RUN_NUM=#{test_run_num}&& " + cmdcore
		pid = spawn comando
		write_rsi_log :debug, "run_parallel.rb SPAWNED pid=#{pid}-, comando=#{comando} "
		pids_spawn << pid

	end

	while true do
	#  #ATENCAO - verificacao de INTERRUPT/TERMINATE etc. .LCK IMEDIATA/OTIMIZADA movida para get_rsi_log !!!!!!

		sleep 10
		
		imprime_pids_processos pids_spawn
		if (pids_spawn-get_pids_filhos_terminados).empty?
			write_rsi_log "run_parallel.rb, todos processos filhos morreram, ACABOU"
			break
		end
	end
	write_rsi_log :debug, "CHEGOU AO FIM DE PROCESSAMENTO DE run_parallel.rb"

	if $not_single_maq_zsproc_debug #2018Mmar30 #and (not (ENV['TEST_BOOTTFC_IN_RUNPARALLEL']=='0'))
		cleanup_final_run_parallel
	end

	begin
		if false
			#2018Abr02 - desistindo (por ora) de fazer cleanup_de_features_interrompidas aqui, e também de tratar em zs_proc, por temer efeitos colaterais de possivelmente nao termos massa.xls nem reports.

			cleanup_de_features_interrompidas(param_feat_dir) #2018Abr02 15:50 NOVO! cleanup_de_features_interrompidas imediato logo ao fim de run_parallel.rb - isso deve diminuir a quantidade de vezes que ZS_PROC.RB nao consegue detectar RUNNING (a.k.a features em diretorio features/auto/r)
		end
	rescue Exception => e
		write_rsi_log :error, "main_run_parallel, erro em cleanup_de_features_interrompidas, excecao=#{e}, de backtrace=#{e.backtrace}"
	end

	write_rsi_log :debug, "FIM GERAL DE PROCESSAMENTO DE run_parallel.rb"

	return exitcode_ok_de_run_parallel
end

def real_main_run_parallel
	falhar "bad configuration, run_parallel.rb tem , no método exitcode_ok_de_run_parallel=0, essa 'constante' deve ser DIFERENTE DE ZERO" if exitcode_ok_de_run_parallel == 0
	rp_exitcode = exitcode_ok_de_run_parallel+22

	write_rsi_log :debug, "run_parallel.rb, rp_exitcode inicial=#{rp_exitcode}"

	begin
		rp_exitcode = main_run_parallel
		write_rsi_log :debug, "run_parallel.rb, rp_exitcode depois de main_run_parallel=#{rp_exitcode}, sendo que exitcode_ok_de_run_parallel=#{exitcode_ok_de_run_parallel}"
	rescue Exception => e
		rp_exitcode = exitcode_ok_de_run_parallel + 44
		write_rsi_log :debug, "run_parallel.rb, erro em main_run_parallel , exception #{e} de backtrace #{e.backtrace}. Por isso, rp_exit_code=#{rp_exitcode}"
	end


	exit rp_exitcode
end

if ARGV[0] == 'run_run_parallel'
	$argv = ARGV.drop(1)
	real_main_run_parallel
end
