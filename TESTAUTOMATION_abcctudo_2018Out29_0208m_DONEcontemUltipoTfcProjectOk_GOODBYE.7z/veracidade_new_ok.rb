require 'httparty'
require 'openssl'
require_relative 'features/support/rsi_utils.rb'

OpenSSL::SSL::VERIFY_PEER = OpenSSL::SSL::VERIFY_NONE

#
###
### rbattagia 2017Set2 - Será que manipular OpenSSL:SSL:VERIFY_PEER pode afetar 
# negativamente outros trechos da aplicação? EM CASO AFIRMATIVO, devemos chamar
# este arquivo .rb como um programa externo !

def checar_status_veracidade_new(cpf)
	status = nil
	options = {
			body: {
				user: "41a5e19475e72656455b5aad45d7be17",
				pass: "fd2fa1ae9f36642fe4d327221010eb2b",
				cpf: cpf,#14964822125
				inquiryStatusEnum: "Approved"
				#siglaAplicacao: "MOB",
				#descAplicacao: "Abertura de Contas",
				#resultadoAnalise: "[04] Sem Risco Aparente", 
				#listaMotivos: [{ "motivo": "" }]
			}.to_json,
			
			headers: { 
				"Content-Type" => "application/json",
				"x-header-origin-santander-as" => "aco" #IMPORTANTE - isto tinha no POSTMAN mas nao tinha no HTTPARTY
			}
		}
	
	msg_excecao = nil
	status = 9999	
	response = nil
	begin
		#response = HTTParty.post("https://mobhk.servcoord.santanderbr.pre.corp:8443/SantanderAbertCoord/v1/abertura/documentReport/document?gw-app-key=9cd0b030747801341aff005056906329", options)
		response = HTTParty.post("https://mobhk.servcoord.santanderbr.pre.corp:8443/SantanderAbertCoord/v1/abertura/documentReport/hsprevents/simulate/", options)
	rescue Errno::ECONNRESET => e
		write_rsi_log :error, "veracidade_ok.rb : Exception Errno::ECONNRESET, e=#{e}"
		msg_excecao=e.inspect
	rescue Exception => e
		write_rsi_log :error, "veracidade_ok.rb : Nao esperava Exception exceto Errno::ECONNRESET, mas obbtive. e=#{e}"
		msg_excecao = e.inspect
	end

	
	if response #sem excecao
		status = response.code
		msg_excecao = nil
		puts "reponse=#{response}" if false
		if response.body and response.body.length > 0
			exc1=response.body.split('"message":')[1]
			if exc1
				msg_excecao = exc1.split("\\n")[0]
			end
		end
	end

	puts "msg_excecao=#{msg_excecao}" if false
	puts "options=#{options}" if false
	puts "status=#{status}" if false #mude IF FALSE pra IF TRUE se estiver debugando
	return [status, msg_excecao]
end

def main_veracidade_new
	puts "rodando main_veracidade_new para cpf #{ARGV[1]}"
	(status, msg_excecao) = checar_status_veracidade_new ARGV[1]
	puts "status=#{status}, msg_excecao=#{msg_excecao}"
end

if ARGV[0]=='run_veracidade_new'
	main_veracidade_new
end
