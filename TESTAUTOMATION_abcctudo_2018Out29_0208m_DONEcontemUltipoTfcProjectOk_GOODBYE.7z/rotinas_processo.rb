#encoding: UTF-8
require 'find'
require 'fileutils'
require_relative './features/support/rsi_log.rb'
require 'json'
require_relative './features/support/rsi_spreadsheet.rb'
require_relative './features/support/shared_utils.rb'
require_relative './features/support/ZipFileGenerator.rb'
require_relative './risco_cpfs.rb'

$split_7z = true #TODO 2017Set24 - melhorar configuracao... se false,=zip RUBY 



def get_all_trns(diretorio)
	retval = Dir[diretorio+'/TRN*'].map { |fdir|
		trn = fdir.split('/TRN')[1].to_i
		trn
	}
	#   2017Nov20 - USO RESIDUAL IMPORTANTISSMO de subdiretorios TRNxx
	#
	#  Nos casos de SPLIT + JOIN, esse subdiretorio que de 2017Nov20 em 
	# diante fica vazio serve para nos proteger de descontrole de número
	# de execucao (TRN).
	#
	#   Mesmo que uma máquina receba em split apenas features que 
	# tiveram execucao até TRN7, elas receberão diretório vazio TRnmax 
	# (Ex: TRN10)
	#
	#   Sendo assim, continuarão numerando suas execucoes a partir de
	# max(10)+1=11 !!!
	#
	return retval 
end

def get_max_trn(diretorio='features/auto')
	trns = get_all_trns(diretorio)
	retval = trns.max || 0
	retval
end

#DONE 2017Sep6 am, testada get_arquivos_feature_da_feature_name
#def get_arquivos_feature_da_feature_name(feat_dir, feature_name)
	#2017Nov19 - removido método "get_arquivos_feature_da_feature_name",
	# DEAD CODE, nunca era chamado. 
#end

def get_feature_name_from_feature_file(fn)
	#obtem nome da feature, de algum nome de arquivo. Tbm funciona Se passar só nome
	retval = File.basename(fn).split('.TRN')[0]
	retval = retval.split('.')[0] #2017Nov19 - antes, vinda basename com extensao (extensoes). CUIDADO!!! NAO PODE HAVER caractere '.' em nenhum lugar do nome da feature, agora!! Se, por exemplo, nome do cartao de credito etc. passar a ter '.' estaremos em maus lençóis...
end

def get_max_trn_da_feature(diretorio, feature_name)
	retval = get_all_trns_da_feature(diretorio, feature_name).max || 0
	return retval
end

#2018Nov20 - testado feature/auto
def get_all_trns_da_feature(feat_dir, feature_name)
	retval= Dir.glob("#{feat_dir}/**/*.feature").select{|ffeat_file| 
		if not ffeat_file.include? 'TRN'
			ok = false 
		else
			fn=get_feature_name_from_feature_file(ffeat_file)
			ok = (fnraw(fn) == fnraw(feature_name))
		end
		#write_rsi_log BLA
		ok
	}.map{|feat_file|
		trn = feat_file.split('.TRN')[1].split('_')[0].to_i
		#write_rsi_log BLA
		trn
	}
	return retval
end


def get_feature_name_from_file_name(feat_file)
	retval =  File.basename(feat_file).split('.')[0]
	return retval
end

def split_get_destdir
	return "#{get_automtmpdir}/dosplt"
end
def split_get_finaldir
	return "#{get_automtmpdir}/split"
end

def split_get_zipextension
	if defined? $split_7z and $split_7z
		return ".7z"
	else
		return ".zip"
	end
end
def split_do_backup(feat_dir, report_dir, massa_dir)
##############################
#
#  2017Set25 - HMM, MUDANDO split pra COPY em vrz de MOVE
#
#  SENDO split NAO INTRUSIVO, acho que posso abandonar BACKUP inicial aqui!!
#
############

	tmpDir = get_automtmpdir

	zipfile = "#{tmpDir}/bkp_before_split.#{split_get_zipextension}"
	Dir["#{zipfile}*"].each{|fn| FileUtils.rm fn} #se 7z, split, mais q 1

	FileUtils.cp_r "#{feat_dir}/.", "#{spltBkpDir}/auto", verbose:true
	FileUtils.cp_r "#{report_dir}/.", "#{spltBkpDir}/reports", verbose:true
	FileUtils.cp_r "#{massa_dir}/.", "#{spltBkpDir}/massas_feature", verbose:true #2017Set25am, massas_feature nao eh manipulado, mas eh util pra UNDO rápido manual
	#write_rsi_log :trace, "PRESS ANY KEY - vai chamar ZIP stuff, p1=#{spltBkpDir}, p2=#{zipfile}"
	#gets

	if defined? $split_7z and $split_7z
		prevd=Dir.pwd
		Dir.chdir spltBkpDir
		system "7za a   -v8m -mx9 #{zipfile}  ."
		Dir.chdir prevd
		# ATENCAO - nada de fazer TAR, afinal, quero os arquivos de até 8mb
		#pra poder enviar via email do Santander, q tem limite de tamanho!
	else
		zg = ZipFileGenerator.new(spltBkpDir,zipfile)
		zg.write
	end
	FileUtils.rm_rf spltBkpDir
end
def split_initialize(feat_dir, report_dir)
	write_rsi_log :debug, "split_initialize, ignorando parametros feat_dir=#{feat_dir}, report_dir=#{report_dir}"
	criadir_senaoexistir split_get_destdir
	criadir_senaoexistir split_get_finaldir
	delete_all_in_dir split_get_destdir
	delete_all_in_dir split_get_finaldir
end

def split_trns(a_pesos, deve_gerar_nice = false, feat_dir='./features/auto', massa_dir='./massas_feature', report_dir='./reports')
	feat_list = nil;
	write_rsi_log :debug, "split_trns, ponto de entrada, a_pesos=#{a_pesos}, deve_gerar_nice=#{deve_gerar_nice}"

	
	write_rsi_log :debug, "split_trns((a_pesos=#{a_pesos}, feat_list = #{feat_list}, feat_dir=#{feat_dir}, report_dir=#{report_dir}, massa_dir=#{massa_dir})"
	if not a_pesos.is_a? Array
		i = a_pesos.to_i
		a_pesos=Array.new(i)
	end 

	split_initialize(feat_dir, report_dir)

	fila=lista_de_features_na_fila(feat_dir)
	if feat_list
		fila.select! {|ft|
			feat_list.any? {|da_lista|
				ascii_only_str(da_lista.gsub('V ','')) == ascii_only_str(ft.gsub('V ',''))
			}
		}
	end


	fora=lista_de_features_fora_da_fila(feat_dir)
	if feat_list
		fora.select! {|ft|
			feat_list.any? {|da_lista|
				ascii_only_str(da_lista.gsub('V ','')) == ascii_only_str(ft.gsub('V ',''))
			}
		}
	end

	write_rsi_log :debug, "split_trns, fila.length=#{fila.length}, fila=#{fila}"
	write_rsi_log :debug, "split_trns, fora.length=#{fora.length}, fora=#{fora}"

	k = 0
	
	$split_feature_nices = Array.new if deve_gerar_nice #2018Fev26

	while (fila.length > 0) or (fora.length > 0) do
		#write_rsi_log :debug, "ZZP00"
		#enuanto nao tiver pego todas features...

		k = k + 1

		dest_num = split_get_destino_num(a_pesos, k) #de 1 até pesos.length
		
		if fila.length>0
			posicao = split_copy_arquivos fila, dest_num, feat_dir, massa_dir, report_dir
			fila.delete_at posicao
		end

		if fora.length>0
			posicao = split_copy_arquivos fora, dest_num, feat_dir, massa_dir, report_dir
			fora.delete_at posicao
		end

	end

	split_distribui_cpfs(a_pesos) if false #2018Fev23, REMOVIDO deprecated, necessario em SPLIT old-style
	
	split_zip_output a_pesos.length, massa_dir

	return
end

def split_distribui_cpfs(a_pesos)
	#
	# 2017Nov26 - Esta subtorina é mais avançada que o core de "split_trns". é 
	#capaz de calcular distribuição proporcional!
	#
	#    TODO 2017Nov26 EOD - aplicar técnica de "aleatorios uniformes", 
	# comentada abaixo, ao core de split_trns !
	#
	a_pesos=a_pesos.clone
	a_pesos.each_index{|i_p| a_pesos[i_p]=a_pesos[i_p] || 1}

	write_rsi_log :debug, "split_distribui_cpfs: a_pesos=#{a_pesos}"
	if not File.exist? get_xls_cpfs_risco
		write_rsi_log :debug, "split_distribui_cpfs: arquivo #{get_xls_cpfs_risco} nao encontrado - retornando"
		return
	end
#
#   Novo recurso: 2017Nov26
#   Rotina de split/join é incapaz, naturalmente, de preservar estrutura completa  
# de diretórios nos casos em que ENVIRONMENT VARIABLE TEST_XLS_CPFS_RISCO 
# contém caminho completo (ex: c:/blabla/somedir/my_risco.xls).
#   !!! Split/join, invariavelmente, enviará .XLS para "planilhas e controles" !!!
#

	rcpfs = ler_xls_com_id(get_xls_cpfs_risco, nil, nil, -1)
	write_rsi_log :debug, "split_distribui_cpfs: rcpfs.length=#{(rcpfs||[]).length}"
	tot_peso = 0; a_pesos.each{|peso|tot_peso = tot_peso + peso}
	distribs = distribui_cpfs_naoqueimados(rcpfs, tot_peso) #em [5,3,2], divide cpfs em 10(soma=5+3+2=10)
	totcpfs=0
	distribs.each{|e|totcpfs=totcpfs+e.length}
	write_rsi_log :debug, "split_distribui_cpfs: distribs.length=#{(distribs||[]).length}, totcpfs=#{totcpfs}"

	randoms = (0..tot_peso-1).to_a.shuffle #aleatorios uniformes, de 0 a tot_peso-1
	
	out_cpfs = Array.new(a_pesos.length)
	out_cpfs.each_index{|i|out_cpfs[i]=Array.new}

	distribs.each_index do |d|
		distr = distribs[d]
		dest=nil;ini=nil; fim = -1
		random = randoms[d]
		dest_index = nil
		a_pesos.each_index do |j|
			#escolhe destino aleatorio, pela quantidade de pesos. "Checa se este peso contém random r".
			#
			# "Pra qual dest, de 1 a 3 [em 5,3,2] vao os cpfs na distribuicao [k de 10] ???""
			#
			peso = a_pesos[j]
			ini = fim + 1       #em a_pesos=[5,3,2] fica: [0, 5, 8]
			fim = ini + peso -1 # ""   ""   ""   fica: [4, 7, 9]
			achou = (random >= ini and random <= fim) #ACHEI O DESTINO [0 a 2], sem a_pesos=[5,2,3]
			dest_index = j if achou
			descricao="nao achou"
			if dest_index
				descricao="SIM, ACHOU!!"
			end
			write_rsi_log :debug, "split_distribui_cpfs: random=#{random}, distr num =#{d+1} de #{distribs.length} tem #{distr.length} cpfs. Avaliando peso #{j+1} de #{a_pesos.length} eue é igual a #{peso}, sendo que a_pesos=#{a_pesos}. NESTE CONTEXTO, ini=#{ini} e fim=#{fim}, achou=#{achou} e dest_index=#{dest_index}. #{descricao}" if false
			if dest
				break
			end
		end
		if dest_index
			out_cpfs[dest_index] = out_cpfs[dest_index] + distr 
			write_rsi_log :debug, "Achou dest #{dest_index} para random=#{random}, adicionados #{distr.length} cpfs do total de #{totcpfs}, e entao out_cpfs[#{dest_index}] ficou com length=#{out_cpfs[dest_index].length}"
		else
			write_rsi_log :debug, "Nao achou dest para random=#{random}"
		end
	end
	a_pesos.length.times do |dest_index|
		destdir = "#{split_get_destdir}/#{dest_index+1}/planilhas e controles"
		xls_basename = File.basename(get_xls_cpfs_risco, '.xls')
		arq_xls = "#{destdir}/#{xls_basename}_zcpfr#{dest_index+1}.xls"
		mkdir_noexist destdir #útil para testes em console IRB
		write_rsi_log "Chamando reescreve_xls_risco com arq_xls= #{arq_xls}, rsk_cpf_cols=#{rsk_cpf_cols}, data.length=#{out_cpfs[dest_index].length}"
		reescreve_xls_risco(arq_xls, rsk_cpf_cols, out_cpfs[dest_index])
	end
	return nil
end

def join_trns #MERGE, 2017Set25 am
	# usa diretorios pre-fixados. ZIPs a processar devem ficar todos
	# sob , por exemplo, c:\autom\tmp\join 
	# Serão escaneados lidos todos .7z, .zip e ;7z.001
	#
	# Entao, sera feita extracao desses arquivos para...
	#
	#      .\massas_feature, .\reports e .\auto
	#
	#  OBS: ZIPs tem nomes de diretorio. Entao, devem ser todos extraídos
	# diretamente para ".\" (que erá o diretório-base, por exemplo, c:\autom)
	#
	#            COMO O chato do features/auto fica sob features\, ao fim
	# do UNZIP eu devo mover diretorio .\auto p .\features\
	###
	dir_join="#{get_automtmpdir}/join"
	puts "join_trns, dir_join=#{dir_join}, Dir.pwd=#{Dir.pwd}"
	dir_auto="auto"
	dir_ft_auto="features/auto"
	
	dir_reports="reports"
	dir_massa="massas_feature"
	dir_planilhas="planilhas e controles"
	
=begin
TODO NOW - cada .7z de SPLIT deve ter dentro dele o arquivo de cpfs_risco
renomeado. De arq.xls para arq_zcpfr999.xls (1 a 999 = split num, 1 a 999)

AÌ, o unzip vai colocá-los todos em planilhas e controles
Ai, plans=Dir["#{dir_planilhas}/*_zpfr*.xls"]
Aí, leio e concacteno em rpfs todos ler_xls_com_id(plan, nil, nil, -1); del each plan
Aí, reescreve_xls_risco(plan, rsk_cpf_cols, rcpfs)
PRONTO!! Missao cumprida.
=end

	# OBVIAMENTE, nao remove planilhas_e_controles, POIS È DIRETÒRIO DE FONTES! O novo recurso (2017Nov26) de split/join de cpfs_risco.xls não precisa de manipulação especial aqui, já que o ZIP/&Z já terá estrutura adequada (parecido com massas_feature, com a diferença que massas_feature, este sim, pode e deve ser removido!!)

	FileUtils.rm_rf dir_auto
	FileUtils.rm_rf dir_ft_auto
	FileUtils.rm_rf dir_reports
	FileUtils.rm_rf dir_massa

	mkdir_noexist dir_ft_auto
	mkdir_noexist dir_reports
	mkdir_noexist dir_massa
	# # 2017Nov26 - foram feitos ajustes que faltavam pra mudança de "features\ft\auto_features" para "features\auto". JOIN NAO HAVIA SIDO BEM TESTADO PRA ESSA MUDANÇA!

	extensoes = [".zip",".7z", ".7z.001"]
	zipfiles = []

	extensoes.each do |extensao|
		Dir.glob("#{dir_join}/**/*#{extensao}").each do |arquivo|
			zipfiles << arquivo
		end
	end

	write_rsi_log :info, "join_trns: zipfiles=#{zipfiles}"
	zipfiles.each do |zipfile|
		write_rsi_log :info, "join_trns: unzipping zipfile=#{zipfile}"
		cmdjoin = "7za x  -y #{zipfile}"
		write_rsi_log :debug, "join_trns, vai executar cmdjoin=#{cmdjoin}, Dir.pwd=#{Dir.pwd}"
		system cmdjoin # REAL=-v8m , 8megabytes
	end

	write_rsi_log :debug, "movendo '#{dir_auto}/*' para '#{dir_ft_auto}/'"
	#2018Mar23 01:35am - estranho, devia ter dado erro sempre... anyway... tirei este rm_tf e mudeu o MV abaixo , antes=dir_auto, agora=dir_auto/* #####FileUtils.rm_rf dir_ft_auto
	FileUtils.mv Dir["#{dir_auto}/*"], dir_ft_auto

	plans=Dir["#{dir_planilhas}/*_zcpfr*.xls"]
	rcpfs=Array.new
	plan = nil
	plans.each do |plan|
		rcpfs = rcpfs + ler_xls_com_id(plan, nil, nil, -1)
		FileUtils.rm plan
	end
	reescreve_xls_risco(get_xls_cpfs_risco, rsk_cpf_cols, rcpfs)
end

def split_curtime
	#TODO 2017Set24- melhore isto, pegue elementos isoladamente
	return Time.now.to_s.split(' -')[0].gsub(':','').gsub(' ','_')
end

def split_zip_output(quantos, massa_dir)
	write_rsi_log :debug, "P00 split_zip_output, quantos=#{quantos}, massa_dir=#{massa_dir}"
	hora = split_curtime
	zipdest_base = split_get_finaldir
	mkdir_noexist zipdest_base
	delete_all_in_dir zipdest_base
	
	if false 
		#2018Mar11 - mudança : arquivos massa.xls agora vao junto com feature, um a um
		#XXX2017Set25 am - MASSa deve ir inteira, nao apenas de features/auto!
		zipfile = "#{zipdest_base}/massas_feature_TMQ#{get_machine_id}_NOW#{hora}#{split_get_zipextension}"
		prevd=Dir.pwd
		Dir.chdir "#{massa_dir}/.."
		cmdcore= "7za a   -v8m -mx9 #{zipfile}  massas_feature" # REAL=-v8m , 8megabytes
		write_rsi_log :debug, "P01 split_zip_output, cmdcore=#{cmdcore}"

		system cmdcore
		Dir.chdir prevd
	end


	quantos.times do |k|
		dest_num = k + 1
		
		write_rsi_log :debug, "P01 split_zip_output, zipdest_base=#{zipdest_base}"

		zipd="#{zipdest_base}/#{dest_num}"
		mkdir_noexist zipd

		sourcedir = "#{split_get_destdir}/#{dest_num}"
		write_rsi_log :debug, "P01 split_zip_output, sourcedir=#{sourcedir}"
		nicemark= "_nice=#{$split_feature_nices[dest_num-1]}_" if $split_feature_nices #2018Fev26
		write_rsi_log :debug, "P01 split_zip_output, nicemark=#{nicemark}"
		zipfile = "#{zipd}/split#{dest_num}#{nicemark}TMQ#{get_machine_id}_NOW#{hora}#{split_get_zipextension}"
		write_rsi_log :debug, "P01 split_zip_output, zipfile=#{zipfile}"

		prevd=Dir.pwd
		Dir.chdir sourcedir
		cmdcore2 =  "7za a   -v8m -mx9 #{zipfile}  ." # REAL=-v8m , 8megabytes
		write_rsi_log :debug, "P01 split_zip_output, cmdcore2=#{cmdcore2}, Dir.pwd=#{Dir.pwd}"
		system cmdcore2
		Dir.chdir prevd
	end
	
	#FileUtils.rm_rf split_get_destdir
end

def split_copy_arquivos(feature_array, dest_num, feat_dir, massa_dir, report_dir)
	write_rsi_log :debug, "split_copy_arquivos, ignorando parametro #{report_dir}"
	falhar 'invalid argument - feature_array.length eh zero' if feature_array.length==0
	write_rsi_log :debug, "split_copy_arquivos P00"

	rp=Random.new.rand(0..feature_array.length-1)

	ft = feature_array[rp]
	$split_feature_nices[dest_num-1] = ft.split("Nice")[1].to_i if $split_feature_nices  #2018Fev26

	dest_dir = "#{split_get_destdir}/#{dest_num}"
#	basic_feature_glob_mask="features/auto/**/**/#{ft}*.feature"  !! TODO - evitar "nem existe feature basica" pra PROCESSO COLABORATIVO. IMPLEMENTACAO DE "def split_trns" tá frágil e nao reutilizável pra PROCESSO COLABORATIVO, SINGLE FEATURE, QUE PODE ESTAR EM SUBDIR auto/r! PROCESSO COLABORATIVO, zs_proc.rb, terá q fazer 7Z/ZIP manualmente, apenas do JSON e PNGs!""
	basic_feature_file="#{feat_dir}/#{ft}.feature"
	basic_dest_feature_dir="#{dest_dir}/auto"

	criadir_senaoexistir dest_dir
	criadir_senaoexistir "#{dest_dir}/reports"
	criadir_senaoexistir basic_dest_feature_dir

	max_trn = get_max_trn(feat_dir)
	if max_trn and max_trn > 0
		dir_dest_feat_maxtrn = "#{basic_dest_feature_dir}/TRN#{max_trn}"
		write_rsi_log :debug, "CRIANDO FORÇOSAMENTE DIRETORIO DE MAXTRN, em destino de feature. dir_dest_feat_maxtrn=#{dir_dest_feat_maxtrn}"
		criadir_senaoexistir dir_dest_feat_maxtrn 
		#   Criação de dir_dest_feat_maxtrn estimula nova maquina que receberá
		# e processará o split a começar da TRN (TEST RUN N UMBER) correta! 
	end

	if File.exist? basic_feature_file
		full_basic_feature_destfile = "#{basic_dest_feature_dir}/#{File.basename basic_feature_file}"
		
		write_rsi_log :debug, "FEATURE BASICA NA FILA - FileUtils.cp #{basic_feature_file} PARA #{basic_dest_feature_dir}, sendo que full_basic_feature_destfile=#{full_basic_feature_destfile}"
		FileUtils.cp basic_feature_file, basic_dest_feature_dir
		if not File.exist? full_basic_feature_destfile
			falhar "nao existe arquivo #{full_basic_feature_destfile} depois de mover #{basic_feature_file} para #{basic_dest_feature_dir}" 
		end
	else
		falhar "Nem existe feature basica #{basic_feature_file}"
	end

	#2018Mar11 - massa.xls não vai mais em 7Z segregado contendo tudo, mas sim junto com a feature assciada
	full_massa_src_file = "#{massa_dir}/V #{get_raw_feature_name_from_feature_file(basic_feature_file)}/massa.xls"
	full_massa_dest_file = "#{dest_dir}/massas_feature/V #{get_raw_feature_name_from_feature_file(basic_feature_file)}/massa.xls"
	criadir_senaoexistir File.dirname(full_massa_dest_file)
	FileUtils.cp full_massa_src_file, full_massa_dest_file



	outputs = get_test_outputs_da_feature(feat_dir, ft, :apenas_nomes_de_arquivos => true)
	write_rsi_log "outputs(a.k.a get_test_outputs_da_feature).length=#{outputs.length}"
	#write_rsi_log "split_copy_arquivos, feature_array.length=#{feature_array.length}, ft=#{ft}, outputs=#{outputs}"
	outputs.each {|output|
		
		arquivos = output[:outputs]

		get_lista_symbols_arquivos_output_split.each{|s|
			um_ou_mais_arqs = arquivos[s]
			#2017Set26 - de um_arq para um_ou_mais_arqs
			if not um_ou_mais_arqs.is_a? Array
				um_ou_mais_arqs = [um_ou_mais_arqs] #transforma em Array[1]
			end

			um_ou_mais_arqs.each do |um_arq|
				source_varying=nil
				dest_dir_type=nil
				
				if um_arq.downcase.include? 'arquivo nao encontrado'
					write_rsi_log "NOT FOUND nao encontrado, s=#{s}, #{um_arq}"
					#ignore-me, de alguma forma nao tem arquivo origem
				elsif not File.exist?(um_arq)
					write_rsi_log "NOT FOUND path ruim, s=#{s}, #{um_arq}"
				else
					write_rsi_log "este eu achei... !!!!!!!, s=#{s}, um_arq=#{um_arq}"
					if um_arq.downcase.include? 'reports/'
						#reports
						source_varying=um_arq.split('reports/')[1] #BAD! PRESO EM ESTRUTURA! TODO - REVAMP IRECOTRIES FLXIBILITY!
						dest_dir_type='reports'
					elsif um_arq.downcase.include? 'auto/'
						source_varying=um_arq.split('auto/')[1] #BAD! PRESO EM ESTRUTURA! TODO - REVAMP IRECOTRIES FLXIBILITY!
						dest_dir_type='auto'
					else
						falhar "Eita nois, nao tem nem reports/ nem auto/ em um_arq=#{um_arq}"
					end 
					full_dest_file="#{dest_dir}/#{dest_dir_type}/#{source_varying}" 
					dest_path_dir = File.dirname full_dest_file
					write_rsi_log :trace, "array length = #{feature_array.length}, devo mover, copiando DIRSTRUCT, chave symbol s=#{s}, um_arq=#{um_arq} PARA dest_dir=#{dest_dir}, dest_path_dir=#{dest_path_dir}, full_dest_file=#{full_dest_file}, source_varying=#{source_varying}, dest_dir_type=#{dest_dir_type}"

					write_rsi_log :trace, "criadir_senaoexistir #{dest_path_dir}"
					criadir_senaoexistir dest_path_dir
					write_rsi_log :trace, "FileUtils.cp #{um_arq} PARA #{dest_path_dir} - E, pra concluir, deve remover diretorio de origem se Dir* dele ficar vazio, recursivamente voltando árvore"
					FileUtils.cp um_arq, dest_path_dir
					if not File.exist? full_dest_file
						falhar "nao existe arquivo #{full_dest_file} depois de mover #{um_arq} para #{dest_path_dir}" 
					end

				end
			end # end "um_ou_mais_arqs.each do |um_arq|""

		}
	}

	write_rsi_log "split_copy_arquivos, retornando #{rp}"
	return rp

end

def split_get_destino_num(pesos, k) #k = inteiro NATURAL, de 1 a 9999999999999
##########
#
# TODO 2017Set25 - ainda nao faço distribuicao inteligente de pesos: a mesma
# quantidade de features vai pra todos SPLITs
#
#          IDÈIA: clonar abordagem de PERCENTUAIS feita em gerador_massa.rb !!!
#
#######



	#retornando, paliativa e temporariamente, partes exatamente iguais
	falhar 'split_get_destino_num, argumento invalido, K nao INTEIRO NATURAL' if k <= 0
	return (k-1) % pesos.length + 1 #retorna: de 1 a pesos.length

=begin
	# EXEMPLO: pesos=[10,20,3], ignora pesos, 
		#pra k=1 volta 1,  
        #      2       2
               3       3
               4       1
               5       2
               6       3
               7       1
               ...     ...
               ...     ...



PESOS... EVOLUCAO A FAZER, TODO 2017Sep6 am
    3 17 8 2
 SORT DESCEND
 	17 8 3 2, tot=30
HMM, DEVO FATORAR pra inteiro... 
	??? (faço no futoru... ex: 60/40/20 vira 3/2/1, 75/25 vira 3/1, TALVEZ, ATÈ MELHOR!)
A CADA 30,
	17 PRA A
	8 PRA B
	3 PRA C
	2 PRA D
PORTANTO, PESOS nao pode ser percentuais, mas os menores inteiros possiveis,
ou datasets pequenos ficarão distorcidos!!!

ENTAO...
	K % TOT between 0        AND [A    ,17]-1=16, A
	K % TOT between [A  ]=17 AND [A+B  ,25]-1=24, B
	K % TOT between [A+B]=25 AND [A+B+C,28]-1=27, C
	ELSE                                          D	

=end

end

def lista_de_features_na_fila(feat_dir)
	return lista_de_arquivos_feature_na_fila(feat_dir).map{|f|
		#2017Nov19, retornando nome raw/cru da feature, sem sufixo
		get_feature_name_from_file_name(f)
		#2017Nov19 e 20: fnraww desnecessario aqui. Feature files na
		#fila nao contêm sufixo.
	}
end

def lista_de_features_em_execucao(feat_dir)
	#pode ser usada em zs_proc
	return lista_de_features_fora_da_fila(feat_dir) - lista_de_features_finalizadas_ausentes_da_fila(feat_dir)
end

def lista_de_features_fora_da_fila(feat_dir)
	return lista_de_features_geral(feat_dir)-lista_de_features_na_fila(feat_dir)
end

def lista_de_features_geral(feat_dir)
#2017Dez11 - nome anterior era ruim! Era lista_de_features_ja_processadas
	return lista_de_arquivos_feature_em_todos_subdirs(feat_dir).map{|f|
		#2017Nov19 - obtendo fnraw, "nome da feature sem sufixo"
		fnraw(get_feature_name_from_file_name(f))
	}.uniq
end


def lista_de_arquivos_feature_na_fila(diretorio)
	return Dir["#{diretorio}/*.feature"].select {|f|
		#2017Nov19 - exclui as features que, por milissegundos, estiverem no diretorio recém-renomeadas, antes de ser movidas para subdiretórios de em_processamento a.k.a features/auto/r !
		
		
		not f.include? '/r/' #2018Fev26 - isto é, nao movido pra diretório de running


		#feature_name = get_feature_name_from_file_name(f)
		#fnraw(feature_name) == feature_name #se iguais, não é temporário c sufix
	}
end

def lista_de_arquivos_feature_nao_finalizadas_em_todos_subdirs(feat_dir)
	return Dir.glob("#{feat_dir}/**/*.feature").select{|e| not e.include? '.f.feature'}
end

def lista_de_arquivos_feature_em_todos_subdirs(feat_dir)
	return Dir.glob("#{feat_dir}/**/*.feature")
end

def arquivos_feature_nao_finalizados_subdirs_de_processamento(feat_dir)
	return Dir.glob("#{feat_dir}/**/*.feature").select{|e| 
		(e.include? '/r/') and not (e.include? '.f.feature')
	}
end

def lista_de_features_finalizadas_ausentes_da_fila(feat_dir)
	arquivos_finalizados=Dir.glob("#{feat_dir}/**/*.f.feature")
	#write_rsi_log :debug, "lista_de_features_finalizadas_ausentes_da_fila:feat_dir=#{feat_dir}"


	finalizadas=arquivos_finalizados. #filenames completos de features finalizadas
		map { |fnlz| 
			feature_name = File.basename(fnlz).split('.TRN')[0] 
			fnraw(feature_name)
			#2017Nov19 - obten nome da feature sem sufixo

		}. #obtem apenas feature_names
		uniq. #2017Ago24 - remove duplicates que podem ocorrer devido a deprocessamento e/ou merge de máquinas
		shuffle #2017Ago24 - embaralha, preserva filosofia de nao escolher ordem de testes. Precisa aqui?
	#write_rsi_log :debug, "finalizadas=#{finalizadas}"
	retval = finalizadas.select { |raw_feature_name|
		file_path_feature_na_fila = "#{feat_dir}/#{raw_feature_name}.feature"
		esta_feat_apenas_em_subdir=(not File.exist? file_path_feature_na_fila)
		esta_feat_apenas_em_subdir
	}

	#write_rsi_log :debug, "lista_de_features_finalizadas_ausentes_da_fila:retval=#{retval}"
	return retval
end

def cleanup_de_features_interrompidas(feat_dir)
 	interrompidas =  arquivos_feature_nao_finalizados_subdirs_de_processamento(feat_dir)
 	#fail "cleanup_de_features_interrompidas(#{feat_dir}) - interrompidas.length=#{interrompidas.length}"
 	interrompidas.each { |fn| 
		dn=File.dirname fn
		bn=File.basename fn,'.feature'
		fn_i=dn+'/'+bn+".i.f.feature"
 		if true
 			#write_rsi_log "Renomeando feature interrompida por queda inesperada de processo, de #{fn} para #{fn_i}"
 			if File.exist? fn
 				#write_rsi_log "EXISTE arquivo de origem"
 			else
 				#write_rsi_log "NOTFOUND arquivo de origem"
 			end
 		end
 		
 		basename_orig = File.basename fn
 		path_dest = File.dirname fn_i
 		basename_dest = File.basename fn_i


 		if File.exist? path_dest
 			#write_rsi_log "EXISTE diretorio de destino"
 		end
 		if basename_orig != basename_dest
 			#write_rsi_log :debug, "basename_orig e basename_dest sao DIFERENTES"
 		end
 		#c = 'move "' + fn + '" "' + fn_i + '"'
 		#write_rsi_log "command shell pra mover=#{c}"
 		#system c # WTF! Dava erro quando eu chamava API do Ruby, tive que chamar SYSTEM CMD !!!

 		#@FileUtils.mv fn, path_dest
 		#Dir.chdir(path_dest) do 
 		#	File.rename basename_orig, basename_dest #Hmmm, serah que long file names era causa de erro antes?
 		#end
 			

 		begin
 			FileUtils.mv fn, fn_i
 		rescue Errno::ENOENT => e_noent 
 			20.times{ write_rsi_log :error, "ATENCAO - cleanup_de_features_interrompidas(...) - NAO FOI POSSIVEL, devido a excecao Errno::ENOENT (e_noent=#{e_noent}),  MOVER/RENOMEAR ARQUIVO #{ascii_only_str(fn)}/encoding=#{fn.encoding} para DESTINO/NOVO-NOME #{ascii_only_str(fn_i)}/enconding=#{fn_i.encoding}, problema desconhecido e não tratada ao lidar com features potencialmente interrompidas!"}
 		end
 	}	
end


def procura_mascaras_em_subdirs(search_dir, search_masks, results_hash)
	search_masks.keys.each {|k| 
		if false
			retval[k] = (Dir[search_mask[k]]).first
		end
		mascara=search_masks[k]
		complete_mask="#{search_dir}/**/#{mascara}"
		achados=Dir.glob(complete_mask)
		
		#write_rsi_log :debug, "procura_mascaras_em_subdirs: search_dir=#{search_dir}, mascara=#{mascara}, complete_mask=#{complete_mask}, achados=#{achados}"
		if achados.length > 1
			write_rsi_log :trace, "procura_mascaras_em_subdirs: mais que um arquivo encontrado com mascara #{mascara}"
		end
		results_hash[k] = achados #2017Set26 - potencialmente, Arrqy
		if achados.length < 2
			results_hash[k] = achados.first #2017Set26 - se len<2, vai String mesmo
		end
	}
end

def get_massa_da_feature_da_ultima_trn(feat_dir, feature_name)
	outputs = get_test_outputs_da_feature_da_ultima_trn(feat_dir, feature_name) || Hash.new
	massa = outputs[:massa] || Hash.new
	return massa
end

def get_test_outputs_da_feature_da_ultima_trn(feat_dir, feature_name, opcoes=nil)
	trn = get_max_trn_da_feature(feat_dir, feature_name)
	return get_test_outputs_da_feature_da_trn(feat_dir,get_automdir,  feature_name,trn, opcoes)
end

def get_test_outputs_da_feature(feat_dir, feature_name, opcoes=nil)
	return [] if not File.directory? feat_dir #2018Mar12 - embriao de robustez para execucao controlada em multiplos diretorios, usado inicialmente por split vindo de splitter.rb vindo de zs_proc.rb(publicacao de features de diretorio temporario em reinsercao de feature)

	trns = get_all_trns_da_feature(feat_dir, feature_name)
	#write_rsi_log :debug, "get_test_outputs_da_feature, feat_dir=#{feat_dir}, feature_name=#{feature_name}, trns=#{trns}"

	retval = trns.map {|trn|
		outputs = get_test_outputs_da_feature_da_trn(feat_dir, get_automdir, feature_name, trn, opcoes)
		trn_and_output = {:trn => trn, :outputs => outputs }
		trn_and_output
	}
		
	retval.sort! {|o1,o2| o1[:trn]<=> o2[:trn]}
end

def get_lista_symbols_arquivos_output_split
	#2017Sep6 am - AINDA NAO sei fazer split adequado de MainLog e do run_parallelXconsumidor
	if true
		return get_lista_symbols_arquivos_output #2017Set25, TUDO! pra facil comparacao 
	end

    falhar 'get_lista_symbols_arquivos_output_split - unimplemented'
	[:seletivamente, :escolha,
	 :o_que,:deve_ser_copiado,
	 :em_split
	 ]
end

def get_lista_symbols_arquivos_output
	#2017Sep6 am - AINDA NAO sei fazer split adequado de MainLog e do run_parallelXconsumidor
	[:old_png_screenshot, :trn_log,
	:tmq_log, :trn_tmq_log, :trn_tpn_tmq_log, #2017Set26
	 :main_log,:tfc_screenshot, :png_screenshot,:desktop_screenshot, :desktoptfc_screenshot, :html_screenshot, 
	 :featname_log, :featnametfc_log,
	 :log_sequencial, :html_report, :json_report,
	 :feature, :arquivo_massa]
end

def get_test_outputs_da_feature_da_trn(feat_dir, autdir, p_feature_name, trn, opcoes=nil)
########3
# 2017nOV18 - feature_name terá sufixos distintos entre TRNs.
#  Pode ser que esta "def get_test_outputs_da_feature_da_trn" seja
# chamada com ou sem sufixo. Entao,estamos  colocando wildcard [*] 
# nas máscaras de buscas de arquivos,.
#
####
	feature_name = fnraw(p_feature_name)


##################################
# 2017Set26 - revamp necessário para PROCESSAMENTO MULTI-MÀQUINAS
#
#                                  Rationale: 
#                         ===============================
#     Arquivos com marca TMQ de id de maquina (TEST_MACHINE_IF) não podem ser
# procurados apenas para TMQ da máquina atual.
#     Quando processamento em maquina A (TEST_MACHINE_ID=A) forem trazidos para 
# maquina B, e maquina B quiser fazer reprocessamento de erros ocorridos na maquina A,
# a busca por TMQ#{get_machine_id} (a.k.a ENV['TEST_MACHINE_ID']||get_numero_mac_address)
# faria programa IGNORAR ERRADAMENTE os arquivos da maquina A.
#     Para resolver isso, busca mais refinada precisa trazer arquivos com mascara rela-
# tiva correta mas trazendo dados de todos TMQ*
#   
#################


	opcoes = opcoes || {:apenas_nomes_de_arquivos => false}

	retval=Hash.new
	reports_masks=Hash.new

	marca_trn="TRN#{trn}"

	reports_masks[:main_log]           = "Log.log" #nem vai mais existir

	#   2017Set26 -´EITA NÒIS, agora temos varios :main_log, ao trazermos arqs de log
	#de outras maquinas. Em teoria, :main_log não é "de uma TRN/test_run_num específica",
	#mas sim algo mais geral. Anyway,  :trn_log tem este mesmo problema que :main_log,
	#apesar de ser de uma TRN específica.
	#   Como podemos lidar com isso? 
	#
	#    VÀRIOS mecanismos dependem de que cada symbol :main_log, :trn_log etc. refira-se
	# a apenas um arquivo específico. Arquivos são, por exemplo, copiados por 
	# método "split_trns" com base nisso.
	#
	#   SIMPLIFICACAO DE SOLUCAO:
	#      a) Mecanismos de cópia/move checar se "class" é "Array". Se for "Array", 
	#   copia cada um dos elementos. Se for String, copia 1.
	#         
	#      b) Mecanismos que fazem leitura (reprocessamento, por enquanto) só podem
	#  abrir um arquivo (lidam sempre com arquivo bem específico). Se algum mecanismo,
	# inadvertidamente, pegar Arrqy, pode e deve dar erro, o que alertará para que
	# equipe do desenvolvimento da automação corrija a lógica.
	#                     OBS: reprocessamento (método: deve_reprocessar) e código
	#                  relacionado, em 2017Set26, nem mesmo abrem arquivos: apenas checam
	#                  :steps. Mas isso pode mudar, pode haver futura interpretação
	#                  de algum LOG , JSON ou whatever!!!!!!!!! 
	#
	#      c) QUE SORTE! Marca TMQ é sempre a última marca. Isso vai facilitar, E MUITO!,
	# a filtragem dos arquivos.
	#          c.1) Arquivos que dependem de TMQ para diferenciação:
	#                 --> :trn_log
	#                 --> :main_log
	#                 --<    SÒ OS DOIS MESMO ! Afinal, uma feature é processada´, 
	#                     cada TRN, em apenas uma máquina (TMQ), pela própria natureza
	#                     do mecamismo de SPLIT.
	#                        Como os outros arquivos baseim-se no nome da feature,
	#                     nao nos darão problemas.  
    #      d) procura_mascaras_em_subdirs() terá novo código pra gerar Array se tiver
    #          mais que um resultado em Dir´[ ou Dir.glob()]
	#
	#      d) Existem trechos aqui tbm (leitura de json/step, massa) que dependem
	#      de que symbols especificos retornem apenas um arquivo. SEM CRISE< nao
	#      houve quebra de comportamento que invalide esses trechos de código!



	reports_masks[:tmq_log]           = "Log_TMQ*.log" #potencialmente, varios arquivos
	reports_masks[:trn_tmq_log]       = "Log_#{marca_trn}_TMQ*.log"  #potencialmente, varios arquivos
	reports_masks[:trn_tpn_tmq_log]   = "Log_#{marca_trn}_TPN*_TMQ*.log"  #potencialmente, varios arquivos


	reports_masks[:tfc_screenshot]     = "#{marca_trn}/scrshot_#{marca_trn}_*#{feature_name}*/*.tfc.png"
	reports_masks[:png_screenshot]     = "#{marca_trn}/scrshot_#{marca_trn}_*#{feature_name}*/*.browser.png"
	reports_masks[:desktop_screenshot] = "#{marca_trn}/scrshot_#{marca_trn}_*#{feature_name}*/*.desktop.png" 
	reports_masks[:desktoptfc_screenshot] = "#{marca_trn}/scrshot_#{marca_trn}_*#{feature_name}*/*.desktoptfc.png" 
		#2017Nov19 GUID SUFIX, adicionado caracter [*] depois de #{feature_name}

	reports_masks[:html_screenshot]    = "#{marca_trn}/scrshot_#{marca_trn}_*#{feature_name}*_*.html"
	reports_masks[:featnametfc_log]       = "#{marca_trn}/Tfc_#{marca_trn}_*#{feature_name}*.log"
	reports_masks[:featname_log]       = "#{marca_trn}/Log_#{marca_trn}_*#{feature_name}*.log"
	#2017Nov19 GUID SUFIX, adicionado caracter [*] depois de #{feature_name}
    #2017Set6 = :trn_log renomeado pra :featname_log - 

	procura_mascaras_em_subdirs('reports', reports_masks, retval)

	tpn_tsq_tmq=nil
	#write_rsi_log :debug, "retval[:featname_log]=#{retval[:featname_log]}"
	
	feature_mask = "#{feature_name}*.#{marca_trn}_*.feature"
	#2017Nov19 GUID SUFIX, adicionado caracter [*] depois de #{feature_name}
	procura_mascaras_em_subdirs(feat_dir, {:feature => feature_mask},  retval)

	if retval[:feature] 
		#2017Sep6 am - usar :feature de subdir em vez de featname_log, pois em casos de
		#TERMINAR.LCK, o arquivo :featname_log nem é criado, pra de lá obter sequenciais!
		#
		# Nao haver o arquivo *.feature correspondente À PRÒPRIA FEATURE ... tende
		# a ser impossível, se não 100% impossível.
		#
		##
		write_rsi_log "retval==#{retval}"
		### nao busco mais as bizarras aspas que tem em :featname_log, mas que em :feature 
		write_rsi_log "retval[:feature]=#{retval[:feature]}"
		tpn_tsq_resto = retval[:feature].split("_TPN")[1] #before 2017Sep6="_'TPN"

			###### HMMMM, esses nomes de arquivo estão me complicando.
			#   TODO 2017Sep6 am - REFINAR E SIMPLIFICAR!
			# 
			###

		##
		##
		##		

		tpn = tpn_tsq_resto.split('_')[0]
		#puts "tpn=#{tpn}"
		tmq = nil
		tsq = nil

		marca_last='TSQ'
		### 2017Sep6 am - JA HA MUITAS SEMANAS nos SEMPRE TEMOS TMQ !!!
		marca_last='TMQ'
		tsq = tpn_tsq_resto.split('_')[1]
		
		tmq = tpn_tsq_resto.split(marca_last)[1].split('.')[0]

		tpn_tsq_tmq="TPN#{tpn}_#{tsq}"
		tpn_tsq_tmq = tpn_tsq_tmq + "_TMQ#{tmq}" ####if marca_last=='TMQ' 

		#write_rsi_log "TMQ ENHANCING - get_output_filenames_da_feature_em_trn(bla,#{feature_name}, #{trn}) - tpn_tsq_tmq=#{tpn_tsq_tmq} "

		reports_masks[:log_sequencial] = "#{marca_trn}/Log_#{marca_trn}_'#{tpn_tsq_tmq}' .log"
		reports_masks[:html_report] = "#{marca_trn}/Report_#{marca_trn}_#{tpn_tsq_tmq}*_*#{feature_name}*.html"
		

		#reports_masks[:json_report] = "#{marca_trn}/Report_#{marca_trn}_#{tpn_tsq_tmq}*.json" #2017Nov19 e 20 - agora, featurename alphanum com sufixo em fim de html e json! COOL!
		reports_masks[:json_report] = "#{marca_trn}/Report_#{marca_trn}_*#{feature_name}*.json" 

	end

	procura_mascaras_em_subdirs("#{autdir}/reports", reports_masks, retval)

	
    #
    #2017Set6 arrumei, só pegava :arquivo_massa se not opcoes[:apenas_nomes_de_arquivos]
	#
	mask_arq_massa_trn="V #{feature_name}*.massa_#{marca_trn}_#{tpn_tsq_tmq}.xls"
	#2017Nov19 GUID SUFIX, adicionado caracter [*] depois de #{feature_name}
	#write_rsi_log :debug, "mask_arq_massa_trn=#{mask_arq_massa_trn}"
	procura_mascaras_em_subdirs(feat_dir, {:arquivo_massa => mask_arq_massa_trn},  retval)
	#write_rsi_log :debug, "retval[:arquivo_massa]=#{retval[:arquivo_massa]}"
	


	if opcoes[:apenas_nomes_de_arquivos] != true
		#write_rsi_log :debug, 'XLS - ainda nao implementado. JSON x STEPS - recem-implementado'

		json_file=retval[:json_report]
		retval[:steps] = parse_cucumber_json_steps(json_file)

	end


	get_lista_symbols_arquivos_output.each {|k|
		retval[k] = retval[k] || "arquivo nao encontrado - #{reports_masks[k]}" if not retval[k]# evita nil
	}
	#write_rsi_log :debug, "get_hash_de_report_filenames_da_feature_em_trn(#{feature_name},#{trn}): retval[:feature]=#{retval[:feature]}"

	if opcoes[:apenas_nomes_de_arquivos] != true
		retval[:massa]=Hash.new
		if File.file? retval[:arquivo_massa]
			retval[:massa] = ler_xls_com_id(retval[:arquivo_massa])
		end
		write_rsi_log :debug, "retval[:massa]=#{retval[:massa]}"
	end

	return retval
end

def get_raw_feature_name_from_feature_file(fn)
	return fnraw(get_feature_name_from_feature_file(fn))
end


def fnraw(fn)
	return fn.split('_')[0]
end


def renomeia_featurefile_e_massa_poe_sufixo(feature_filepath)
#
# CHAMADA POR: consumidor_feature.rb, no momento de retirar feature
# da fa lista em espera e colocar pra executar.
#


#
# Será que renomear no mesmo dir, por milissegundos existindo lá com
# nome "inválido", pode gerar efeitos colaterais?



#
#
# DEBU NOTES 2017Nov19 22:41 - pronto pra testar até CONSOPLIDA, sem
# reprocessamento
#
#    NA hora de reprocessar, vai precisar tbm talvez de novas manutencoes
# com FEATURE_NAME: RAW versus COM_SUFIXO !!!! gerador_massa,reproc etc.
#



	#
	#2017Nov19 - caracter sublinha/underline '_' usado como separador!
	# NAO pode existir em nenhum lugar da feature_name de feature_filepath
	#
	#
	sufixo= ("ts#{Time.now.strftime('%m%d-%H%M%S')}mq#{get_machine_id[-4..-1]}")
	if sufixo.include? '_'
		falhar "ERRO - metodo renomeia_featurefile_e_massa_poe_sufixo tem variavel sufixo invalida (#{sufixo}, contendo em si mesma o separador de sufixo '_' !!! " 
	end

	feature_name = get_feature_name_from_feature_file(feature_filepath)
	write_rsi_log :debug, "renomeia_featurefile_e_massa_poe_sufixo, feature_filepath=#{feature_filepath}, feature_name=#{feature_name}"
	if feature_name.include? '_'
		falhar "ERRO - metodo renomeia_featurefile_e_massa_poe_sufixo recebeu parametro feature_filepath=#{feature_filepath}, cuja feature_name=#{feature_name} tem separador de sufixo '_' !!!"
	end

	new_tmp_path  = feature_filepath.gsub(feature_name, obtem_guid).gsub(".feature",".tmpfeat")
	write_rsi_log :debug, "renomeia_featurefile_e_massa_poe_sufixo, feature_filepath=#{feature_filepath}, new_tmp_path=#{new_tmp_path}"

	e=nil
	begin
		FileUtils.mv feature_filepath, new_tmp_path
	rescue Errno::ENOENT => enoent
		e=enoent
	rescue Errno::EACCES => eacces
		e=eacces
	end

	if e
		write_rsi_log :warn, "Erro #{e} ao renomear feature_filepath=#{feature_filepath} para new_tmp_path=#{new_tmp_path}, e=#{e}...  deve tratar-se de arquivo de feature movido por outro processo, o que eh esperado e possivel em raras ocasicoes"
		return nil
	end



	#
	# sufixo - permite report consolidado de execucoes de mesma feature
	# em processos independentes e que nao tenham sido preparados.
	#
	#  Em casos , frequentes, em que tentamos múltiplas vezes executar   
	# automacao, poderemos ver uma dada feature falhando algumas vezes
	# e tendo sucesso em outras, mudando a falha/resultado etc.
	# 
	#  Na criação deste conceito, em 2017Nov19, ainda nao somos capazes
	# 
	#Ex sufixo: "TS1119-213317_MQAD-11"	

	massadir_path = "#{get_automdir}/massas_feature/V #{feature_name}"
	new_name = "#{feature_name}_#{sufixo}"


	new_path_feat  = feature_filepath.gsub(feature_name, new_name)
	new_path_massa = massadir_path   .gsub(feature_name, new_name)

	write_rsi_log :debug, "renomeia_featurefile_e_massa_poe_sufixo, feature_filepath=#{feature_filepath}, new_tmp_path=#{new_tmp_path}, new_path_feat=#{new_path_feat} ------------- massadir_path=#{massadir_path}, new_path_massa=#{new_path_massa}"

	e_onde = nil
	e=nil
	begin
		e_onde = 'feature'
		FileUtils.mv new_tmp_path, new_path_feat
		e_onde='massa'
		FileUtils.mv massadir_path   , new_path_massa
	rescue Errno::ENOENT => enoent
		e=enoent
	rescue Errno::EACCES => eacces
		e=eacces
	end

	if e
		falhar "Erro #{e} ao renomear new_tmp_path=#{new_tmp_path} para new_path_feat=#{new_path_feat} (original name feature_filepath=#{feature_filepath}), ou ao renomear massadir_path=#{massadir_path} para new_path_massa=#{new_path_massa}, e_onde=#{e_onde}... Neste ponto, isto significa ERRO , ou em codigo, ou em ambiente/filesystem"
	end

	# AGORA, troca string de nome de cenário DENTRO de feature file
	orig_content= File.open(new_path_feat,'r:utf-8') { |f| f.read} #File.read(fname,:encoding=>'utf-8' nao funciona! mas read de instance funciona!)
	write_rsi_log "orig_content=#{orig_content}"
	write_rsi_log "orig_content.encode('UTF-8')=#{orig_content.encode('UTF-8')}"

	#write_rsi_log "feature_name.encoding=#{feature_name.encoding}"
	#puts feature_name
	#puts feature_name.encode('UTF-8')
	#write_rsi_log "new_name.encoding=#{new_name.encoding}"
	#puts new_name
	#puts new_name.encode('UTF-8')

	new_content = orig_content.encode('utf-8').gsub(feature_name.encode('utf-8'), new_name.encode('utf-8'))
	write_rsi_log "new_content.encoding=#{new_content.encoding}"
	write_rsi_log "new_content=#{new_content}"


	File.open(new_path_feat,'w') {|h| h.write(new_content)}
	modified_content= File.open(new_path_feat,'r:utf-8') { |f| f.read}
	write_rsi_log "modified_content=#{modified_content}"
	write_rsi_log "modified_content.encode('UTF-8')=#{modified_content.encode('UTF-8')}"
##################################	#File.open(local_filename, 'w') {|f| f.write(doc) }
#	fail 'LEIAME'

	return new_path_feat
end

def split_cpfs_naoqueimados(cpfs, q)
=begin
#   2017Nov26
#
# (este método deveria estar em risco_cpfs.rb, mas devido à primitiva estrutura 
#  de fonftes da aplicação de automação, precisa estar em em shared_utils.rb
#  para que shared_utils.rb nao dependa/requeira risco_cpfs.rb cicularmente)
#
#   Retorna array de Hashs de cpfs divivida em "q" partes, com TIPO_CRÈDITO 
# [Crédito, Débito e Crédito Adormecido] distribuídos igualmente qm cada uma
# das "q" partes.
#
#    Somente cpfs nao-queimados sao retornados [PROCESSADO DIFERENTE de '1']
#
# DISTIBUIÇÂO: para cada parte "de 1 a q", tenta colocar cpfs dos 3 tipos 
# de crédito. Partes do fim da distribuicao podem ter menos elementos.
#
#
#   TIPO DE DADO DO RETORNO: Array[q], cada elemento contém um Array de Hash
=end

	rcpfs=cpfs.clone #opera sobre cópia/clone, não adulterando parâmetro
	t=Array.new(q)
	t.each_index{|i| t[i]=Array.new}
	rcpfs.select{|e|e['PROCESSADO'].to_i!=1}.shuffle #embraralha cpfs nao queimados

	cr=['Múltiplo', 'Débito', 'Crédito Adormecido']
	a=Array.new(cr.length)
	cr.each_index{    |i| a[i]=rcpfs.select{  |e|e['TIPO_CREDITO']==cr[i]  }    }

	while a[0].length+a[1].length+a[2].length > 0 do
		cr.length.times do |j|
			t.length.times do |k| 
		 		t[k] << a[j].pop if a[j].length > 0
		 	end
		end
	end
	return t
end
