def gerar_cpf (valido, fixa_ultimo_digito = 0, digito = 1)

	@CPF = Array.new()

	valido == 0 ? multiplicador = 10 : multiplicador = 11

	
	(0..7).each do |i|
		@CPF[i]  = rand(10)
		@CPF[9]  = (@CPF[i].to_i * (multiplicador - i))     + @CPF[9].to_i
		@CPF[10] = (@CPF[i].to_i * (multiplicador + 1 - i)) + @CPF[10].to_i
	end
	
	if fixa_ultimo_digito == 0
		@CPF[8] = digito
	else
		@CPF[8] = rand(10)
	end

	@CPF[9] = (@CPF[8].to_i * 2) + @CPF[9].to_i
	@CPF[9] = 11 - (@CPF[9].to_i % 11)

		if @CPF[9] > 9 then @CPF[9] = 0 end

		@CPF[10] = @CPF[10].to_i + (@CPF[9].to_i * 2) + (@CPF[8].to_i * 3)
		@CPF[10] = 11 - (@CPF[10].to_i % 11)

		if (@CPF[10] > 9) then @CPF[10] = 0 end
			
	return @CPF.join
end	

def gerar_arquivo_cpf (cpfs, valido = 0, fixa_ultimo_digito = 0, digito = 1, arquivo ="cpfs")
		# valido = 0 => válidos
		# valido = 1 => inválidos
		# valido = 2 => sortidos

		# fixa_ultimo_digito = 0 => fixo
		# fixa_ultimo_digito = 1 => aleatório

		tempo = Time.now
		case valido
			when 0
				flag = "v"
			when 1
				flag = "i"
			when 2
				flag = "s"
		end	
		@arquivo = File.new("./txt/#{arquivo}#{cpfs}_#{flag}_#{tempo.strftime("%Y")}#{tempo.strftime("%m")}#{tempo.strftime("%d")}_#{tempo.strftime("%H%M%S")}.txt","w")
		
		if valido == 0 || valido == 1
		   (0..cpfs-1).each do |i|
		   	 @arquivo.puts gerar_cpf valido, fixa_ultimo_digito, digito
            end
        end

		if valido == 2 && cpfs == 1
		   valido = rand(2)
		   (0..cpfs-1).each do |i|
		   	 @arquivo.puts gerar_cpf valido, fixa_ultimo_digito, digito
            end
        end

		if valido == 2 && cpfs > 1
		   case (cpfs % 2)
		      when 0
		      	valido = 0
		        (0..cpfs/2-1).each do |i|
		   	       @arquivo.puts gerar_cpf valido, fixa_ultimo_digito, digito
                end

		      	valido = 1
		        (0..cpfs/2-1).each do |i|
		   	       @arquivo.puts gerar_cpf valido, fixa_ultimo_digito, digito		   	       
		   	    end  

		   	  else
		   	    valido = 0
		        (0..cpfs/2).each do |i|
		   	       @arquivo.puts gerar_cpf valido, fixa_ultimo_digito, digito
				end  
				valido = 1
		        (0..(cpfs-1)/2-1).each do |i|
		   	       @arquivo.puts gerar_cpf valido, fixa_ultimo_digito, digito
			    end   
            end
        end
		@arquivo.close
end